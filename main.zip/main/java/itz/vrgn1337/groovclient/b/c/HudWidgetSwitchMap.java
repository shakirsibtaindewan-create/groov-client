/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.b.c;

import itz.vrgn1337.groovclient.b.c.HudWidget;

class HudWidgetSwitchMap {
    static final int[] a = new int[HudWidget.values().length];

    static {
        try {
            HudWidgetSwitchMap.a[HudWidget.CLOCK.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.FPS.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.PING.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.USERNAME.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.TARGET_HUD.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.MODULE_LIST.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.POTIONS.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.KEYBINDS.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.KEYSTROKES.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.INVENTORY.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.ARMOR.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.COMPASS.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.RADAR.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HudWidgetSwitchMap.a[HudWidget.REACH.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

