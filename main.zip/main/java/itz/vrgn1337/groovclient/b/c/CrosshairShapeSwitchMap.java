/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.b.c;

import itz.vrgn1337.groovclient.gui.hud.CrosshairShape;

class CrosshairShapeSwitchMap {
    static final int[] a = new int[CrosshairShape.values().length];

    static {
        try {
            CrosshairShapeSwitchMap.a[CrosshairShape.CROSS.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            CrosshairShapeSwitchMap.a[CrosshairShape.T_SHAPE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            CrosshairShapeSwitchMap.a[CrosshairShape.BRACKET.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            CrosshairShapeSwitchMap.a[CrosshairShape.SQUARE.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            CrosshairShapeSwitchMap.a[CrosshairShape.DOT.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            CrosshairShapeSwitchMap.a[CrosshairShape.CIRCLE.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            CrosshairShapeSwitchMap.a[CrosshairShape.X_SHAPE.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

