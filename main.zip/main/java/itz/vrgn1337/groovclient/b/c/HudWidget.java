/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.b.c;

public enum HudWidget {
    CLOCK("Clock", 140.0f, 28.0f), FPS("FPS", 60.0f, 26.0f), PING("Ping", 60.0f, 26.0f), USERNAME("Username", 90.0f, 26.0f), TARGET_HUD("Target HUD", 140.0f, 50.0f), MODULE_LIST("Module List", 110.0f, 0.0f), POTIONS("Potions", 130.0f, 0.0f), KEYBINDS("Keybinds", 120.0f, 0.0f), KEYSTROKES("Keystrokes", 76.0f, 86.0f), INVENTORY("Inventory", 0.0f, 0.0f), ARMOR("Armor", 80.0f, 22.0f), COMPASS("Compass", 200.0f, 24.0f), RADAR("Radar", 90.0f, 90.0f), REACH("Length (vibecodedev was here)", 80.0f, 26.0f);
    public final String displayName;
    public final float defaultW;
    public final float defaultH;

    private HudWidget(String displayName, float defaultW, float defaultH) {
        this.displayName = (String)displayName;
        this.defaultW = defaultW;
        this.defaultH = defaultH;

    }

}

