/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.b.c;

import itz.vrgn1337.groovclient.api.util.SoundManager;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.b.c.CrosshairShapeSwitchMap;
import itz.vrgn1337.groovclient.b.c.HudElementSettings;
import itz.vrgn1337.groovclient.b.c.HudManager;
import itz.vrgn1337.groovclient.b.c.HudRenderMode;
import itz.vrgn1337.groovclient.b.c.HudWidget;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.hud.CrosshairConfig;
import itz.vrgn1337.groovclient.gui.hud.CrosshairShape;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudConfigRegistry;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudElementSettings;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudSection;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import java.awt.Color;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;

public class HudEditorScreen
extends Screen {
    private static final HudEditorScreen a = new HudEditorScreen();
    private HudRenderMode b = HudRenderMode.GROOV;
    private static final float c = 20.0f;
    private static final float d = 8.0f;
    private static final Color e = new Color(255, 255, 255, 15);
    private static final Color f = new Color(100, 200, 255, 60);
    private HudElementSettings g = null;
    private float h;
    private float i;
    private VanillaHudElementSettings j = null;
    private float k;
    private float l;
    private VanillaHudElementSettings m = null;
    private boolean n = false;
    private boolean o = false;
    private float p;
    private float q;
    private boolean r = false;
    private float s;
    private float t;
    private HudElementSettings u = null;
    private boolean v = false;
    private float w;
    private float x;
    private HudElementSettings y = null;
    private boolean z = false;
    private float A;
    private float B;
    private HudElementSettings C = null;
    private boolean D = false;
    private static final String E = "hud.editor.open";
    private boolean F = false;
    private boolean G = false;
    private static final String[][] H = new String[][]{{"rainbow", "Rainbow"}, {"lowercase", "Lowercase"}, {"sidebar", "Sidebar"}, {"background", "Background"}, {"bg_blur", "Blur"}, {"glass", "Glass"}, {"animation", "Animation"}, {"rounded", "Rounded"}, {"detail", "Detail"}, {"blink", "Blink"}, {"text_glow", "Text Glow"}, {"outline", "Outline"}, {"outline_glow", "Glow"}, {"outline_bloom", "Bloom"}, {"outline_shadow", "Shadow"}};
    private static final String[][] I = new String[][]{{"show_plan", "Show Plan"}, {"glass", "Glass"}};
    private static final String[][] J = new String[][]{{"glass", "Glass"}};
    private static final String[][] K = new String[][]{{"enabled", "Replace Vanilla"}, {"animation", "Animation"}};
    private float L;
    private float M;
    private static final float N = 140.0f;
    private static final float O = 230.0f;
    private static final float P = 360.0f;

    public static HudEditorScreen getInstance() {
        return a;
    }

    protected HudEditorScreen() {
        super((Text)Text.empty());
    }

    public boolean keyPressed(KeyInput mc27) {
        if (mc27.key() == 256) {
            if (this.n) {
                this.n = false;
                return true;
            }
            if (this.m != null) {
                this.m = null;
                return true;
            }
            if (this.z) {
                this.z = false;
                this.C = null;
                return true;
            }
            if (this.v) {
                this.v = false;
                this.y = null;
                return true;
            }
            if (this.r) {
                this.r = false;
                this.u = null;
                return true;
            }
            if (this.o) {
                this.o = false;
                return true;
            }
            this.D = true;
            return true;
        }
        if (mc27.key() == 258) {
            this.b = this.b == HudRenderMode.GROOV ? HudRenderMode.VANILLA : HudRenderMode.GROOV;
            this.g = null;
            this.j = null;
            SoundManager.b();
            return true;
        }
        if (mc27.key() == 261 && this.g == null && this.b == HudRenderMode.GROOV) {
            HudElementSettings hudElementSettings = this.c();
            if (hudElementSettings != null) {
                HudManager.getInstance().b(hudElementSettings);
            }
            return true;
        }
        return super.keyPressed(mc27);
    }

    protected void applyBlur(DrawContext mc15) {
    }

    public void render(DrawContext mc15, int n2, int n3, float f2) {
        MatrixStack mc13 = new MatrixStack();
        float f3 = GuiRenderer.a(E, this.D ? 0.0f : 1.0f, 0.06f);
        if (this.D && f3 <= 0.01f) {
            this.D = false;
            GuiRenderer.b(E);
            Main.mc.setScreen(null);
            return;
        }
        float f4 = RenderScale.c();
        float f5 = RenderScale.d();
        new PanelRenderer(mc13, 0.0f, 0.0f, f4, f5).a(GuiRenderer.a(new Color(0, 0, 0), (int)(80.0f * f3))).j();
        this.a(mc13, f4, f5, f3);
        float f6 = (float)RenderScale.j();
        float f7 = (float)RenderScale.k();
        if (this.b == HudRenderMode.GROOV) {
            this.i(f6, f7);
            this.h(f6, f7);
            this.a(mc13, f3, n2, n3, f4, f5);
        }
        this.a(mc13, f4, f3);
    }

    private void a(MatrixStack mc13, float f2, int n2, int n3, float f3, float f4) {
        for (HudElementSettings hudElementSettings : HudManager.getInstance().c()) {
            HudManager.getInstance().a(mc13, hudElementSettings, true);
            this.a(mc13, hudElementSettings, f2, n2, n3);
        }
        if (this.g != null) {
            this.getInstance(mc13, this.g, f3, f4, f2);
        }
        if (this.o) {
            this.getInstance(mc13, f2);
        }
        if (this.r) {
            this.b(mc13, f2);
        }
        if (this.v) {
            this.c(mc13, f2);
        }
        if (this.z) {
            this.d(mc13, f2);
        }
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4) {
        float f5;
        int n2 = (int)((float)e.getAlpha() * f4);
        Color color = GuiRenderer.a(e, n2);
        for (f5 = 0.0f; f5 < f2; f5 += 20.0f) {
            new PanelRenderer(mc13, f5, 0.0f, 0.5f, f3).a(color).j();
        }
        for (f5 = 0.0f; f5 < f3; f5 += 20.0f) {
            new PanelRenderer(mc13, 0.0f, f5, f2, 0.5f).a(color).j();
        }
        Color color2 = GuiRenderer.a(f, (int)((float)f.getAlpha() * f4));
        new PanelRenderer(mc13, f2 * 0.5f - 0.25f, 0.0f, 0.5f, f3).a(color2).j();
        new PanelRenderer(mc13, 0.0f, f3 * 0.5f - 0.25f, f2, 0.5f).a(color2).j();
    }

    private void a(MatrixStack mc13, HudElementSettings hudElementSettings, float f2, int n2, int n3) {
        float f3 = hudElementSettings.b();
        float f4 = hudElementSettings.c();
        float f5 = hudElementSettings.d();
        float f6 = hudElementSettings.e();
        if (f5 <= 0.0f || f6 <= 0.0f) {
            return;
        }
        boolean bl = (float)n2 >= f3 && (float)n2 <= f3 + f5 && (float)n3 >= f4 && (float)n3 <= f4 + f6;
        boolean bl2 = hudElementSettings == this.g;
        Color color = MenuGuiScreen.c();
        float f7 = GuiRenderer.a("hud.frame." + hudElementSettings.a().name(), bl || bl2 ? 1.0f : 0.0f, 0.1f);
        int n4 = (int)((30.0f + 50.0f * f7) * f2);
        Color color2 = GuiRenderer.a(color, n4);
        GuiRenderer.a(mc13, f3, f4, f5, f6, 1.0f, 4.0f, color2);
        if (f7 > 0.1f) {
            float f8 = 6.0f;
            StringConstant stringConstant = new StringConstant(hudElementSettings.a().displayName);
            float f9 = FontManager.a().a(stringConstant, f8);
            float f10 = f3 + (f5 - f9) * 0.5f;
            float f11 = f4 - FontManager.a().b(f8) - 3.0f;
            FontManager.a().a(mc13, stringConstant, f10, f11, f8, GuiRenderer.a(Color.WHITE, (int)(200.0f * f7 * f2)));
        }
    }

    private void a(MatrixStack mc13, HudElementSettings hudElementSettings, float f2, float f3, float f4) {
        float f5 = hudElementSettings.b() + hudElementSettings.d() * 0.5f;
        float f6 = hudElementSettings.c() + hudElementSettings.e() * 0.5f;
        int n2 = (int)((float)f.getAlpha() * f4);
        Color color = GuiRenderer.a(MenuGuiScreen.c(), n2);
        if (Math.abs(f5 - f2 * 0.5f) < 8.0f) {
            new PanelRenderer(mc13, f2 * 0.5f - 0.25f, 0.0f, 0.5f, f3).a(color).j();
        }
        if (Math.abs(f6 - f3 * 0.5f) < 8.0f) {
            new PanelRenderer(mc13, 0.0f, f3 * 0.5f - 0.25f, f2, 0.5f).a(color).j();
        }
        for (HudElementSettings hudElementSettings2 : HudManager.getInstance().c()) {
            float f7;
            float f8;
            if (hudElementSettings2 == hudElementSettings || hudElementSettings2.d() <= 0.0f) continue;
            if (Math.abs(hudElementSettings.b() - hudElementSettings2.b()) < 8.0f) {
                f8 = Math.min(hudElementSettings.c(), hudElementSettings2.c());
                f7 = Math.max(hudElementSettings.c() + hudElementSettings.e(), hudElementSettings2.c() + hudElementSettings2.e());
                new PanelRenderer(mc13, hudElementSettings2.b() - 0.25f, f8, 0.5f, f7 - f8).a(color).j();
            }
            if (!(Math.abs((f8 = hudElementSettings.b() + hudElementSettings.d()) - (f7 = hudElementSettings2.b() + hudElementSettings2.d())) < 8.0f)) continue;
            float f9 = Math.min(hudElementSettings.c(), hudElementSettings2.c());
            float f10 = Math.max(hudElementSettings.c() + hudElementSettings.e(), hudElementSettings2.c() + hudElementSettings2.e());
            new PanelRenderer(mc13, f7 - 0.25f, f9, 0.5f, f10 - f9).a(color).j();
        }
    }

    private void a(MatrixStack mc13, float f2, float f3) {
        float f4;
        float f5 = 110.0f;
        float f6 = 22.0f;
        float f7 = f6 / 2.0f;
        int n2 = (int)(220.0f * f3);
        HudRenderMode[] hudRenderModeArray = HudRenderMode.values();
        float f8 = 100.0f;
        float f9 = 6.0f;
        float f10 = f5 + f9 + (float)hudRenderModeArray.length * f8 + (float)(hudRenderModeArray.length - 1) * 2.0f;
        float f11 = (f2 - f10) * 0.5f;
        float f12 = 6.0f;
        new PanelRenderer(mc13, f11, f12, f5, f6).a(GuiRenderer.a(new Color(14, 14, 14), n2)).a(14.0f, 1.0f).a(f7).j();
        StringConstant stringConstant = new StringConstant("HUD Editor");
        float f13 = 8.0f;
        float f14 = FontManager.a().a(stringConstant, f13);
        FontManager.a().a(mc13, stringConstant, f11 + (f5 - f14) * 0.5f, f12 + f6 * 0.5f - FontManager.a().b(f13) * 0.5f, f13, GuiRenderer.a(Color.WHITE, (int)(240.0f * f3)));
        Color color = MenuGuiScreen.c();
        float f15 = f11 + f5 + f9;
        for (int i2 = 0; i2 < hudRenderModeArray.length; ++i2) {
            f4 = f15 + (float)i2 * (f8 + 2.0f);
            HudRenderMode hudRenderMode = hudRenderModeArray[i2];
            boolean bl = hudRenderMode == this.b;
            float f16 = GuiRenderer.a("hud.tab." + hudRenderMode.name(), bl ? 1.0f : 0.0f, 0.1f);
            Color color2 = GuiRenderer.a(GuiRenderer.a(new Color(14, 14, 14), n2), GuiRenderer.a(color, n2), f16 * 0.85f);
            new PanelRenderer(mc13, f4, f12, f8, f6).a(color2).a(14.0f, 1.0f).a(f7).j();
            StringConstant stringConstant2 = new StringConstant(hudRenderMode.displayName);
            float f17 = FontManager.a().a(stringConstant2, f13);
            Color color3 = GuiRenderer.a(GuiRenderer.a(new Color(180, 180, 180), Color.WHITE, f16), (int)(255.0f * f3));
            FontManager.a().a(mc13, stringConstant2, f4 + (f8 - f17) * 0.5f, f12 + f6 * 0.5f - FontManager.a().b(f13) * 0.5f, f13, color3);
            if (!(f3 > 0.9f)) continue;
            new PanelRenderer(mc13, f4, f12, f8, f6).a(new Color(0, 0, 0, 0)).j().a(0, () -> ((HudEditorScreen)this).lambda$drawTitleBar$0((HudRenderMode)hudRenderMode));
        }
        if (this.b == HudRenderMode.VANILLA) {
            StringConstant stringConstant3 = new StringConstant("Drag elements \u00b7 Right-click for options \u00b7 Click Crosshair to edit");
            f4 = FontManager.a().a(stringConstant3, 6.5f);
            FontManager.a().a(mc13, stringConstant3, (f2 - f4) * 0.5f, f12 + f6 + 4.0f, 6.5f, GuiRenderer.a(new Color(160, 160, 160), (int)(200.0f * f3)));
        }
    }

    private void a(MatrixStack mc13, float f2) {
        float f3 = GuiRenderer.a("hud.editor.popup", this.o ? 1.0f : 0.0f, 0.06f);
        float f4 = GuiRenderer.g(f3);
        if (f3 < 0.01f) {
            this.o = false;
            return;
        }
        HudWidget[] hudWidgetArray = HudWidget.values();
        float f5 = 22.0f;
        float f6 = 6.0f;
        float f7 = 120.0f;
        float f8 = f6 * 2.0f + (float)hudWidgetArray.length * f5;
        float f9 = 8.0f;
        float f10 = f4;
        float f11 = this.p;
        float f12 = this.q;
        float f13 = f7 * f10;
        float f14 = f8 * f10;
        if (f11 + f13 > RenderScale.c()) {
            f11 = RenderScale.c() - f13 - 4.0f;
        }
        if (f12 + f14 > RenderScale.d()) {
            f12 = RenderScale.d() - f14 - 4.0f;
        }
        int n2 = (int)(230.0f * f3 * f2);
        float f15 = 5.0f;
        new PanelRenderer(mc13, this.p - f15 * 0.5f, this.q - f15 * 0.5f, f15, f15).a(GuiRenderer.a(new Color(18, 18, 18), n2)).a(2.0f).j();
        new PanelRenderer(mc13, f11, f12, f13, f14).a(GuiRenderer.a(new Color(18, 18, 18), n2)).a(16.0f, 1.0f).a(f9 * f10).j();
        if (f3 < 0.4f) {
            return;
        }
        float f16 = GuiRenderer.b((f3 - 0.3f) / 0.7f, 0.0f, 1.0f) * f2;
        Color color = MenuGuiScreen.c();
        float f17 = 7.0f;
        for (int i2 = 0; i2 < hudWidgetArray.length; ++i2) {
            HudWidget hudWidget = hudWidgetArray[i2];
            float f18 = f11 + f6 * f10;
            float f19 = f12 + (f6 + (float)i2 * f5) * f10;
            float f20 = (f7 - f6 * 2.0f) * f10;
            float f21 = f5 * f10;
            boolean bl = HudManager.getInstance().a(hudWidget);
            float f22 = GuiRenderer.a("hud.popup.item." + hudWidget.name(), this.a(f18, f19, f20, f21) ? 1.0f : 0.0f, 0.12f);
            int n3 = (int)(f16 * 255.0f);
            if (f22 > 0.05f && !bl) {
                new PanelRenderer(mc13, f18, f19, f20, f21).a(GuiRenderer.a(color, (int)(40.0f * f22 * f16))).a(4.0f * f10).j();
            }
            Color color2 = bl ? GuiRenderer.a(new Color(80, 80, 80), n3) : GuiRenderer.a(GuiRenderer.a(Color.WHITE, color, f22), n3);
            FontManager.a().a(mc13, new StringConstant(hudWidget.displayName), f18 + 4.0f * f10, f19 + f21 * 0.28f, f17 * f10, color2);
            if (!(f3 > 0.85f) || bl) continue;
            new PanelRenderer(mc13, f18, f19, f20, f21).a(new Color(0, 0, 0, 0)).j().a(0, () -> ((HudEditorScreen)this).lambda$drawAddPopup$1((HudWidget)hudWidget));
        }
    }

    private void b(MatrixStack mc13, float f2) {
        float f3 = GuiRenderer.a("hud.editor.mlpopup", this.r ? 1.0f : 0.0f, 0.06f);
        float f4 = GuiRenderer.g(f3);
        if (f3 < 0.01f) {
            this.r = false;
            this.u = null;
            return;
        }
        float f5 = 22.0f;
        float f6 = 6.0f;
        float f7 = 115.0f;
        float f8 = f6 * 2.0f + (float)H.length * f5;
        float f9 = 8.0f;
        float f10 = f4;
        float f11 = this.s;
        float f12 = this.t;
        float f13 = f7 * f10;
        float f14 = f8 * f10;
        if (f11 + f13 > RenderScale.c()) {
            f11 = RenderScale.c() - f13 - 4.0f;
        }
        if (f12 + f14 > RenderScale.d()) {
            f12 = RenderScale.d() - f14 - 4.0f;
        }
        int n2 = (int)(230.0f * f3 * f2);
        float f15 = 5.0f;
        new PanelRenderer(mc13, this.s - f15 * 0.5f, this.t - f15 * 0.5f, f15, f15).a(GuiRenderer.a(new Color(18, 18, 18), n2)).a(2.0f).j();
        new PanelRenderer(mc13, f11, f12, f13, f14).a(GuiRenderer.a(new Color(18, 18, 18), n2)).a(16.0f, 1.0f).a(f9 * f10).j();
        if (f3 < 0.4f) {
            return;
        }
        float f16 = GuiRenderer.b((f3 - 0.3f) / 0.7f, 0.0f, 1.0f) * f2;
        Color color = MenuGuiScreen.c();
        float f17 = 7.0f;
        float f18 = 8.0f * f10;
        boolean bl = this.u != null && this.u.a("outline");
        boolean bl2 = this.u != null && this.u.a("detail");
        for (int i2 = 0; i2 < H.length; ++i2) {
            String string = H[i2][0];
            String string2 = H[i2][1];
            boolean bl3 = this.u != null && this.u.a(string);
            boolean bl4 = !bl && (string.equals("outline_glow") || string.equals("outline_bloom") || string.equals("outline_shadow")) || !bl2 && string.equals("blink");
            float f19 = f11 + f6 * f10;
            float f20 = f12 + (f6 + (float)i2 * f5) * f10;
            float f21 = (f7 - f6 * 2.0f) * f10;
            float f22 = f5 * f10;
            float f23 = GuiRenderer.a("hud.mlpopup." + string, !bl4 && this.a(f19, f20, f21, f22) ? 1.0f : 0.0f, 0.12f);
            float f24 = bl4 ? 0.35f : 1.0f;
            int n3 = (int)(f16 * 255.0f * f24);
            if (f23 > 0.05f) {
                new PanelRenderer(mc13, f19, f20, f21, f22).a(GuiRenderer.a(color, (int)(30.0f * f23 * f16))).a(4.0f * f10).j();
            }
            float f25 = f19 + 4.0f * f10;
            float f26 = f20 + (f22 - f18) * 0.5f;
            float f27 = GuiRenderer.a("hud.mlpopup.tog." + string, bl3 && !bl4 ? 1.0f : 0.0f, 0.1f);
            Color color2 = GuiRenderer.a(GuiRenderer.a(new Color(60, 60, 60), n3), GuiRenderer.a(color, n3), f27);
            new PanelRenderer(mc13, f25, f26, f18, f18).a(color2).a(2.0f * f10).j();
            if (f27 > 0.1f) {
                GuiRenderer.a(mc13, "check", f25 + 1.0f * f10, f26 + 1.0f * f10, f18 - 2.0f * f10, f18 - 2.0f * f10, GuiRenderer.a(Color.WHITE, (int)(255.0f * f27 * f16 * f24)));
            }
            FontManager.a().a(mc13, new StringConstant(string2), f25 + f18 + 4.0f * f10, f20 + f22 * 0.28f, f17 * f10, GuiRenderer.a(Color.WHITE, n3));
            if (!(f3 > 0.85f) || this.u == null || bl4) continue;
            new PanelRenderer(mc13, f19, f20, f21, f22).a(new Color(0, 0, 0, 0)).j().a(0, () -> ((HudEditorScreen)this).lambda$drawMLSettingsPopup$2((String)string));
        }
    }

    private boolean a(float f2, float f3) {
        if (!this.r) {
            return false;
        }
        float f4 = 115.0f;
        float f5 = 12.0f + (float)H.length * 22.0f;
        float f6 = this.s;
        float f7 = this.t;
        if (f6 + f4 > RenderScale.c()) {
            f6 = RenderScale.c() - f4 - 4.0f;
        }
        if (f7 + f5 > RenderScale.d()) {
            f7 = RenderScale.d() - f5 - 4.0f;
        }
        return f2 >= f6 && f2 <= f6 + f4 && f3 >= f7 && f3 <= f7 + f5;
    }

    private void c(MatrixStack mc13, float f2) {
        float f3 = GuiRenderer.a("hud.editor.userpopup", this.v ? 1.0f : 0.0f, 0.06f);
        float f4 = GuiRenderer.g(f3);
        if (f3 < 0.01f) {
            this.v = false;
            this.y = null;
            return;
        }
        float f5 = 22.0f;
        float f6 = 6.0f;
        float f7 = 115.0f;
        float f8 = f6 * 2.0f + (float)I.length * f5;
        float f9 = 8.0f;
        float f10 = f4;
        float f11 = this.w;
        float f12 = this.x;
        float f13 = f7 * f10;
        float f14 = f8 * f10;
        if (f11 + f13 > RenderScale.c()) {
            f11 = RenderScale.c() - f13 - 4.0f;
        }
        if (f12 + f14 > RenderScale.d()) {
            f12 = RenderScale.d() - f14 - 4.0f;
        }
        int n2 = (int)(230.0f * f3 * f2);
        float f15 = 5.0f;
        new PanelRenderer(mc13, this.w - f15 * 0.5f, this.x - f15 * 0.5f, f15, f15).a(GuiRenderer.a(new Color(18, 18, 18), n2)).a(2.0f).j();
        new PanelRenderer(mc13, f11, f12, f13, f14).a(GuiRenderer.a(new Color(18, 18, 18), n2)).a(16.0f, 1.0f).a(f9 * f10).j();
        if (f3 < 0.4f) {
            return;
        }
        float f16 = GuiRenderer.b((f3 - 0.3f) / 0.7f, 0.0f, 1.0f) * f2;
        Color color = MenuGuiScreen.c();
        float f17 = 7.0f;
        float f18 = 8.0f * f10;
        for (int i2 = 0; i2 < I.length; ++i2) {
            String string = I[i2][0];
            String string2 = I[i2][1];
            boolean bl = this.y != null && (!this.y.f().containsKey(string) || this.y.a(string));
            float f19 = f11 + f6 * f10;
            float f20 = f12 + (f6 + (float)i2 * f5) * f10;
            float f21 = (f7 - f6 * 2.0f) * f10;
            float f22 = f5 * f10;
            float f23 = GuiRenderer.a("hud.userpopup." + string, this.a(f19, f20, f21, f22) ? 1.0f : 0.0f, 0.12f);
            int n3 = (int)(f16 * 255.0f);
            if (f23 > 0.05f) {
                new PanelRenderer(mc13, f19, f20, f21, f22).a(GuiRenderer.a(color, (int)(30.0f * f23 * f16))).a(4.0f * f10).j();
            }
            float f24 = f19 + 4.0f * f10;
            float f25 = f20 + (f22 - f18) * 0.5f;
            float f26 = GuiRenderer.a("hud.userpopup.tog." + string, bl ? 1.0f : 0.0f, 0.1f);
            Color color2 = GuiRenderer.a(GuiRenderer.a(new Color(60, 60, 60), n3), GuiRenderer.a(color, n3), f26);
            new PanelRenderer(mc13, f24, f25, f18, f18).a(color2).a(2.0f * f10).j();
            if (f26 > 0.1f) {
                GuiRenderer.a(mc13, "check", f24 + 1.0f * f10, f25 + 1.0f * f10, f18 - 2.0f * f10, f18 - 2.0f * f10, GuiRenderer.a(Color.WHITE, (int)(255.0f * f26 * f16)));
            }
            FontManager.a().a(mc13, new StringConstant(string2), f24 + f18 + 4.0f * f10, f20 + f22 * 0.28f, f17 * f10, GuiRenderer.a(Color.WHITE, n3));
            if (!(f3 > 0.85f) || this.y == null) continue;
            new PanelRenderer(mc13, f19, f20, f21, f22).a(new Color(0, 0, 0, 0)).j().a(0, () -> ((HudEditorScreen)this).lambda$drawUsernameSettingsPopup$3((String)string));
        }
    }

    private boolean b(float f2, float f3) {
        if (!this.v) {
            return false;
        }
        float f4 = 115.0f;
        float f5 = 12.0f + (float)I.length * 22.0f;
        float f6 = this.w;
        float f7 = this.x;
        if (f6 + f4 > RenderScale.c()) {
            f6 = RenderScale.c() - f4 - 4.0f;
        }
        if (f7 + f5 > RenderScale.d()) {
            f7 = RenderScale.d() - f5 - 4.0f;
        }
        return f2 >= f6 && f2 <= f6 + f4 && f3 >= f7 && f3 <= f7 + f5;
    }

    private void d(MatrixStack mc13, float f2) {
        float f3 = GuiRenderer.a("hud.editor.simplepopup", this.z ? 1.0f : 0.0f, 0.06f);
        float f4 = GuiRenderer.g(f3);
        if (f3 < 0.01f) {
            this.z = false;
            this.C = null;
            return;
        }
        float f5 = 22.0f;
        float f6 = 6.0f;
        float f7 = 115.0f;
        float f8 = f6 * 2.0f + (float)J.length * f5;
        float f9 = 8.0f;
        float f10 = f4;
        float f11 = this.A;
        float f12 = this.B;
        float f13 = f7 * f10;
        float f14 = f8 * f10;
        if (f11 + f13 > RenderScale.c()) {
            f11 = RenderScale.c() - f13 - 4.0f;
        }
        if (f12 + f14 > RenderScale.d()) {
            f12 = RenderScale.d() - f14 - 4.0f;
        }
        int n2 = (int)(230.0f * f3 * f2);
        float f15 = 5.0f;
        new PanelRenderer(mc13, this.A - f15 * 0.5f, this.B - f15 * 0.5f, f15, f15).a(GuiRenderer.a(new Color(18, 18, 18), n2)).a(2.0f).j();
        new PanelRenderer(mc13, f11, f12, f13, f14).a(GuiRenderer.a(new Color(18, 18, 18), n2)).a(16.0f, 1.0f).a(f9 * f10).j();
        if (f3 < 0.4f) {
            return;
        }
        float f16 = GuiRenderer.b((f3 - 0.3f) / 0.7f, 0.0f, 1.0f) * f2;
        Color color = MenuGuiScreen.c();
        float f17 = 7.0f;
        float f18 = 8.0f * f10;
        for (int i2 = 0; i2 < J.length; ++i2) {
            String string = J[i2][0];
            String string2 = J[i2][1];
            boolean bl = this.C != null && this.C.a(string);
            float f19 = f11 + f6 * f10;
            float f20 = f12 + (f6 + (float)i2 * f5) * f10;
            float f21 = (f7 - f6 * 2.0f) * f10;
            float f22 = f5 * f10;
            float f23 = GuiRenderer.a("hud.simplepopup." + string, this.a(f19, f20, f21, f22) ? 1.0f : 0.0f, 0.12f);
            int n3 = (int)(f16 * 255.0f);
            if (f23 > 0.05f) {
                new PanelRenderer(mc13, f19, f20, f21, f22).a(GuiRenderer.a(color, (int)(30.0f * f23 * f16))).a(4.0f * f10).j();
            }
            float f24 = f19 + 4.0f * f10;
            float f25 = f20 + (f22 - f18) * 0.5f;
            float f26 = GuiRenderer.a("hud.simplepopup.tog." + string, bl ? 1.0f : 0.0f, 0.1f);
            Color color2 = GuiRenderer.a(GuiRenderer.a(new Color(60, 60, 60), n3), GuiRenderer.a(color, n3), f26);
            new PanelRenderer(mc13, f24, f25, f18, f18).a(color2).a(2.0f * f10).j();
            if (f26 > 0.1f) {
                GuiRenderer.a(mc13, "check", f24 + 1.0f * f10, f25 + 1.0f * f10, f18 - 2.0f * f10, f18 - 2.0f * f10, GuiRenderer.a(Color.WHITE, (int)(255.0f * f26 * f16)));
            }
            FontManager.a().a(mc13, new StringConstant(string2), f24 + f18 + 4.0f * f10, f20 + f22 * 0.28f, f17 * f10, GuiRenderer.a(Color.WHITE, n3));
            if (!(f3 > 0.85f) || this.C == null) continue;
            new PanelRenderer(mc13, f19, f20, f21, f22).a(new Color(0, 0, 0, 0)).j().a(0, () -> ((HudEditorScreen)this).lambda$drawSimpleSettingsPopup$4((String)string));
        }
    }

    private boolean c(float f2, float f3) {
        if (!this.z) {
            return false;
        }
        float f4 = 115.0f;
        float f5 = 12.0f + (float)J.length * 22.0f;
        float f6 = this.A;
        float f7 = this.B;
        if (f6 + f4 > RenderScale.c()) {
            f6 = RenderScale.c() - f4 - 4.0f;
        }
        if (f7 + f5 > RenderScale.d()) {
            f7 = RenderScale.d() - f5 - 4.0f;
        }
        return f2 >= f6 && f2 <= f6 + f4 && f3 >= f7 && f3 <= f7 + f5;
    }

    private void a(MatrixStack mc13, float f2, DrawContext mc15) {
        float f3 = RenderScale.c();
        float f4 = RenderScale.d();
        for (VanillaHudElementSettings vanillaHudElementSettings : VanillaHudConfigRegistry.getInstance().c()) {
            this.getInstance(mc13, vanillaHudElementSettings, f2, f3, f4);
        }
        if (this.j != null) {
            this.b(mc13, this.j, f3, f4, f2);
        }
        if (this.m != null && !this.n) {
            this.e(mc13, f2);
        }
        if (this.n) {
            this.f(mc13, f2);
        }
    }

    private void a(MatrixStack mc13, VanillaHudElementSettings vanillaHudElementSettings, float f2, float f3, float f4) {
        float f5 = vanillaHudElementSettings.b();
        float f6 = vanillaHudElementSettings.c();
        float f7 = vanillaHudElementSettings.d();
        float f8 = vanillaHudElementSettings.e();
        boolean bl = this.a(f5, f6, f7, f8);
        boolean bl2 = vanillaHudElementSettings == this.j;
        boolean bl3 = vanillaHudElementSettings == this.m;
        float f9 = GuiRenderer.a("hud.vanilla.frame." + vanillaHudElementSettings.g().name(), bl || bl2 || bl3 ? 1.0f : 0.0f, 0.1f);
        Color color = MenuGuiScreen.c();
        int n2 = (int)((40.0f + 60.0f * f9) * f2);
        new PanelRenderer(mc13, f5, f6, f7, f8).a(GuiRenderer.a(color, (int)((float)n2 * 0.4f))).a(10.0f, 1.0f).a(4.0f).j();
        int n3 = (int)((80.0f + 120.0f * f9) * f2);
        GuiRenderer.a(mc13, f5, f6, f7, f8, 1.0f, 4.0f, GuiRenderer.a(vanillaHudElementSettings.n() ? color : new Color(120, 120, 120), n3));
        float f10 = 7.0f;
        StringConstant stringConstant = new StringConstant(vanillaHudElementSettings.g().displayName);
        float f11 = FontManager.a().a(stringConstant, f10);
        FontManager.a().a(mc13, stringConstant, f5 + (f7 - f11) * 0.5f, f6 + f8 * 0.5f - FontManager.a().b(f10) * 0.5f, f10, GuiRenderer.a(Color.WHITE, (int)(220.0f * f2)));
        if (!vanillaHudElementSettings.n()) {
            StringConstant stringConstant2 = new StringConstant("vanilla");
            float f12 = FontManager.a().a(stringConstant2, 5.5f);
            FontManager.a().a(mc13, stringConstant2, f5 + (f7 - f12) * 0.5f, f6 + f8 + 2.0f, 5.5f, GuiRenderer.a(new Color(150, 150, 150), (int)(200.0f * f2)));
        }
    }

    private void b(MatrixStack mc13, VanillaHudElementSettings vanillaHudElementSettings, float f2, float f3, float f4) {
        float f5 = vanillaHudElementSettings.b();
        float f6 = vanillaHudElementSettings.c();
        float f7 = vanillaHudElementSettings.d();
        float f8 = vanillaHudElementSettings.e();
        float f9 = f5 + f7 * 0.5f;
        float f10 = f6 + f8 * 0.5f;
        int n2 = (int)((float)f.getAlpha() * f4);
        Color color = GuiRenderer.a(MenuGuiScreen.c(), n2);
        if (Math.abs(f9 - f2 * 0.5f) < 8.0f) {
            new PanelRenderer(mc13, f2 * 0.5f - 0.25f, 0.0f, 0.5f, f3).a(color).j();
        }
        if (Math.abs(f10 - f3 * 0.5f) < 8.0f) {
            new PanelRenderer(mc13, 0.0f, f3 * 0.5f - 0.25f, f2, 0.5f).a(color).j();
        }
    }

    private void d(float f2, float f3) {
        VanillaHudElementSettings vanillaHudElementSettings;
        long l2 = Main.mc.getWindow().getHandle();
        boolean bl = GLFW.glfwGetMouseButton((long)l2, (int)0) == 1;
        boolean bl2 = GLFW.glfwGetMouseButton((long)l2, (int)1) == 1;
        boolean bl3 = bl && !this.F;
        boolean bl4 = bl2 && !this.G;
        this.F = bl;
        this.G = bl2;
        if (bl3) {
            if (this.n) {
                if (!this.g(f2, f3)) {
                    this.n = false;
                }
                return;
            }
            if (this.m != null && !this.f(f2, f3)) {
                this.m = null;
                return;
            }
            vanillaHudElementSettings = this.b();
            if (vanillaHudElementSettings != null) {
                if (vanillaHudElementSettings.g() == VanillaHudSection.CROSSHAIR) {
                    this.n = true;
                    this.m = null;
                    SoundManager.b();
                    return;
                }
                this.j = vanillaHudElementSettings;
                float f4 = vanillaHudElementSettings.b();
                float f5 = vanillaHudElementSettings.c();
                this.k = f2 - f4;
                this.l = f3 - f5;
            }
        }
        if (bl4) {
            if (this.n) {
                this.n = false;
                return;
            }
            vanillaHudElementSettings = this.b();
            this.m = vanillaHudElementSettings != null && vanillaHudElementSettings.g() != VanillaHudSection.CROSSHAIR ? vanillaHudElementSettings : null;
        }
    }

    private void e(float f2, float f3) {
        boolean bl;
        boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
        if (!bl) {
            this.j = null;
            return;
        }
        if (this.j == null) {
            return;
        }
        float f4 = RenderScale.c();
        float f5 = RenderScale.d();
        float f6 = f2 - this.k;
        float f7 = f3 - this.l;
        f6 = this.a(f6);
        f7 = this.a(f7);
        float f8 = this.j.d();
        float f9 = this.j.e();
        float f10 = f6 + f8 * 0.5f;
        float f11 = f7 + f9 * 0.5f;
        if (Math.abs(f10 - f4 * 0.5f) < 8.0f) {
            f6 = f4 * 0.5f - f8 * 0.5f;
        }
        if (Math.abs(f11 - f5 * 0.5f) < 8.0f) {
            f7 = f5 * 0.5f - f9 * 0.5f;
        }
        f6 = Math.max(0.0f, Math.min(f6, f4 - f8));
        f7 = Math.max(0.0f, Math.min(f7, f5 - f9));
        this.j.a(f6, f7);
    }

    private VanillaHudElementSettings b() {
        float f2 = RenderScale.c();
        float f3 = RenderScale.d();
        double d2 = RenderScale.j();
        double d3 = RenderScale.k();
        VanillaHudElementSettings vanillaHudElementSettings = null;
        float f4 = Float.MAX_VALUE;
        for (VanillaHudElementSettings vanillaHudElementSettings2 : VanillaHudConfigRegistry.getInstance().c()) {
            float f5;
            float f6 = vanillaHudElementSettings2.b();
            float f7 = vanillaHudElementSettings2.c();
            float f8 = vanillaHudElementSettings2.d();
            float f9 = vanillaHudElementSettings2.e();
            if (!(d2 >= (double)f6) || !(d2 <= (double)(f6 + f8)) || !(d3 >= (double)f7) || !(d3 <= (double)(f7 + f9)) || !((f5 = f8 * f9) < f4)) continue;
            f4 = f5;
            vanillaHudElementSettings = vanillaHudElementSettings2;
        }
        return vanillaHudElementSettings;
    }

    private void e(MatrixStack mc13, float f2) {
        if (this.m == null) {
            return;
        }
        VanillaHudElementSettings vanillaHudElementSettings = this.m;
        float f3 = RenderScale.c();
        float f4 = RenderScale.d();
        float f5 = vanillaHudElementSettings.b();
        float f6 = vanillaHudElementSettings.c();
        float f7 = vanillaHudElementSettings.d();
        this.L = f5 + f7 + 8.0f;
        this.M = f6;
        int n2 = K.length + 2;
        float f8 = 18.0f;
        float f9 = 8.0f;
        float f10 = 22.0f;
        float f11 = f10 + f9 + (float)n2 * f8 + f9;
        if (this.L + 140.0f > f3) {
            this.L = f5 - 140.0f - 8.0f;
        }
        if (this.M + f11 > f4) {
            this.M = f4 - f11 - 6.0f;
        }
        if (this.L < 4.0f) {
            this.L = 4.0f;
        }
        if (this.M < 4.0f) {
            this.M = 4.0f;
        }
        float f12 = GuiRenderer.a("hud.vanilla.popup", 1.0f, 0.08f);
        int n3 = (int)(230.0f * f12 * f2);
        new PanelRenderer(mc13, this.L, this.M, 140.0f, f11).a(GuiRenderer.a(new Color(18, 18, 18), n3)).a(16.0f, 1.0f).a(8.0f).j();
        Color color = MenuGuiScreen.c();
        StringConstant stringConstant = new StringConstant(vanillaHudElementSettings.g().displayName);
        FontManager.a().a(mc13, stringConstant, this.L + f9, this.M + f10 * 0.5f - FontManager.a().b(8.0f) * 0.5f, 8.0f, color);
        new PanelRenderer(mc13, this.L + f9, this.M + f10, 140.0f - f9 * 2.0f, 0.5f).a(GuiRenderer.a(color, 80)).j();
        float f13 = this.M + f10 + f9;
        float f14 = this.L + f9;
        float f15 = 140.0f - f9 * 2.0f;
        for (String[] stringArray : K) {
            this.a(mc13, vanillaHudElementSettings, stringArray[0], stringArray[1], f14, f13, f15, f8, f2);
            f13 += f8;
        }
        this.getInstance(mc13, vanillaHudElementSettings, f14, f13 + 2.0f, f15, f8 - 2.0f, f2);
        this.b(mc13, vanillaHudElementSettings, f14, f13 += f8, f15, f8 - 2.0f, f2);
    }

    private void a(MatrixStack mc13, VanillaHudElementSettings vanillaHudElementSettings, String string, String string2, float f2, float f3, float f4, float f5, float f6) {
        boolean bl = vanillaHudElementSettings.a(string);
        boolean bl2 = this.a(f2, f3, f4, f5);
        float f7 = GuiRenderer.a("hud.vanilla.opt." + vanillaHudElementSettings.g().name() + "." + string, bl2 ? 1.0f : 0.0f, 0.1f);
        Color color = MenuGuiScreen.c();
        if (f7 > 0.05f) {
            new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(color, (int)(30.0f * f7 * f6))).a(3.0f).j();
        }
        float f8 = 14.0f;
        float f9 = 7.0f;
        float f10 = f2 + f4 - f8 - 4.0f;
        float f11 = f3 + (f5 - f9) * 0.5f;
        float f12 = GuiRenderer.a("hud.vanilla.opt.tog." + vanillaHudElementSettings.g().name() + "." + string, bl ? 1.0f : 0.0f, 0.12f);
        Color color2 = GuiRenderer.a(new Color(60, 60, 60), color, f12);
        new PanelRenderer(mc13, f10, f11, f8, f9).a(GuiRenderer.a(color2, (int)(255.0f * f6))).a(f9 / 2.0f).j();
        float f13 = f9 - 2.0f;
        float f14 = f10 + 1.0f + (f8 - f13 - 2.0f) * f12;
        float f15 = f11 + 1.0f;
        new PanelRenderer(mc13, f14, f15, f13, f13).a(GuiRenderer.a(Color.WHITE, (int)(255.0f * f6))).a(f13 / 2.0f).j();
        FontManager.a().a(mc13, new StringConstant(string2), f2 + 2.0f, f3 + f5 * 0.5f - FontManager.a().b(6.5f) * 0.5f, 6.5f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        new PanelRenderer(mc13, f2, f3, f4, f5).a(new Color(0, 0, 0, 0)).j().a(0, () -> i.lambda$drawOptionRow$5((VanillaHudElementSettings)vanillaHudElementSettings, (String)string));
    }

    private void a(MatrixStack mc13, VanillaHudElementSettings vanillaHudElementSettings, float f2, float f3, float f4, float f5, float f6) {
        boolean bl;
        Color color = MenuGuiScreen.c();
        FontManager.a().a(mc13, new StringConstant("Scale"), f2 + 2.0f, f3, 6.5f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        float f7 = f2 + 34.0f;
        float f8 = f4 - 34.0f - 22.0f;
        float f9 = 3.0f;
        float f10 = f3 + f5 * 0.5f - f9 * 0.5f;
        new PanelRenderer(mc13, f7, f10, f8, f9).a(GuiRenderer.a(new Color(55, 55, 55), (int)(200.0f * f6))).a(f9 / 2.0f).j();
        float f11 = vanillaHudElementSettings.j();
        float f12 = (f11 - 0.5f) / 1.5f;
        f12 = GuiRenderer.b(f12, 0.0f, 1.0f);
        new PanelRenderer(mc13, f7, f10, f8 * f12, f9).a(GuiRenderer.a(color, (int)(220.0f * f6))).a(f9 / 2.0f).j();
        float f13 = 4.0f;
        new PanelRenderer(mc13, f7 + f8 * f12 - f13, f10 + f9 * 0.5f - f13, f13 * 2.0f, f13 * 2.0f).a(GuiRenderer.a(Color.WHITE, (int)(255.0f * f6))).a(f13).j();
        FontManager.a().a(mc13, new StringConstant(String.format("%.2f", Float.valueOf(f11))), f2 + f4 - 20.0f, f3, 6.5f, GuiRenderer.a(new Color(180, 180, 180), (int)(200.0f * f6)));
        long l2 = Main.mc.getWindow().getHandle();
        boolean bl2 = bl = GLFW.glfwGetMouseButton((long)l2, (int)0) == 1;
        if (bl && this.a(f7 - 4.0f, f10 - 4.0f, f8 + 8.0f, f9 + 8.0f)) {
            float f14 = (float)RenderScale.j();
            float f15 = GuiRenderer.b((f14 - f7) / f8, 0.0f, 1.0f);
            vanillaHudElementSettings.c(0.5f + f15 * 1.5f);
        }
    }

    private void b(MatrixStack mc13, VanillaHudElementSettings vanillaHudElementSettings, float f2, float f3, float f4, float f5, float f6) {
        Color color = MenuGuiScreen.c();
        boolean bl = this.a(f2, f3, f4, f5);
        float f7 = GuiRenderer.a("hud.vanilla.reset." + vanillaHudElementSettings.g().name(), bl ? 1.0f : 0.0f, 0.1f);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(GuiRenderer.a(new Color(40, 40, 40), color, f7 * 0.7f), (int)(200.0f * f6))).a(3.0f).j();
        StringConstant stringConstant = new StringConstant("Reset Position");
        float f8 = FontManager.a().a(stringConstant, 6.5f);
        FontManager.a().a(mc13, stringConstant, f2 + (f4 - f8) * 0.5f, f3 + f5 * 0.5f - FontManager.a().b(6.5f) * 0.5f, 6.5f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        new PanelRenderer(mc13, f2, f3, f4, f5).a(new Color(0, 0, 0, 0)).j().a(0, () -> i.lambda$drawResetButton$6((VanillaHudElementSettings)vanillaHudElementSettings));
    }

    private boolean f(float f2, float f3) {
        if (this.m == null) {
            return false;
        }
        int n2 = K.length + 2;
        float f4 = 30.0f + (float)n2 * 18.0f + 8.0f;
        return f2 >= this.L && f2 <= this.L + 140.0f && f3 >= this.M && f3 <= this.M + f4;
    }

    private void f(MatrixStack mc13, float f2) {
        float f3;
        float f4 = RenderScale.c();
        float f5 = RenderScale.d();
        float f6 = f4 - 230.0f - 20.0f;
        float f7 = (f5 - 360.0f) * 0.5f;
        float f8 = GuiRenderer.a("hud.crosshair.panel", 1.0f, 0.08f);
        int n2 = (int)(235.0f * f8 * f2);
        new PanelRenderer(mc13, f6, f7, 230.0f, 360.0f).a(GuiRenderer.a(new Color(10, 10, 12), n2)).a(20.0f, 1.0f).a(10.0f).j();
        Color color = MenuGuiScreen.c();
        StringConstant stringConstant = new StringConstant("Crosshair Editor");
        FontManager.a().a(mc13, stringConstant, f6 + 12.0f, f7 + 10.0f, 9.5f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f2)));
        StringConstant stringConstant2 = new StringConstant("Flat & customizable");
        FontManager.a().a(mc13, stringConstant2, f6 + 12.0f, f7 + 21.0f, 6.0f, GuiRenderer.a(new Color(160, 160, 170), (int)(200.0f * f2)));
        float f9 = f6 + 230.0f - 20.0f;
        float f10 = f7 + 8.0f;
        new PanelRenderer(mc13, f9, f10, 14.0f, 14.0f).a(new Color(0, 0, 0, 0)).j().a(0, () -> ((HudEditorScreen)this).lambda$drawCrosshairPanel$7());
        FontManager.a().a(mc13, new StringConstant("\u00d7"), f9 + 4.0f, f10 + 2.0f, 10.0f, GuiRenderer.a(Color.WHITE, (int)(220.0f * f2)));
        new PanelRenderer(mc13, f6 + 12.0f, f7 + 34.0f, 206.0f, 0.5f).a(GuiRenderer.a(Color.WHITE, (int)(30.0f * f2))).j();
        CrosshairConfig crosshairConfig = CrosshairConfig.getInstance();
        float f11 = 44.0f;
        float f12 = f6 + 230.0f - f11 - 12.0f;
        float f13 = f7 + 42.0f;
        new PanelRenderer(mc13, f12, f13, f11, f11).a(GuiRenderer.a(new Color(30, 30, 34), (int)(220.0f * f2))).a(6.0f).j();
        if (crosshairConfig.b()) {
            this.a(mc13, crosshairConfig, f12 + f11 * 0.5f, f13 + f11 * 0.5f, f2);
        } else {
            StringConstant stringConstant3 = new StringConstant("off");
            f3 = FontManager.a().a(stringConstant3, 6.0f);
            FontManager.a().a(mc13, stringConstant3, f12 + (f11 - f3) * 0.5f, f13 + f11 * 0.5f - FontManager.a().b(6.0f) * 0.5f, 6.0f, GuiRenderer.a(new Color(120, 120, 130), (int)(200.0f * f2)));
        }
        float f14 = f7 + 42.0f;
        f3 = f6 + 12.0f;
        float f15 = 230.0f - f11 - 28.0f;
        f14 = this.a(mc13, "Enable", crosshairConfig.b(), f3, f14, f15, f2, arg_0 -> ((CrosshairConfig)crosshairConfig).a((boolean)arg_0));
        f14 = this.a(mc13, "Center Dot", crosshairConfig.k(), f3, f14, f15, f2, arg_0 -> ((CrosshairConfig)crosshairConfig).c((boolean)arg_0));
        float f16 = f6 + 12.0f;
        float f17 = 206.0f;
        f14 = Math.max(f14, f7 + 42.0f + f11 + 6.0f) + 6.0f;
        f14 = this.a(mc13, "Shape", f16, f14, f2);
        f14 = this.a(mc13, crosshairConfig, f16, f14, f17, f2);
        f14 = this.a(mc13, "Geometry", f16, f14 + 4.0f, f2);
        f14 = this.a(mc13, "Length", crosshairConfig.d(), 0.0f, 20.0f, 1.0f, f16, f14, f17, f2, arg_0 -> ((CrosshairConfig)crosshairConfig).a((float)arg_0));
        f14 = this.a(mc13, "Thickness", crosshairConfig.e(), 0.25f, 6.0f, 0.25f, f16, f14, f17, f2, arg_0 -> ((CrosshairConfig)crosshairConfig).b((float)arg_0));
        f14 = this.a(mc13, "Gap", crosshairConfig.f(), 0.0f, 15.0f, 1.0f, f16, f14, f17, f2, arg_0 -> ((CrosshairConfig)crosshairConfig).c((float)arg_0));
        f14 = this.a(mc13, "Color", f16, f14 + 4.0f, f2);
        f14 = this.a(mc13, "", crosshairConfig.g(), arg_0 -> ((CrosshairConfig)crosshairConfig).a((Color)arg_0), f16, f14, f17, f2);
        f14 = this.a(mc13, "Hit Marker", f16, f14 + 4.0f, f2);
        f14 = this.a(mc13, "Enable Hit Marker", crosshairConfig.h(), f16, f14, f17, f2, arg_0 -> ((CrosshairConfig)crosshairConfig).b((boolean)arg_0));
        f14 = this.a(mc13, "", crosshairConfig.j(), arg_0 -> ((CrosshairConfig)crosshairConfig).b((Color)arg_0), f16, f14, f17, f2);
        f14 = this.a(mc13, "Dynamic Spread", crosshairConfig.m(), f16, f14 + 2.0f, f17, f2, arg_0 -> ((CrosshairConfig)crosshairConfig).d((boolean)arg_0));
    }

    private float a(MatrixStack mc13, String string, float f2, float f3, float f4) {
        FontManager.a().a(mc13, new StringConstant(string.toUpperCase()), f2 + 1.0f, f3, 5.5f, GuiRenderer.a(new Color(140, 140, 150), (int)(200.0f * f4)));
        return f3 + 8.0f;
    }

    private void a(MatrixStack mc13, CrosshairConfig crosshairConfig, float f2, float f3, float f4) {
        int n2 = Math.max(0, Math.round(crosshairConfig.d()));
        int n3 = Math.max(1, Math.round(crosshairConfig.e()));
        int n4 = Math.max(0, Math.round(crosshairConfig.f()));
        Color color = GuiRenderer.a(crosshairConfig.g(), (int)(255.0f * f4));
        switch (CrosshairShapeSwitchMap.a[crosshairConfig.c().ordinal()]) {
            case 1: 
            case 2: 
            case 3: 
            case 4: {
                new PanelRenderer(mc13, f2 - (float)n4 - (float)n2, f3 - (float)n3 * 0.5f, n2, n3).a(color).j();
                new PanelRenderer(mc13, f2 + (float)n4, f3 - (float)n3 * 0.5f, n2, n3).a(color).j();
                new PanelRenderer(mc13, f2 - (float)n3 * 0.5f, f3 - (float)n4 - (float)n2, n3, n2).a(color).j();
                new PanelRenderer(mc13, f2 - (float)n3 * 0.5f, f3 + (float)n4, n3, n2).a(color).j();
                break;
            }
            case 5: {
                float f5 = crosshairConfig.l();
                new PanelRenderer(mc13, f2 - f5 * 0.5f, f3 - f5 * 0.5f, f5, f5).a(color).a(f5 / 2.0f).j();
                break;
            }
            case 6: {
                float f6 = Math.max(2.0f, (float)n2);
                GuiRenderer.a(mc13, f2 - f6, f3 - f6, f6 * 2.0f, f6 * 2.0f, Math.max(1.0f, (float)n3), f6, color);
                break;
            }
            case 7: {
                int n5 = Math.max(1, n2);
                for (int i2 = 1; i2 <= n5; ++i2) {
                    new PanelRenderer(mc13, f2 - (float)n4 - (float)i2, f3 - (float)n4 - (float)i2, 1.0f, 1.0f).a(color).j();
                    new PanelRenderer(mc13, f2 + (float)n4 + (float)i2 - 1.0f, f3 - (float)n4 - (float)i2, 1.0f, 1.0f).a(color).j();
                    new PanelRenderer(mc13, f2 - (float)n4 - (float)i2, f3 + (float)n4 + (float)i2 - 1.0f, 1.0f, 1.0f).a(color).j();
                    new PanelRenderer(mc13, f2 + (float)n4 + (float)i2 - 1.0f, f3 + (float)n4 + (float)i2 - 1.0f, 1.0f, 1.0f).a(color).j();
                }
                break;
            }
        }
        if (crosshairConfig.k()) {
            float f7 = crosshairConfig.l();
            new PanelRenderer(mc13, f2 - f7 * 0.5f, f3 - f7 * 0.5f, f7, f7).a(color).j();
        }
    }

    private float a(MatrixStack mc13, String string, boolean bl, float f2, float f3, float f4, float f5, Consumer consumer) {
        float f6 = 18.0f;
        boolean bl2 = this.a(f2, f3, f4, f6);
        float f7 = GuiRenderer.a("hud.ch.tog." + string, bl2 ? 1.0f : 0.0f, 0.1f);
        Color color = MenuGuiScreen.c();
        if (f7 > 0.05f) {
            new PanelRenderer(mc13, f2, f3, f4, f6).a(GuiRenderer.a(color, (int)(25.0f * f7 * f5))).a(3.0f).j();
        }
        FontManager.a().a(mc13, new StringConstant(string), f2 + 4.0f, f3 + f6 * 0.5f - FontManager.a().b(7.0f) * 0.5f, 7.0f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f5)));
        float f8 = 18.0f;
        float f9 = 9.0f;
        float f10 = f2 + f4 - f8 - 4.0f;
        float f11 = f3 + (f6 - f9) * 0.5f;
        float f12 = GuiRenderer.a("hud.ch.tog.knob." + string, bl ? 1.0f : 0.0f, 0.12f);
        new PanelRenderer(mc13, f10, f11, f8, f9).a(GuiRenderer.a(GuiRenderer.a(new Color(60, 60, 60), color, f12), (int)(255.0f * f5))).a(f9 / 2.0f).j();
        float f13 = f9 - 2.0f;
        new PanelRenderer(mc13, f10 + 1.0f + (f8 - f13 - 2.0f) * f12, f11 + 1.0f, f13, f13).a(GuiRenderer.a(Color.WHITE, (int)(255.0f * f5))).a(f13 / 2.0f).j();
        new PanelRenderer(mc13, f2, f3, f4, f6).a(new Color(0, 0, 0, 0)).j().a(0, () -> i.lambda$drawCrosshairToggle$8((Consumer)consumer, (boolean)bl));
        return f3 + f6 + 2.0f;
    }

    private float a(MatrixStack mc13, CrosshairConfig crosshairConfig, float f2, float f3, float f4, float f5) {
        float f6 = 22.0f;
        FontManager.a().a(mc13, new StringConstant("Shape"), f2 + 2.0f, f3, 6.5f, GuiRenderer.a(new Color(170, 170, 170), (int)(220.0f * f5)));
        float f7 = f3 + 9.0f;
        CrosshairShape[] crosshairShapeArray = CrosshairShape.values();
        float f8 = (f4 - (float)(crosshairShapeArray.length - 1) * 2.0f) / (float)crosshairShapeArray.length;
        Color color = MenuGuiScreen.c();
        for (int i2 = 0; i2 < crosshairShapeArray.length; ++i2) {
            float f9 = f2 + (float)i2 * (f8 + 2.0f);
            CrosshairShape crosshairShape = crosshairShapeArray[i2];
            boolean bl = crosshairConfig.c() == crosshairShape;
            float f10 = GuiRenderer.a("hud.ch.shape." + crosshairShape.name(), bl ? 1.0f : 0.0f, 0.1f);
            Color color2 = GuiRenderer.a(new Color(40, 40, 40), GuiRenderer.a(color, 200), f10);
            new PanelRenderer(mc13, f9, f7, f8, f6).a(GuiRenderer.a(color2, (int)(220.0f * f5))).a(3.0f).j();
            StringConstant stringConstant = new StringConstant(crosshairShape.displayName);
            float f11 = FontManager.a().a(stringConstant, 6.5f);
            FontManager.a().a(mc13, stringConstant, f9 + (f8 - f11) * 0.5f, f7 + f6 * 0.5f - FontManager.a().b(6.5f) * 0.5f, 6.5f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f5)));
            new PanelRenderer(mc13, f9, f7, f8, f6).a(new Color(0, 0, 0, 0)).j().a(0, () -> i.lambda$drawShapeSelector$9((CrosshairConfig)crosshairConfig, (CrosshairShape)crosshairShape));
        }
        return f7 + f6 + 4.0f;
    }

    private float a(MatrixStack mc13, String string, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, Consumer consumer) {
        boolean bl;
        float f10 = 22.0f;
        Color color = MenuGuiScreen.c();
        FontManager.a().a(mc13, new StringConstant(string), f6 + 2.0f, f7, 6.5f, GuiRenderer.a(new Color(170, 170, 170), (int)(220.0f * f9)));
        FontManager.a().a(mc13, new StringConstant(String.format("%.2f", Float.valueOf(f2))), f6 + f8 - 28.0f, f7, 6.5f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f9)));
        float f11 = f7 + 12.0f;
        float f12 = 3.0f;
        new PanelRenderer(mc13, f6, f11, f8, f12).a(GuiRenderer.a(new Color(55, 55, 55), (int)(200.0f * f9))).a(f12 / 2.0f).j();
        float f13 = GuiRenderer.b((f2 - f3) / (f4 - f3), 0.0f, 1.0f);
        new PanelRenderer(mc13, f6, f11, f8 * f13, f12).a(GuiRenderer.a(color, (int)(220.0f * f9))).a(f12 / 2.0f).j();
        float f14 = 4.0f;
        new PanelRenderer(mc13, f6 + f8 * f13 - f14, f11 + f12 * 0.5f - f14, f14 * 2.0f, f14 * 2.0f).a(GuiRenderer.a(Color.WHITE, (int)(255.0f * f9))).a(f14).j();
        long l2 = Main.mc.getWindow().getHandle();
        boolean bl2 = bl = GLFW.glfwGetMouseButton((long)l2, (int)0) == 1;
        if (bl && this.a(f6 - 4.0f, f11 - 6.0f, f8 + 8.0f, f12 + 12.0f)) {
            float f15 = (float)RenderScale.j();
            float f16 = GuiRenderer.b((f15 - f6) / f8, 0.0f, 1.0f);
            float f17 = f3 + f16 * (f4 - f3);
            f17 = (float)Math.round(f17 / f5) * f5;
            consumer.accept(Float.valueOf(f17));
        }
        return f7 + f10;
    }

    private float a(MatrixStack mc13, String string, Color color, Consumer consumer, float f2, float f3, float f4, float f5) {
        float f6 = 18.0f;
        float f7 = f2;
        float f8 = f4;
        if (!string.isEmpty()) {
            FontManager.a().a(mc13, new StringConstant(string), f2 + 2.0f, f3 + 5.0f, 6.5f, GuiRenderer.a(new Color(170, 170, 170), (int)(220.0f * f5)));
            f7 = f2 + 40.0f;
            f8 = f4 - 40.0f;
        }
        Color[] colorArray = new Color[]{Color.WHITE, new Color(80, 220, 120), new Color(80, 180, 255), new Color(255, 220, 80), new Color(255, 100, 100), new Color(220, 120, 255), MenuGuiScreen.c()};
        float f9 = (f8 - (float)(colorArray.length - 1) * 2.0f) / (float)colorArray.length;
        float f10 = f6 - 4.0f;
        for (int i2 = 0; i2 < colorArray.length; ++i2) {
            Color color2 = colorArray[i2];
            boolean bl = color2.getRGB() == color.getRGB();
            float f11 = f7 + (float)i2 * (f9 + 2.0f);
            float f12 = f3 + 2.0f;
            new PanelRenderer(mc13, f11, f12, f9, f10).a(GuiRenderer.a(color2, (int)(240.0f * f5))).a(3.0f).j();
            if (bl) {
                new PanelRenderer(mc13, f11 - 1.0f, f12 - 1.0f, f9 + 2.0f, f10 + 2.0f).a(new Color(0, 0, 0, 0)).a(4.0f).j();
                GuiRenderer.a(mc13, f11, f12, f9, f10, 1.0f, 3.0f, GuiRenderer.a(Color.WHITE, (int)(255.0f * f5)));
            }
            new PanelRenderer(mc13, f11, f12, f9, f10).a(new Color(0, 0, 0, 0)).j().a(0, () -> i.lambda$drawColorRow$10((Consumer)consumer, (Color)color2));
        }
        return f3 + f6 + 2.0f;
    }

    private boolean g(float f2, float f3) {
        float f4 = RenderScale.c();
        float f5 = RenderScale.d();
        float f6 = f4 - 230.0f - 20.0f;
        float f7 = (f5 - 360.0f) * 0.5f;
        return f2 >= f6 && f2 <= f6 + 230.0f && f3 >= f7 && f3 <= f7 + 360.0f;
    }

    private void h(float f2, float f3) {
        boolean bl;
        boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
        if (!bl) {
            this.g = null;
            return;
        }
        if (this.g != null) {
            float f4 = f2 - this.h;
            float f5 = f3 - this.i;
            f4 = this.a(f4);
            f5 = this.a(f5);
            float f6 = f4 + this.g.d() * 0.5f;
            float f7 = f5 + this.g.e() * 0.5f;
            if (Math.abs(f6 - RenderScale.c() * 0.5f) < 8.0f) {
                f4 = RenderScale.c() * 0.5f - this.g.d() * 0.5f;
            }
            if (Math.abs(f7 - RenderScale.d() * 0.5f) < 8.0f) {
                f5 = RenderScale.d() * 0.5f - this.g.e() * 0.5f;
            }
            for (HudElementSettings hudElementSettings : HudManager.getInstance().c()) {
                float f8;
                float f9;
                float f10;
                float f11;
                if (hudElementSettings == this.g || hudElementSettings.d() <= 0.0f) continue;
                if (Math.abs(f4 - hudElementSettings.b()) < 8.0f) {
                    f4 = hudElementSettings.b();
                }
                if (Math.abs((f11 = f4 + this.g.d()) - (f10 = hudElementSettings.b() + hudElementSettings.d())) < 8.0f) {
                    f4 = f10 - this.g.d();
                }
                if (Math.abs(f5 - hudElementSettings.c()) < 8.0f) {
                    f5 = hudElementSettings.c();
                }
                if (Math.abs((f9 = f5 + this.g.e()) - (f8 = hudElementSettings.c() + hudElementSettings.e())) < 8.0f) {
                    f5 = f8 - this.g.e();
                }
                if (Math.abs(f4 - f10) < 8.0f) {
                    f4 = f10;
                }
                if (!(Math.abs(f11 - hudElementSettings.b()) < 8.0f)) continue;
                f4 = hudElementSettings.b() - this.g.d();
            }
            f4 = Math.max(0.0f, Math.min(f4, RenderScale.c() - this.g.d()));
            f5 = Math.max(0.0f, Math.min(f5, RenderScale.d() - this.g.e()));
            this.g.a(f4);
            this.g.b(f5);
        }
    }

    private void i(float f2, float f3) {
        HudElementSettings hudElementSettings;
        long l2 = Main.mc.getWindow().getHandle();
        boolean bl = GLFW.glfwGetMouseButton((long)l2, (int)0) == 1;
        boolean bl2 = GLFW.glfwGetMouseButton((long)l2, (int)1) == 1;
        boolean bl3 = bl && !this.F;
        boolean bl4 = bl2 && !this.G;
        this.F = bl;
        this.G = bl2;
        if (bl3) {
            if (this.z && !this.c(f2, f3)) {
                this.z = false;
                this.C = null;
                return;
            }
            if (this.v && !this.b(f2, f3)) {
                this.v = false;
                this.y = null;
                return;
            }
            if (this.r && !this.getInstance(f2, f3)) {
                this.r = false;
                this.u = null;
                return;
            }
            if (this.o && !this.j(f2, f3)) {
                this.o = false;
                return;
            }
            if (!(this.r || this.v || this.z || (hudElementSettings = this.c()) == null)) {
                this.g = hudElementSettings;
                this.h = f2 - hudElementSettings.b();
                this.i = f3 - hudElementSettings.c();
            }
        }
        if (bl4) {
            this.o = false;
            this.r = false;
            this.v = false;
            this.z = false;
            hudElementSettings = this.c();
            if (hudElementSettings != null && hudElementSettings.a() == HudWidget.MODULE_LIST) {
                this.u = hudElementSettings;
                this.s = f2;
                this.t = f3;
                this.r = true;
                GuiRenderer.b("hud.editor.mlpopup", 0.0f);
            } else if (hudElementSettings != null && hudElementSettings.a() == HudWidget.USERNAME) {
                this.y = hudElementSettings;
                this.w = f2;
                this.x = f3;
                this.v = true;
                GuiRenderer.b("hud.editor.userpopup", 0.0f);
            } else if (hudElementSettings != null) {
                this.C = hudElementSettings;
                this.A = f2;
                this.B = f3;
                this.z = true;
                GuiRenderer.b("hud.editor.simplepopup", 0.0f);
            } else {
                this.p = f2;
                this.q = f3;
                this.o = true;
                GuiRenderer.b("hud.editor.popup", 0.0f);
            }
        }
    }

    private HudElementSettings c() {
        double d2 = RenderScale.j();
        double d3 = RenderScale.k();
        List list = HudManager.getInstance().c();
        for (int i2 = list.size() - 1; i2 >= 0; --i2) {
            HudElementSettings hudElementSettings = (HudElementSettings)list.get(i2);
            if (hudElementSettings.d() <= 0.0f || hudElementSettings.e() <= 0.0f || !(d2 >= (double)hudElementSettings.b()) || !(d2 <= (double)(hudElementSettings.b() + hudElementSettings.d())) || !(d3 >= (double)hudElementSettings.c()) || !(d3 <= (double)(hudElementSettings.c() + hudElementSettings.e()))) continue;
            return hudElementSettings;
        }
        return null;
    }

    private boolean a(float f2, float f3, float f4, float f5) {
        double d2 = RenderScale.j();
        double d3 = RenderScale.k();
        return d2 >= (double)f2 && d2 <= (double)(f2 + f4) && d3 >= (double)f3 && d3 <= (double)(f3 + f5);
    }

    private boolean j(float f2, float f3) {
        if (!this.o) {
            return false;
        }
        HudWidget[] hudWidgetArray = HudWidget.values();
        float f4 = 120.0f;
        float f5 = 12.0f + (float)hudWidgetArray.length * 22.0f;
        float f6 = this.p;
        float f7 = this.q;
        if (f6 + f4 > RenderScale.c()) {
            f6 = RenderScale.c() - f4 - 4.0f;
        }
        if (f7 + f5 > RenderScale.d()) {
            f7 = RenderScale.d() - f5 - 4.0f;
        }
        return f2 >= f6 && f2 <= f6 + f4 && f3 >= f7 && f3 <= f7 + f5;
    }

    private float a(float f2) {
        float f3 = (float)Math.round(f2 / 20.0f) * 20.0f;
        return Math.abs(f2 - f3) < 8.0f ? f3 : f2;
    }

    public boolean shouldPause() {
        return false;
    }

    public void close() {
        if (!this.D) {
            this.D = true;
        }
    }

    public void init() {
        this.D = false;
        this.m = null;
        this.n = false;
        GuiRenderer.b(E, 0.0f);
        GuiRenderer.b("hud.vanilla.popup", 0.0f);
        GuiRenderer.b("hud.crosshair.panel", 0.0f);
    }

    private static void lambda$drawColorRow$10(Consumer consumer, Color color) {
        consumer.accept(color);
        SoundManager.b();
    }

    private static void lambda$drawShapeSelector$9(CrosshairConfig crosshairConfig, CrosshairShape crosshairShape) {
        crosshairConfig.getInstance(crosshairShape);
        SoundManager.b();
    }

    private static void lambda$drawCrosshairToggle$8(Consumer consumer, boolean bl) {
        consumer.accept(!bl);
        SoundManager.b();
    }

    private void lambda$drawCrosshairPanel$7() {
        this.n = false;
        SoundManager.b();
    }

    private static void lambda$drawResetButton$6(VanillaHudElementSettings vanillaHudElementSettings) {
        vanillaHudElementSettings.f();
        vanillaHudElementSettings.c(1.0f);
        SoundManager.b();
    }

    private static void lambda$drawOptionRow$5(VanillaHudElementSettings vanillaHudElementSettings, String string) {
        vanillaHudElementSettings.b(string);
        SoundManager.b();
    }

    private void lambda$drawSimpleSettingsPopup$4(String string) {
        this.C.b(string);
        SoundManager.b();
    }

    private void lambda$drawUsernameSettingsPopup$3(String string) {
        this.y.b(string);
        SoundManager.b();
    }

    private void lambda$drawMLSettingsPopup$2(String string) {
        this.u.b(string);
        SoundManager.b();
    }

    private void lambda$drawAddPopup$1(HudWidget hudWidget) {
        HudManager.getInstance().a(new HudElementSettings(hudWidget, this.p, this.q));
        this.o = false;
        SoundManager.b();
    }

    private void lambda$drawTitleBar$0(HudRenderMode hudRenderMode) {
        if (this.b != hudRenderMode) {
            this.b = hudRenderMode;
            this.g = null;
            this.j = null;
            SoundManager.b();
        }
    }
}

