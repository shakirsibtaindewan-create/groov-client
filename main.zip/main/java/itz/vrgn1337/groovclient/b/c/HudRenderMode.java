/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.b.c;

public enum HudRenderMode {
    GROOV("Hud (vibecodedev was here)"), VANILLA("Minecraft HUD");
    public final String displayName;

    private HudRenderMode(String displayName) {
        this.displayName = displayName;

    }

}

