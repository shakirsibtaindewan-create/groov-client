/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.b.c;

import itz.vrgn1337.groovclient.api.backend.BackendClient;
import itz.vrgn1337.groovclient.api.backend.Session;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GlassStyle;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.api.util.render.ThemeVariant;
import itz.vrgn1337.groovclient.b.c.HudAnimation;
import itz.vrgn1337.groovclient.b.c.HudEditorScreen;
import itz.vrgn1337.groovclient.b.c.HudElementSettings;
import itz.vrgn1337.groovclient.b.c.HudWidget;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleManager;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.hit.HitResult;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.entity.player.SkinTextures;
import org.lwjgl.glfw.GLFW;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;

public class HudManager {
    private static final HudManager a = new HudManager();
    private final List<HudElementSettings> b = new CopyOnWriteArrayList();
    private static final Color c = new Color(6, 6, 8, 125);
    private static final Color d = new Color(150, 150, 150);
    private static final DateTimeFormatter e = DateTimeFormatter.ofPattern("HH:mm:ss");
    private final HudAnimation[] f = new HudAnimation[]{new HudAnimation(), new HudAnimation(), new HudAnimation(), new HudAnimation(), new HudAnimation(), new HudAnimation()};
    private boolean g;
    private static final int h = 300;
    private static final int i = 1500;
    private static final int j = 300;
    private static final int k = 2100;
    private StringConstant l = null;
    private boolean m = false;
    private long n = 0L;
    private static final float o = 3.0f;
    private List p = new ArrayList();
    private final Map<Module, Boolean> q = new HashMap<>();
    private final Map r = new HashMap();
    private static final int s = 250;
    private float t = 0.0f;
    private long u = 0L;
    private DrawContext v;

    public static HudManager getInstance() {
        return a;
    }

    public void a(Module module, boolean bl) {
        this.l = module.getName();
        this.m = bl;
        this.n = System.currentTimeMillis();
    }

    public void b() {
        Main.eventBus().register(this);
    }

    public List<HudElementSettings> c() {
        return this.b;
    }

    public void a(HudElementSettings hudElementSettings) {
        this.b.add(hudElementSettings);
    }

    public void b(HudElementSettings hudElementSettings) {
        this.b.remove(hudElementSettings);
    }

    public boolean a(HudWidget hudWidget) {
        return this.b.stream().anyMatch(arg_0 -> e.lambda$hasWidgetType$0((HudWidget)hudWidget, arg_0));
    }

    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        if (Main.mc.player == null) {
            return;
        }
        HitResult ItemStackParticleEffect = Main.mc.crosshairTarget;
        if (!(ItemStackParticleEffect instanceof EntityHitResult)) {
            return;
        }
        EntityHitResult mc26 = (EntityHitResult)ItemStackParticleEffect;
        Entity mc2 = mc26.getEntity();
        if (!(mc2 instanceof LivingEntity)) {
            return;
        }
        LivingEntity ItemStackParticleEffect_p;
        ItemStackParticleEffect_p = (LivingEntity)mc2;
        Vec3d mc2_p = Main.mc.player.getEyePos();
        Box HorizontalFacingBlock = ItemStackParticleEffect_p.getBoundingBox();
        double d2 = Math.max(HorizontalFacingBlock.minX, Math.min(mc2_p.x, HorizontalFacingBlock.maxX));
        double d3 = Math.max(HorizontalFacingBlock.minY, Math.min(mc2_p.y, HorizontalFacingBlock.maxY));
        double d4 = Math.max(HorizontalFacingBlock.minZ, Math.min(mc2_p.z, HorizontalFacingBlock.maxZ));
        double d5 = d2 - mc2_p.x;
        double d6 = d3 - mc2_p.y;
        double d7 = d4 - mc2_p.z;
        this.t = (float)Math.sqrt(d5 * d5 + d6 * d6 + d7 * d7);
        this.u = System.currentTimeMillis();
    }

    private void onRenderHUDEventPre(RenderHUDEvent.Pre renderHUDEvent$Pre) {
        if (Main.mc.player == null) {
            return;
        }
        if (Main.mc.currentScreen instanceof HudEditorScreen) {
            return;
        }
        this.v = renderHUDEvent$Pre.context;
        MatrixStack mc13 = new MatrixStack();
        for (HudElementSettings hudElementSettings : this.b) {
            this.a(mc13, hudElementSettings, false);
        }
        this.v = null;
    }

    private void a(MatrixStack mc13, HudElementSettings hudElementSettings, float f2, float f3, float f4, float f5, float f6) {
        this.a(mc13, hudElementSettings, f2, f3, f4, f5, f6, c);
    }

    private void a(MatrixStack mc13, HudElementSettings hudElementSettings, float f2, float f3, float f4, float f5, float f6, Color color) {
        if (hudElementSettings.a("glass")) {
            GlassStyle glassStyle = GlassStyle.getInstance().a(ThemeVariant.LIGHT);
            float f7 = Math.min(1.0f, (float)color.getAlpha() / (float)Math.max(1, c.getAlpha()));
            if (f7 < 0.999f) {
                Color color2 = glassStyle.d;
                Color color3 = glassStyle.i;
                glassStyle.ordinal(new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), (int)((float)color2.getAlpha() * f7)));
                glassStyle.ordinal(glassStyle.h, new Color(color3.getRed(), color3.getGreen(), color3.getBlue(), (int)((float)color3.getAlpha() * f7)));
            }
            new PanelRenderer(mc13, f2, f3, f4, f5).a(f6).a(glassStyle).j();
        } else {
            new PanelRenderer(mc13, f2, f3, f4, f5).a(color).a(14.0f, 1.0f).a(f6).j();
        }
    }

    public void a(MatrixStack mc13, HudElementSettings hudElementSettings, boolean bl) {
        Color color = MenuGuiScreen.c();
        switch (hudElementSettings.a()) {
            case CLOCK: {
                this.a(mc13, hudElementSettings, color);
                break;
            }
            case FPS: {
                this.b(mc13, hudElementSettings, color);
                break;
            }
            case PING: {
                this.c(mc13, hudElementSettings, color);
                break;
            }
            case USERNAME: {
                this.e(mc13, hudElementSettings, color);
                break;
            }
            case TARGET_HUD: {
                this.a(mc13, hudElementSettings, color, bl);
                break;
            }
            case MODULE_LIST: {
                this.f(mc13, hudElementSettings, color);
                break;
            }
            case POTIONS: {
                this.g(mc13, hudElementSettings, color);
                break;
            }
            case KEYBINDS: {
                this.h(mc13, hudElementSettings, color);
                break;
            }
            case KEYSTROKES: {
                this.i(mc13, hudElementSettings, color);
                break;
            }
            case INVENTORY: {
                this.j(mc13, hudElementSettings, color);
                break;
            }
            case ARMOR: {
                this.k(mc13, hudElementSettings, color);
                break;
            }
            case COMPASS: {
                this.l(mc13, hudElementSettings, color);
                break;
            }
            case RADAR: {
                this.b(mc13, hudElementSettings, color, bl);
                break;
            }
            case REACH: {
                this.d(mc13, hudElementSettings, color);
            }
        }
    }

    private void a(MatrixStack mc13, HudElementSettings hudElementSettings, Color color) {
        int n2;
        float f2;
        boolean bl;
        String string = LocalTime.now().format(e);
        int n3 = string.charAt(0) - 48;
        int n4 = string.charAt(1) - 48;
        int n5 = string.charAt(3) - 48;
        int n6 = string.charAt(4) - 48;
        int n7 = string.charAt(6) - 48;
        int n8 = string.charAt(7) - 48;
        if (!this.g) {
            int[] nArray = new int[]{n3, n4, n5, n6, n7, n8};
            for (int i2 = 0; i2 < 6; ++i2) {
                this.f[i2].a(nArray[i2]);
            }
            this.g = true;
        }
        this.f[0].b(n3);
        this.f[1].b(n4);
        this.f[2].b(n5);
        this.f[3].b(n6);
        this.f[4].b(n7);
        this.f[5].b(n8);
        float f3 = 10.0f;
        float f4 = FontManager.a().a(new StringConstant("0"), f3);
        float f5 = FontManager.a().b(f3);
        float f6 = FontManager.a().a(new StringConstant(":"), f3);
        float f7 = 2.0f;
        float f8 = f4 * 6.0f + f6 * 2.0f + f7 * 7.0f;
        float f9 = f8 + 16.0f;
        float f10 = f5 + 10.0f;
        float f11 = 0.0f;
        long l2 = System.currentTimeMillis() - this.n;
        boolean bl2 = bl = this.l != null && l2 < 2100L;
        if (bl) {
            if (l2 < 300L) {
                f11 = GuiRenderer.e(GuiRenderer.b((float)l2 / 300.0f, 0.0f, 1.0f));
            } else if (l2 < 1800L) {
                f11 = 1.0f;
            } else {
                f2 = (float)(l2 - 300L - 1500L) / 300.0f;
                f11 = 1.0f - GuiRenderer.e(GuiRenderer.b(f2, 0.0f, 1.0f));
            }
        }
        f2 = f10 * 0.55f;
        float f12 = 9.0f;
        float f13 = this.l != null ? FontManager.a().a(this.l, f12) : 0.0f;
        float f14 = 14.0f + f2 + 6.0f + f13 + 10.0f + f2 + 14.0f;
        f14 = Math.max(f14, f9);
        float f15 = f9 + (f14 - f9) * f11;
        hudElementSettings.c(f15);
        hudElementSettings.d(f10);
        float f16 = hudElementSettings.b() + f9 * 0.5f;
        float f17 = f16 - f15 * 0.5f;
        float f18 = hudElementSettings.c();
        float f19 = f10 / 2.0f;
        this.a(mc13, hudElementSettings, f17, f18, f15, f10, f19);
        float f20 = GuiRenderer.b(1.0f - f11 * 3.0f, 0.0f, 1.0f);
        float f21 = GuiRenderer.b(f11 * 3.0f - 1.0f, 0.0f, 1.0f);
        if (f20 > 0.01f) {
            n2 = (int)(255.0f * f20);
            Color color2 = GuiRenderer.a(Color.WHITE, n2);
            float f22 = f18 + (f10 - f5) * 0.5f;
            float f23 = f17 + (f15 - f8) * 0.5f;
            f23 = this.a(mc13, this.f[0], f23, f22, f4, f5, f3, f7, color2);
            f23 = this.a(mc13, this.f[1], f23, f22, f4, f5, f3, f7, color2);
            FontManager.a().a(mc13, new StringConstant(":"), f23, f22, f3, color2);
            f23 += f6 + f7;
            f23 = this.a(mc13, this.f[2], f23, f22, f4, f5, f3, f7, color2);
            f23 = this.a(mc13, this.f[3], f23, f22, f4, f5, f3, f7, color2);
            FontManager.a().a(mc13, new StringConstant(":"), f23, f22, f3, color2);
            f23 += f6 + f7;
            f23 = this.a(mc13, this.f[4], f23, f22, f4, f5, f3, f7, color2);
            this.a(mc13, this.f[5], f23, f22, f4, f5, f3, f7, color2);
        }
        if (f21 > 0.01f && this.l != null) {
            n2 = (int)(255.0f * f21);
            float f24 = f18 + f10 * 0.5f;
            String string2 = this.m ? "check" : "cross";
            Color color3 = this.m ? GuiRenderer.a(new Color(80, 220, 120), n2) : GuiRenderer.a(new Color(220, 80, 80), n2);
            float f25 = f17 + 12.0f;
            float f26 = f24 - f2 * 0.5f;
            GuiRenderer.a(mc13, string2, f25, f26, f2, f2, color3);
            float f27 = f25 + f2 + 6.0f;
            float f28 = f24 - FontManager.a().b(f12) * 0.5f;
            FontManager.a().a(mc13, this.l, f27, f28, f12, GuiRenderer.a(Color.WHITE, n2));
            float f29 = 4.0f;
            float f30 = f17 + f15 - 12.0f - f29;
            float f31 = f24 - f29 * 0.5f;
            Color color4 = this.m ? GuiRenderer.a(new Color(80, 220, 120), n2) : GuiRenderer.a(new Color(220, 80, 80), n2);
            new PanelRenderer(mc13, f30, f31, f29, f29).a(color4).a(f29 / 2.0f).j();
        }
    }

    private float a(MatrixStack mc13, HudAnimation hudAnimation, float f2, float f3, float f4, float f5, float f6, float f7, Color color) {
        float f8 = hudAnimation.a();
        float f9 = f3 + f8 * f5;
        float f10 = f3 - f5 + f8 * f5;
        GuiRenderer.a(f2, f3, f4 + 0.5f, f5 + 0.5f);
        FontManager.a().a(mc13, new StringConstant(Integer.toString(hudAnimation.a)), f2, f9, f6, color);
        FontManager.a().a(mc13, new StringConstant(Integer.toString(hudAnimation.b)), f2, f10, f6, color);
        GuiRenderer.b();
        return f2 + f4 + f7;
    }

    private void b(MatrixStack mc13, HudElementSettings hudElementSettings, Color color) {
        float f2 = hudElementSettings.d();
        float f3 = hudElementSettings.e();
        this.a(mc13, hudElementSettings, hudElementSettings.b(), hudElementSettings.c(), f2, f3, 6.0f);
        StringConstant stringConstant = new StringConstant(Main.mc.getCurrentFps() + " FPS");
        float f4 = 8.0f;
        float f5 = FontManager.a().a(stringConstant, f4);
        FontManager.a().a(mc13, stringConstant, hudElementSettings.b() + (f2 - f5) * 0.5f, hudElementSettings.c() + f3 * 0.5f - FontManager.a().b(f4) * 0.5f, f4, color);
    }

    private void c(MatrixStack mc13, HudElementSettings hudElementSettings, Color color) {
        Color color2;
        float f2 = hudElementSettings.d();
        float f3 = hudElementSettings.e();
        this.a(mc13, hudElementSettings, hudElementSettings.b(), hudElementSettings.c(), f2, f3, 6.0f);
        int n2 = 0;
        if (Main.mc.player != null && Main.mc.getNetworkHandler() != null && (color2 = Main.mc.getNetworkHandler().getPlayerListEntry(Main.mc.player.getUuid())) != null) {
            n2 = color2.getLatency();
        }
        color2 = n2 < 50 ? new Color(80, 220, 100) : (n2 < 100 ? color : (n2 < 200 ? new Color(220, 200, 60) : new Color(220, 60, 60)));
        StringConstant stringConstant = new StringConstant(n2 + " ms");
        float f4 = 8.0f;
        float f5 = FontManager.a().a(stringConstant, f4);
        FontManager.a().a(mc13, stringConstant, hudElementSettings.b() + (f2 - f5) * 0.5f, hudElementSettings.c() + f3 * 0.5f - FontManager.a().b(f4) * 0.5f, f4, color2);
    }

    private void d(MatrixStack mc13, HudElementSettings hudElementSettings, Color color) {
        String string = this.u > 0L ? String.format("%.2fm", Float.valueOf(this.t)) : "-.--m";
        StringConstant stringConstant = new StringConstant("Reach: " + string);
        float f2 = 8.0f;
        float f3 = 8.0f;
        float f4 = FontManager.a().a(stringConstant, f2);
        float f5 = Math.max(hudElementSettings.d(), f4 + f3 * 2.0f);
        float f6 = hudElementSettings.e();
        hudElementSettings.c(f5);
        this.a(mc13, hudElementSettings, hudElementSettings.b(), hudElementSettings.c(), f5, f6, 6.0f);
        Color color2 = this.u <= 0L ? d : (this.t <= 3.0f ? new Color(80, 220, 100) : (this.t <= 3.5f ? color : (this.t <= 4.0f ? new Color(220, 200, 60) : new Color(220, 60, 60))));
        FontManager.a().a(mc13, stringConstant, hudElementSettings.b() + (f5 - f4) * 0.5f, hudElementSettings.c() + f6 * 0.5f - FontManager.a().b(f2) * 0.5f, f2, color2);
    }

    private void e(MatrixStack mc13, HudElementSettings hudElementSettings, Color color) {
        Session session = BackendClient.getInstance().h();
        String string = session != null && session.a() != null && !session.a().isBlank() ? session.a() : (Main.mc.player != null ? Main.mc.player.getName().getString() : "Player");
        String string2 = session != null && session.b() != null && !session.b().isBlank() ? session.b() : "";
        boolean bl = !hudElementSettings.f().containsKey("show_plan") || hudElementSettings.a("show_plan");
        String string3 = bl && session != null && !string2.isBlank() ? string2 + " " + string : string;
        float f2 = 8.0f;
        float f3 = 8.0f;
        float f4 = FontManager.a().a(new StringConstant(string3), f2);
        StringConstant stringConstant = new StringConstant("Groov");
        float f5 = FontManager.a().a(stringConstant, 7.0f);
        float f6 = Math.max(hudElementSettings.d(), f3 + f5 + 4.0f + f4 + f3);
        float f7 = hudElementSettings.e();
        hudElementSettings.c(f6);
        this.a(mc13, hudElementSettings, hudElementSettings.b(), hudElementSettings.c(), f6, f7, 6.0f);
        float f8 = hudElementSettings.c() + f7 * 0.5f - FontManager.a().b(7.0f) * 0.5f;
        FontManager.a().a(mc13, stringConstant, hudElementSettings.b() + f3, f8, 7.0f, color, 1.0f, color);
        FontManager.a().a(mc13, new StringConstant(string3), hudElementSettings.b() + f3 + f5 + 4.0f, f8, 7.0f, Color.WHITE);
    }

    private void a(MatrixStack mc13, HudElementSettings hudElementSettings, Color color, boolean bl) {
        Object object;
        PlayerEntity mc6;
        PlayerEntity mc70;
        EntityHitResult mc26;
        HitResult ItemStackParticleEffect;
        LivingEntity mc58 = null;
        if (!bl && Main.mc.player != null && (ItemStackParticleEffect = Main.mc.crosshairTarget) instanceof EntityHitResult && (mc26 = (EntityHitResult) ItemStackParticleEffect).getEntity() instanceof LivingEntity) {
            LivingEntity mc71;
            mc58 = mc71 = (LivingEntity)ItemStackParticleEffect;
        }
        float f2 = hudElementSettings.d();
        float f3 = hudElementSettings.e();
        float f4 = GuiRenderer.a("hud.target.show", mc58 != null || bl ? 1.0f : 0.0f, 0.08f);
        if (f4 < 0.01f) {
            return;
        }
        int n2 = (int)((float)c.getAlpha() * f4);
        this.a(mc13, hudElementSettings, hudElementSettings.b(), hudElementSettings.c(), f2, f3, 6.0f, GuiRenderer.a(c, n2));
        float f5 = 6.0f;
        String string = mc58 != null ? mc58.getName().getString() : "Target";
        float f6 = mc58 != null ? mc58.getHealth() : 20.0f;
        float f7 = mc58 != null ? mc58.getMaxHealth() : 20.0f;
        float f8 = Math.min(1.0f, f6 / Math.max(1.0f, f7));
        int n3 = (int)(255.0f * f4);
        float f9 = f3 - f5 * 2.0f;
        float f10 = hudElementSettings.b() + f5;
        float f11 = hudElementSettings.c() + f5;
        Object object2 = mc58 instanceof PlayerEntity ? (mc70 = (PlayerEntity)mc58) : (mc6 = bl ? Main.mc.player : null);
        if (mc6 instanceof AbstractClientPlayerEntity) {
            mc70 = (AbstractClientPlayerEntity)mc6;
            if (this.v != null) {
                PlayerSkinDrawer.draw((DrawContext)this.v, (SkinTextures)mc70.getSkin(), (int)((int)f10), (int)((int)f11), (int)((int)f9));
                if (mc6.hurtTime > 0 && mc6 != Main.mc.player) {
                    int n4 = Math.min(mc6.hurtTime * 15, 100);
                    this.v.fill((int)f10, (int)f11, (int)(f10 + f9), (int)(f11 + f9), new Color(255, 0, 0, (int)((float)n4 * f4)).getRGB());
                }
            }
        }
        float f12 = f10 + f9 + f5;
        float f13 = f2 - f9 - f5 * 3.0f;
        FontManager.a().a(mc13, new StringConstant(string), f12, hudElementSettings.c() + f5, 7.5f, GuiRenderer.a(Color.WHITE, n3));
        float f14 = f12;
        float f15 = hudElementSettings.c() + f3 - f5 - 6.0f;
        float f16 = f13;
        float f17 = 4.0f;
        float f18 = f17 / 2.0f;
        new PanelRenderer(mc13, f14, f15, f16, f17).a(GuiRenderer.a(new Color(40, 40, 40), (int)(180.0f * f4))).a(f18).j();
        float f19 = GuiRenderer.a("hud.target.hp", f8, 0.08f);
        float f20 = f16 * f19;
        if (f20 > f17) {
            object = f8 > 0.5f ? new Color(80, 220, 100) : (f8 > 0.25f ? new Color(220, 200, 60) : new Color(220, 60, 60));
            new PanelRenderer(mc13, f14, f15, f20, f17).a(GuiRenderer.a((Color)object, (int)(220.0f * f4))).a(f18).j();
        }
        object = new StringConstant(String.format("%.1f", Float.valueOf(f6)));
        FontManager.a().a(mc13, (StringConstant)object, f12, f15 - FontManager.a().b(6.5f) - 2.0f, 6.5f, GuiRenderer.a(d, n3));
    }

    private void f(MatrixStack mc13, HudElementSettings hudElementSettings, Color color) {
        float f2;
        float f3;
        float f4;
        float f5;
        float f6;
        float f7;
        Object object;
        int n2;
        float f8;
        Object object2;
        Object object32;
        float f9 = 7.5f;
        float f10 = 4.0f;
        float f11 = FontManager.a().b(f9) + 2.0f;
        boolean bl = hudElementSettings.a("lowercase");
        boolean bl2 = hudElementSettings.a("rainbow");
        boolean bl3 = hudElementSettings.a("sidebar");
        boolean bl4 = hudElementSettings.a("background");
        boolean bl5 = hudElementSettings.a("animation");
        boolean bl6 = hudElementSettings.a("rounded");
        boolean bl7 = hudElementSettings.a("bg_blur");
        boolean bl8 = hudElementSettings.a("outline");
        boolean bl9 = hudElementSettings.a("outline_glow");
        boolean bl10 = hudElementSettings.a("outline_bloom");
        boolean bl11 = hudElementSettings.a("outline_shadow");
        boolean bl12 = hudElementSettings.a("text_glow");
        boolean bl13 = hudElementSettings.a("detail");
        boolean bl14 = hudElementSettings.a("blink");
        long l2 = System.currentTimeMillis();
        for (Module object32 : ModuleManager.c()) {
            boolean bl15;
            boolean bl16 = this.q.getOrDefault(object32, false);
            if (bl16 != (bl15 = object32.e())) {
                this.r.put(object32, new long[]{l2, bl15 ? 1L : 0L});
                this.q.put(object32, bl15);
            }
            if ((object2 = (long[])this.r.get(object32)) == null || object2[1] != 0L || l2 - object2[0] <= 250L) continue;
            this.r.remove(object32);
        }
        ArrayList<Module> arrayList = new ArrayList<>();
        Set<Class<?>> object32 = new HashSet<>();
        for (Module module : ModuleManager.c()) {
            if (!object32.add(module.getClass())) continue;
            if (module.isEnabled()) {
                arrayList.add(module);
                continue;
            }
            if (!bl5 || !this.r.containsKey(module) || ((long[])this.r.get(module))[1] != 0L) continue;
            arrayList.add(module);
        }
        arrayList.sort((arg_0, arg_1) -> ((HudManager)this).lambda$renderModuleList$1((float)f9, (boolean)bl, (boolean)bl13, arg_0, arg_1));
        this.p = arrayList;
        if (arrayList.isEmpty()) {
            hudElementSettings.d(0.0f);
            return;
        }
        float f12 = 0.0f;
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            object2 = (Module)iterator.next();
            object2.a();
            f8 = this.a((Module)object2, f9, bl, bl13) + f10 * 2.0f;
            if (!(f8 > f12)) continue;
            f12 = f8;
        }
        boolean bl17 = hudElementSettings.b() + hudElementSettings.d() * 0.5f > RenderScale.c() * 0.5f;
        float f13 = Math.max(60.0f, f12);
        if (bl17) {
            f8 = hudElementSettings.b() + hudElementSettings.d();
            hudElementSettings.a(f8 - f13);
        }
        hudElementSettings.c(f13);
        Color[] colorArray = MenuGuiScreen.b();
        float f14 = bl6 ? 4.0f : 0.0f;
        int n3 = arrayList.size();
        float[] fArray = new float[n3];
        float[] fArray2 = new float[n3];
        float[] fArray3 = new float[n3];
        float f15 = 0.0f;
        for (n2 = 0; n2 < n3; ++n2) {
            long[] lArray;
            object = (Module)arrayList.get(n2);
            fArray[n2] = this.a((Module)object, f9, bl, bl13) + f10 * 2.0f;
            float f16 = 1.0f;
            if (bl5 && (lArray = (long[])this.r.get(object)) != null) {
                f7 = Math.min(1.0f, (float)(l2 - lArray[0]) / 250.0f);
                float f17 = GuiRenderer.e(f7);
                f16 = lArray[1] == 1L ? f17 : 1.0f - f17;
            }
            fArray2[n2] = f16;
            fArray3[n2] = f15;
            if (!(f16 > 0.0f)) continue;
            f15 += f11 * f16;
        }
        if (bl4) {
            n2 = 0;
            float[] fArray5 = new float[n3];
            for (int i2 = 0; i2 < n3; ++i2) {
                if (!(fArray2[i2] > 0.01f)) continue;
                fArray5[n2++] = fArray[i2];
            }
            if (n2 > 0) {
                Color color2;
                float f18;
                float[] fArray4 = new float[n2];
                fArray4[0] = fArray5[0];
                for (int i3 = 1; i3 < n2; ++i3) {
                    f7 = fArray4[i3 - 1] - fArray5[i3];
                    fArray4[i3] = f7 >= 0.0f && f7 <= 3.0f ? fArray4[i3 - 1] : fArray5[i3];
                }
                float f19 = f18 = bl17 ? hudElementSettings.b() + hudElementSettings.d() : hudElementSettings.b();
                if (bl11 && !bl9 && !bl10) {
                    GuiRenderer.a(mc13, f18, hudElementSettings.c(), fArray4, f11, bl17, f14, new Color(0, 0, 0, 220), 0.0f, 10.0f, 20.0f);
                }
                if (bl10) {
                    if (bl2) {
                        float[] fArray5 = new float[1];
                        for (int i4 = 0; i4 < n2; ++i4) {
                            fArray5[0] = fArray4[i4];
                            f6 = (float)((l2 + (long)i4 * 120L) % 3000L) / 3000.0f;
                            color2 = Color.getHSBColor(f6, 0.7f, 1.0f);
                            GuiRenderer.a(mc13, f18, hudElementSettings.c() + (float)i4 * f11, fArray5, f11, bl17, f14, GuiRenderer.a(color2, 80), 0.0f, 0.0f, 16.0f);
                        }
                    } else {
                        GuiRenderer.a(mc13, f18, hudElementSettings.c(), fArray4, f11, bl17, f14, GuiRenderer.a(colorArray[0], 80), 0.0f, 0.0f, 16.0f);
                    }
                }
                if (bl9) {
                    if (bl2) {
                        float[] fArray6 = new float[1];
                        for (int i5 = 0; i5 < n2; ++i5) {
                            fArray6[0] = fArray4[i5];
                            f6 = (float)((l2 + (long)i5 * 120L) % 3000L) / 3000.0f;
                            color2 = Color.getHSBColor(f6, 0.7f, 1.0f);
                            GuiRenderer.a(mc13, f18, hudElementSettings.c() + (float)i5 * f11, fArray6, f11, bl17, f14, GuiRenderer.a(color2, 150), 0.0f, 8.0f, 0.0f);
                        }
                    } else {
                        GuiRenderer.a(mc13, f18, hudElementSettings.c(), fArray4, f11, bl17, f14, GuiRenderer.a(colorArray[0], 150), 0.0f, 8.0f, 0.0f);
                    }
                }
                if (bl8) {
                    if (bl2) {
                        float[] fArray7 = new float[1];
                        for (int i6 = 0; i6 < n2; ++i6) {
                            fArray7[0] = fArray4[i6];
                            f6 = (float)((l2 + (long)i6 * 120L) % 3000L) / 3000.0f;
                            color2 = Color.getHSBColor(f6, 0.7f, 1.0f);
                            GuiRenderer.a(mc13, f18, hudElementSettings.c() + (float)i6 * f11, fArray7, f11, bl17, f14, GuiRenderer.a(color2, 200), 1.2f, 0.0f, 0.0f);
                        }
                    } else {
                        GuiRenderer.a(mc13, f18, hudElementSettings.c(), fArray4, f11, bl17, f14, GuiRenderer.a(colorArray[0], 200), 1.2f, 0.0f, 0.0f);
                    }
                }
                if (hudElementSettings.a("glass")) {
                    for (int i7 = 0; i7 < n2; ++i7) {
                        float f20;
                        float f21;
                        float f22;
                        float f23 = fArray4[i7];
                        f6 = bl17 ? f18 - f23 : f18;
                        float f24 = hudElementSettings.c() + (float)i7 * f11;
                        f5 = i7 > 0 ? fArray4[i7 - 1] : 0.0f;
                        f4 = i7 < n2 - 1 ? fArray4[i7 + 1] : 0.0f;
                        float f25 = f23 > f5 ? f14 : 0.0f;
                        float f26 = f23 > f4 ? f14 : 0.0f;
                        float f27 = i7 == 0 ? f14 : 0.0f;
                        float f28 = f22 = i7 == n2 - 1 ? f14 : 0.0f;
                        if (bl17) {
                            f3 = f25;
                            f21 = f26;
                            f20 = f27;
                            f2 = f22;
                        } else {
                            f20 = f25;
                            f2 = f26;
                            f3 = f27;
                            f21 = f22;
                        }
                        new PanelRenderer(mc13, f6, f24, f23, f11).a(f3, f20, f21, f2).a(ThemeVariant.LIGHT).j();
                    }
                } else {
                    if (bl7) {
                        GuiRenderer.a(mc13, f18, hudElementSettings.c(), fArray4, f11, bl17, f14, 14.0f, 1.0f);
                    }
                    GuiRenderer.a(mc13, f18, hudElementSettings.c(), fArray4, f11, bl17, c, f14);
                }
            }
        }
        n2 = -1;
        int n4 = -1;
        for (int i8 = 0; i8 < n3; ++i8) {
            if (!(fArray2[i8] > 0.0f)) continue;
            if (n2 == -1) {
                n2 = i8;
            }
            n4 = i8;
        }
        float f29 = 1.5f;
        for (int i9 = 0; i9 < n3; ++i9) {
            Color color3;
            Object object4;
            Color color4;
            Module module = (Module)arrayList.get(i9);
            float f30 = fArray2[i9];
            if (f30 <= 0.0f) continue;
            f6 = fArray[i9];
            float f31 = 0.0f;
            if (bl5 && f30 < 1.0f) {
                f5 = (1.0f - f30) * (f6 + 10.0f);
                f31 = bl17 ? -f5 : f5;
            }
            f5 = bl17 ? hudElementSettings.b() + hudElementSettings.d() - f6 + f31 : hudElementSettings.b() + f31;
            f4 = hudElementSettings.c() + fArray3[i9];
            int n5 = (int)(255.0f * f30);
            Color color5 = color4 = bl2 ? Color.getHSBColor((float)((l2 + (long)i9 * 120L) % 3000L) / 3000.0f, 0.7f, 1.0f) : colorArray[i9 % colorArray.length];
            if (bl3) {
                object4 = GuiRenderer.a(color4, (int)(220.0f * f30));
                float f32 = f29 + 1.0f;
                float f33 = f3 = bl17 ? hudElementSettings.b() + hudElementSettings.d() - f32 + 1.0f : hudElementSettings.b() - 1.0f;
                if (bl6) {
                    float f34 = 0.0f;
                    float f35 = 0.0f;
                    f2 = 0.0f;
                    float f36 = 0.0f;
                    float f37 = Math.min(f14, f29);
                    if (i9 == n2) {
                        if (bl17) {
                            f35 = f37;
                        } else {
                            f34 = f37;
                        }
                    }
                    if (i9 == n4) {
                        if (bl17) {
                            f36 = f37;
                        } else {
                            f2 = f37;
                        }
                    }
                    GuiRenderer.a(mc13, f3, f4, f32, f11, f34, f35, f2, f36, (Color)object4, (Color)object4, (Color)object4, (Color)object4);
                } else {
                    new PanelRenderer(mc13, f3, f4, f32, f11).a((Color)object4).j();
                }
            }
            Object object5 = object4 = bl ? new StringConstant(module.getName().a().toLowerCase()) : module.getName();
            if (bl2) {
                f3 = (float)((l2 + (long)i9 * 120L) % 3000L) / 3000.0f;
                color3 = GuiRenderer.a(Color.getHSBColor(f3, 0.5f, 1.0f), n5);
            } else {
                color3 = GuiRenderer.a(Color.WHITE, n5);
            }
            f3 = f5 + f10;
            if (bl12) {
                FontManager.a().a(mc13, (StringConstant)object4, f3, f4 + 1.0f, f9, color3, 0.32f, color4);
            } else {
                FontManager.a().a(mc13, (StringConstant)object4, f3, f4 + 1.0f, f9, color3);
            }
            if (!bl13 || module.getSuffix() == null) continue;
            String string = bl ? module.getSuffix().a().toLowerCase() : module.getSuffix().a();
            StringConstant stringConstant = new StringConstant(" " + string);
            f2 = FontManager.a().a((StringConstant)object4, f9);
            Color color6 = bl14 && module.isBlinking() ? GuiRenderer.a(new Color(220, 60, 60), n5) : GuiRenderer.a(d, n5);
            FontManager.a().a(mc13, stringConstant, f3 + f2, f4 + 1.0f, f9, color6);
        }
        hudElementSettings.d(f15);
    }

    private float a(Module module, float f2, boolean bl, boolean bl2) {
        String string = bl ? module.getName().a().toLowerCase() : module.getName().a();
        float f3 = FontManager.a().a(new StringConstant(string), f2);
        if (bl2 && module.getSuffix() != null) {
            String string2 = bl ? module.getSuffix().a().toLowerCase() : module.getSuffix().a();
            f3 += FontManager.a().a(new StringConstant(" " + string2), f2);
        }
        return f3;
    }

    private void g(MatrixStack mc13, HudElementSettings hudElementSettings, Color color) {
        List<StatusEffectInstance> list = Main.mc.player != null ? Main.mc.player.getStatusEffects().stream().toList() : Collections.emptyList();
        float f2 = 7.0f;
        float f3 = 8.0f;
        float f4 = 6.0f;
        float f5 = 18.0f;
        float f6 = FontManager.a().b(f2) + 3.0f;
        float f7 = f5 + 4.0f + (float)Math.max(1, list.size()) * f6 + f4;
        float f8 = hudElementSettings.d();
        hudElementSettings.d(f7);
        this.a(mc13, hudElementSettings, hudElementSettings.b(), hudElementSettings.c(), f8, f7, 6.0f);
        FontManager.a().a(mc13, new StringConstant("Effects"), hudElementSettings.b() + f4, hudElementSettings.c() + f5 * 0.5f - FontManager.a().b(f3) * 0.5f, f3, color);
        this.a(mc13, hudElementSettings.b(), hudElementSettings.c() + f5, f8, color);
        float f9 = hudElementSettings.c() + f5 + 4.0f;
        if (list.isEmpty()) {
            FontManager.a().a(mc13, new StringConstant("None"), hudElementSettings.b() + f4, f9 + 1.0f, f2, d);
        } else {
            for (StatusEffectInstance mc72 : list) {
                String string = this.a(mc72);
                String string2 = this.b(mc72);
                FontManager.a().a(mc13, new StringConstant(string), hudElementSettings.b() + f4, f9 + 1.0f, f2, color);
                float f10 = FontManager.a().a(new StringConstant(string2), f2);
                FontManager.a().a(mc13, new StringConstant(string2), hudElementSettings.b() + f8 - f4 - f10, f9 + 1.0f, f2, d);
                f9 += f6;
            }
        }
    }

    private void h(MatrixStack mc13, HudElementSettings hudElementSettings, Color color) {
        ArrayList<Module> arrayList = new ArrayList<Module>();
        ModuleManager.getInstance();
        for (Module module : ModuleManager.c()) {
            if (module.getKey() <= 0) continue;
            arrayList.add(module);
        }
        float f2 = 7.0f;
        float f3 = 8.0f;
        float f4 = 6.0f;
        float f5 = 18.0f;
        float f6 = FontManager.a().b(f2) + 3.0f;
        float f7 = f5 + 4.0f + (float)Math.max(1, arrayList.size()) * f6 + f4;
        float f8 = hudElementSettings.d();
        hudElementSettings.d(f7);
        this.a(mc13, hudElementSettings, hudElementSettings.b(), hudElementSettings.c(), f8, f7, 6.0f);
        FontManager.a().a(mc13, new StringConstant("Keybinds"), hudElementSettings.b() + f4, hudElementSettings.c() + f5 * 0.5f - FontManager.a().b(f3) * 0.5f, f3, color);
        this.a(mc13, hudElementSettings.b(), hudElementSettings.c() + f5, f8, color);
        float f9 = hudElementSettings.c() + f5 + 4.0f;
        if (arrayList.isEmpty()) {
            FontManager.a().a(mc13, new StringConstant("None"), hudElementSettings.b() + f4, f9 + 1.0f, f2, d);
        } else {
            for (Module module : arrayList) {
                Color color2 = module.isEnabled() ? color : d;
                FontManager.a().a(mc13, module.getName(), hudElementSettings.b() + f4, f9 + 1.0f, f2, color2);
                StringConstant stringConstant = KeybindSetting.j(module.getKey());
                float f10 = FontManager.a().a(stringConstant, f2);
                FontManager.a().a(mc13, stringConstant, hudElementSettings.b() + f8 - f4 - f10, f9 + 1.0f, f2, color2);
                f9 += f6;
            }
        }
    }

    private void i(MatrixStack mc13, HudElementSettings hudElementSettings, Color color) {
        float f2 = 24.0f;
        float f3 = 2.0f;
        float f4 = 14.0f;
        float f5 = 18.0f;
        float f6 = f2 * 3.0f + f3 * 2.0f;
        float f7 = f2 * 2.0f + f3 * 3.0f + f4 + f5;
        hudElementSettings.c(f6);
        hudElementSettings.d(f7);
        float f8 = hudElementSettings.b();
        float f9 = hudElementSettings.c();
        long l2 = Main.mc.getWindow().getHandle();
        boolean bl = Main.mc.options.forwardKey.isPressed();
        boolean bl2 = Main.mc.options.leftKey.isPressed();
        boolean bl3 = Main.mc.options.backKey.isPressed();
        boolean bl4 = Main.mc.options.rightKey.isPressed();
        boolean bl5 = Main.mc.options.jumpKey.isPressed();
        boolean bl6 = GLFW.glfwGetMouseButton((long)l2, (int)0) == 1;
        boolean bl7 = GLFW.glfwGetMouseButton((long)l2, (int)1) == 1;
        this.a(mc13, f8 + f2 + f3, f9, f2, f2, "W", bl, color, "ks.w");
        float f10 = f9 + f2 + f3;
        this.a(mc13, f8, f10, f2, f2, "A", bl2, color, "ks.a");
        this.a(mc13, f8 + f2 + f3, f10, f2, f2, "S", bl3, color, "ks.s");
        this.a(mc13, f8 + (f2 + f3) * 2.0f, f10, f2, f2, "D", bl4, color, "ks.d");
        float f11 = f10 + f2 + f3;
        float f12 = (f6 - f3) * 0.5f;
        this.a(mc13, f8, f11, f12, f5, "LMB", bl6, color, "ks.lmb");
        this.a(mc13, f8 + f12 + f3, f11, f12, f5, "RMB", bl7, color, "ks.rmb");
        float f13 = f11 + f5 + f3;
        this.a(mc13, f8, f13, f6, f4, "---", bl5, color, "ks.space");
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, float f5, String string, boolean bl, Color color, String string2) {
        float f6 = GuiRenderer.a(string2, bl ? 1.0f : 0.0f, 0.12f);
        Color color2 = GuiRenderer.a(new Color(30, 30, 35, 130), GuiRenderer.a(color, 200), f6);
        float f7 = f6 * 1.5f;
        new PanelRenderer(mc13, f2 + f7, f3 + f7, f4 - f7 * 2.0f, f5 - f7 * 2.0f).a(color2).a(4.0f).j();
        StringConstant stringConstant = new StringConstant(string);
        float f8 = f5 > 16.0f ? 7.0f : 6.0f;
        float f9 = FontManager.a().a(stringConstant, f8);
        Color color3 = GuiRenderer.a(new Color(180, 180, 180), Color.WHITE, f6);
        FontManager.a().a(mc13, stringConstant, f2 + (f4 - f9) * 0.5f, f3 + f5 * 0.5f - FontManager.a().b(f8) * 0.5f, f8, color3);
    }

    private void j(MatrixStack mc13, HudElementSettings hudElementSettings, Color color) {
        int n2 = 9;
        int n3 = 3;
        float f2 = 18.0f;
        float f3 = 2.0f;
        float f4 = 6.0f;
        float f5 = 18.0f;
        float f6 = (float)n2 * f2 + (float)(n2 - 1) * f3;
        float f7 = (float)n3 * f2 + (float)(n3 - 1) * f3;
        float f8 = f6 + f4 * 2.0f;
        float f9 = f5 + f4 + f7 + f4;
        hudElementSettings.c(f8);
        hudElementSettings.d(f9);
        this.a(mc13, hudElementSettings, hudElementSettings.b(), hudElementSettings.c(), f8, f9, 6.0f);
        FontManager.a().a(mc13, new StringConstant("Inventory"), hudElementSettings.b() + f4, hudElementSettings.c() + f5 * 0.5f - FontManager.a().b(8.0f) * 0.5f, 8.0f, color);
        this.a(mc13, hudElementSettings.b(), hudElementSettings.c() + f5, f8, color);
        float f10 = hudElementSettings.b() + f4;
        float f11 = hudElementSettings.c() + f5 + f4;
        for (int i2 = 0; i2 < n3; ++i2) {
            for (int i3 = 0; i3 < n2; ++i3) {
                float f12 = f10 + (float)i3 * (f2 + f3);
                float f13 = f11 + (float)i2 * (f2 + f3);
                new PanelRenderer(mc13, f12, f13, f2, f2).a(new Color(18, 18, 24, 170)).a(3.0f).j();
                if (Main.mc.player == null || this.v == null) continue;
                int n4 = 9 + i2 * 9 + i3;
                ItemStack mc33 = Main.mc.player.getInventory().getStack(n4);
                if (mc33.isEmpty()) continue;
                float f14 = 0.55f;
                float f15 = 16.0f * f14;
                float f16 = f12 + (f2 - f15) * 0.5f;
                float f17 = f13 + (f2 - f15) * 0.5f;
                float f18 = RenderScale.h();
                this.v.getMatrices().pushMatrix();
                this.v.getMatrices().translate(f16 * f18, f17 * f18);
                this.v.getMatrices().scale(f14 * f18, f14 * f18);
                this.v.drawItem(mc33, 0, 0);
                this.v.getMatrices().popMatrix();
            }
        }
    }

    private void k(MatrixStack mc13, HudElementSettings hudElementSettings, Color color) {
        float f2 = 4.0f;
        float f3 = 16.0f;
        float f4 = 3.0f;
        float f5 = f2 * 2.0f + 4.0f * f3 + 3.0f * f4;
        float f6 = f3 + f2 * 2.0f;
        hudElementSettings.c(f5);
        hudElementSettings.d(f6);
        this.a(mc13, hudElementSettings, hudElementSettings.b(), hudElementSettings.c(), f5, f6, 6.0f);
        if (Main.mc.player != null && this.v != null) {
            for (int i2 = 0; i2 < 4; ++i2) {
                ItemStack mc33 = Main.mc.player.getInventory().getStack(39 - i2);
                float f7 = hudElementSettings.b() + f2 + (float)i2 * (f3 + f4);
                float f8 = hudElementSettings.c() + f2;
                if (!mc33.isEmpty()) {
                    float f9 = RenderScale.h();
                    this.v.getMatrices().pushMatrix();
                    this.v.getMatrices().translate(f7 * f9, f8 * f9);
                    this.v.getMatrices().scale(f9, f9);
                    this.v.drawItem(mc33, 0, 0);
                    this.v.getMatrices().popMatrix();
                    if (!mc33.isDamaged()) continue;
                    float f10 = 1.0f - (float)mc33.getDamage() / (float)mc33.getMaxDamage();
                    Color color2 = f10 > 0.5f ? new Color(80, 220, 100) : (f10 > 0.25f ? new Color(220, 200, 60) : new Color(220, 60, 60));
                    float f11 = f3 * f10;
                    new PanelRenderer(mc13, f7, f8 + f3 - 2.0f, f11, 1.5f).a(color2).j();
                    continue;
                }
                new PanelRenderer(mc13, f7, f8, f3, f3).a(new Color(18, 18, 24, 100)).a(2.0f).j();
            }
        }
    }

    private void l(MatrixStack mc13, HudElementSettings hudElementSettings, Color color) {
        boolean bl;
        float f2;
        float f3;
        int n2;
        float f4 = hudElementSettings.d();
        float f5 = hudElementSettings.e();
        this.a(mc13, hudElementSettings, hudElementSettings.b(), hudElementSettings.c(), f4, f5, 6.0f);
        if (Main.mc.player == null) {
            return;
        }
        float f6 = Main.mc.player.getYaw() % 360.0f;
        if (f6 < 0.0f) {
            f6 += 360.0f;
        }
        float f7 = hudElementSettings.b() + f4 * 0.5f;
        float f8 = hudElementSettings.c() + f5 * 0.5f;
        float f9 = 90.0f;
        float f10 = (f4 - 20.0f) / (f9 * 2.0f);
        new PanelRenderer(mc13, f7 - 0.5f, hudElementSettings.c() + 2.0f, 1.0f, 4.0f).a(color).j();
        GuiRenderer.a(hudElementSettings.b() + 4.0f, hudElementSettings.c(), f4 - 8.0f, f5);
        String[] stringArray = new String[]{"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        float[] fArray = new float[]{0.0f, 45.0f, 90.0f, 135.0f, 180.0f, 225.0f, 270.0f, 315.0f};
        float f11 = 7.0f;
        for (n2 = 0; n2 < stringArray.length; ++n2) {
            f3 = fArray[n2] - f6;
            if (f3 > 180.0f) {
                f3 -= 360.0f;
            }
            if (f3 < -180.0f) {
                f3 += 360.0f;
            }
            if (!(Math.abs(f3) <= f9)) continue;
            f2 = f7 + f3 * f10;
            boolean bl2 = bl = n2 % 2 == 0;
            Color color2 = n2 == 4 ? new Color(220, 60, 60) : (bl ? Color.WHITE : d);
            StringConstant stringConstant = new StringConstant(stringArray[n2]);
            float f12 = FontManager.a().a(stringConstant, f11);
            FontManager.a().a(mc13, stringConstant, f2 - f12 * 0.5f, f8 - FontManager.a().b(f11) * 0.5f, f11, color2);
        }
        for (n2 = 0; n2 < 360; n2 += 15) {
            f3 = (float)n2 - f6;
            if (f3 > 180.0f) {
                f3 -= 360.0f;
            }
            if (f3 < -180.0f) {
                f3 += 360.0f;
            }
            if (!(Math.abs(f3) <= f9)) continue;
            f2 = f7 + f3 * f10;
            boolean bl3 = bl = n2 % 45 == 0;
            if (bl) continue;
            float f13 = 3.0f;
            new PanelRenderer(mc13, f2 - 0.25f, hudElementSettings.c() + f5 - f13 - 2.0f, 0.5f, f13).a(GuiRenderer.a(d, 120)).j();
        }
        GuiRenderer.b();
    }

    private void b(MatrixStack mc13, HudElementSettings hudElementSettings, Color color, boolean bl) {
        float f2 = hudElementSettings.d();
        hudElementSettings.d(f2);
        float f3 = hudElementSettings.b() + f2 * 0.5f;
        float f4 = hudElementSettings.c() + f2 * 0.5f;
        float f5 = f2 * 0.5f;
        float f6 = 6.0f;
        this.a(mc13, hudElementSettings, hudElementSettings.b(), hudElementSettings.c(), f2, f2, f6);
        new PanelRenderer(mc13, f3 - 0.25f, hudElementSettings.c() + 4.0f, 0.5f, f2 - 8.0f).a(GuiRenderer.a(d, 40)).j();
        new PanelRenderer(mc13, hudElementSettings.b() + 4.0f, f4 - 0.25f, f2 - 8.0f, 0.5f).a(GuiRenderer.a(d, 40)).j();
        float f7 = f5 * 0.33f;
        float f8 = f5 * 0.66f;
        GuiRenderer.a(mc13, f3 - f7, f4 - f7, f7 * 2.0f, f7 * 2.0f, 0.5f, f7, GuiRenderer.a(d, 25));
        GuiRenderer.a(mc13, f3 - f8, f4 - f8, f8 * 2.0f, f8 * 2.0f, 0.5f, f8, GuiRenderer.a(d, 25));
        new PanelRenderer(mc13, f3 - 2.0f, f4 - 2.0f, 4.0f, 4.0f).a(color).a(2.0f).j();
        if (Main.mc.player == null) {
            return;
        }
        float f9 = (float)Math.toRadians(Main.mc.player.getYaw());
        float f10 = 50.0f;
        float f11 = (f5 - 6.0f) / f10;
        for (Entity mc2 : Main.mc.world.getEntities()) {
            float f12;
            float f13;
            float f14;
            float f15;
            double d2;
            double d3;
            double d4;
            if (mc2 == Main.mc.player || !(mc2 instanceof PlayerEntity) || (d4 = Math.sqrt((d3 = mc2.getX() - Main.mc.player.getX()) * d3 + (d2 = mc2.getZ() - Main.mc.player.getZ()) * d2)) > (double)f10) continue;
            float f16 = (float)Math.sin(-f9);
            float f17 = (float)Math.cos(-f9);
            float f18 = (float)(d3 * (double)f17 - d2 * (double)f16) * f11;
            float f19 = f3 + f18;
            float f20 = f19 - f3;
            float f21 = (float)Math.sqrt(f20 * f20 + (f15 = (f14 = f4 + (f13 = (float)(d3 * (double)f16 + d2 * (double)f17) * f11)) - f4) * f15);
            if (f21 > (f12 = f5 - 6.0f)) {
                float f22 = f12 / f21;
                f19 = f3 + f20 * f22;
                f14 = f4 + f15 * f22;
            }
            new PanelRenderer(mc13, f19 - 2.0f, f14 - 2.0f, 4.0f, 4.0f).a(new Color(220, 60, 60)).a(2.0f).j();
        }
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, Color color) {
        Color color2 = GuiRenderer.a(color, 0);
        float f5 = f4 / 2.0f;
        new PanelRenderer(mc13, f2 + 2.0f, f3, f5 - 2.0f, 0.5f).a(color2, color, color2, color).j();
        new PanelRenderer(mc13, f2 + f5, f3, f5 - 2.0f, 0.5f).a(color, color2, color, color2).j();
    }

    private String a(StatusEffectInstance mc72) {
        Object object = mc72.getTranslationKey().replaceAll("effect\\minecraft\\", "");
        if (!((String)object).isEmpty()) {
            object = ((String)object).substring(0, 1).toUpperCase() + ((String)object).substring(1);
        }
        object = ((String)object).replace('_', ' ');
        int n2 = mc72.getAmplifier() + 1;
        if (n2 > 1) {
            object = (String)object + " " + this.a(n2);
        }
        return object;
    }

    private String b(StatusEffectInstance mc72) {
        int n2 = mc72.getDuration() / 20;
        return String.format("%d:%02d", n2 / 60, n2 % 60);
    }

    private String a(int n2) {
        if (n2 <= 0 || n2 > 10) {
            return String.valueOf(n2);
        }
        return (new String[]{"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"})[n2 - 1];
    }

    private int lambda$renderModuleList$1(float f2, boolean bl, boolean bl2, Module module, Module module2) {
        return Float.compare(this.a(module2, f2, bl, bl2), this.a(module, f2, bl, bl2));
    }

    private static boolean lambda$hasWidgetType$0(HudWidget hudWidget, HudElementSettings hudElementSettings) {
        return hudElementSettings.a() == hudWidget;
    }
}

