/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.b.c;

import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;

final class HudAnimation {
    int a;
    int b;
    long c;
    boolean d;

    HudAnimation() {
    }

    void a(int n2) {
        this.a = n2;
        this.b = n2;
        this.d = false;
        this.c = 0L;
    }

    void b(int n2) {
        if (this.d || n2 == this.a) {
            return;
        }
        this.b = n2;
        this.c = System.currentTimeMillis();
        this.d = true;
    }

    float a() {
        if (!this.d) {
            return 1.0f;
        }
        float f2 = (float)(System.currentTimeMillis() - this.c) / 220.0f;
        if (f2 >= 1.0f) {
            this.a = this.b;
            this.d = false;
            return 1.0f;
        }
        return GuiRenderer.e(GuiRenderer.b(f2, 0.0f, 1.0f));
    }
}

