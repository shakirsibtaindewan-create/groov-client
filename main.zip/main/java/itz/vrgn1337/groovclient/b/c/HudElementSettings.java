/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.b.c;

import itz.vrgn1337.groovclient.b.c.HudWidget;
import java.util.HashMap;
import java.util.Map;

public class HudElementSettings {
    public static final String a = "rainbow";
    public static final String b = "lowercase";
    public static final String c = "sidebar";
    public static final String d = "background";
    public static final String e = "animation";
    public static final String f = "rounded";
    public static final String g = "bg_blur";
    public static final String h = "outline";
    public static final String i = "outline_glow";
    public static final String j = "outline_bloom";
    public static final String k = "outline_shadow";
    public static final String l = "text_glow";
    public static final String m = "detail";
    public static final String n = "blink";
    public static final String o = "show_plan";
    public static final String p = "glass";
    private final HudWidget q;
    private float r;
    private float s;
    private float t;
    private float u;
    private final Map v = new HashMap();

    public HudElementSettings(HudWidget hudWidget, float f2, float f3) {
        this.q = hudWidget;
        this.r = f2;
        this.s = f3;
        this.t = hudWidget.defaultW;
        this.u = hudWidget.defaultH;
        this.v.put(p, false);
        if (hudWidget == HudWidget.MODULE_LIST) {
            this.v.put(a, true);
            this.v.put(b, false);
            this.v.put(c, true);
            this.v.put(d, true);
            this.v.put(e, true);
            this.v.put(f, true);
            this.v.put(g, true);
            this.v.put(h, false);
            this.v.put(i, false);
            this.v.put(j, false);
            this.v.put(k, false);
            this.v.put(l, false);
            this.v.put(m, true);
            this.v.put(n, true);
        } else if (hudWidget == HudWidget.USERNAME) {
            this.v.put(o, false);
        }
    }

    public HudWidget a() {
        return this.q;
    }

    public float b() {
        return this.r;
    }

    public float c() {
        return this.s;
    }

    public float d() {
        return this.t;
    }

    public float e() {
        return this.u;
    }

    public void a(float f2) {
        this.r = f2;
    }

    public void b(float f2) {
        this.s = f2;
    }

    public void c(float f2) {
        this.t = f2;
    }

    public void d(float f2) {
        this.u = f2;
    }

    public boolean a(String string) {
        return this.v.getOrDefault(string, false);
    }

    public void a(String string, boolean bl) {
        this.v.put(string, bl);
    }

    public void b(String string) {
        this.v.put(string, !this.a(string));
    }

    public Map f() {
        return this.v;
    }
}

