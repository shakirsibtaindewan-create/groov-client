/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

public final class FriendEntry {
    public final String a;
    public final String b;
    public final boolean c;
    public final String d;

    public FriendEntry(String string, String string2, boolean bl, String string3) {
        this.a = string;
        this.b = string2;
        this.c = bl;
        this.d = string3;
    }
}

