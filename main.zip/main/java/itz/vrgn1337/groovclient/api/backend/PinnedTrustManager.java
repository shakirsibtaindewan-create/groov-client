/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

import itz.vrgn1337.groovclient.api.backend.CryptoUtils;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Set;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.X509ExtendedTrustManager;

class PinnedTrustManager
extends X509ExtendedTrustManager {
    final Set a;

    PinnedTrustManager(Set set) {
        this.a = set;
    }

    @Override
    public void checkClientTrusted(X509Certificate[] x509CertificateArray, String string) throws CertificateException {
        throw new CertificateException("");
    }

    @Override
    public void checkClientTrusted(X509Certificate[] x509CertificateArray, String string, Socket socket) throws CertificateException {
        throw new CertificateException("");
    }

    @Override
    public void checkClientTrusted(X509Certificate[] x509CertificateArray, String string, SSLEngine sSLEngine) throws CertificateException {
        throw new CertificateException("");
    }

    @Override
    public X509Certificate[] getAcceptedIssuers() {
        return new X509Certificate[0];
    }

    private void a(X509Certificate[] x509CertificateArray) throws CertificateException {
        if (x509CertificateArray == null || x509CertificateArray.length == 0) {
            throw new CertificateException("");
        }
        try {
            for (X509Certificate x509Certificate : x509CertificateArray) {
                byte[] byArray = x509Certificate.getPublicKey().getEncoded();
                byte[] byArray2 = MessageDigest.getInstance("SHA-256").digest(byArray);
                String string = CryptoUtils.c(byArray2);
                if (!this.a.contains(string)) continue;
                x509Certificate.checkValidity();
                return;
            }
        }
        catch (Exception exception) {
            throw new CertificateException("");
        }
        throw new CertificateException("");
    }

    @Override
    public void checkServerTrusted(X509Certificate[] x509CertificateArray, String string) throws CertificateException {
        this.a(x509CertificateArray);
    }

    @Override
    public void checkServerTrusted(X509Certificate[] x509CertificateArray, String string, Socket socket) throws CertificateException {
        this.a(x509CertificateArray);
    }

    @Override
    public void checkServerTrusted(X509Certificate[] x509CertificateArray, String string, SSLEngine sSLEngine) throws CertificateException {
        this.a(x509CertificateArray);
    }
}

