/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

public final class StringCodec {
    private static final int[] a = new int[]{90, 195, 23, 142, 66, 255, 1, 157, 107, 36, 171, 112, 56, 233, 79, 18};

    private StringCodec() {
    }

    public static String a(int[] nArray) {
        char[] cArray = new char[nArray.length];
        for (int j = 0; j < nArray.length; ++j) {
            cArray[j] = (char)((nArray[j] ^ a[j % a.length]) & 0xFF);
        }
        return new String(cArray);
    }

    public static int[] a(String string) {
        int[] nArray = new int[string.length()];
        for (int j = 0; j < string.length(); ++j) {
            nArray[j] = string.charAt(j) & 0xFF ^ a[j % a.length];
        }
        return nArray;
    }
}

