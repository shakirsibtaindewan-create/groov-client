/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

public final class Session {
    private final String a;
    private final String b;
    private final long c;

    public Session(String string, String string2) {
        this.a = string;
        this.b = string2;
        this.c = System.currentTimeMillis();
    }

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public long c() {
        return this.c;
    }

    public boolean a(String string) {
        int[] nArray = new int[]{Session.b(this.b()), Session.b(string)};
        return nArray[0] >= nArray[1];
    }

    private static int b(String string) {
        return switch (string == null ? "None" : string) {
            case "Basic" -> 1;
            case "Pro" -> 2;
            case "Elite" -> 3;
            default -> 0;
        };
    }

    public String toString() {
        return "Session{username='" + this.a + "', plan='" + this.b + "'}";
    }
}

