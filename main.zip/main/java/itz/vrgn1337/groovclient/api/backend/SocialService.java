/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

import itz.vrgn1337.groovclient.api.backend.ConnectionState;
import itz.vrgn1337.groovclient.api.backend.DirectMessage;
import itz.vrgn1337.groovclient.api.backend.FriendEntry;
import itz.vrgn1337.groovclient.api.backend.WebSocketClient;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;

public final class SocialService {
    private static final SocialService a = new SocialService();
    private volatile Consumer b = null;
    private volatile Consumer c = null;
    private volatile Consumer d = null;
    private volatile Consumer e = null;
    private volatile Consumer f = null;
    private volatile Consumer g = null;
    private final CopyOnWriteArrayList h = new CopyOnWriteArrayList();
    private final CopyOnWriteArrayList<Consumer> i = new CopyOnWriteArrayList();

    public static SocialService getInstance() {
        return a;
    }

    private SocialService() {
    }

    public List b() {
        return Collections.unmodifiableList(this.h);
    }

    public void a(Consumer consumer) {
        if (consumer != null) {
            this.i.add(consumer);
        }
    }

    public void b(Consumer consumer) {
        this.i.remove(consumer);
    }

    public void a(Consumer consumer, Consumer consumer2) {
        if (!this.c(consumer2)) {
            return;
        }
        this.b = consumer;
        this.g = consumer2;
        WebSocketClient.getInstance().a("{\"type\":\"friend_list_users\"}");
    }

    public void a(String string, String string2, Consumer consumer, Consumer consumer2) {
        if (!this.c(consumer2)) {
            return;
        }
        this.c = consumer;
        this.g = consumer2;
        WebSocketClient.getInstance().a("{\"type\":\"friend_add_user\",\"username\":\"" + SocialService.d(string) + "\",\"alias\":\"" + SocialService.d(string2) + "\"}");
    }

    public void a(String string, Consumer consumer, Consumer consumer2) {
        if (!this.c(consumer2)) {
            return;
        }
        this.d = consumer;
        this.g = consumer2;
        WebSocketClient.getInstance().a("{\"type\":\"friend_remove_user\",\"username\":\"" + SocialService.d(string) + "\"}");
    }

    public void a(boolean bl, boolean bl2) {
        if (WebSocketClient.getInstance().c() != ConnectionState.CONNECTED) {
            return;
        }
        String string = bl ? "always_offline" : "online";
        WebSocketClient.getInstance().a("{\"type\":\"privacy_mode_set\",\"mode\":\"" + string + "\",\"ghost_mode\":" + bl2 + "}");
    }

    public void b(String string, String string2, Consumer consumer, Consumer consumer2) {
        if (!this.c(consumer2)) {
            return;
        }
        this.e = consumer;
        this.g = consumer2;
        WebSocketClient.getInstance().a("{\"type\":\"dm_send\",\"to\":\"" + SocialService.d(string) + "\",\"message\":\"" + SocialService.d(string2) + "\"}");
    }

    public void a(String string, int n2, Consumer consumer, Consumer consumer2) {
        if (!this.c(consumer2)) {
            return;
        }
        this.f = consumer;
        this.g = consumer2;
        int n3 = Math.max(1, Math.min(n2, 100));
        WebSocketClient.getInstance().a("{\"type\":\"dm_history\",\"with\":\"" + SocialService.d(string) + "\",\"limit\":" + n3 + "}");
    }

    public void a(String string, String string2) {
        switch (string) {
            case "friend_list_users_result": {
                this.getInstance(string2);
                break;
            }
            case "friend_add_user_result": {
                this.a( ((SocialService)this).lambda$onMessage$0());
                break;
            }
            case "friend_remove_user_result": {
                this.a( ((SocialService)this).lambda$onMessage$1());
                break;
            }
            case "dm_send_result": {
                this.a( ((SocialService)this).lambda$onMessage$2());
                break;
            }
            case "dm_history_result": {
                this.b(string2);
                break;
            }
            case "dm_receive": {
                this.c(string2);
                break;
            }
            case "error": {
                this.a( ((SocialService)this).lambda$onMessage$3((String)string2));
            }
        }
    }

    private void a(String string) {
        CopyOnWriteArrayList<FriendEntry> copyOnWriteArrayList = new CopyOnWriteArrayList<FriendEntry>();
        int n2 = string.indexOf("[");
        int n3 = string.lastIndexOf("]");
        if (n2 >= 0 && n3 >= n2) {
            String string2 = string.substring(n2 + 1, n3);
            for (String string3 : SocialService.e(string2)) {
                String string4 = SocialService.b(string3, "username");
                if (string4 == null) {
                    string4 = WebSocketClient.a(string3, "username");
                }
                if (string4 == null) continue;
                String string5 = SocialService.b(string3, "alias");
                if (string5 == null) {
                    string5 = "";
                }
                boolean bl = "true".equalsIgnoreCase(WebSocketClient.a(string3, "online"));
                String string6 = SocialService.b(string3, "created_at");
                copyOnWriteArrayList.add(new FriendEntry(string4, string5, bl, string6 != null ? string6 : ""));
            }
        }
        this.a( ((SocialService)this).lambda$handleFriendList$4(copyOnWriteArrayList));
    }

    private void b(String string) {
        CopyOnWriteArrayList<DirectMessage> copyOnWriteArrayList = new CopyOnWriteArrayList<DirectMessage>();
        int n2 = string.indexOf("[");
        int n3 = string.lastIndexOf("]");
        if (n2 >= 0 && n3 >= n2) {
            String string2 = string.substring(n2 + 1, n3);
            for (String string3 : SocialService.e(string2)) {
                long l2 = SocialService.f(WebSocketClient.a(string3, "id"));
                String string4 = SocialService.b(string3, "sender");
                String string5 = SocialService.b(string3, "receiver");
                String string6 = SocialService.b(string3, "message");
                String string7 = SocialService.b(string3, "created_at");
                copyOnWriteArrayList.add(new DirectMessage(l2, string4 != null ? string4 : "", string5 != null ? string5 : "", string6 != null ? string6 : "", string7 != null ? string7 : ""));
            }
        }
        this.a( ((SocialService)this).lambda$handleDmHistory$5(copyOnWriteArrayList));
    }

    private void c(String string) {
        String string2 = SocialService.b(string, "from");
        if (string2 == null) {
            string2 = WebSocketClient.a(string, "from");
        }
        String string3 = SocialService.b(string, "message");
        String string4 = SocialService.b(string, "created_at");
        DirectMessage directMessage = new DirectMessage(-1L, string2 != null ? string2 : "", "", string3 != null ? string3 : "", string4 != null ? string4 : "");
        this.a(() -> ((SocialService)this).lambda$handleDmReceive$6((DirectMessage)directMessage));
    }

    private boolean c(Consumer consumer) {
        if (WebSocketClient.getInstance().c() != ConnectionState.CONNECTED) {
            if (consumer != null) {
                consumer.accept("Not connected");
            }
            return false;
        }
        return true;
    }

    private void c() {
        this.b = null;
        this.c = null;
        this.d = null;
        this.e = null;
        this.f = null;
        this.g = null;
    }

    private static String d(String string) {
        if (string == null) {
            return "";
        }
        return string.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    private static List<String> e(String string) {
        CopyOnWriteArrayList<String> copyOnWriteArrayList = new CopyOnWriteArrayList<String>();
        int n2 = 0;
        int n3 = -1;
        for (int i = 0; i < string.length(); ++i) {
            char c2 = string.charAt(i);
            if (c2 == '{') {
                if (n2++ != 0) continue;
                n3 = i;
                continue;
            }
            if (c2 != '}' || --n2 != 0 || n3 < 0) continue;
            copyOnWriteArrayList.add(string.substring(n3, i + 1));
            n3 = -1;
        }
        return copyOnWriteArrayList;
    }

    private static String b(String string, String string2) {
        String string3 = "\"" + string2 + "\"";
        int n2 = string.indexOf(string3);
        if (n2 < 0) {
            return null;
        }
        n2 += string3.length();
        while (n2 < string.length() && (string.charAt(n2) == ' ' || string.charAt(n2) == ':')) {
            ++n2;
        }
        if (n2 >= string.length() || string.charAt(n2) != '\"') {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        ++n2;
        while (n2 < string.length()) {
            char c2 = string.charAt(n2);
            if (c2 == '\\' && n2 + 1 < string.length()) {
                char c3 = string.charAt(n2 + 1);
                stringBuilder.append(switch (c3) {
                    case '\"' -> '\"';
                    case '\\' -> '\\';
                    case 'n' -> '\n';
                    case 'r' -> '\r';
                    case 't' -> '\t';
                    default -> c3;
                });
                n2 += 2;
                continue;
            }
            if (c2 == '\"') break;
            stringBuilder.append(c2);
            ++n2;
        }
        return stringBuilder.toString();
    }

    private static long f(String string) {
        if (string == null) {
            return -1L;
        }
        try {
            return Long.parseLong(string.trim());
        }
        catch (Exception exception) {
            return -1L;
        }
    }

    private static void a(Runnable runnable) {
        MinecraftClient.getInstance().execute(runnable);
    }

    private void lambda$handleDmReceive$6(DirectMessage directMessage) {
        for (Consumer consumer : this.i) {
            try {
                consumer.accept(directMessage);
            }
            catch (Exception exception) {}
        }
    }

    private void lambda$handleDmHistory$5(List list) {
        Consumer consumer = this.f;
        this.f = null;
        if (consumer != null) {
            consumer.accept(List.copyOf(list));
        }
    }

    private void lambda$handleFriendList$4(List list) {
        this.h.clear();
        this.h.addAll(list);
        Consumer consumer = this.b;
        this.b = null;
        if (consumer != null) {
            consumer.accept(List.copyOf(list));
        }
    }

    private void lambda$onMessage$3(String string) {
        String string2 = WebSocketClient.a(string, "detail");
        Consumer consumer = this.g;
        this.c();
        if (consumer != null) {
            consumer.accept(string2 != null ? string2 : "error");
        }
    }

    private void lambda$onMessage$2() {
        Consumer consumer = this.e;
        this.e = null;
        if (consumer != null) {
            consumer.accept("ok");
        }
    }

    private void lambda$onMessage$1() {
        Consumer consumer = this.d;
        this.d = null;
        if (consumer != null) {
            consumer.accept("ok");
        }
    }

    private void lambda$onMessage$0() {
        Consumer consumer = this.c;
        this.c = null;
        if (consumer != null) {
            consumer.accept("ok");
        }
    }
}

