/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

public final class DirectMessage {
    public final long a;
    public final String b;
    public final String c;
    public final String d;
    public final String e;

    public DirectMessage(long l2, String string, String string2, String string3, String string4) {
        this.a = l2;
        this.b = string;
        this.c = string2;
        this.d = string3;
        this.e = string4;
    }
}

