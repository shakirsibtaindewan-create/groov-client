/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class CryptoUtils {
    public static final byte[] a = new byte[]{122, 63, -31, -68, 77, -110, 8, -11, 108, 27, -87, 87, 48, -28};

    private CryptoUtils() {
    }

    public static String a(byte[] byArray, String string, long l2) throws Exception {
        return CryptoUtils.a(byArray, string, l2, null);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static String a(byte[] byArray, String string, long l2, byte[] byArray2) throws Exception {
        byte[] byArray3 = CryptoUtils.b(byArray);
        try {
            byte[] byArray4 = CryptoUtils.a(string);
            byte[] byArray5 = ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN).putLong(l2).array();
            int n2 = byArray2 != null ? byArray2.length : 0;
            byte[] byArray6 = new byte[a.length + byArray4.length + byArray5.length + n2];
            int n3 = 0;
            System.arraycopy(a, 0, byArray6, n3, a.length);
            System.arraycopy(byArray4, 0, byArray6, n3 += a.length, byArray4.length);
            System.arraycopy(byArray5, 0, byArray6, n3 += byArray4.length, byArray5.length);
            n3 += byArray5.length;
            if (n2 > 0) {
                System.arraycopy(byArray2, 0, byArray6, n3, n2);
            }
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(byArray3, "HmacSHA256"));
            byte[] byArray7 = mac.doFinal(byArray6);
            Arrays.fill(byArray6, (byte)0);
            String string2 = CryptoUtils.c(byArray7);
            return string2;
        }
        finally {
            Arrays.fill(byArray3, (byte)0);
        }
    }

    public static String a(byte[] byArray) throws Exception {
        return CryptoUtils.c(CryptoUtils.b(byArray));
    }

    public static byte[] b(byte[] byArray) throws Exception {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        return messageDigest.digest(byArray);
    }

    public static String c(byte[] byArray) {
        char[] cArray = new char[byArray.length * 2];
        char[] cArray2 = "0123456789abcdef".toCharArray();
        for (int i = 0; i < byArray.length; ++i) {
            int n2 = byArray[i] & 0xFF;
            cArray[i * 2] = cArray2[n2 >>> 4];
            cArray[i * 2 + 1] = cArray2[n2 & 0xF];
        }
        return new String(cArray);
    }

    public static byte[] a(String string) {
        int n2 = string.length();
        if ((n2 & 1) != 0) {
            throw new IllegalArgumentException();
        }
        byte[] byArray = new byte[n2 / 2];
        for (int i = 0; i < n2; i += 2) {
            byArray[i / 2] = (byte)(CryptoUtils.a(string.charAt(i)) << 4 | CryptoUtils.a(string.charAt(i + 1)));
        }
        return byArray;
    }

    private static int a(char c2) {
        if (c2 >= '0' && c2 <= '9') {
            return c2 - 48;
        }
        if (c2 >= 'a' && c2 <= 'f') {
            return 10 + (c2 - 97);
        }
        if (c2 >= 'A' && c2 <= 'F') {
            return 10 + (c2 - 65);
        }
        throw new IllegalArgumentException();
    }

    public static byte[] a(char[] cArray) {
        byte[] byArray = new byte[cArray.length];
        for (int i = 0; i < cArray.length; ++i) {
            char c2 = cArray[i];
            if (c2 > '\u007f') {
                return new String(cArray).getBytes(StandardCharsets.UTF_8);
            }
            byArray[i] = (byte)c2;
        }
        return byArray;
    }
}

