/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

import itz.vrgn1337.groovclient.api.backend.CryptoUtils;
import java.io.File;
import java.io.FileInputStream;
import java.lang.management.ManagementFactory;
import java.net.URI;
import java.security.CodeSource;
import java.security.MessageDigest;
import java.security.ProtectionDomain;
import java.util.List;

public final class AntiDebug {
    private static volatile String a = null;
    private static final byte[] b = new byte[]{75, -115, 42, -25, -15, 54, -55, 80, 126, -78, -108, 97, 3, -38, 95, -120};

    private AntiDebug() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static String a() {
        String string = a;
        if (string != null) {
            return string;
        }
        Class<AntiDebug> clazz = AntiDebug.class;
        synchronized (AntiDebug.class) {
            if (a != null) {
                // ** MonitorExit[var1_1] (shouldn't be in output)
                return a;
            }
            a = AntiDebug.b();
            // ** MonitorExit[var1_1] (shouldn't be in output)
            return a;
        }
    }

    private static String b() {
        try {
            CodeSource codeSource;
            ProtectionDomain protectionDomain = AntiDebug.class.getProtectionDomain();
            CodeSource codeSource2 = codeSource = protectionDomain != null ? protectionDomain.getCodeSource() : null;
            if (codeSource == null || codeSource.getLocation() == null) {
                return AntiDebug.c();
            }
            URI uRI = codeSource.getLocation().toURI();
            File file = new File(uRI);
            if (!file.exists() || file.isDirectory()) {
                return AntiDebug.c();
            }
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            try (FileInputStream fileInputStream = new FileInputStream(file);){
                int n2;
                byte[] byArray = new byte[65536];
                while ((n2 = fileInputStream.read(byArray)) != -1) {
                    messageDigest.update(byArray, 0, n2);
                }
            }
            return CryptoUtils.c(messageDigest.digest());
        }
        catch (Exception exception) {
            return AntiDebug.c();
        }
    }

    private static String c() {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            return CryptoUtils.c(messageDigest.digest(b));
        }
        catch (Exception exception) {
            return "0000000000000000000000000000000000000000000000000000000000000000";
        }
    }

    public static boolean d() {
        try {
            List<String> list = ManagementFactory.getRuntimeMXBean().getInputArguments();
            for (String string : list) {
                String string2;
                if (string == null || !(string2 = string.toLowerCase()).contains("-agentlib:jdwp") && !string2.contains("-agentpath:") && !string2.startsWith("-javaagent:") && !string2.contains("xrunjdwp")) continue;
                return true;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }
}

