/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

import itz.vrgn1337.groovclient.api.backend.AntiDebug;
import itz.vrgn1337.groovclient.api.backend.AuthState;
import itz.vrgn1337.groovclient.api.backend.ConnectionState;
import itz.vrgn1337.groovclient.api.backend.ReflectionUtils;
import itz.vrgn1337.groovclient.api.backend.SecretStore;
import itz.vrgn1337.groovclient.api.backend.Session;
import itz.vrgn1337.groovclient.api.backend.SocialService;
import itz.vrgn1337.groovclient.api.backend.WebSocketClient;
import itz.vrgn1337.groovclient.api.util.protection.NativeObfuscate;
import itz.vrgn1337.groovclient.config.ClientSettings;
import itz.vrgn1337.groovclient.config.ConfigManager;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;

public final class BackendClient {
    private static final BackendClient a = new BackendClient();
    private volatile AuthState b = AuthState.LOGGED_OUT;
    private volatile Session c = null;
    private volatile String d = null;
    private final CopyOnWriteArrayList<Consumer> e = new CopyOnWriteArrayList();
    private volatile long f = System.currentTimeMillis();
    private ScheduledExecutorService g;
    private static final long h = 180000L;
    private static final long i = 20000L;

    public static BackendClient getInstance() {
        return a;
    }

    private BackendClient() {
    }

    public void b() {
        this.l();
        this.c();
    }

    private void c() {
        if (this.g != null) {
            return;
        }
        this.g = Executors.newSingleThreadScheduledExecutor((arg_0) -> ((BackendClient)this).lambda$startAuthWatchdog$0(arg_0));
        this.g.scheduleWithFixedDelay(() -> ((BackendClient)this).lambda$startAuthWatchdog$1(), 20000L, 20000L, TimeUnit.MILLISECONDS);
    }

    public void d() {
        if (this.i() || this.b == AuthState.CONNECTING || this.b == AuthState.AUTHENTICATED) {
            return;
        }
        if (AntiDebug.d()) {
            this.d = "tamper_detected";
            this.a(AuthState.ERROR);
            return;
        }
        String string = null;
        try {
            string = MinecraftClient.getInstance().keyboard.getClipboard();
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        if (string != null && !string.isEmpty()) {
            char[] cArray = BackendClient.b(string.toCharArray());
            try {
                if (BackendClient.getInstance(cArray)) {
                    SecretStore.getInstance().a(cArray);
                    this.k();
                    return;
                }
            }
            finally {
                Arrays.fill(cArray, '\u0000');
            }
        }
        SecretStore.getInstance().c();
        this.k();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean e() {
        if (AntiDebug.d()) {
            this.d = "tamper_detected";
            this.a(AuthState.ERROR);
            return false;
        }
        String string = MinecraftClient.getInstance().keyboard.getClipboard();
        if (string == null || string.isEmpty()) {
            this.d = "invalid_key";
            this.a(AuthState.ERROR);
            return false;
        }
        char[] cArray = string.toCharArray();
        cArray = BackendClient.b(cArray);
        try {
            if (!BackendClient.getInstance(cArray)) {
                this.d = "invalid_key";
                this.a(AuthState.ERROR);
                boolean bl = false;
                return bl;
            }
            SecretStore.getInstance().a(cArray);
            boolean bl = this.k();
            return bl;
        }
        finally {
            Arrays.fill(cArray, '\u0000');
        }
    }

    public void f() {
        WebSocketClient.getInstance().e();
        SecretStore.getInstance().c();
        this.c = null;
        this.d = null;
        this.a(AuthState.LOGGED_OUT);
    }

    public AuthState g() {
        return this.b;
    }

    public Session h() {
        return this.c;
    }

    public boolean i() {
        return this.b == AuthState.AUTHENTICATED;
    }

    public String j() {
        return this.d;
    }

    public void a(Consumer consumer) {
        this.e.add(consumer);
    }

    public void b(Consumer consumer) {
        this.e.remove(consumer);
    }

    private boolean k() {
        if (WebSocketClient.getInstance().c() != ConnectionState.DISCONNECTED) {
            WebSocketClient.getInstance().e();
        }
        this.a(AuthState.CONNECTING);
        WebSocketClient.getInstance().d();
        return true;
    }

    private void l() {
        WebSocketClient webSocketClient = WebSocketClient.getInstance();
        webSocketClient.u = arg_0 -> ((BackendClient)this).lambda$wireWebSocket$4(arg_0);
        webSocketClient.x = () -> ((BackendClient)this).lambda$wireWebSocket$5();
        webSocketClient.w = arg_0 -> ((BackendClient)this).lambda$wireWebSocket$6(arg_0);
        webSocketClient.v = arg_0 -> ((BackendClient)this).getInstance(arg_0);
    }

    private void a(String string) {
        String string2 = WebSocketClient.a(string, "type");
        if (string2 == null) {
            return;
        }
        switch (string2) {
            case "config": {
                String string3 = WebSocketClient.a(string, "data");
                if (string3 == null) break;
                MinecraftClient.getInstance().execute(() -> ((BackendClient)this).lambda$dispatchServerMessage$7());
                break;
            }
        }
    }

    private void a(AuthState authState) {
        AuthState authState2 = this.b;
        this.b = authState;
        if (authState == AuthState.AUTHENTICATED) {
            this.f = 0L;
        } else if (authState2 == AuthState.AUTHENTICATED || this.f == 0L) {
            this.f = System.currentTimeMillis();
        }
        for (Consumer consumer : this.e) {
            try {
                consumer.accept(authState);
            }
            catch (Exception exception) {}
        }
    }

    @NativeObfuscate
    private static boolean a(char[] cArray) {
        if (cArray == null || cArray.length != 64) {
            return false;
        }
        for (char c2 : cArray) {
            if (c2 >= '0' && c2 <= '9' || c2 >= 'a' && c2 <= 'f') continue;
            return false;
        }
        return true;
    }

    private static char[] b(char[] cArray) {
        int n2;
        int n3 = cArray.length;
        for (n2 = 0; n2 < n3 && cArray[n2] <= ' '; ++n2) {
        }
        while (n3 > n2 && cArray[n3 - 1] <= ' ') {
            --n3;
        }
        if (n2 == 0 && n3 == cArray.length) {
            return cArray;
        }
        char[] cArray2 = Arrays.copyOfRange(cArray, n2, n3);
        Arrays.fill(cArray, '\u0000');
        return cArray2;
    }

    private static void lambda$dispatchServerMessage$7() {
    }

    private void lambda$wireWebSocket$6(String string) {
        this.d = string;
        if (string != null && string.startsWith("Kicked")) {
            SecretStore.getInstance().c();
            this.c = null;
            this.a(AuthState.LOGGED_OUT);
        } else {
            this.a(AuthState.ERROR);
        }
    }

    private void lambda$wireWebSocket$5() {
        this.c = null;
        if (this.b == AuthState.AUTHENTICATED || this.b == AuthState.CONNECTING) {
            this.a(AuthState.CONNECTING);
        }
    }

    private void lambda$wireWebSocket$4(Session session) {
        this.c = session;
        this.d = null;
        this.a(AuthState.AUTHENTICATED);
        ConfigManager.getInstance().a(null, null);
        ClientSettings.getInstance().o();
        SocialService.getInstance().getInstance(this::lambda$wireWebSocket$2, this::lambda$wireWebSocket$3);
    }

    private static void lambda$wireWebSocket$3(String string) {
    }

    private static void lambda$wireWebSocket$2(List list) {
    }

    private void lambda$startAuthWatchdog$1() {
        try {
            if (this.b == AuthState.AUTHENTICATED) {
                return;
            }
            long l2 = this.f;
            if (l2 == 0L) {
                return;
            }
            long l3 = System.currentTimeMillis() - l2;
            if (l3 < 180000L) {
                return;
            }
            ReflectionUtils.a(26952, 3735928559L);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static Thread lambda$startAuthWatchdog$0(Runnable runnable) {
        Thread thread = new Thread(runnable);
        thread.setDaemon(true);
        return thread;
    }
}

