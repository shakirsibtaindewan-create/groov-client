/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

import itz.vrgn1337.groovclient.api.backend.CryptoUtils;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.invoke.CallSite;
import java.net.NetworkInterface;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;

public final class HardwareId {
    private static volatile String a = null;
    private static volatile String b = null;

    private HardwareId() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static String a() {
        if (a != null) {
            return a;
        }
        Class<HardwareId> clazz = HardwareId.class;
        synchronized (HardwareId.class) {
            if (a != null) {
                // ** MonitorExit[var0] (shouldn't be in output)
                return a;
            }
            a = HardwareId.c();
            // ** MonitorExit[var0] (shouldn't be in output)
            return a;
        }
    }

    public static String b() {
        if (b != null) {
            return b;
        }
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] byArray = messageDigest.digest(HardwareId.a().getBytes(StandardCharsets.UTF_8));
            b = CryptoUtils.c(byArray);
        }
        catch (Exception exception) {
            b = "0".repeat(64);
        }
        return b;
    }

    private static String c() {
        String string;
        ArrayList<CallSite> arrayList = new ArrayList<CallSite>();
        arrayList.addAll(HardwareId.d());
        String string2 = HardwareId.e();
        if (string2 != null) {
            arrayList.add((CallSite)((Object)("WIN:" + string2)));
        }
        if ((string = HardwareId.f()) != null) {
            arrayList.add((CallSite)((Object)("LIN:" + string)));
        }
        String string3 = System.getProperty("os.name", "unknown").toLowerCase(Locale.ROOT);
        String string4 = System.getProperty("os.arch", "unknown").toLowerCase(Locale.ROOT);
        arrayList.add((CallSite)((Object)("OS:" + string3 + "/" + string4)));
        return String.join((CharSequence)"|", arrayList);
    }

    private static List d() {
        ArrayList<String> arrayList = new ArrayList<String>();
        try {
            Enumeration<NetworkInterface> enumeration = NetworkInterface.getNetworkInterfaces();
            if (enumeration == null) {
                return arrayList;
            }
            while (enumeration.hasMoreElements()) {
                NetworkInterface networkInterface = enumeration.nextElement();
                try {
                    if (networkInterface.isLoopback() || networkInterface.isVirtual()) continue;
                    if (!networkInterface.isUp()) {
                    }
                }
                catch (Exception exception) {}
                continue;
                byte[] byArray = networkInterface.getHardwareAddress();
                if (byArray == null || byArray.length == 0) continue;
                StringBuilder stringBuilder = new StringBuilder(byArray.length * 2);
                for (byte by : byArray) {
                    stringBuilder.append(String.format("%02X", by));
                }
                arrayList.add(stringBuilder.toString());
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        Collections.sort(arrayList);
        return arrayList;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static String e() {
        String string = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (!string.contains("win")) {
            return null;
        }
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("reg", "query", "HKLM\\SOFTWARE\\Microsoft\\Cryptography", "/v", "MachineGuid");
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));){
                String string2;
                while ((string2 = bufferedReader.readLine()) != null) {
                    String string3;
                    int n2 = (string2 = string2.trim()).indexOf("REG_SZ");
                    if (n2 < 0 || (string3 = string2.substring(n2 + "REG_SZ".length()).trim()).isEmpty()) continue;
                    String string4 = string3.toLowerCase(Locale.ROOT);
                    return string4;
                }
            }
            process.waitFor();
            return null;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    private static String f() {
        String string = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (string.contains("win") || string.contains("mac")) {
            return null;
        }
        for (String string2 : new String[]{"/etc/machine-id", "/var/lib/dbus/machine-id"}) {
            try {
                String string3;
                Path path = Paths.get(string2, new String[0]);
                if (!Files.exists(path, new LinkOption[0]) || (string3 = new String(Files.readAllBytes(path), StandardCharsets.UTF_8).trim()).isEmpty()) continue;
                return string3.toLowerCase(Locale.ROOT);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return null;
    }
}

