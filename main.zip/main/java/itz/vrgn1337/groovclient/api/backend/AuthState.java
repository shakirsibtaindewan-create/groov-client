/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

public enum AuthState {
    LOGGED_OUT, CONNECTING, AUTHENTICATED, ERROR;

    private AuthState() {

    }

}

