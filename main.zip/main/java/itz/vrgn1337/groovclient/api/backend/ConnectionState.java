/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

public enum ConnectionState {
    DISCONNECTED, CONNECTING, AUTHENTICATING, CONNECTED, RECONNECTING;

    private ConnectionState() {

    }

}

