/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

import itz.vrgn1337.groovclient.api.backend.CryptoUtils;
import itz.vrgn1337.groovclient.api.backend.DecryptCallback;
import java.util.Arrays;

public final class SecretStore {
    private static final SecretStore a = new SecretStore();
    private volatile char[] b = null;
    private final Object c = new Object();

    public static SecretStore getInstance() {
        return a;
    }

    private SecretStore() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void a(char[] cArray) {
        Object object = this.c;
        synchronized (object) {
            this.d();
            this.b = Arrays.copyOf(cArray, cArray.length);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean b() {
        Object object = this.c;
        synchronized (object) {
            return this.b != null;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void a(DecryptCallback decryptCallback) throws Exception {
        char[] cArray;
        Object object = this.c;
        synchronized (object) {
            if (this.b == null) {
                throw new IllegalStateException();
            }
            cArray = Arrays.copyOf(this.b, this.b.length);
        }
        object = CryptoUtils.a(cArray);
        Arrays.fill(cArray, '\u0000');
        try {
            decryptCallback.a((byte[])object);
        }
        finally {
            Arrays.fill((byte[])object, (byte)0);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void c() {
        Object object = this.c;
        synchronized (object) {
            this.d();
        }
    }

    private void d() {
        if (this.b != null) {
            Arrays.fill(this.b, '\u0000');
            this.b = null;
        }
    }
}

