/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

import itz.vrgn1337.groovclient.api.backend.AntiDebug;
import itz.vrgn1337.groovclient.api.backend.ConnectionState;
import itz.vrgn1337.groovclient.api.backend.CryptoUtils;
import itz.vrgn1337.groovclient.api.backend.HardwareId;
import itz.vrgn1337.groovclient.api.backend.IntegritySealer;
import itz.vrgn1337.groovclient.api.backend.PinnedTrustManager;
import itz.vrgn1337.groovclient.api.backend.SecretStore;
import itz.vrgn1337.groovclient.api.backend.Session;
import itz.vrgn1337.groovclient.api.backend.SocialService;
import itz.vrgn1337.groovclient.api.backend.StringCodec;
import itz.vrgn1337.groovclient.config.ConfigCloudClient;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.HashSet;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;

public final class WebSocketClient
implements WebSocket.Listener {
    private static final int a = 6;
    private static final long b = 2000L;
    private static final long c = 60000L;
    private static final int[] d = new int[]{45, 176, 45, 161, 109, 203, 52, 179, 90, 22, 146, 94, 0, 199, 126, 37, 107, 249, 37, 190, 122, 200, 46, 234, 24};
    private static final boolean e = true;
    private static final String[] f = new String[0];
    public static final String g = "1.0.0";
    private final AtomicReference h = new AtomicReference<ConnectionState>(ConnectionState.DISCONNECTED);
    private final AtomicReference<WebSocket> i = new AtomicReference<WebSocket>(null);
    private final AtomicBoolean j = new AtomicBoolean(false);
    private final AtomicInteger k = new AtomicInteger(0);
    private final AtomicLong l = new AtomicLong(0L);
    private final StringBuilder m = new StringBuilder();
    private volatile String n = null;
    private volatile long o = 0L;
    private volatile int p = -1;
    private volatile int q = 0;
    private final URI r;
    private final HttpClient s;
    private final ScheduledExecutorService t;
    volatile Consumer u;
    volatile Consumer v;
    volatile Consumer w;
    volatile Runnable x;
    private static final WebSocketClient y = new WebSocketClient(WebSocketClient.b());

    public static WebSocketClient getInstance() {
        return y;
    }

    private WebSocketClient(URI uRI) {
        this.r = uRI;
        HttpClient.Builder builder = HttpClient.newBuilder().executor(Executors.newVirtualThreadPerTaskExecutor());
        if ("wss".equalsIgnoreCase(uRI.getScheme())) {
            try {
                SSLContext sSLContext = WebSocketClient.h();
                if (sSLContext != null) {
                    builder.sslContext(sSLContext);
                }
            }
            catch (Exception exception) {
                throw new IllegalStateException("", exception);
            }
        }
        this.s = builder.build();
        this.t = Executors.newSingleThreadScheduledExecutor((arg_0) -> ((WebSocketClient)this).lambda$new$0(arg_0));
    }

    private static URI b() {
        String string = StringCodec.a(d);
        URI uRI = URI.create(string);
        if (!"wss".equalsIgnoreCase(uRI.getScheme())) {
            // empty if block
        }
        return uRI;
    }

    public ConnectionState c() {
        return (ConnectionState)((Object)this.h.get());
    }

    public void d() {
        if (this.h.get() == ConnectionState.CONNECTED || this.h.get() == ConnectionState.CONNECTING) {
            return;
        }
        if (AntiDebug.d()) {
            this.e("tamper_detected");
            return;
        }
        this.j.set(false);
        this.k.set(0);
        this.l.set(0L);
        this.f();
    }

    public void e() {
        this.j.set(true);
        WebSocket webSocket = this.i.getAndSet(null);
        if (webSocket != null && !webSocket.isInputClosed()) {
            webSocket.sendClose(1000, "bye").exceptionally((arg_0) -> ((WebSocketClient)this).lambda$disconnect$1(arg_0));
        }
        this.h.set(ConnectionState.DISCONNECTED);
        Runnable runnable = this.x;
        if (runnable != null) {
            runnable.run();
        }
    }

    public void a(String string) {
        WebSocket webSocket = (WebSocket)this.i.get();
        if (webSocket == null || this.h.get() != ConnectionState.CONNECTED) {
            return;
        }
        String string2 = this.b(string);
        webSocket.sendText(string2, true);
    }

    private String b(String string) {
        long l2 = this.l.incrementAndGet();
        long l3 = System.currentTimeMillis();
        String string2 = "\"seq\":" + l2 + ",\"t\":" + l3;
        if (string == null || string.isEmpty()) {
            return "{" + string2 + "}";
        }
        int n2 = string.indexOf(123);
        if (n2 < 0) {
            return string;
        }
        int n3 = string.lastIndexOf(125);
        if (n3 <= n2) {
            return string;
        }
        String string3 = string.substring(n2 + 1, n3).trim();
        if (string3.isEmpty()) {
            return string.substring(0, n2 + 1) + string2 + "}";
        }
        return string.substring(0, n2 + 1) + string3 + "," + string2 + "}";
    }

    private void f() {
        this.h.set(this.k.get() == 0 ? ConnectionState.CONNECTING : ConnectionState.RECONNECTING);
        this.s.newWebSocketBuilder().buildAsync(this.r, this).whenComplete((arg_0, arg_1) -> ((WebSocketClient)this).lambda$attemptConnect$2(arg_0, arg_1));
    }

    private void g() {
        if (this.j.get()) {
            return;
        }
        int n2 = this.k.incrementAndGet();
        if (n2 > 6) {
            this.k.set(6);
            this.t.schedule(() -> ((WebSocketClient)this).f(), 60000L, TimeUnit.MILLISECONDS);
            return;
        }
        long l2 = Math.min(2000L * (1L << n2 - 1), 60000L);
        this.t.schedule(() -> ((WebSocketClient)this).f(), l2, TimeUnit.MILLISECONDS);
    }

    @Override
    public void onOpen(WebSocket webSocket) {
        this.i.set(webSocket);
        this.h.set(ConnectionState.CONNECTING);
        this.l.set(0L);
        webSocket.request(1L);
    }

    public CompletionStage onText(WebSocket webSocket, CharSequence charSequence, boolean bl) {
        this.m.append(charSequence);
        if (bl) {
            String string = this.m.toString();
            this.m.setLength(0);
            this.getInstance(webSocket, string);
        }
        webSocket.request(1L);
        return null;
    }

    public CompletionStage onClose(WebSocket webSocket, int n2, String string) {
        this.i.set(null);
        this.h.set(ConnectionState.DISCONNECTED);
        Runnable runnable = this.x;
        if (runnable != null) {
            runnable.run();
        }
        if (!this.j.get()) {
            this.g();
        }
        return null;
    }

    @Override
    public void onError(WebSocket webSocket, Throwable throwable) {
        this.e("disconnected");
        this.i.set(null);
        this.h.set(ConnectionState.DISCONNECTED);
        if (!this.j.get()) {
            this.g();
        }
    }

    private void a(WebSocket webSocket, String string) {
        String string2 = WebSocketClient.a(string, "type");
        if (string2 == null) {
            return;
        }
        switch (string2) {
            case "auth_required": {
                this.b(webSocket, string);
                break;
            }
            case "auth_ok": {
                this.d(string);
                break;
            }
            case "auth_needs_key": {
                this.j.set(true);
                this.e("needs_key");
                this.e();
                break;
            }
            case "kicked": {
                this.j.set(true);
                this.e("Kicked: " + WebSocketClient.a(string, "detail"));
                this.e();
                break;
            }
            case "error": {
                this.e(WebSocketClient.a(string, "detail"));
                break;
            }
            case "ping": {
                WebSocket webSocket2 = (WebSocket)this.i.get();
                if (webSocket2 == null) break;
                long l2 = this.l.incrementAndGet();
                webSocket2.sendText("{\"type\":\"pong\",\"seq\":" + l2 + ",\"t\":" + System.currentTimeMillis() + "}", true);
                break;
            }
            default: {
                if (string2.startsWith("config_") || string2.startsWith("settings_")) {
                    ConfigCloudClient.getInstance().a(string2, string);
                    break;
                }
                if (string2.startsWith("friend_") || string2.startsWith("dm_") || string2.startsWith("privacy_")) {
                    SocialService.getInstance().a(string2, string);
                    break;
                }
                Consumer consumer = this.v;
                if (consumer == null) break;
                consumer.accept(string);
            }
        }
    }

    private void b(WebSocket webSocket, String string) {
        String string2 = WebSocketClient.a(string, "nonce");
        String string3 = WebSocketClient.a(string, "server_time");
        long l2 = 0L;
        try {
            l2 = Long.parseLong(string3);
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (string2 == null || string2.length() != 64 || l2 <= 0L) {
            this.e("bad_challenge");
            this.e();
            return;
        }
        this.n = string2;
        this.o = l2;
        this.p = WebSocketClient.a(string, "integrity_offset", -1);
        this.q = WebSocketClient.a(string, "integrity_length", 0);
        this.h.set(ConnectionState.AUTHENTICATING);
        if (SecretStore.getInstance().b()) {
            this.b(webSocket, string2, l2);
        } else {
            this.getInstance(webSocket, string2, l2);
        }
    }

    private static int a(String string, String string2, int n2) {
        String string3 = WebSocketClient.a(string, string2);
        if (string3 == null || string3.isEmpty()) {
            return n2;
        }
        try {
            return Integer.parseInt(string3.trim());
        }
        catch (NumberFormatException numberFormatException) {
            return n2;
        }
    }

    private void a(WebSocket webSocket, String string, long l2) {
        try {
            String string2 = HardwareId.a();
            String string3 = AntiDebug.a();
            long l3 = System.currentTimeMillis();
            byte[] byArray = this.c(string);
            StringBuilder stringBuilder = new StringBuilder(256);
            stringBuilder.append("{").append("\"type\":\"hwid_login\",").append("\"hwid_raw\":\"").append(WebSocketClient.f(string2)).append("\",").append("\"build_hash\":\"").append(string3).append("\",").append("\"client_version\":\"").append(g).append("\",").append("\"client_time\":").append(l3);
            if (byArray != null) {
                stringBuilder.append(",\"integrity_digest\":\"").append(CryptoUtils.c(byArray)).append("\"");
            }
            stringBuilder.append("}");
            webSocket.sendText(stringBuilder.toString(), true).exceptionally(arg_0 -> ((WebSocketClient)this).lambda$sendHwidLogin$3(arg_0));
        }
        catch (Exception exception) {
            this.e("auth_failed");
            this.e();
        }
    }

    private void b(WebSocket webSocket, String string, long l2) {
        try {
            SecretStore.getInstance().a(arg_0 -> ((WebSocketClient)this).lambda$sendAuthResponse$5((String)string, (long)l2, (WebSocket)webSocket, arg_0));
        }
        catch (Exception exception) {
            this.e("auth_failed");
            this.e();
        }
    }

    private byte[] c(String string) {
        int n2 = this.p;
        int n3 = this.q;
        if (n2 < 0 || n3 <= 0) {
            return null;
        }
        try {
            byte[] byArray = CryptoUtils.a(string);
            return IntegritySealer.sealTextRegion(byArray, n2, n3);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private void d(String string) {
        String string2 = WebSocketClient.a(string, "username");
        String string3 = WebSocketClient.a(string, "plan");
        if (string2 == null) {
            this.e("auth_ok missing username");
            return;
        }
        this.k.set(0);
        this.h.set(ConnectionState.CONNECTED);
        this.l.set(0L);
        Session session = new Session(string2, string3 != null ? string3 : "None");
        Consumer consumer = this.u;
        if (consumer != null) {
            consumer.accept(session);
        }
    }

    private void e(String string) {
        Consumer consumer = this.w;
        if (consumer != null) {
            consumer.accept(string != null ? string : "Unknown error");
        }
    }

    private static String f(String string) {
        if (string == null) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder(string.length() + 8);
        block7: for (int j = 0; j < string.length(); ++j) {
            char c2 = string.charAt(j);
            switch (c2) {
                case '\\': {
                    stringBuilder.append("\\\\");
                    continue block7;
                }
                case '\"': {
                    stringBuilder.append("\\\"");
                    continue block7;
                }
                case '\n': {
                    stringBuilder.append("\\n");
                    continue block7;
                }
                case '\r': {
                    stringBuilder.append("\\r");
                    continue block7;
                }
                case '\t': {
                    stringBuilder.append("\\t");
                    continue block7;
                }
                default: {
                    if (c2 < ' ') {
                        stringBuilder.append(String.format("\\u%04x", c2));
                        continue block7;
                    }
                    stringBuilder.append(c2);
                }
            }
        }
        return stringBuilder.toString();
    }

    public static String a(String string, String string2) {
        String string3 = "\"" + string2 + "\"";
        int n2 = string.indexOf(string3);
        if (n2 < 0) {
            return null;
        }
        n2 += string3.length();
        while (n2 < string.length() && (string.charAt(n2) == ' ' || string.charAt(n2) == ':')) {
            ++n2;
        }
        if (n2 >= string.length()) {
            return null;
        }
        if (string.charAt(n2) == '\"') {
            int n3 = n2 + 1;
            int n4 = string.indexOf(34, n3);
            return n4 < 0 ? null : string.substring(n3, n4);
        }
        int n5 = n2;
        while (n2 < string.length() && string.charAt(n2) != ',' && string.charAt(n2) != '}') {
            ++n2;
        }
        return string.substring(n5, n2).trim();
    }

    private static SSLContext h() throws Exception {
        if (f.length == 0) {
            return null;
        }
        HashSet<String> hashSet = new HashSet<String>();
        for (String string : f) {
            String string2;
            if (string == null || (string2 = string.trim().toLowerCase()).isEmpty()) continue;
            hashSet.add(string2);
        }
        if (hashSet.isEmpty()) {
            return null;
        }
        PinnedTrustManager pinnedTrustManager = new PinnedTrustManager(hashSet);
        SSLContext sSLContext = SSLContext.getInstance("TLS");
        sSLContext.init(null, new TrustManager[]{pinnedTrustManager}, null);
        return sSLContext;
    }

    private void lambda$sendAuthResponse$5(String string, long l2, WebSocket webSocket, byte[] byArray) throws Exception {
        byte[] byArray2 = this.c(string);
        String string2 = CryptoUtils.a(byArray, string, l2, byArray2);
        String string3 = CryptoUtils.a(byArray);
        String string4 = HardwareId.a();
        String string5 = AntiDebug.a();
        long l3 = System.currentTimeMillis();
        StringBuilder stringBuilder = new StringBuilder(512);
        stringBuilder.append("{").append("\"type\":\"auth_response\",").append("\"api_key_hash\":\"").append(string3).append("\",").append("\"proof\":\"").append(string2).append("\",").append("\"hwid_raw\":\"").append(WebSocketClient.f(string4)).append("\",").append("\"build_hash\":\"").append(string5).append("\",").append("\"client_version\":\"").append(g).append("\",").append("\"client_time\":").append(l3);
        if (byArray2 != null) {
            stringBuilder.append(",\"integrity_digest\":\"").append(CryptoUtils.c(byArray2)).append("\"");
        }
        stringBuilder.append("}");
        webSocket.sendText(stringBuilder.toString(), true).exceptionally(arg_0 -> ((WebSocketClient)this).lambda$sendAuthResponse$4(arg_0));
    }

    private WebSocket lambda$sendAuthResponse$4(Throwable throwable) {
        this.e("auth_failed");
        return null;
    }

    private WebSocket lambda$sendHwidLogin$3(Throwable throwable) {
        this.e("auth_failed");
        return null;
    }

    private void lambda$attemptConnect$2(WebSocket webSocket, Throwable throwable) {
        if (throwable != null) {
            this.e("connection_failed");
            this.g();
        }
    }

    private static WebSocket lambda$disconnect$1(Throwable throwable) {
        return null;
    }

    private static Thread lambda$new$0(Runnable runnable) {
        Thread thread = new Thread(runnable);
        thread.setDaemon(true);
        return thread;
    }
}

