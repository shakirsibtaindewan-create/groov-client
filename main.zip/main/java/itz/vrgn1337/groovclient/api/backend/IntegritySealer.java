/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

public final class IntegritySealer {
    private IntegritySealer() {
    }

    public static native byte[] sealTextRegion(byte[] var0, int var1, int var2);

    static {
        try {
            Class<?> clazz = Class.forName("groov.obf.runtime.NativeLoader");
            clazz.getMethod("ensureLoaded", new Class[0]).invoke(null, new Object[0]);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

