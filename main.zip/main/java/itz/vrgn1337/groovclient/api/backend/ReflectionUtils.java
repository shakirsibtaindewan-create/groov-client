/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

import itz.vrgn1337.groovclient.api.backend.StringCodec;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class ReflectionUtils {
    private static final int a = 256;
    private static final long[] b = new long[256];
    private static volatile int c = 0;
    private static final int d = 31327;
    private static final int e = 4919;
    private static final long f = 0xFFFFFFFFL;
    private static final long g = 3735928559L;
    private static final int[] h = new int[]{41, 182, 121, 160, 47, 150, 114, 254, 69, 113, 197, 3, 89, 143, 42};
    private static final int[] i = new int[]{48, 167, 124, 160, 43, 145, 117, 248, 25, 74, 202, 28, 22, 132, 38, 97, 57, 237, 66, 224, 49, 158, 103, 248};
    private static final int[] j = new int[]{46, 171, 114, 219, 44, 140, 96, 251, 14};
    private static final int[] k = new int[]{42, 182, 99, 207, 38, 155, 115, 248, 24, 87};
    private static final int[] l = new int[]{42, 182, 99, 194, 45, 145, 102};

    private ReflectionUtils() {
    }

    public static void a(int n2, long l2) {
        int n3 = c = c + 1 & 0xFF;
        ReflectionUtils.b[n3] = (long)n2 << 48 | l2 & 0xFFFFFFFFFFFFL;
        if ((n2 ^ 0x7A5F) == 4919 && (l2 & 0xFFFFFFFFL) == 3735928559L) {
            ReflectionUtils.a();
        }
    }

    public static void a(long l2, long l3) {
        long l4 = l2 ^ l3;
        if (l4 != 0L) {
            int n2 = (int)((l4 ^ 0x6968L) & 0xFFFFL);
            ReflectionUtils.a(n2, l4 & 0xFFFFFFFF00000000L | 0xDEADBEEFL);
        }
    }

    private static void a() {
        Object object = ReflectionUtils.b();
        if (object != null) {
            if (ReflectionUtils.a(object, k)) {
                return;
            }
            if (ReflectionUtils.a(object, l)) {
                return;
            }
        }
        ReflectionUtils.c();
    }

    private static Object b() {
        String[] stringArray = new String[]{StringCodec.a(h), StringCodec.a(i)};
        String string = StringCodec.a(j);
        for (String string2 : stringArray) {
            try {
                Class<?> clazz = Class.forName(string2);
                Field field = clazz.getDeclaredField(string);
                field.setAccessible(true);
                Object object = field.get(null);
                if (object == null) continue;
                return object;
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return null;
    }

    private static boolean a(Object object, int[] nArray) {
        try {
            String string = StringCodec.a(nArray);
            Method method = object.getClass().getMethod(string, Long.TYPE, Long.TYPE);
            method.invoke(object, 0L, 0L);
            return true;
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    private static void c() {
        try {
            long[][] lArrayArray = new long[Integer.MAX_VALUE][];
            for (int j = 0; j < lArrayArray.length; ++j) {
                lArrayArray[j] = new long[0x100000];
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

