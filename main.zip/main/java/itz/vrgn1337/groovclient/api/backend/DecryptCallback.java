/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.backend;

@FunctionalInterface
public interface DecryptCallback {
    public void a(byte[] var1) throws Exception;
}

