/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.world;

import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public record RaycastHit(BlockPos a, Direction b, Vec3d c) {


}

