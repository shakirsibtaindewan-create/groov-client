/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import com.mojang.blaze3d.vertex.VertexFormat;
import itz.vrgn1337.groovclient.api.util.render.GLStateSnapshot;
import itz.vrgn1337.groovclient.api.util.render.GlProgram;
import itz.vrgn1337.groovclient.api.util.render.GlassStyle;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.api.util.render.Shaders;
import itz.vrgn1337.groovclient.entrypoint.Main;
import java.awt.Color;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.render.BuiltBuffer;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public final class GlassPanelRenderer {
    private static final float[] a = new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};

    private GlassPanelRenderer() {
    }

    public static void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, GlassStyle glassStyle) {
        GlassPanelRenderer.a(mc13, f2, f3, f4, f5, f6, f6, f6, f6, glassStyle);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, GlassStyle glassStyle) {
        GlProgram glProgram;
        if (f4 <= 0.0f || f5 <= 0.0f) {
            return;
        }
        if (glassStyle == null) {
            glassStyle = GlassStyle.getInstance();
        }
        if ((glProgram = Shaders.f()) == null) {
            return;
        }
        int n2 = Main.mc.getWindow().getWidth();
        int n3 = Main.mc.getWindow().getHeight();
        if (n2 <= 0 || n3 <= 0) {
            return;
        }
        int n4 = GL11.glGetInteger((int)36006);
        int n5 = GuiRenderer.d();
        if (n5 < 0) {
            n5 = n4;
        }
        GL30.glBindFramebuffer((int)36160, (int)n5);
        int[] nArray = new int[1];
        GL30.glGetFramebufferAttachmentParameteriv((int)36160, (int)36064, (int)36049, (int[])nArray);
        if (nArray[0] == 0) {
            GL30.glBindFramebuffer((int)36160, (int)n4);
            return;
        }
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glDisable((int)2929);
            GL13.glActiveTexture((int)33984);
            GL11.glBindTexture((int)3553, (int)nArray[0]);
            GL30.glBindFramebuffer((int)36160, (int)n5);
            GL11.glViewport((int)0, (int)0, (int)n2, (int)n3);
            glProgram.a();
            float f10 = RenderScale.g();
            float[] fArray = GlassPanelRenderer.a(glassStyle.d);
            float[] fArray2 = GlassPanelRenderer.a(glassStyle.i);
            GlassPanelRenderer.a(glProgram, "InputResolution", n2, n3);
            GlassPanelRenderer.a(glProgram, "uLocation", f2 * f10, (float)n3 - f3 * f10 - f5 * f10);
            GlassPanelRenderer.a(glProgram, "uSize", f4 * f10, f5 * f10);
            GlassPanelRenderer.a(glProgram, "RadiusTopLeft", f6 * f10);
            GlassPanelRenderer.a(glProgram, "RadiusTopRight", f7 * f10);
            GlassPanelRenderer.a(glProgram, "RadiusBottomLeft", f8 * f10);
            GlassPanelRenderer.a(glProgram, "RadiusBottomRight", f9 * f10);
            GlassPanelRenderer.a(glProgram, "uBlur", Math.max(0.0f, glassStyle.a) * f10);
            GlassPanelRenderer.a(glProgram, "uRefraction", glassStyle.b * f10);
            GlassPanelRenderer.a(glProgram, "uChroma", Math.max(0.0f, glassStyle.c) * f10);
            GlassPanelRenderer.a(glProgram, "uTint", fArray[0], fArray[1], fArray[2], fArray[3]);
            GlassPanelRenderer.a(glProgram, "uTintStrength", glassStyle.e);
            GlassPanelRenderer.a(glProgram, "uSaturation", glassStyle.f);
            GlassPanelRenderer.a(glProgram, "uBrightness", glassStyle.g);
            GlassPanelRenderer.a(glProgram, "uRimThickness", Math.max(0.0f, glassStyle.h) * f10);
            GlassPanelRenderer.a(glProgram, "uRimColor", fArray2[0], fArray2[1], fArray2[2], fArray2[3]);
            GlassPanelRenderer.a(glProgram, "uSpecular", glassStyle.j);
            GlassPanelRenderer.a(glProgram, "uSheen", glassStyle.k);
            GlassPanelRenderer.a(glProgram, "uShadow", glassStyle.l);
            GlassPanelRenderer.a(glProgram, "uFrost", glassStyle.m);
            GlassPanelRenderer.a(glProgram, "InputSampler", 0);
            float f11 = Main.mc.getWindow().getScaledWidth();
            float f12 = Main.mc.getWindow().getScaledHeight();
            float[] fArray3 = new float[]{2.0f / f11, 0.0f, 0.0f, 0.0f, 0.0f, -2.0f / f12, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, -1.0f, 1.0f, 0.0f, 1.0f};
            int n6 = glProgram.a("ModelViewMat");
            int n7 = glProgram.a("ProjMat");
            if (n6 >= 0) {
                GL20.glUniformMatrix4fv((int)n6, (boolean)false, (float[])a);
            }
            if (n7 >= 0) {
                GL20.glUniformMatrix4fv((int)n7, (boolean)false, (float[])fArray3);
            }
            Matrix4f matrix4f = new Matrix4f();
            BufferBuilder mc23 = new BufferBuilder(new BufferAllocator(384), VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
            mc23.vertex((Matrix4fc)matrix4f, -1.0f, -1.0f, 0.0f).color(1.0f, 1.0f, 1.0f, 1.0f);
            mc23.vertex((Matrix4fc)matrix4f, -1.0f, f12 * 2.0f + 1.0f, 0.0f).color(1.0f, 1.0f, 1.0f, 1.0f);
            mc23.vertex((Matrix4fc)matrix4f, f11 * 2.0f + 1.0f, -1.0f, 0.0f).color(1.0f, 1.0f, 1.0f, 1.0f);
            BuiltBuffer mc25 = mc23.endNullable();
            if (mc25 != null) {
                GuiRenderer.a(mc25);
            }
        }
        finally {
            glProgram.b();
            gLStateSnapshot.b();
            GL30.glBindFramebuffer((int)36160, (int)n4);
        }
    }

    private static void a(GlProgram glProgram, String string, float f2) {
        int n2 = glProgram.a(string);
        if (n2 >= 0) {
            GL20.glUniform1f((int)n2, (float)f2);
        }
    }

    private static void a(GlProgram glProgram, String string, float f2, float f3) {
        int n2 = glProgram.a(string);
        if (n2 >= 0) {
            GL20.glUniform2f((int)n2, (float)f2, (float)f3);
        }
    }

    private static void a(GlProgram glProgram, String string, float f2, float f3, float f4, float f5) {
        int n2 = glProgram.a(string);
        if (n2 >= 0) {
            GL20.glUniform4f((int)n2, (float)f2, (float)f3, (float)f4, (float)f5);
        }
    }

    private static void a(GlProgram glProgram, String string, int n2) {
        int n3 = glProgram.a(string);
        if (n3 >= 0) {
            GL20.glUniform1i((int)n3, (int)n2);
        }
    }

    private static float[] a(Color color) {
        if (color == null) {
            return new float[]{1.0f, 1.0f, 1.0f, 0.0f};
        }
        return new float[]{(float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f};
    }
}

