/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.rotation;

enum RotationState {
    IDLE, REACTION_DELAY, ROTATING, OVERSHOOTING, CORRECTING, READY, WAITING_POST, HOLDING, ROTATING_BACK;

    private RotationState() {

    }

}

