/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util;

public interface WaitCondition {
    public boolean a();
}

