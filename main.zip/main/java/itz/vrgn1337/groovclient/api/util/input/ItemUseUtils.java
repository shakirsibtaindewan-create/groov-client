/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.input;

import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.mixin.accessor.AbstractContainerScreenAccessor;
import itz.vrgn1337.groovclient.mixin.accessor.MouseHandlerAccessor;
import java.util.Random;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ItemConvertible;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import org.lwjgl.glfw.GLFW;

public final class ItemUseUtils {
    private static final Random a = new Random();
    private static long b = 0L;
    private static double c = 0.0;
    private static double d = 0.0;
    private static long e = 0L;

    private ItemUseUtils() {
    }

    public static void a(Item mc17, float f2, float f3, float f4) {
        if (Main.mc == null || Main.mc.player == null || Main.mc.world == null) {
            return;
        }
        Screen mc29 = Main.mc.currentScreen;
        if (!(mc29 instanceof InventoryScreen)) {
            return;
        }
        InventoryScreen RealmsConnection = (InventoryScreen)mc29;
        long l2 = System.currentTimeMillis();
        if ((float)(l2 - b) < Math.max(0.0f, f2)) {
            return;
        }
        Slot mc30 = ItemUseUtils.a(RealmsConnection, mc17, f3);
        if (mc30 != null && ItemUseUtils.a(RealmsConnection, mc30, f4)) {
            b = l2;
        }
    }

    private static Slot a(InventoryScreen RealmsConnection, Item mc17, float f2) {
        int n2 = ((AbstractContainerScreenAccessor)RealmsConnection).getLeftPos();
        int n3 = ((AbstractContainerScreenAccessor)RealmsConnection).getTopPos();
        double d2 = Main.mc.getWindow().getWidth();
        double d3 = Main.mc.getWindow().getHeight();
        double d4 = Main.mc.getWindow().getScaledWidth();
        double d5 = Main.mc.getWindow().getScaledHeight();
        double d6 = Main.mc.mouse.getX();
        double d7 = Main.mc.mouse.getY();
        double d8 = d6 / d2 * d4;
        double d9 = d7 / d3 * d5;
        Slot mc30 = null;
        double d10 = Double.MAX_VALUE;
        for (Slot mc31 : ((PlayerScreenHandler)RealmsConnection.getScreenHandler()).slots) {
            double d11;
            double d12;
            double d13;
            double d14;
            double d15;
            if (!mc31.hasStack() || !mc31.getStack().isOf(mc17) || mc31.id > 35 || mc31.id < 9 || !((d15 = (d14 = d8 - (d13 = (double)((float)(n2 + mc31.x) + f2))) * d14 + (d12 = d9 - (d11 = (double)((float)(n3 + mc31.y) + f2))) * d12) < d10)) continue;
            d10 = d15;
            mc30 = mc31;
        }
        return mc30;
    }

    public static boolean a(InventoryScreen RealmsConnection, Slot mc30, float f2) {
        int n2 = ((AbstractContainerScreenAccessor)RealmsConnection).getLeftPos();
        int n3 = ((AbstractContainerScreenAccessor)RealmsConnection).getTopPos();
        double d2 = n2 + mc30.x + 8;
        double d3 = n3 + mc30.y + 8;
        double d4 = Main.mc.getWindow().getWidth();
        double d5 = Main.mc.getWindow().getHeight();
        double d6 = Main.mc.getWindow().getScaledWidth();
        double d7 = Main.mc.getWindow().getScaledHeight();
        double d8 = d2 / d6 * d4;
        double d9 = d3 / d7 * d5;
        double d10 = Main.mc.mouse.getX();
        double d11 = Main.mc.mouse.getY();
        float f3 = Math.max(1.0f, f2);
        float f4 = (float)(System.currentTimeMillis() % 1000L) / f3;
        f4 = f4 < 0.5f ? 4.0f * f4 * f4 * f4 : (float)(1.0 - Math.pow(-2.0f * f4 + 2.0f, 3.0) / 2.0);
        double d12 = ItemUseUtils.a(d10, d8, (double)f4);
        double d13 = ItemUseUtils.a(d11, d9, (double)f4);
        long l2 = System.currentTimeMillis();
        if (l2 - e > 100L) {
            c = ((double)a.nextFloat() - 0.5) * 2.0;
            d = ((double)a.nextFloat() - 0.5) * 2.0;
            e = l2;
        }
        double d14 = Math.sqrt((d8 - d10) * (d8 - d10) + (d9 - d11) * (d9 - d11));
        double d15 = Math.min(1.0, d14 / 100.0);
        ((MouseHandlerAccessor)Main.mc.mouse).setXpos(d12 += c * d15 * 0.5);
        ((MouseHandlerAccessor)Main.mc.mouse).setYpos(d13 += d * d15 * 0.5);
        GLFW.glfwSetCursorPos((long)Main.mc.getWindow().getHandle(), (double)d12, (double)d13);
        return ItemUseUtils.a(RealmsConnection).isOf(mc30.getStack().getItem());
    }

    public static ItemStack a(InventoryScreen RealmsConnection) {
        Slot mc30 = ((AbstractContainerScreenAccessor)RealmsConnection).getHoveredSlot();
        if (mc30 == null) {
            return new ItemStack((ItemConvertible)Items.AIR);
        }
        return mc30.getStack();
    }

    private static double a(double d2, double d3, double d4) {
        return d2 + (d3 - d2) * d4;
    }
}

