/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import itz.vrgn1337.groovclient.api.util.render.UniformSetter;
import java.util.HashMap;
import java.util.Map;
import org.lwjgl.opengl.GL20;

public final class GlProgram {
    private final int a;
    private final Map b = new HashMap();
    private static final UniformSetter c = new UniformSetter(-1);

    public GlProgram(String string, String string2, String string3) {
        int n2 = GlProgram.a(35633, string2, string + ".vsh");
        int n3 = GlProgram.a(35632, string3, string + ".fsh");
        this.a = GL20.glCreateProgram();
        GL20.glAttachShader((int)this.a, (int)n2);
        GL20.glAttachShader((int)this.a, (int)n3);
        GL20.glBindAttribLocation((int)this.a, (int)0, (CharSequence)"Position");
        GL20.glBindAttribLocation((int)this.a, (int)1, (CharSequence)"Color");
        GL20.glBindAttribLocation((int)this.a, (int)2, (CharSequence)"UV0");
        GL20.glLinkProgram((int)this.a);
        if (GL20.glGetProgrami((int)this.a, (int)35714) == 0) {
            GL20.glDeleteProgram((int)this.a);
            GL20.glDeleteShader((int)n2);
            GL20.glDeleteShader((int)n3);
        }
        GL20.glDetachShader((int)this.a, (int)n2);
        GL20.glDetachShader((int)this.a, (int)n3);
        GL20.glDeleteShader((int)n2);
        GL20.glDeleteShader((int)n3);
    }

    private static int a(int n2, String string, String string2) {
        int n3 = GL20.glCreateShader((int)n2);
        GL20.glShaderSource((int)n3, (CharSequence)string);
        GL20.glCompileShader((int)n3);
        if (GL20.glGetShaderi((int)n3, (int)35713) == 0) {
            String string3 = GL20.glGetShaderInfoLog((int)n3);
            GL20.glDeleteShader((int)n3);
        }
        return n3;
    }

    public void a() {
        GL20.glUseProgram((int)this.a);
    }

    public void b() {
        GL20.glUseProgram((int)0);
    }

    public int c() {
        return this.a;
    }

    public int a(String string) {
        return this.b.computeIfAbsent(string, arg_0 -> ((GlProgram)this).lambda$getUniformLocation$0(arg_0));
    }

    public UniformSetter b(String string) {
        int n2 = this.a(string);
        return n2 >= 0 ? new UniformSetter(n2) : c;
    }

    public void d() {
        GL20.glDeleteProgram((int)this.a);
    }

    private Integer lambda$getUniformLocation$0(String string) {
        return GL20.glGetUniformLocation((int)this.a, (CharSequence)string);
    }
}

