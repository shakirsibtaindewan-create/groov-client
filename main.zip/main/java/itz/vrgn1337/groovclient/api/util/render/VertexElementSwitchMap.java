/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import com.mojang.blaze3d.vertex.VertexFormat;

class VertexElementSwitchMap {
    static final int[] a = new int[VertexFormat.DrawMode.values().length];

    static {
        try {
            VertexElementSwitchMap.a[VertexFormat.DrawMode.LINES.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            VertexElementSwitchMap.a[VertexFormat.DrawMode.DEBUG_LINES.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            VertexElementSwitchMap.a[VertexFormat.DrawMode.DEBUG_LINE_STRIP.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            VertexElementSwitchMap.a[VertexFormat.DrawMode.TRIANGLES.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            VertexElementSwitchMap.a[VertexFormat.DrawMode.TRIANGLE_STRIP.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            VertexElementSwitchMap.a[VertexFormat.DrawMode.TRIANGLE_FAN.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            VertexElementSwitchMap.a[VertexFormat.DrawMode.QUADS.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

