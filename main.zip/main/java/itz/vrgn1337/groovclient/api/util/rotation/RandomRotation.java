/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.rotation;

import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.entrypoint.Main;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.math.MathHelper;

public final class RandomRotation {
    public static Rotation a(Rotation rotation) {
        if (rotation == null) {
            return null;
        }
        float[] fArray = RandomRotation.a(rotation.a(), rotation.b());
        Rotation rotation2 = new Rotation(fArray[0], fArray[1]);
        rotation2.a(rotation.c());
        return rotation2;
    }

    public static float[] a(float f2, float f3) {
        if (Main.mc == null || Main.mc.options == null || Main.mc.player == null) {
            return new float[]{f2, f3};
        }
        double d2 = (Double)Main.mc.options.getMouseSensitivity().getValue();
        double d3 = d2 * 0.6 + 0.2;
        double d4 = d3 * d3 * d3 * 8.0;
        RotationManager rotationManager = RotationManager.getInstance();
        boolean bl = RotationUtils.a();
        float f4 = bl ? rotationManager.k() : Main.mc.player.getYaw();
        float f5 = bl ? rotationManager.l() : Main.mc.player.getPitch();
        float f6 = MathHelper.wrapDegrees((float)(f2 - f4));
        float f7 = f3 - f5;
        f6 = (float)((double)Math.round((double)f6 / d4) * d4);
        f7 = (float)((double)Math.round((double)f7 / d4) * d4);
        return new float[]{f4 + f6, MathHelper.clamp((float)(f5 + f7), (float)-90.0f, (float)90.0f)};
    }

    public static double a() {
        if (Main.mc == null || Main.mc.options == null) {
            return 0.0;
        }
        double d2 = (Double)Main.mc.options.getMouseSensitivity().getValue();
        double d3 = d2 * 0.6 + 0.2;
        return d3 * d3 * d3 * 8.0;
    }

    public static float[] a(float f2, float f3, int n2, int n3) {
        int n4;
        double d2 = RandomRotation.a();
        if (d2 <= 0.0) {
            return new float[]{f2, MathHelper.clamp((float)f3, (float)-90.0f, (float)90.0f)};
        }
        ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();
        int n5 = n2 > 0 ? threadLocalRandom.nextInt(-n2, n2 + 1) : 0;
        int n6 = n4 = n3 > 0 ? threadLocalRandom.nextInt(-n3, n3 + 1) : 0;
        if (n5 == 0 && n2 > 0) {
            int n7 = n5 = threadLocalRandom.nextBoolean() ? n2 : -n2;
        }
        if (n4 == 0 && n3 > 0) {
            n4 = threadLocalRandom.nextBoolean() ? n3 : -n3;
        }
        return new float[]{(float)((double)f2 + (double)n5 * d2), MathHelper.clamp((float)((float)((double)f3 + (double)n4 * d2)), (float)-90.0f, (float)90.0f)};
    }
}

