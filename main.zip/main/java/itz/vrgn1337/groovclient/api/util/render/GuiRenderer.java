/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.vertex.VertexFormat;
import itz.vrgn1337.groovclient.api.util.render.GLStateSnapshot;
import itz.vrgn1337.groovclient.api.util.render.GlProgram;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.api.util.render.RoundedRectRenderer;
import itz.vrgn1337.groovclient.api.util.render.Shaders;
import itz.vrgn1337.groovclient.entrypoint.Main;
import java.awt.Color;
import java.io.InputStream;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.gl.GlBackend;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.render.BuiltBuffer;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

public final class GuiRenderer {
    public static final int a = 12;
    public static final int b = 0;
    public static final int c = 1;
    private static final float[] d = new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
    private static final RoundedRectRenderer e = new RoundedRectRenderer();
    private static int f = -1;
    private static int g = -1;
    private static int h = -1;
    private static int i;
    private static int j;
    public static final Matrix4f k;
    private static final Map l;
    private static final Map<String, NativeImageBackedTexture> m;
    private static final Map<String, float[]> n;

    private GuiRenderer() {
    }

    public static RoundedRectRenderer a() {
        return e;
    }

    public static void a(float f2, float f3, float f4, float f5) {
        int n2 = Main.mc.getWindow().getWidth();
        int n3 = Main.mc.getWindow().getHeight();
        double d2 = (double)n2 / (double)RenderScale.c();
        double d3 = (double)n3 / (double)RenderScale.d();
        int n4 = (int)Math.round((double)f2 * d2);
        int n5 = (int)Math.round((double)n3 - (double)(f3 + f5) * d3);
        int n6 = (int)Math.round((double)f4 * d2);
        int n7 = (int)Math.round((double)f5 * d3);
        GL11.glEnable((int)3089);
        GL11.glScissor((int)n4, (int)n5, (int)n6, (int)n7);
    }

    public static void b() {
        GL11.glDisable((int)3089);
    }

    public static void a(float f2, float f3, float f4, float f5, Color color) {
        GuiRenderer.a(null, f2, f3, f4, f5, 0.0f, color);
    }

    public static void a(MatrixStack mc13, float f2, float f3, float f4, float f5, Color color) {
        GuiRenderer.a(mc13, f2, f3, f4, f5, 0.0f, color);
    }

    public static void a(float f2, float f3, float f4, float f5, float f6, Color color) {
        GuiRenderer.a(null, f2, f3, f4, f5, f6, color);
    }

    public static void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, Color color) {
        GuiRenderer.a(mc13, f2, f3, f4, f5, f6, f6, f6, f6, color, color, color, color);
    }

    public static void a(float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, Color color, Color color2, Color color3, Color color4) {
        GuiRenderer.a(null, f2, f3, f4, f5, f6, f7, f8, f9, color, color2, color3, color4);
    }

    public static void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, Color color, Color color2, Color color3, Color color4) {
        GuiRenderer.a(mc13, f2, f3, f4, f5, f6, f7, f8, f9, color, color2, color3, color4, 0.0f, Color.WHITE, 0.0f);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, Color color, Color color2, Color color3, Color color4, float f10, Color color5, float f11) {
        GlProgram glProgram = Shaders.a();
        if (glProgram == null || f4 <= 0.0f || f5 <= 0.0f) {
            return;
        }
        int n2 = GuiRenderer.d();
        if (n2 < 0) {
            return;
        }
        int n3 = GL11.glGetInteger((int)36006);
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            GL30.glBindFramebuffer((int)36160, (int)n2);
            GuiRenderer.c();
            glProgram.a();
            GuiRenderer.a(glProgram, mc13, null);
            float f12 = RenderScale.g();
            float f13 = RenderScale.e();
            float f14 = RenderScale.f();
            glProgram.b("uLocation").a(f2 * f12, f14 - (f3 + f5) * f12);
            glProgram.b("uSize").a(f4 * f12, f5 * f12);
            glProgram.b("uResolution").a(f13, f14);
            glProgram.b("RadiusTopLeft").a(f6 * f12);
            glProgram.b("RadiusTopRight").a(f7 * f12);
            glProgram.b("RadiusBottomLeft").a(f8 * f12);
            glProgram.b("RadiusBottomRight").a(f9 * f12);
            GuiRenderer.a(glProgram, "color1", color);
            GuiRenderer.a(glProgram, "color2", color2);
            GuiRenderer.a(glProgram, "color3", color3);
            GuiRenderer.a(glProgram, "color4", color4);
            glProgram.b("uOutlineThickness").a(f10 * f12);
            GuiRenderer.a(glProgram, "uOutlineColor", color5 != null ? color5 : Color.WHITE);
            glProgram.b("uOutlineAlpha").a(GuiRenderer.b(f11, 0.0f, 1.0f));
            GuiRenderer.a(mc13, f2, f3, f4, f5);
        }
        finally {
            glProgram.b();
            gLStateSnapshot.b();
            GL30.glBindFramebuffer((int)36160, (int)n3);
        }
    }

    public static void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, Color color, Color color2, Color color3, Color color4, float f10, float f11, float f12, float f13, int n2) {
        GuiRenderer.a(mc13, f2, f3, f4, f5, f6, f7, f8, f9, color, color2, color3, color4, f10, f11, f12, f13, n2, 0, 6.0f, 0.08f, 0.22f);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, Color color, Color color2, Color color3, Color color4, float f10, float f11, float f12, float f13, int n2, int n3, float f14, float f15, float f16) {
        GlProgram glProgram = Shaders.i();
        if (glProgram == null || f4 <= 0.0f || f5 <= 0.0f) {
            return;
        }
        int n4 = GuiRenderer.d();
        if (n4 < 0) {
            return;
        }
        int n5 = GL11.glGetInteger((int)36006);
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            GL30.glBindFramebuffer((int)36160, (int)n4);
            GuiRenderer.c();
            glProgram.a();
            GuiRenderer.a(glProgram, mc13, null);
            float f17 = RenderScale.g();
            float f18 = RenderScale.e();
            float f19 = RenderScale.f();
            float f20 = (float)RenderScale.j() * f17;
            float f21 = f19 - (float)RenderScale.k() * f17;
            float f22 = (float)(System.currentTimeMillis() % 100000L) / 1000.0f;
            glProgram.b("uLocation").a(f2 * f17, f19 - (f3 + f5) * f17);
            glProgram.b("uSize").a(f4 * f17, f5 * f17);
            glProgram.b("uResolution").a(f18, f19);
            glProgram.b("uTime").a(f22);
            glProgram.b("uSpeed").a(f10);
            glProgram.b("uScale").a(f11);
            glProgram.b("uWarp").a(f12);
            glProgram.b("uShimmer").a(f13);
            glProgram.b("uOctaves").a(n2);
            glProgram.b("uPatternMode").a(n3);
            glProgram.b("uGeoDensity").a(f14);
            glProgram.b("uGeoSoftness").a(f15);
            glProgram.b("uGeoJitter").a(f16);
            glProgram.b("uMouse").a(f20, f21);
            glProgram.b("uMouseRadius").a(42.0f * f17);
            glProgram.b("uMousePush").a(0.007857f);
            glProgram.b("RadiusTopLeft").a(f6 * f17);
            glProgram.b("RadiusTopRight").a(f7 * f17);
            glProgram.b("RadiusBottomLeft").a(f8 * f17);
            glProgram.b("RadiusBottomRight").a(f9 * f17);
            GuiRenderer.a(glProgram, "color1", color);
            GuiRenderer.a(glProgram, "color2", color2);
            GuiRenderer.a(glProgram, "color3", color3);
            GuiRenderer.a(glProgram, "color4", color4);
            GuiRenderer.a(mc13, f2, f3, f4, f5);
        }
        finally {
            glProgram.b();
            gLStateSnapshot.b();
            GL30.glBindFramebuffer((int)36160, (int)n5);
        }
    }

    public static void a(float f2, float f3, float f4, float f5, int n2, int n3, float f6, float f7, float f8, Color color, Color color2, Color color3, Color color4) {
        GlProgram glProgram = Shaders.i();
        if (glProgram == null) {
            return;
        }
        GuiRenderer.a(glProgram, color, color2, color3, color4, arg_0 -> k.lambda$drawSkyCamouflage$0((float)f2, (float)f3, (float)f4, (float)f5, (int)n2, (int)n3, (float)f6, (float)f7, (float)f8, arg_0));
    }

    public static void a(float f2, float f3, float f4, float f5, float f6, Color color, Color color2, Color color3, Color color4) {
        GlProgram glProgram = Shaders.j();
        if (glProgram == null) {
            return;
        }
        GuiRenderer.a(glProgram, color, color2, color3, color4, arg_0 -> k.lambda$drawSkyGalaxy$1((float)f2, (float)f3, (float)f4, (float)f5, (float)f6, arg_0));
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void a(GlProgram glProgram, Color color, Color color2, Color color3, Color color4, Consumer consumer) {
        int n2 = GuiRenderer.d();
        if (n2 < 0) {
            return;
        }
        float f2 = RenderScale.e();
        float f3 = RenderScale.f();
        float f4 = RenderScale.c();
        float f5 = RenderScale.d();
        if (f4 <= 0.0f || f5 <= 0.0f) {
            return;
        }
        int n3 = GL11.glGetInteger((int)36006);
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            GL30.glBindFramebuffer((int)36160, (int)n2);
            GuiRenderer.c();
            glProgram.a();
            GuiRenderer.a(glProgram, null, null);
            glProgram.b("uLocation").a(0.0f, 0.0f);
            glProgram.b("uSize").a(f2, f3);
            glProgram.b("uResolution").a(f2, f3);
            glProgram.b("RadiusTopLeft").a(0.0f);
            glProgram.b("RadiusTopRight").a(0.0f);
            glProgram.b("RadiusBottomLeft").a(0.0f);
            glProgram.b("RadiusBottomRight").a(0.0f);
            GuiRenderer.a(glProgram, "color1", color);
            GuiRenderer.a(glProgram, "color2", color2);
            GuiRenderer.a(glProgram, "color3", color3);
            GuiRenderer.a(glProgram, "color4", color4);
            glProgram.b("uSkyMode").a(1);
            Camera mc22 = Main.mc.gameRenderer.getCamera();
            glProgram.b("uYaw").a((float)Math.toRadians(mc22.getYaw()));
            glProgram.b("uPitch").a((float)Math.toRadians(mc22.getPitch()));
            glProgram.b("uFov").a((float)Math.toRadians(((Integer)Main.mc.options.getFov().getValue()).intValue()));
            consumer.accept(glProgram);
            GuiRenderer.a(null, 0.0f, 0.0f, f4, f5);
        }
        finally {
            glProgram.b();
            gLStateSnapshot.b();
            GL30.glBindFramebuffer((int)36160, (int)n3);
        }
    }

    public static void a(float f2, float f3, float f4, float f5, float f6, float f7, Color color) {
        GuiRenderer.a(null, f2, f3, f4, f5, f6, f7, color);
    }

    public static void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, float f7, Color color) {
        if (f6 <= 0.0f) {
            return;
        }
        GuiRenderer.a(mc13, f2, f3, f4, f5, f7, color);
        float f8 = f4 - f6 * 2.0f;
        float f9 = f5 - f6 * 2.0f;
        if (f8 > 0.0f && f9 > 0.0f) {
            GuiRenderer.a(mc13, f2 + f6, f3 + f6, f8, f9, Math.max(0.0f, f7 - f6), new Color(0, 0, 0, 0));
        }
    }

    static void a(GlProgram glProgram) {
        GuiRenderer.a(glProgram, null, null);
    }

    static void a(GlProgram glProgram, MatrixStack mc13, Matrix4f matrix4f) {
        int n2;
        float[] fArray;
        float[] fArray2;
        if (mc13 != null) {
            fArray2 = new float[16];
            mc13.peek().getPositionMatrix().get(fArray2);
        } else {
            fArray2 = d;
        }
        if (matrix4f != null) {
            fArray = new float[16];
            matrix4f.get(fArray);
        } else {
            float f2 = RenderScale.c();
            float f3 = RenderScale.d();
            fArray = new float[]{2.0f / f2, 0.0f, 0.0f, 0.0f, 0.0f, -2.0f / f3, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, -1.0f, 1.0f, 0.0f, 1.0f};
        }
        int n3 = glProgram.a("ModelViewMat");
        if (n3 >= 0) {
            GL20.glUniformMatrix4fv((int)n3, (boolean)false, (float[])fArray2);
        }
        if ((n2 = glProgram.a("ProjMat")) >= 0) {
            GL20.glUniformMatrix4fv((int)n2, (boolean)false, (float[])fArray);
        }
    }

    static void c() {
        GL11.glEnable((int)3042);
        GL14.glBlendFuncSeparate((int)770, (int)771, (int)1, (int)771);
        GL11.glDisable((int)2884);
        GL11.glDisable((int)2929);
    }

    static void b(float f2, float f3, float f4, float f5) {
        GuiRenderer.a(null, f2, f3, f4, f5);
    }

    static void a(MatrixStack mc13, float f2, float f3, float f4, float f5) {
        Matrix4f matrix4f;
        BufferBuilder mc23 = new BufferBuilder(new BufferAllocator(256), VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        if (mc13 != null) {
            matrix4f = mc13.peek().getPositionMatrix();
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, 0.0f).color(255, 255, 255, 255);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3 + f5, 0.0f).color(255, 255, 255, 255);
            mc23.vertex((Matrix4fc)matrix4f, f2 + f4, f3 + f5, 0.0f).color(255, 255, 255, 255);
            mc23.vertex((Matrix4fc)matrix4f, f2 + f4, f3, 0.0f).color(255, 255, 255, 255);
        } else {
            mc23.vertex(f2, f3, 0.0f).color(255, 255, 255, 255);
            mc23.vertex(f2, f3 + f5, 0.0f).color(255, 255, 255, 255);
            mc23.vertex(f2 + f4, f3 + f5, 0.0f).color(255, 255, 255, 255);
            mc23.vertex(f2 + f4, f3, 0.0f).color(255, 255, 255, 255);
        }
        matrix4f = mc23.endNullable();
        if (matrix4f != null) {
            GuiRenderer.a((BuiltBuffer)matrix4f);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void a(BuiltBuffer mc25) {
        try {
            BuiltBuffer.DrawParameters mc35 = mc25.getDrawParameters();
            ByteBuffer byteBuffer = mc25.getBuffer();
            if (byteBuffer == null || !byteBuffer.hasRemaining()) {
                return;
            }
            GuiRenderer.e();
            int n2 = GL11.glGetInteger((int)34229);
            int n3 = GL11.glGetInteger((int)34964);
            int n4 = GL11.glGetInteger((int)34965);
            GL30.glBindVertexArray((int)f);
            GL15.glBindBuffer((int)34962, (int)g);
            int n5 = byteBuffer.remaining();
            if (n5 > j) {
                GL15.glBufferData((int)34962, (ByteBuffer)byteBuffer, (int)35048);
                j = n5;
            } else {
                GL15.glBufferSubData((int)34962, (long)0L, (ByteBuffer)byteBuffer);
            }
            GuiRenderer.b(mc35.format().getVertexSize());
            if (mc35.mode() == VertexFormat.DrawMode.QUADS) {
                GuiRenderer.a(mc35.vertexCount() / 4);
                GL15.glBindBuffer((int)34963, (int)h);
                GL11.glDrawElements((int)4, (int)(mc35.vertexCount() / 4 * 6), (int)5125, (long)0L);
            } else {
                GL15.glBindBuffer((int)34963, (int)0);
                GL11.glDrawArrays((int)GuiRenderer.a(mc35.mode()), (int)0, (int)mc35.vertexCount());
            }
            GL30.glBindVertexArray((int)n2);
            GL15.glBindBuffer((int)34962, (int)n3);
            GL15.glBindBuffer((int)34963, (int)n4);
        }
        finally {
            mc25.close();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void a(BuiltBuffer mc25, Matrix4f matrix4f, Matrix4f matrix4f2) {
        GlProgram glProgram = Shaders.k();
        if (glProgram == null || mc25 == null) {
            if (mc25 != null) {
                mc25.close();
            }
            return;
        }
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            int n2;
            GL11.glEnable((int)3042);
            GL14.glBlendFuncSeparate((int)770, (int)771, (int)1, (int)771);
            GL11.glDisable((int)2929);
            GL11.glDisable((int)2884);
            glProgram.a();
            float[] fArray = new float[16];
            matrix4f.get(fArray);
            float[] fArray2 = new float[16];
            matrix4f2.get(fArray2);
            int n3 = glProgram.a("ModelViewMat");
            if (n3 >= 0) {
                GL20.glUniformMatrix4fv((int)n3, (boolean)false, (float[])fArray);
            }
            if ((n2 = glProgram.a("ProjMat")) >= 0) {
                GL20.glUniformMatrix4fv((int)n2, (boolean)false, (float[])fArray2);
            }
            GuiRenderer.a(mc25);
        }
        finally {
            glProgram.b();
            gLStateSnapshot.b();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void b(BuiltBuffer mc25, Matrix4f matrix4f, Matrix4f matrix4f2) {
        GlProgram glProgram = Shaders.k();
        if (glProgram == null || mc25 == null) {
            if (mc25 != null) {
                mc25.close();
            }
            return;
        }
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            int n2;
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)1);
            GL11.glDisable((int)2929);
            GL11.glDisable((int)2884);
            glProgram.a();
            float[] fArray = new float[16];
            matrix4f.get(fArray);
            float[] fArray2 = new float[16];
            matrix4f2.get(fArray2);
            int n3 = glProgram.a("ModelViewMat");
            if (n3 >= 0) {
                GL20.glUniformMatrix4fv((int)n3, (boolean)false, (float[])fArray);
            }
            if ((n2 = glProgram.a("ProjMat")) >= 0) {
                GL20.glUniformMatrix4fv((int)n2, (boolean)false, (float[])fArray2);
            }
            GuiRenderer.a(mc25);
        }
        finally {
            glProgram.b();
            gLStateSnapshot.b();
        }
    }

    private static int a(VertexFormat.DrawMode mc36) {
        return switch (mc36) {
            case VertexFormat.DrawMode.LINES, VertexFormat.DrawMode.DEBUG_LINES -> 1;
            case VertexFormat.DrawMode.DEBUG_LINE_STRIP -> 3;
            case VertexFormat.DrawMode.TRIANGLES -> 4;
            case VertexFormat.DrawMode.TRIANGLE_STRIP -> 5;
            case VertexFormat.DrawMode.TRIANGLE_FAN -> 6;
            case VertexFormat.DrawMode.QUADS -> 4;
            default -> 4;
        };
    }

    public static int d() {
        try {
            Framebuffer mc37 = Main.mc.getFramebuffer();
            GpuTexture gpuTexture = mc37.getColorAttachment();
            if (gpuTexture instanceof GlTexture) {
                GlTexture mc18 = (GlTexture)gpuTexture;
                GpuDevice gpuDevice = RenderSystem.getDevice();
                if (gpuDevice instanceof GlBackend) {
                    GlBackend mc38 = (GlBackend)gpuDevice;
                    return mc18.getOrCreateFramebuffer(mc38.getBufferManager(), mc37.getDepthAttachment());
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return -1;
    }

    private static void e() {
        if (f == -1) {
            f = GL30.glGenVertexArrays();
        }
        if (g == -1) {
            g = GL15.glGenBuffers();
        }
        if (h == -1) {
            h = GL15.glGenBuffers();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void a(int n2) {
        int n3 = n2 * 6;
        if (n3 <= i) {
            return;
        }
        IntBuffer intBuffer = MemoryUtil.memAllocInt((int)n3);
        try {
            for (int j = 0; j < n2; ++j) {
                int n4 = j * 4;
                intBuffer.put(n4).put(n4 + 1).put(n4 + 2);
                intBuffer.put(n4 + 2).put(n4 + 3).put(n4);
            }
            intBuffer.flip();
            GL15.glBindBuffer((int)34963, (int)h);
            GL15.glBufferData((int)34963, (IntBuffer)intBuffer, (int)35044);
            i = n3;
        }
        finally {
            MemoryUtil.memFree((Buffer)intBuffer);
        }
    }

    private static void b(int n2) {
        GL20.glDisableVertexAttribArray((int)0);
        GL20.glDisableVertexAttribArray((int)1);
        GL20.glDisableVertexAttribArray((int)2);
        if (n2 == 24) {
            GL20.glVertexAttribPointer((int)0, (int)3, (int)5126, (boolean)false, (int)n2, (long)0L);
            GL20.glEnableVertexAttribArray((int)0);
            GL20.glVertexAttribPointer((int)2, (int)2, (int)5126, (boolean)false, (int)n2, (long)12L);
            GL20.glEnableVertexAttribArray((int)2);
            GL20.glVertexAttribPointer((int)1, (int)4, (int)5121, (boolean)true, (int)n2, (long)20L);
            GL20.glEnableVertexAttribArray((int)1);
        } else {
            GL20.glVertexAttribPointer((int)0, (int)3, (int)5126, (boolean)false, (int)n2, (long)0L);
            GL20.glEnableVertexAttribArray((int)0);
            GL20.glVertexAttribPointer((int)1, (int)4, (int)5121, (boolean)true, (int)n2, (long)12L);
            GL20.glEnableVertexAttribArray((int)1);
        }
    }

    static void a(GlProgram glProgram, String string, Color color) {
        glProgram.b(string).a((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f);
    }

    public static void a(MatrixStack mc13, String string, float f2, float f3, float f4, float f5) {
        GuiRenderer.a(mc13, string, f2, f3, f4, f5, Color.WHITE);
    }

    public static void a(MatrixStack mc13, String string, float f2, float f3, float f4, float f5, Color color) {
        GuiRenderer.a(mc13, string, f2, f3, f4, f5, color, 32.0f, true);
    }

    public static void b(MatrixStack mc13, String string, float f2, float f3, float f4, float f5, Color color) {
        GuiRenderer.a(mc13, string, f2, f3, f4, f5, color, 32.0f, false);
    }

    private static void a(MatrixStack mc13, String string, float f2, float f3, float f4, float f5, Color color, float f6, boolean bl) {
        try {
            int n2;
            int n3;
            int n4;
            int n5 = GuiRenderer.a(string);
            if (n5 < 0) {
                return;
            }
            GlProgram glProgram = Shaders.h();
            if (glProgram == null) {
                return;
            }
            int n6 = GuiRenderer.d();
            if (n6 < 0) {
                return;
            }
            int n7 = GL11.glGetInteger((int)35725);
            int n8 = GL11.glGetInteger((int)36006);
            GL30.glBindFramebuffer((int)36160, (int)n6);
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glDisable((int)2929);
            GL11.glBindTexture((int)3553, (int)n5);
            glProgram.a();
            float f7 = (float)color.getRed() / 255.0f;
            float f8 = (float)color.getGreen() / 255.0f;
            float f9 = (float)color.getBlue() / 255.0f;
            float f10 = (float)color.getAlpha() / 255.0f;
            int n9 = glProgram.a("ColorModulator");
            if (n9 >= 0) {
                GL20.glUniform4f((int)n9, (float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            }
            if ((n4 = glProgram.a("Sampler0")) >= 0) {
                GL20.glUniform1i((int)n4, (int)0);
            }
            if ((n3 = glProgram.a("pxRange")) >= 0) {
                GL20.glUniform1f((int)n3, (float)f6);
            }
            if ((n2 = glProgram.a("msdfMode")) >= 0) {
                GL20.glUniform1i((int)n2, (int)(bl ? 1 : 0));
            }
            GuiRenderer.a(glProgram, mc13, null);
            Matrix4f matrix4f = mc13.peek().getPositionMatrix();
            BufferBuilder mc23 = new BufferBuilder(new BufferAllocator(160), VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, 0.0f).texture(0.0f, 0.0f).color(f7, f8, f9, f10);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3 + f5, 0.0f).texture(0.0f, 1.0f).color(f7, f8, f9, f10);
            mc23.vertex((Matrix4fc)matrix4f, f2 + f4, f3 + f5, 0.0f).texture(1.0f, 1.0f).color(f7, f8, f9, f10);
            mc23.vertex((Matrix4fc)matrix4f, f2 + f4, f3, 0.0f).texture(1.0f, 0.0f).color(f7, f8, f9, f10);
            BuiltBuffer mc25 = mc23.endNullable();
            if (mc25 != null) {
                GuiRenderer.a(mc25);
            }
            GL20.glUseProgram((int)n7);
            GL30.glBindFramebuffer((int)36160, (int)n8);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static int a(String string) {
        Integer n2 = (Integer)l.get(string);
        if (n2 != null) {
            return n2;
        }
        try {
            String string2 = "/assets/groovclient/textures/icons/" + string + ".png";
            InputStream inputStream = GuiRenderer.class.getResourceAsStream(string2);
            if (inputStream == null) {
                return -1;
            }
            String string3 = "groovclient:textures/icons/" + string;
            NativeImageBackedTexture BundleSelectedItemModel = new NativeImageBackedTexture(() -> this.lambda$getOrLoadIconTexture$2((String)string3), NativeImage.read((InputStream)inputStream));
            inputStream.close();
            int n3 = ((GlTexture)BundleSelectedItemModel.getGlTexture()).getGlId();
            GL11.glBindTexture((int)3553, (int)n3);
            GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
            GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
            l.put(string, n3);
            m.put(string, BundleSelectedItemModel);
            return n3;
        }
        catch (Exception exception) {
            return -1;
        }
    }

    public static void f() {
        for (NativeImageBackedTexture BundleSelectedItemModel : m.values()) {
            try {
                BundleSelectedItemModel.close();
            }
            catch (Exception exception) {}
        }
        m.clear();
        l.clear();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void a(MatrixStack mc13, float f2, float f3, float[] fArray, float f4, boolean bl, Color color, float f5) {
        if (fArray == null || fArray.length == 0) {
            return;
        }
        GlProgram glProgram = Shaders.b();
        if (glProgram == null) {
            return;
        }
        int n2 = Math.min(fArray.length, 32);
        float f6 = 0.0f;
        for (int j = 0; j < n2; ++j) {
            f6 = Math.max(f6, fArray[j]);
        }
        float f7 = f4 * (float)n2;
        float f8 = 3.0f;
        int n3 = GuiRenderer.d();
        if (n3 < 0) {
            return;
        }
        int n4 = GL11.glGetInteger((int)36006);
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            GL30.glBindFramebuffer((int)36160, (int)n3);
            GuiRenderer.c();
            glProgram.a();
            float f9 = RenderScale.g();
            float f10 = RenderScale.e();
            float f11 = RenderScale.f();
            float f12 = bl ? f2 - f6 - f8 : f2 - f8;
            float f13 = f3 - f8;
            float f14 = f6 + f8 * 2.0f;
            float f15 = f7 + f8 * 2.0f;
            glProgram.b("uResolution").a(f10, f11);
            glProgram.b("uLocation").a(f12 * f9, f13 * f9);
            glProgram.b("uSize").a(f14 * f9, f15 * f9);
            glProgram.b("padding").a(f8 * f9);
            glProgram.b("rowHeight").a(f4 * f9);
            glProgram.b("cornerRadius").a(f5 * f9);
            glProgram.b("moduleCount").a(n2);
            glProgram.b("rightAligned").a(bl ? 1 : 0);
            int n5 = glProgram.a("widths");
            if (n5 >= 0) {
                float[] fArray2 = new float[32];
                for (int j = 0; j < n2; ++j) {
                    fArray2[j] = fArray[j] * f9;
                }
                GL20.glUniform1fv((int)n5, (float[])fArray2);
            }
            glProgram.b("color1").a((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f);
            GuiRenderer.a(glProgram, mc13, null);
            GuiRenderer.a(mc13, f12, f13, f14, f15);
        }
        finally {
            glProgram.b();
            gLStateSnapshot.b();
            GL30.glBindFramebuffer((int)36160, (int)n4);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void a(MatrixStack mc13, float f2, float f3, float[] fArray, float f4, boolean bl, float f5, float f6, float f7) {
        if (fArray == null || fArray.length == 0) {
            return;
        }
        GlProgram glProgram = Shaders.c();
        if (glProgram == null) {
            return;
        }
        int n2 = Math.min(fArray.length, 32);
        float f8 = 0.0f;
        for (int j = 0; j < n2; ++j) {
            f8 = Math.max(f8, fArray[j]);
        }
        float f9 = f4 * (float)n2;
        float f10 = 3.0f;
        int n3 = GuiRenderer.d();
        if (n3 < 0) {
            return;
        }
        int n4 = GL11.glGetInteger((int)36006);
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            int n5;
            GL30.glBindFramebuffer((int)36160, (int)n3);
            int[] nArray = new int[1];
            GL30.glGetFramebufferAttachmentParameteriv((int)36160, (int)36064, (int)36049, (int[])nArray);
            if (nArray[0] <= 0) {
                return;
            }
            GuiRenderer.c();
            glProgram.a();
            GL13.glActiveTexture((int)33984);
            GL11.glBindTexture((int)3553, (int)nArray[0]);
            GL30.glBindFramebuffer((int)36160, (int)n3);
            float f11 = RenderScale.g();
            float f12 = RenderScale.e();
            float f13 = RenderScale.f();
            float f14 = bl ? f2 - f8 - f10 : f2 - f10;
            float f15 = f3 - f10;
            float f16 = f8 + f10 * 2.0f;
            float f17 = f9 + f10 * 2.0f;
            glProgram.b("InputResolution").a(f12, f13);
            glProgram.b("uResolution").a(f12, f13);
            glProgram.b("uLocation").a(f14 * f11, f15 * f11);
            glProgram.b("uSize").a(f16 * f11, f17 * f11);
            glProgram.b("padding").a(f10 * f11);
            glProgram.b("rowHeight").a(f4 * f11);
            glProgram.b("cornerRadius").a(f5 * f11);
            glProgram.b("moduleCount").a(n2);
            glProgram.b("rightAligned").a(bl ? 1 : 0);
            glProgram.b("Quality").a(f6);
            glProgram.b("Brightness").a(f7);
            int n6 = glProgram.a("widths");
            if (n6 >= 0) {
                float[] fArray2 = new float[32];
                for (int j = 0; j < n2; ++j) {
                    fArray2[j] = fArray[j] * f11;
                }
                GL20.glUniform1fv((int)n6, (float[])fArray2);
            }
            if ((n5 = glProgram.a("InputSampler")) >= 0) {
                GL20.glUniform1i((int)n5, (int)0);
            }
            GuiRenderer.a(glProgram, mc13, null);
            GuiRenderer.a(mc13, f14, f15, f16, f17);
        }
        finally {
            glProgram.b();
            gLStateSnapshot.b();
            GL30.glBindFramebuffer((int)36160, (int)n4);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void a(MatrixStack mc13, float f2, float f3, float[] fArray, float f4, boolean bl, float f5, Color color, float f6, float f7, float f8) {
        if (fArray == null || fArray.length == 0) {
            return;
        }
        GlProgram glProgram = Shaders.d();
        if (glProgram == null) {
            return;
        }
        int n2 = Math.min(fArray.length, 32);
        float f9 = 0.0f;
        for (int j = 0; j < n2; ++j) {
            f9 = Math.max(f9, fArray[j]);
        }
        float f10 = f4 * (float)n2;
        float f11 = 3.0f;
        float f12 = Math.max(f7, f8) + 4.0f;
        int n3 = GuiRenderer.d();
        if (n3 < 0) {
            return;
        }
        int n4 = GL11.glGetInteger((int)36006);
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            GL30.glBindFramebuffer((int)36160, (int)n3);
            GuiRenderer.c();
            glProgram.a();
            float f13 = RenderScale.g();
            float f14 = RenderScale.e();
            float f15 = RenderScale.f();
            float f16 = bl ? f2 - f9 - f11 : f2 - f11;
            float f17 = f3 - f11;
            float f18 = f9 + f11 * 2.0f;
            float f19 = f10 + f11 * 2.0f;
            glProgram.b("uResolution").a(f14, f15);
            glProgram.b("uLocation").a(f16 * f13, f17 * f13);
            glProgram.b("uSize").a(f18 * f13, f19 * f13);
            glProgram.b("padding").a(f11 * f13);
            glProgram.b("rowHeight").a(f4 * f13);
            glProgram.b("cornerRadius").a(f5 * f13);
            glProgram.b("moduleCount").a(n2);
            glProgram.b("rightAligned").a(bl ? 1 : 0);
            glProgram.b("outlineWidth").a(f6 * f13);
            glProgram.b("glowSize").a(f7 * f13);
            glProgram.b("bloomSize").a(f8 * f13);
            int n5 = glProgram.a("widths");
            if (n5 >= 0) {
                float[] fArray2 = new float[32];
                for (int j = 0; j < n2; ++j) {
                    fArray2[j] = fArray[j] * f13;
                }
                GL20.glUniform1fv((int)n5, (float[])fArray2);
            }
            glProgram.b("color1").a((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f);
            GuiRenderer.a(glProgram, mc13, null);
            GuiRenderer.a(mc13, f16 - f12, f17 - f12, f18 + f12 * 2.0f, f19 + f12 * 2.0f);
        }
        finally {
            glProgram.b();
            gLStateSnapshot.b();
            GL30.glBindFramebuffer((int)36160, (int)n4);
        }
    }

    public static float a(float f2, float f3, float f4) {
        return f2 + (f3 - f2) * f4;
    }

    public static double a(double d2, double d3, double d4) {
        return d2 + (d3 - d2) * d4;
    }

    public static float b(float f2, float f3, float f4) {
        return Math.max(f3, Math.min(f4, f2));
    }

    public static float a(float f2, float f3, float f4, float f5, float f6) {
        return f5 + (f2 - f3) / (f4 - f3) * (f6 - f5);
    }

    public static float c(float f2, float f3, float f4) {
        float f5 = GuiRenderer.b((f4 - f2) / (f3 - f2), 0.0f, 1.0f);
        return f5 * f5 * (3.0f - 2.0f * f5);
    }

    public static float d(float f2, float f3, float f4) {
        float f5 = GuiRenderer.b((f4 - f2) / (f3 - f2), 0.0f, 1.0f);
        return f5 * f5 * f5 * (f5 * (f5 * 6.0f - 15.0f) + 10.0f);
    }

    public static float a(float f2) {
        return f2 * f2;
    }

    public static float b(float f2) {
        return f2 * (2.0f - f2);
    }

    public static float c(float f2) {
        return f2 < 0.5f ? 2.0f * f2 * f2 : -1.0f + (4.0f - 2.0f * f2) * f2;
    }

    public static float d(float f2) {
        return f2 * f2 * f2;
    }

    public static float e(float f2) {
        float f3 = f2 - 1.0f;
        return f3 * f3 * f3 + 1.0f;
    }

    public static float f(float f2) {
        return f2 < 0.5f ? 4.0f * f2 * f2 * f2 : 1.0f + (f2 - 1.0f) * (2.0f * f2 - 2.0f) * (2.0f * f2 - 2.0f);
    }

    public static float g(float f2) {
        float f3 = 1.70158f;
        float f4 = f2 - 1.0f;
        return 1.0f + (f3 + 1.0f) * f4 * f4 * f4 + f3 * f4 * f4;
    }

    public static float h(float f2) {
        if (f2 == 0.0f || f2 == 1.0f) {
            return f2;
        }
        return (float)(Math.pow(2.0, -10.0f * f2) * Math.sin(((double)(f2 * 10.0f) - 0.75) * 2.0943951023931953) + 1.0);
    }

    public static float i(float f2) {
        if (f2 < 0.36363637f) {
            return 7.5625f * f2 * f2;
        }
        if (f2 < 0.72727275f) {
            return 7.5625f * (f2 -= 0.54545456f) * f2 + 0.75f;
        }
        if (f2 < 0.90909094f) {
            return 7.5625f * (f2 -= 0.8181818f) * f2 + 0.9375f;
        }
        return 7.5625f * (f2 -= 0.95454544f) * f2 + 0.984375f;
    }

    public static float a(String string, float f2, float f3) {
        float[] fArray = n.computeIfAbsent(string, arg_0 -> k.lambda$animate$3((float)f2, arg_0));
        fArray[0] = fArray[0] + (f2 - fArray[0]) * GuiRenderer.b(f3, 0.0f, 1.0f);
        if (Math.abs(fArray[0] - f2) < 0.001f) {
            fArray[0] = f2;
        }
        return fArray[0];
    }

    public static float a(String string, float f2) {
        return GuiRenderer.a(string, f2, 0.15f);
    }

    public static void b(String string) {
        n.remove(string);
    }

    public static void b(String string, float f2) {
        n.put(string, new float[]{f2});
    }

public static double a(double d2, double d3) {
    return d3 + (d2 - d3) * (double)Main.mc.getRenderTickCounter().getTickProgress(true);
    }

    public static Color a(Color color, Color color2, float f2) {
        f2 = GuiRenderer.b(f2, 0.0f, 1.0f);
        return new Color((int)GuiRenderer.a(color.getRed(), (float)color2.getRed(), f2), (int)GuiRenderer.a(color.getGreen(), (float)color2.getGreen(), f2), (int)GuiRenderer.a(color.getBlue(), (float)color2.getBlue(), f2), (int)GuiRenderer.a(color.getAlpha(), (float)color2.getAlpha(), f2));
    }

    public static Color a(Color color, int n2) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)GuiRenderer.b(n2, 0.0f, 255.0f));
    }

    public static Color a(Color color, float f2) {
        return GuiRenderer.a(color, (int)(GuiRenderer.b(f2, 0.0f, 1.0f) * 255.0f));
    }

    public static Color b(Color color, float f2) {
        return new Color((int)GuiRenderer.b((float)color.getRed() * f2, 0.0f, 255.0f), (int)GuiRenderer.b((float)color.getGreen() * f2, 0.0f, 255.0f), (int)GuiRenderer.b((float)color.getBlue() * f2, 0.0f, 255.0f), color.getAlpha());
    }

    public static Color c(Color color, float f2) {
        return GuiRenderer.b(color, 1.0f / f2);
    }

    public static float g() {
        return (float)(System.currentTimeMillis() % 100000L) / 1000.0f;
    }

    public static float j(float f2) {
        return (float)(Math.sin((double)(GuiRenderer.g() * f2) * Math.PI * 2.0) * 0.5 + 0.5);
    }

    public static float e(float f2, float f3, float f4) {
        return GuiRenderer.a(f3, f4, GuiRenderer.j(f2));
    }

    private static float[] lambda$animate$3(float f2, String string) {
        return new float[]{f2};
    }

    private static String lambda$getOrLoadIconTexture$2(String string) {
        return string;
    }

    private static void lambda$drawSkyGalaxy$1(float f2, float f3, float f4, float f5, float f6, GlProgram glProgram) {
        float f7 = (float)(System.currentTimeMillis() % 100000L) / 1000.0f;
        glProgram.b("uTime").a(f7);
        glProgram.b("uSpeed").a(f2);
        glProgram.b("uDensity").a(f3);
        glProgram.b("uNebulaScale").a(f4);
        glProgram.b("uTwirl").a(f5);
        glProgram.b("uShimmer").a(f6);
    }

    private static void lambda$drawSkyCamouflage$0(float f2, float f3, float f4, float f5, int n2, int n3, float f6, float f7, float f8, GlProgram glProgram) {
        float f9 = RenderScale.e();
        float f10 = RenderScale.f();
        float f11 = (float)(System.currentTimeMillis() % 100000L) / 1000.0f;
        glProgram.b("uTime").a(f11);
        glProgram.b("uSpeed").a(f2);
        glProgram.b("uScale").a(f3);
        glProgram.b("uWarp").a(f4);
        glProgram.b("uShimmer").a(f5);
        glProgram.b("uOctaves").a(n2);
        glProgram.b("uPatternMode").a(n3);
        glProgram.b("uGeoDensity").a(f6);
        glProgram.b("uGeoSoftness").a(f7);
        glProgram.b("uGeoJitter").a(f8);
        glProgram.b("uMouse").a(-9999.0f, -9999.0f);
        glProgram.b("uMouseRadius").a(0.0f);
        glProgram.b("uMousePush").a(0.0f);
    }

    static {
        k = new Matrix4f();
        l = new HashMap();
        m = new HashMap();
        n = new HashMap();
    }
}

