/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.math;

import java.util.concurrent.ThreadLocalRandom;

public class RandomUtils {
    public static int a(int n2, int n3) {
        if (n2 >= n3) {
            return n2;
        }
        return ThreadLocalRandom.current().nextInt(n2, n3 + 1);
    }

    public static double a(double d2, double d3) {
        if (d2 >= d3) {
            return d2;
        }
        return ThreadLocalRandom.current().nextDouble(d2, d3 + 1.0);
    }

    public static float a(float f2, float f3) {
        if (f2 >= f3) {
            return f2;
        }
        return ThreadLocalRandom.current().nextFloat(f2, f3 + 1.0f);
    }
}

