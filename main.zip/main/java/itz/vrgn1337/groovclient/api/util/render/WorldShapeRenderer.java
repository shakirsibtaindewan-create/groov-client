/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import com.mojang.blaze3d.vertex.VertexFormat;
import itz.vrgn1337.groovclient.api.util.bridge.GameRendererMixinBridge;
import itz.vrgn1337.groovclient.api.util.render.GLStateSnapshot;
import itz.vrgn1337.groovclient.api.util.render.GlProgram;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.Shaders;
import itz.vrgn1337.groovclient.api.util.render.Shape;
import java.awt.Color;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.render.BuiltBuffer;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL20;

public class WorldShapeRenderer {
    private final MatrixStack a;
    private float b;
    private float c;
    private float d;
    private float e = 0.5f;
    private float f = 2.0f;
    private Color g = new Color(255, 50, 50, 180);
    private Color h = null;
    private boolean i = false;
    private float j = 1.0f;
    private Color k = null;
    private boolean l = false;
    private Color m = Color.WHITE;
    private float n = 2.0f;
    private boolean o = false;
    private float p = 3.0f;
    private float q = 0.15f;
    private float r = 2.5f;
    private Shape s = Shape.CYLINDER;
    private float t = 0.0f;
    private boolean u = false;
    private float v = 1.0f;
    private boolean w = false;
    private float x = 1.0f;
    private float y = 1.0f;
    private float z = 1.0f;
    private boolean A = false;
    private float B = 2.0f;
    private float C = 0.5f;
    private float D = 0.0f;
    private boolean E = false;
    private int F = 6;
    private float G = 0.08f;
    private float H = 0.0f;
    private float I = 0.55f;
    private float J = 0.7f;
    private boolean K = true;

    public WorldShapeRenderer(MatrixStack mc13) {
        this.a = mc13;
    }

    public WorldShapeRenderer a(Entity mc2) {
        return this.a(mc2, null);
    }

    public WorldShapeRenderer a(Entity mc2, Vec3d VanillaChestLootTableGenerator) {
        if (mc2 == null) {
            return this;
        }
        double d2 = GuiRenderer.a(mc2.getX(), mc2.lastRenderX);
        double d3 = GuiRenderer.a(mc2.getY(), mc2.lastRenderY);
        double d4 = GuiRenderer.a(mc2.getZ(), mc2.lastRenderZ);
        if (VanillaChestLootTableGenerator != null) {
            d2 += VanillaChestLootTableGenerator.x;
            d3 += VanillaChestLootTableGenerator.y;
            d4 += VanillaChestLootTableGenerator.z;
        }
        this.b = (float)d2;
        this.c = (float)d3;
        this.d = (float)d4;
        this.e = mc2.getWidth() * 0.5f + 0.05f;
        this.f = mc2.getHeight();
        return this;
    }

    public WorldShapeRenderer a(double d2, double d3, double d4) {
        this.b = (float)d2;
        this.c = (float)d3;
        this.d = (float)d4;
        return this;
    }

    public WorldShapeRenderer a(Vec3d VanillaChestLootTableGenerator) {
        return this.a(VanillaChestLootTableGenerator.x, VanillaChestLootTableGenerator.y, VanillaChestLootTableGenerator.z);
    }

    public WorldShapeRenderer a(float f2) {
        this.e = f2;
        return this;
    }

    public WorldShapeRenderer b(float f2) {
        this.f = f2;
        return this;
    }

    public WorldShapeRenderer a(float f2, float f3) {
        this.e = f2;
        this.f = f3;
        return this;
    }

    public WorldShapeRenderer a(Color color) {
        this.g = color;
        return this;
    }

    public WorldShapeRenderer a(int n2, int n3, int n4, int n5) {
        this.g = new Color(n2, n3, n4, n5);
        return this;
    }

    public WorldShapeRenderer a(Color color, Color color2) {
        this.g = color;
        this.h = color2;
        return this;
    }

    public WorldShapeRenderer a() {
        this.s = Shape.CYLINDER;
        return this;
    }

    public WorldShapeRenderer b() {
        this.s = Shape.TRIANGLE;
        return this;
    }

    public WorldShapeRenderer c() {
        this.s = Shape.QUAD;
        return this;
    }

    public WorldShapeRenderer d() {
        this.s = Shape.PENTAGON;
        return this;
    }

    public WorldShapeRenderer e() {
        this.s = Shape.HEXAGON;
        return this;
    }

    public WorldShapeRenderer f() {
        this.s = Shape.STAR;
        return this;
    }

    public WorldShapeRenderer g() {
        this.s = Shape.FLOWER;
        return this;
    }

    public WorldShapeRenderer a(Shape shape) {
        this.s = shape;
        return this;
    }

    public WorldShapeRenderer c(float f2) {
        this.t = f2;
        return this;
    }

    public WorldShapeRenderer a(float f2, boolean bl) {
        this.u = true;
        this.v = bl ? -f2 : f2;
        return this;
    }

    public WorldShapeRenderer d(float f2) {
        this.u = true;
        this.v = f2;
        return this;
    }

    public WorldShapeRenderer b(float f2, boolean bl) {
        return this.a(f2, bl);
    }

    public WorldShapeRenderer h() {
        this.w = true;
        return this;
    }

    public WorldShapeRenderer e(float f2) {
        this.w = true;
        this.x = f2;
        return this;
    }

    public WorldShapeRenderer a(float f2, float f3, float f4) {
        this.w = true;
        this.x = f2;
        this.y = f3;
        this.z = f4;
        return this;
    }

    public WorldShapeRenderer b(float f2, float f3) {
        this.A = true;
        this.B = f2;
        this.C = f3;
        return this;
    }

    public WorldShapeRenderer i() {
        return this.b(2.0f, 0.5f);
    }

    public WorldShapeRenderer f(float f2) {
        this.D = f2;
        return this;
    }

    public WorldShapeRenderer j() {
        this.E = true;
        return this;
    }

    public WorldShapeRenderer a(int n2) {
        this.E = true;
        this.F = n2;
        return this;
    }

    public WorldShapeRenderer a(int n2, float f2) {
        this.E = true;
        this.F = n2;
        this.G = f2;
        return this;
    }

    public WorldShapeRenderer g(float f2) {
        this.i = true;
        this.j = f2;
        return this;
    }

    public WorldShapeRenderer a(float f2, Color color) {
        this.i = true;
        this.j = f2;
        this.k = color;
        return this;
    }

    public WorldShapeRenderer a(Color color, float f2) {
        this.l = true;
        this.m = color;
        this.n = f2;
        return this;
    }

    public WorldShapeRenderer h(float f2) {
        this.o = true;
        this.p = f2;
        return this;
    }

    public WorldShapeRenderer c(float f2, float f3) {
        this.o = true;
        this.p = f2;
        this.q = f3;
        return this;
    }

    public WorldShapeRenderer i(float f2) {
        this.r = f2;
        return this;
    }

    public WorldShapeRenderer k() {
        this.r = 0.0f;
        return this;
    }

    public WorldShapeRenderer j(float f2) {
        this.H = f2;
        return this;
    }

    public WorldShapeRenderer k(float f2) {
        this.I = f2;
        return this;
    }

    public WorldShapeRenderer l(float f2) {
        this.J = f2;
        return this;
    }

    public WorldShapeRenderer a(boolean bl) {
        this.K = bl;
        return this;
    }

    public WorldShapeRenderer l() {
        this.g = new Color(255, 100, 0, 200);
        this.h = new Color(255, 200, 50, 0);
        this.i = true;
        this.j = 1.0f;
        this.o = true;
        this.p = 4.0f;
        this.r = 3.0f;
        this.H = 0.6f;
        return this;
    }

    public WorldShapeRenderer m() {
        this.g = new Color(100, 200, 255, 180);
        this.h = new Color(200, 240, 255, 0);
        this.i = true;
        this.j = 0.8f;
        this.o = true;
        this.p = 1.5f;
        this.r = 2.0f;
        return this;
    }

    public WorldShapeRenderer n() {
        this.g = new Color(50, 255, 100, 150);
        this.h = new Color(150, 255, 200, 0);
        this.i = true;
        this.j = 1.2f;
        this.o = true;
        this.p = 2.5f;
        this.r = 2.5f;
        this.H = 0.4f;
        return this;
    }

    public WorldShapeRenderer o() {
        this.g = new Color(255, 0, 0, 200);
        this.h = new Color(255, 50, 50, 0);
        this.i = true;
        this.j = 2.0f;
        this.o = true;
        this.p = 6.0f;
        this.r = 3.5f;
        return this;
    }

    public WorldShapeRenderer p() {
        this.g = new Color(150, 50, 255, 180);
        this.h = new Color(255, 150, 255, 0);
        this.i = true;
        this.j = 1.8f;
        this.o = true;
        this.p = 3.0f;
        this.r = 2.8f;
        this.H = 0.3f;
        return this;
    }

    public WorldShapeRenderer q() {
        this.i = false;
        this.o = false;
        this.r = 0.0f;
        this.h = null;
        this.H = 0.0f;
        this.J = 0.0f;
        this.I = 0.0f;
        return this;
    }

    public WorldShapeRenderer r() {
        this.f = 0.1f;
        this.A = true;
        this.B = 2.0f;
        this.C = 0.8f;
        this.i = true;
        this.j = 1.0f;
        this.o = true;
        this.p = 2.0f;
        this.r = 0.0f;
        return this;
    }

    public WorldShapeRenderer s() {
        this.s = Shape.TRIANGLE;
        this.f = 0.15f;
        this.A = true;
        this.B = 1.5f;
        this.C = 1.0f;
        this.u = true;
        this.v = 0.5f;
        this.i = true;
        this.j = 1.2f;
        this.r = 0.0f;
        return this;
    }

    public WorldShapeRenderer b(int n2) {
        this.f = 0.08f;
        this.A = true;
        this.B = 2.5f;
        this.C = 0.6f;
        this.D = (float)n2 * 2.1f;
        this.g = new Color(255, 50, 50, 200);
        this.i = true;
        this.j = 0.8f;
        this.r = 0.0f;
        return this;
    }

    public WorldShapeRenderer t() {
        this.f = 0.08f;
        this.A = true;
        this.B = 2.5f;
        this.C = 1.0f;
        this.E = true;
        this.F = 10;
        this.G = 0.06f;
        this.g = new Color(100, 180, 255, 180);
        this.i = true;
        this.j = 0.6f;
        this.r = 0.0f;
        return this;
    }

    public WorldShapeRenderer u() {
        this.f = 0.1f;
        this.A = true;
        this.B = 1.5f;
        this.C = 0.8f;
        this.E = true;
        this.F = 12;
        this.G = 0.05f;
        this.g = new Color(200, 200, 255, 150);
        this.i = true;
        this.j = 0.5f;
        this.r = 0.0f;
        return this;
    }

    public WorldShapeRenderer v() {
        this.s = Shape.TRIANGLE;
        this.f = 0.12f;
        this.A = true;
        this.B = 3.0f;
        this.C = 0.6f;
        this.u = true;
        this.v = 1.5f;
        this.E = true;
        this.F = 8;
        this.G = 0.04f;
        this.g = new Color(255, 150, 50, 200);
        this.i = true;
        this.j = 1.0f;
        this.r = 0.0f;
        return this;
    }

    public WorldShapeRenderer w() {
        this.s = Shape.STAR;
        this.f = 0.1f;
        this.A = true;
        this.B = 2.0f;
        this.C = 0.7f;
        this.u = true;
        this.v = 0.8f;
        this.g = new Color(255, 215, 0, 200);
        this.i = true;
        this.j = 1.5f;
        this.r = 0.0f;
        return this;
    }

    public WorldShapeRenderer x() {
        this.s = Shape.FLOWER;
        this.f = 0.08f;
        this.A = true;
        this.B = 1.5f;
        this.C = 0.5f;
        this.u = true;
        this.v = 0.3f;
        this.g = new Color(255, 150, 200, 180);
        this.i = true;
        this.j = 1.0f;
        this.r = 0.0f;
        return this;
    }

    public WorldShapeRenderer y() {
        this.f = 0.1f;
        this.A = true;
        this.B = 2.0f;
        this.C = 0.8f;
        this.w = true;
        this.x = 2.0f;
        this.i = true;
        this.j = 1.0f;
        this.r = 0.0f;
        return this;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void z() {
        float f2 = GuiRenderer.g();
        float f3 = this.A ? (float)Math.sin((f2 + this.D) * this.B) * this.C : 0.0f;
        float f4 = this.t + (this.u ? f2 * this.v * 360.0f % 360.0f : 0.0f);
        float f5 = this.c + f3;
        GLStateSnapshot gLStateSnapshot = null;
        if (this.K) {
            gLStateSnapshot = GLStateSnapshot.getInstance();
            GL11.glDisable((int)2929);
            GL11.glDepthMask((boolean)false);
        }
        try {
            if (this.E) {
                for (int j = this.F; j >= 1; --j) {
                    float f6 = (float)j / (float)(this.F + 1);
                    float f7 = (1.0f - f6 * f6) * 0.5f;
                    float f8 = f2 - (float)j * this.G;
                    float f9 = this.A ? (float)Math.sin((f8 + this.D) * this.B) * this.C : 0.0f;
                    float f10 = this.t + (this.u ? f8 * this.v * 360.0f % 360.0f : 0.0f);
                    this.a(this.c + f9, f10, f8, f7, false, 1.0f);
                }
            }
            if (this.i) {
                float f11 = this.j * 0.18f;
                this.a(f5 - f11 * 0.5f, f4, f2, 0.55f, true, 1.0f + f11);
            }
            this.a(f5, f4, f2, 1.0f, false, 1.0f);
            if (this.l) {
                GL11.glLineWidth((float)this.n);
                this.d(f5, f4);
                GL11.glLineWidth((float)1.0f);
            }
        }
        finally {
            if (gLStateSnapshot != null) {
                gLStateSnapshot.b();
            }
        }
    }

    private void a(float f2, float f3, float f4, float f5, boolean bl, float f6) {
        float f7 = this.e * f6;
        float f8 = this.f * (f6 > 1.0f ? f6 : 1.0f);
        BufferBuilder mc23 = new BufferBuilder(new BufferAllocator(1024), VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_TEXTURE_COLOR);
        Matrix4f matrix4f = this.a.peek().getPositionMatrix();
        float f9 = (float)Math.toRadians(f3);
        float f10 = f2 + f8;
        if (this.s == Shape.STAR) {
            float f11;
            double var13_13;
            var13_13 = 5;
            float f12 = f7 * 0.4f;
            int n2 = var13_13 * 2;
            for (int j = 0; j <= n2; ++j) {
                f11 = (float)((double)j * Math.PI / (double)var13_13) + f9;
                float f13 = j % 2 == 0 ? f7 : f12;
                float f14 = this.b + (float)Math.cos(f11) * f13;
                float f15 = this.d + (float)Math.sin(f11) * f13;
                float f16 = (float)j / (float)n2;
                this.a(mc23, matrix4f, f14, f2, f10, f15, f16);
            }
            float f17 = this.b + (float)Math.cos(f9) * f7;
            f11 = this.d + (float)Math.sin(f9) * f7;
            this.a(mc23, matrix4f, f17, f2, f10, f11, 0.0f);
        } else if (this.s == Shape.FLOWER) {
            double var13_13;
            var13_13 = 6;
            int n3 = var13_13 * 8;
            for (int j = 0; j <= n3; ++j) {
                float f18 = (float)((double)(j * 2) * Math.PI / (double)n3) + f9;
                float f19 = 0.7f + 0.3f * (float)Math.cos(f18 * (float)var13_13);
                float f20 = f7 * f19;
                float f21 = this.b + (float)Math.cos(f18) * f20;
                float f22 = this.d + (float)Math.sin(f18) * f20;
                this.a(mc23, matrix4f, f21, f2, f10, f22, (float)j / (float)n3);
            }
        } else {
            double var13_13;
            var13_13 = this.s.segments;
            for (int j = 0; j <= var13_13; ++j) {
                float f23 = (float)((double)(j * 2) * Math.PI / (double)var13_13) + f9;
                float f24 = this.b + (float)Math.cos(f23) * f7;
                float f25 = this.d + (float)Math.sin(f23) * f7;
                this.a(mc23, matrix4f, f24, f2, f10, f25, (float)j / (float)var13_13);
            }
        }
        BuiltBuffer mc25 = mc23.endNullable();
        if (mc25 == null) {
            return;
        }
        Color color = this.k != null ? this.k : (this.h != null ? this.h : this.g);
        this.a(mc25, this.g, this.h != null ? this.h : this.g, color, f4, f5, bl);
    }

    private void a(BufferBuilder mc23, Matrix4f matrix4f, float f2, float f3, float f4, float f5, float f6) {
        mc23.vertex((Matrix4fc)matrix4f, f2, f3, f5).texture(f6, 0.0f).color(255, 255, 255, 255);
        mc23.vertex((Matrix4fc)matrix4f, f2, f4, f5).texture(f6, 1.0f).color(255, 255, 255, 255);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void a(BuiltBuffer mc25, Color color, Color color2, Color color3, float f2, float f3, boolean bl) {
        GlProgram glProgram = Shaders.l();
        if (glProgram == null) {
            GuiRenderer.b(mc25, new Matrix4f(), GameRendererMixinBridge.getProjection());
            return;
        }
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            int n2;
            GL11.glEnable((int)3042);
            if (bl) {
                GL11.glBlendFunc((int)770, (int)1);
            } else {
                GL14.glBlendFuncSeparate((int)770, (int)771, (int)1, (int)771);
            }
            GL11.glDisable((int)2929);
            GL11.glDisable((int)2884);
            glProgram.a();
            float[] fArray = new float[16];
            new Matrix4f().get(fArray);
            float[] fArray2 = new float[16];
            GameRendererMixinBridge.getProjection().get(fArray2);
            int n3 = glProgram.a("ModelViewMat");
            if (n3 >= 0) {
                GL20.glUniformMatrix4fv((int)n3, (boolean)false, (float[])fArray);
            }
            if ((n2 = glProgram.a("ProjMat")) >= 0) {
                GL20.glUniformMatrix4fv((int)n2, (boolean)false, (float[])fArray2);
            }
            glProgram.b("uTime").a(f2);
            GuiRenderer.a(glProgram, "uColorBottom", color);
            GuiRenderer.a(glProgram, "uColorTop", color2);
            GuiRenderer.a(glProgram, "uGlowColor", color3);
            glProgram.b("uAlphaMul").a(f3);
            glProgram.b("uPulseSpeed").a(this.o ? this.p : 0.0f);
            glProgram.b("uPulseAmount").a(this.q);
            glProgram.b("uFadeHeight").a(this.r > 0.0f && this.f > 0.0f ? this.r / Math.max(this.f, 1.0E-4f) : 0.0f);
            glProgram.b("uRainbow").a(this.w ? 1 : 0);
            glProgram.b("uRainbowSpeed").a(this.x);
            glProgram.b("uRainbowSat").a(this.y);
            glProgram.b("uRainbowBright").a(this.z);
            glProgram.b("uGlowIntensity").a(this.i ? this.j : 0.0f);
            glProgram.b("uScanSpeed").a(this.H);
            glProgram.b("uEdgeBloom").a(this.i ? this.I : 0.0f);
            glProgram.b("uFresnelStrength").a(this.i ? this.J : 0.0f);
            glProgram.b("uAdditive").a(bl ? 1 : 0);
            glProgram.b("uUseTopColor").a(this.h != null ? 1 : 0);
            GuiRenderer.a(mc25);
        }
        finally {
            glProgram.b();
            gLStateSnapshot.b();
        }
    }

    private void d(float f2, float f3) {
        Color color = this.m;
        float f4 = (float)color.getRed() / 255.0f;
        float f5 = (float)color.getGreen() / 255.0f;
        float f6 = (float)color.getBlue() / 255.0f;
        float f7 = (float)color.getAlpha() / 255.0f;
        Matrix4f matrix4f = this.a.peek().getPositionMatrix();
        float f8 = (float)Math.toRadians(f3);
        float f9 = f2 + this.f;
        BufferBuilder mc23 = new BufferBuilder(new BufferAllocator(512), VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
        this.a(mc23, matrix4f, f2, f8, f4, f5, f6, f7);
        BuiltBuffer mc25 = mc23.endNullable();
        if (mc25 != null) {
            GuiRenderer.a(mc25, new Matrix4f(), GameRendererMixinBridge.getProjection());
        }
        mc23 = new BufferBuilder(new BufferAllocator(512), VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
        this.a(mc23, matrix4f, f9, f8, f4, f5, f6, f7 * 0.3f);
        mc25 = mc23.endNullable();
        if (mc25 != null) {
            GuiRenderer.a(mc25, new Matrix4f(), GameRendererMixinBridge.getProjection());
        }
        mc23 = new BufferBuilder(new BufferAllocator(512), VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        int n2 = Math.min(this.s.segments, 4);
        if (this.s == Shape.STAR) {
            n2 = 5;
        }
        if (this.s == Shape.FLOWER) {
            n2 = 6;
        }
        for (int j = 0; j < n2; ++j) {
            float f10 = (float)((double)(j * 2) * Math.PI / (double)n2) + f8;
            float f11 = this.b + (float)Math.cos(f10) * this.e;
            float f12 = this.d + (float)Math.sin(f10) * this.e;
            mc23.vertex((Matrix4fc)matrix4f, f11, f2, f12).color(f4, f5, f6, f7);
            mc23.vertex((Matrix4fc)matrix4f, f11, f9, f12).color(f4, f5, f6, f7 * 0.3f);
        }
        mc25 = mc23.endNullable();
        if (mc25 != null) {
            GuiRenderer.a(mc25, new Matrix4f(), GameRendererMixinBridge.getProjection());
        }
    }

    private void a(BufferBuilder mc23, Matrix4f matrix4f, float f2, float f3, float f4, float f5, float f6, float f7) {
        if (this.s == Shape.STAR) {
            float f8;
            int n2 = 5;
            float f9 = this.e * 0.4f;
            for (int j = 0; j <= n2 * 2; ++j) {
                f8 = (float)((double)j * Math.PI / (double)n2) + f3;
                float f10 = j % 2 == 0 ? this.e : f9;
                float f11 = this.b + (float)Math.cos(f8) * f10;
                float f12 = this.d + (float)Math.sin(f8) * f10;
                mc23.vertex((Matrix4fc)matrix4f, f11, f2, f12).color(f4, f5, f6, f7);
            }
            float f13 = this.b + (float)Math.cos(f3) * this.e;
            f8 = this.d + (float)Math.sin(f3) * this.e;
            mc23.vertex((Matrix4fc)matrix4f, f13, f2, f8).color(f4, f5, f6, f7);
        } else if (this.s == Shape.FLOWER) {
            int n3 = 6;
            int n4 = n3 * 8;
            for (int j = 0; j <= n4; ++j) {
                float f14 = (float)((double)(j * 2) * Math.PI / (double)n4) + f3;
                float f15 = 0.7f + 0.3f * (float)Math.cos(f14 * (float)n3);
                float f16 = this.e * f15;
                float f17 = this.b + (float)Math.cos(f14) * f16;
                float f18 = this.d + (float)Math.sin(f14) * f16;
                mc23.vertex((Matrix4fc)matrix4f, f17, f2, f18).color(f4, f5, f6, f7);
            }
        } else {
            int n5 = this.s.segments;
            for (int j = 0; j <= n5; ++j) {
                float f19 = (float)((double)(j * 2) * Math.PI / (double)n5) + f3;
                float f20 = this.b + (float)Math.cos(f19) * this.e;
                float f21 = this.d + (float)Math.sin(f19) * this.e;
                mc23.vertex((Matrix4fc)matrix4f, f20, f2, f21).color(f4, f5, f6, f7);
            }
        }
    }
}

