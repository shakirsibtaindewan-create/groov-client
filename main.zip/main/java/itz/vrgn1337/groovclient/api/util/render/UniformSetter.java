/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public final class UniformSetter {
    private final int a;

    public UniformSetter(int n2) {
        this.a = n2;
    }

    private boolean a() {
        return this.a >= 0 && GL11.glGetInteger((int)35725) != 0;
    }

    public void a(float f2) {
        if (this.a()) {
            GL20.glUniform1f((int)this.a, (float)f2);
        }
    }

    public void a(float f2, float f3) {
        if (this.a()) {
            GL20.glUniform2f((int)this.a, (float)f2, (float)f3);
        }
    }

    public void a(float f2, float f3, float f4, float f5) {
        if (this.a()) {
            GL20.glUniform4f((int)this.a, (float)f2, (float)f3, (float)f4, (float)f5);
        }
    }

    public void a(int n2) {
        if (this.a()) {
            GL20.glUniform1i((int)this.a, (int)n2);
        }
    }
}

