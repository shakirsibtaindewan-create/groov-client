/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.item;

import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

public class ItemUtils {
    public static ItemStack a(Item mc17) {
        for (int j = 0; j < 9; ++j) {
            ItemStack mc33 = Main.mc.player.getInventory().getStack(j);
            if (!mc33.isOf(mc17)) continue;
            return mc33;
        }
        return null;
    }

    public static boolean b(Item mc17) {
        for (int j = 0; j < 9; ++j) {
            if (Main.mc.player.getMainHandStack().getItem() != mc17) continue;
            Main.mc.player.getInventory().setSelectedSlot(j);
            return true;
        }
        return false;
    }

    public static boolean c(Item mc17) {
        String string = Registries.ITEM.getId((Object)mc17).getPath();
        return string.endsWith("_sword");
    }

    public static boolean d(Item mc17) {
        String string = Registries.ITEM.getId((Object)mc17).getPath();
        return string.endsWith("_axe");
    }

    public static boolean e(Item mc17) {
        String string = Registries.ITEM.getId((Object)mc17).getPath();
        return string.endsWith("_spear");
    }

    public static int a() {
        for (int j = 0; j < 9; ++j) {
            if (!ItemUtils.c(Main.mc.player.getInventory().getStack(j).getItem())) continue;
            return j;
        }
        return -1;
    }

    public static int b() {
        for (int j = 0; j < 9; ++j) {
            if (!ItemUtils.d(Main.mc.player.getInventory().getStack(j).getItem())) continue;
            return j;
        }
        return -1;
    }

    public static int c() {
        for (int j = 0; j < 9; ++j) {
            if (!ItemUtils.e(Main.mc.player.getInventory().getStack(j).getItem())) continue;
            return j;
        }
        return -1;
    }

    public static int f(Item mc17) {
        for (int j = 0; j < 9; ++j) {
            if (Main.mc.player.getInventory().getStack(j).getItem() != mc17) continue;
            return j;
        }
        return -1;
    }

    public static boolean g(Item mc17) {
        return ItemUtils.f(mc17) != -1;
    }

    public static boolean h(Item mc17) {
        int n2 = ItemUtils.f(mc17);
        if (n2 == -1) {
            return false;
        }
        Main.mc.player.getInventory().setSelectedSlot(n2);
        return true;
    }
}

