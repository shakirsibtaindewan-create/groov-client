/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util;

import itz.vrgn1337.groovclient.api.util.WaitCondition;
import java.util.function.BooleanSupplier;

final class TimeoutWaitCondition
implements WaitCondition {
    private final BooleanSupplier a;
    private int b;

    TimeoutWaitCondition(BooleanSupplier booleanSupplier, int n2) {
        this.a = booleanSupplier;
        this.b = n2;
    }

    public boolean a() {
        if (this.a != null && this.a.getAsBoolean()) {
            return true;
        }
        if (this.b <= 0) {
            return true;
        }
        --this.b;
        return this.b <= 0;
    }
}

