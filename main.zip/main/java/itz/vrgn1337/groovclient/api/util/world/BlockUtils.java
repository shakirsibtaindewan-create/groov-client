/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.world;

import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.api.util.world.RaycastHit;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.entity.Entity;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.BlockState;
import net.minecraft.state.property.Property;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.block.RespawnAnchorBlock;

public class BlockUtils {
    public static final Direction[] a = new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, Direction.UP};

    public static BlockState a(BlockPos mc0) {
        return Main.mc.world.getBlockState(mc0);
    }

    public static boolean b(BlockPos mc0) {
        BlockState mc1 = Main.mc.world.getBlockState(mc0);
        return mc1.isOf(Blocks.RESPAWN_ANCHOR) && (Integer)mc1.get((Property)RespawnAnchorBlock.CHARGES) != 0;
    }

    public static Vec3d a(BlockPos mc0, Direction mc63) {
        return Vec3d.ofCenter((Vec3i)mc0).add(Vec3d.of((Vec3i)mc63.getVector()).multiply(0.45));
    }

    public static boolean a(BlockPos mc0, Direction mc63, Vec3d VanillaChestLootTableGenerator) {
        BlockHitResult mc7 = Main.mc.world.raycast(new RaycastContext(Main.mc.player.getEyePos(), VanillaChestLootTableGenerator, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, (Entity)Main.mc.player));
        return mc7.getType() == HitResult.Type.BLOCK && mc7.getBlockPos().equals((Object)mc0) && mc7.getSide() == mc63;
    }

    public static RaycastHit a(BlockPos mc0, BlockPos mc64, Direction mc63) {
        if (Main.mc.player == null || Main.mc.world == null) {
            return null;
        }
        RaycastHit raycastHit = null;
        double d2 = Double.MAX_VALUE;
        boolean bl = RotationManager.getInstance().a(mc0);
        for (Direction mc65 : a) {
            BlockPos mc66 = mc0.offset(mc65.getOpposite());
            if (mc64 != null && mc66.equals((Object)mc64) || !Main.mc.player.canInteractWithBlockAt(mc66, 0.0) || Main.mc.world.isAir(mc66) || RotationManager.getInstance().a(mc66)) continue;
            Vec3d VanillaChestLootTableGenerator = BlockUtils.a(mc66, mc65);
            if (!bl && !BlockUtils.a(mc66, mc65, VanillaChestLootTableGenerator)) continue;
            Rotation rotation = RotationUtils.a(VanillaChestLootTableGenerator, Main.mc.player.getEyePos());
            float f2 = Math.abs(MathHelper.wrapDegrees((float)(Main.mc.player.getYaw() - rotation.a())));
            float f3 = MathHelper.clamp((float)rotation.b(), (float)-90.0f, (float)90.0f);
            float f4 = Math.abs(Main.mc.player.getPitch() - f3);
            double d3 = (double)f2 + (double)f4 * 0.6 + Main.mc.player.getEyePos().squaredDistanceTo(VanillaChestLootTableGenerator) * 0.12;
            if (mc63 != null && mc64 != null && mc0.equals((Object)mc64.offset(mc63))) {
                d3 -= 2.0;
            }
            if (!(d3 < d2)) continue;
            d2 = d3;
            raycastHit = new RaycastHit(mc66, mc65, VanillaChestLootTableGenerator);
        }
        return raycastHit;
    }
}

