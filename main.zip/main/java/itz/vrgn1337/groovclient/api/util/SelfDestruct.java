/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util;

import itz.vrgn1337.groovclient.entrypoint.Main;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.URI;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Stream;

public final class SelfDestruct {
    private static final String ROOT = "itz.vrgn1337.groovclient.";
    private static final String MIXIN = "itz.vrgn1337.groovclient.mixin.";

    private SelfDestruct() {
    }

    public static void detonate() {
        List<String> list = SelfDestruct.collectClassNames();
        ClassLoader classLoader = Main.class.getClassLoader();
        for (String string : list) {
            if (!string.startsWith(ROOT) || string.startsWith(MIXIN) || string.equals(Main.class.getName()) || string.equals(SelfDestruct.class.getName())) continue;
            try {
                Class<?> clazz = Class.forName(string, false, classLoader);
                SelfDestruct.wipeStatics(clazz);
            }
            catch (Throwable throwable) {}
        }
    }

    private static List collectClassNames() {
        ArrayList<String> arrayList;
        block15: {
            arrayList = new ArrayList<String>();
            try {
                URI uRI = Main.class.getProtectionDomain().getCodeSource().getLocation().toURI();
                Path path = Paths.get(uRI);
                if (Files.isDirectory(path, new LinkOption[0])) {
                    try (Stream<Path> stream = Files.walk(path, new FileVisitOption[0]);){
                        stream.filter(SelfDestruct::lambda$collectClassNames$0).forEach(arg_0 -> SelfDestruct.lambda$collectClassNames$1(path, arrayList, arg_0));
                        break block15;
                    }
                }
                try (JarFile jarFile = new JarFile(path.toFile());){
                    Enumeration<JarEntry> enumeration = jarFile.entries();
                    while (enumeration.hasMoreElements()) {
                        JarEntry jarEntry = enumeration.nextElement();
                        String string = jarEntry.getName();
                        if (!string.endsWith(".class")) continue;
                        arrayList.add(string.substring(0, string.length() - 6).replace('/', '.'));
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return arrayList;
    }

    private static void wipeStatics(Class clazz) {
        for (Field field : clazz.getDeclaredFields()) {
            int n2 = field.getModifiers();
            if (!Modifier.isStatic(n2) || field.getType().isPrimitive()) continue;
            try {
                field.setAccessible(true);
                if (Modifier.isFinal(n2)) {
                    Object object = field.get(null);
                    if (object instanceof Collection) {
                        ((Collection)object).clear();
                        continue;
                    }
                    if (!(object instanceof Map)) continue;
                    ((Map)object).clear();
                    continue;
                }
                field.set(null, null);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private static void lambda$collectClassNames$1(Path path, List list, Path path2) {
        String string = path.relativize(path2).toString().replace('\\', '/').replace('/', '.');
        list.add(string.substring(0, string.length() - 6));
    }

    private static boolean lambda$collectClassNames$0(Path path) {
        return path.toString().endsWith(".class");
    }
}

