/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.rotation;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;

public final class TweenUtil {
    private static final TweenUtil a = new TweenUtil();
    private static final MinecraftClient b = MinecraftClient.getInstance();
    private Object c;
    private boolean d;
    private float e;
    private float f = 12.0f;
    private float g = 0.65f;
    private float h = 0.8f;
    private float i = 0.0f;
    private float j = 0.0f;
    private float k = 0.0f;
    private long l = 0L;
    private long m = 0L;
    private float n = 1.0f;
    private float o = 1.0f;
    private long p = 0L;
    private float q = 0.0f;
    private boolean r = false;
    private boolean s = false;
    private float t = 1.0f;
    private long u = 0L;
    private Vec3d v = null;
    private Vec3d w = Vec3d.ZERO;
    private float x = 0.0f;
    private float y = 0.0f;
    private long z = 0L;
    private int A = 0;
    private int B = 0;
    private float C = 0.0f;
    private float D = 0.0f;
    private long E = 0L;
    private float F = 0.0f;
    private float G = 0.0f;
    private long H = 0L;

    public static TweenUtil getInstance() {
        return a;
    }

    private TweenUtil() {
    }

    public void a(Object object, Vec3d VanillaChestLootTableGenerator, float f2) {
        this.a(object, VanillaChestLootTableGenerator, f2, 0.65f, 0.8f);
    }

    public void a(Object object, Vec3d VanillaChestLootTableGenerator, float f2, float f3, float f4) {
        Vec3d WallPlayerSkullBlock;
        if (TweenUtil.b.player == null || VanillaChestLootTableGenerator == null) {
            return;
        }
        this.c = object;
        this.d = true;
        this.z = System.currentTimeMillis();
        this.f = Math.max(0.5f, f2);
        this.g = MathHelper.clamp((float)f3, (float)0.05f, (float)1.0f);
        this.h = MathHelper.clamp((float)f4, (float)0.05f, (float)1.0f);
        long l2 = System.nanoTime();
        float f5 = 0.016666668f;
        if (this.u > 0L) {
            f5 = (float)((double)(l2 - this.u) / 1.0E9);
            f5 = MathHelper.clamp((float)f5, (float)0.002f, (float)0.08f);
        }
        this.u = l2;
        if (this.v == null) {
            this.v = VanillaChestLootTableGenerator;
            this.w = Vec3d.ZERO;
        } else {
            WallPlayerSkullBlock = VanillaChestLootTableGenerator.subtract(this.v).multiply(1.0 / (double)f5);
            WallPlayerSkullBlock = TweenUtil.a(WallPlayerSkullBlock, 14.0);
            float f6 = 0.12f + this.h * 0.24f;
            this.w = this.w.lerp(WallPlayerSkullBlock, (double)MathHelper.clamp((float)f6, (float)0.08f, (float)0.42f));
            this.v = VanillaChestLootTableGenerator;
        }
        WallPlayerSkullBlock = TweenUtil.b.player.getEyePos();
        this.y = (float)Math.sqrt(VanillaChestLootTableGenerator.squaredDistanceTo(WallPlayerSkullBlock));
        double d2 = Math.sqrt(this.w.x * this.w.x + this.w.z * this.w.z);
        float f7 = TweenUtil.b.player.getYaw();
        float f8 = Math.abs(MathHelper.wrapDegrees((float)(this.e - f7)));
        double d3 = 0.01 + (1.0 - (double)this.h) * 0.02 + Math.min(0.028, (double)f8 / 520.0) + Math.min(0.02, d2 * 0.0045);
        d3 += Math.min(0.01, Math.max(0.0, (double)(this.y - 3.0f)) * 0.0018);
        d3 = MathHelper.clamp((float)((float)d3), (float)0.0f, (float)0.09f);
        Vec3d VanillaEntityLootTableGenerator = VanillaChestLootTableGenerator.add(this.w.multiply(d3));
        float f9 = TweenUtil.a(WallPlayerSkullBlock, VanillaEntityLootTableGenerator);
        if (!this.s) {
            this.e = f9;
            this.x = 0.0f;
            return;
        }
        float f10 = MathHelper.wrapDegrees((float)(f9 - this.e)) / f5;
        f10 = MathHelper.clamp((float)f10, (float)-900.0f, (float)900.0f);
        float f11 = MathHelper.clamp((float)(0.1f + this.h * 0.2f), (float)0.08f, (float)0.36f);
        this.x = MathHelper.lerp((float)f11, (float)this.x, (float)f10);
        double d4 = 0.006 + (1.0 - (double)this.h) * 0.01;
        d4 = MathHelper.clamp((float)((float)d4), (float)0.0f, (float)0.025f);
        this.a(System.currentTimeMillis(), (float)d2, f8, f5);
        this.e = f9 + this.x * (float)d4 + this.F;
    }

    public void a(Object object) {
        if (this.c == object) {
            this.d = false;
            this.c = null;
            this.m = 0L;
            this.i = 0.0f;
            this.j = 0.0f;
            this.l = 0L;
            this.n = 1.0f;
            this.o = 1.0f;
            this.p = 0L;
            this.q = 0.0f;
            this.r = false;
            this.s = false;
            this.t = 1.0f;
            this.u = 0L;
            this.v = null;
            this.w = Vec3d.ZERO;
            this.x = 0.0f;
            this.y = 0.0f;
            this.z = 0L;
            this.A = 0;
            this.B = 0;
            this.C = 0.0f;
            this.D = 0.0f;
            this.E = 0L;
            this.F = 0.0f;
            this.G = 0.0f;
            this.H = 0L;
        }
    }

    public void b() {
        float f2;
        int n2;
        float f3;
        if (!this.d || TweenUtil.b.player == null) {
            return;
        }
        if (TweenUtil.b.currentScreen != null || b.isPaused() || !b.isWindowFocused()) {
            return;
        }
        if (TweenUtil.b.player.isSpectator() || TweenUtil.b.player.isDead()) {
            return;
        }
        long l2 = System.nanoTime();
        long l3 = l2 / 1000000L;
        if (this.z > 0L && l3 - this.z > 180L) {
            this.a(this.c);
            return;
        }
        if (this.m > 0L) {
            f3 = (float)((double)(l2 - this.m) / 1.0E9);
            f3 = MathHelper.clamp((float)f3, (float)0.005f, (float)0.05f);
        } else {
            f3 = 0.016666668f;
        }
        this.m = l2;
        float f4 = TweenUtil.b.player.getYaw();
        if (!this.r) {
            this.k = f4;
            this.r = true;
        }
        if (!this.s) {
            this.j = this.e;
            this.s = true;
        }
        this.a(l3, f3);
        float f5 = Math.abs(MathHelper.wrapDegrees((float)(f4 - this.k)));
        float f6 = 2.2f + (1.0f - this.h) * 2.0f;
        float f7 = f6 * 2.2f;
        if (f5 > f7) {
            this.l = l3 + 80L;
            this.t = 0.0f;
            this.i = 0.0f;
        } else if (f5 > f6) {
            this.t = Math.max(0.0f, this.t - 0.32f * (f3 * 60.0f));
            this.i *= 0.75f;
        } else {
            this.t = Math.min(1.0f, this.t + 0.1f * (f3 * 60.0f));
        }
        if (l3 < this.l) {
            this.k = f4;
            return;
        }
        float f8 = f3 * 60.0f;
        float f9 = MathHelper.clamp((float)(Math.abs(this.x) / 450.0f), (float)0.0f, (float)0.26f);
        float f10 = 0.08f + this.h * 0.14f + f9;
        float f11 = 1.0f - (float)Math.pow(1.0f - f10, f8);
        this.j += MathHelper.wrapDegrees((float)(this.e - this.j)) * f11;
        float f12 = MathHelper.wrapDegrees((float)(this.j - f4));
        this.a(l3, f3, Math.abs(f12));
        float f13 = MathHelper.clamp((float)(1.15f - Math.abs(f12) / 10.0f), (float)0.0f, (float)1.0f);
        f12 = MathHelper.wrapDegrees((float)(f12 + this.C * f13));
        if (Math.abs(f12) < 0.01f) {
            this.k = f4;
            return;
        }
        int n3 = Math.abs(f12) < 0.03f ? 0 : (n2 = f12 > 0.0f ? 1 : -1);
        if (n2 != 0) {
            this.B = this.A != 0 && n2 != this.A ? Math.min(10, this.B + 2) : Math.max(0, this.B - 1);
            this.A = n2;
        } else {
            this.B = Math.max(0, this.B - 1);
        }
        float f14 = Math.abs(f12);
        float f15 = MathHelper.clamp((float)(f14 / 18.0f), (float)0.0f, (float)1.0f);
        float f16 = 0.18f + f15 * 0.82f;
        float f17 = MathHelper.clamp((float)(f14 / 40.0f), (float)0.1f, (float)1.3f);
        float f18 = 1.0f - Math.min(0.42f, (float)this.B * 0.055f);
        float f19 = Math.max(0.35f, this.f) * f8 * this.n;
        f19 *= (0.82f + f17 * 0.26f) * f16;
        f19 *= 0.86f + f18 * 0.14f;
        float f20 = (0.06f + this.h * 0.24f) * f8;
        f20 *= (0.8f + f17 * 0.25f) * f16;
        float f21 = MathHelper.clamp((float)(0.72f + this.g * 0.22f), (float)0.72f, (float)0.94f);
        this.i += f12 * (f20 *= f18);
        this.i *= f21;
        if (this.B >= 4 && f14 < 4.5f) {
            this.i *= 0.82f;
        }
        this.i = MathHelper.clamp((float)this.i, (float)(-f19), (float)f19);
        float f22 = this.i * this.t;
        if (f14 < 2.0f) {
            f2 = MathHelper.clamp((float)(0.2f + f14 / 2.0f * 0.7f), (float)0.2f, (float)0.9f);
            f22 *= f2;
        }
        if (f14 < 0.35f) {
            f22 = f12 * 0.4f * this.t;
        }
        if (Math.abs(f2 = this.a(f22)) < 1.0E-4f) {
            this.k = f4;
            return;
        }
        float f23 = f4 + f2;
        TweenUtil.b.player.setYaw(f23);
        this.k = f23;
    }

    private void a(long l2, float f2, float f3, float f4) {
        float f5;
        float f6;
        long l3 = 420L + (long)(ThreadLocalRandom.current().nextDouble() * 720.0);
        if (this.H == 0L || l2 - this.H > l3) {
            f6 = 0.9f + f2 * 0.06f + Math.min(f3 * 0.01f, 1.6f);
            f6 = MathHelper.clamp((float)f6, (float)0.5f, (float)3.5f);
            f5 = (float)ThreadLocalRandom.current().nextGaussian() * f6 * 0.48f;
            this.G = MathHelper.clamp((float)f5, (float)(-f6), (float)f6);
            this.H = l2;
        }
        f6 = MathHelper.clamp((float)(f4 * 60.0f), (float)0.5f, (float)3.0f);
        f5 = 1.0f - (float)Math.pow(0.962f, f6);
        this.F = MathHelper.lerp((float)f5, (float)this.F, (float)this.G);
    }

    private void a(long l2, float f2) {
        if (this.p == 0L || l2 - this.p > 160L + (long)ThreadLocalRandom.current().nextInt(300)) {
            double d2 = ThreadLocalRandom.current().nextDouble();
            this.o = d2 < 0.1 ? (float)(1.02 + ThreadLocalRandom.current().nextDouble(0.05)) : (d2 < 0.22 ? (float)(0.94 + ThreadLocalRandom.current().nextDouble(0.05)) : (float)(0.97 + ThreadLocalRandom.current().nextDouble(0.04)));
            this.p = l2;
        }
        float f3 = MathHelper.clamp((float)(f2 * 60.0f), (float)0.5f, (float)3.0f);
        float f4 = 1.0f - (float)Math.pow(0.974f, f3);
        this.n = MathHelper.lerp((float)f4, (float)this.n, (float)this.o);
    }

    private void a(long l2, float f2, float f3) {
        float f4;
        if (this.E == 0L || l2 - this.E > 170L + (long)ThreadLocalRandom.current().nextInt(360)) {
            f4 = 0.04f + (1.0f - this.h) * 0.16f + (1.0f - this.g) * 0.08f;
            if (f3 > 7.0f) {
                f4 *= 0.55f;
            }
            f4 = MathHelper.clamp((float)f4, (float)0.03f, (float)0.28f);
            this.D = (float)ThreadLocalRandom.current().nextDouble(-f4, f4);
            this.E = l2;
        }
        f4 = MathHelper.clamp((float)(f2 * 60.0f), (float)0.5f, (float)3.0f);
        float f5 = 1.0f - (float)Math.pow(0.945f, f4);
        this.C = MathHelper.lerp((float)f5, (float)this.C, (float)this.D);
    }

    private static Vec3d a(Vec3d VanillaChestLootTableGenerator, double d2) {
        double d3 = Math.sqrt(VanillaChestLootTableGenerator.x * VanillaChestLootTableGenerator.x + VanillaChestLootTableGenerator.z * VanillaChestLootTableGenerator.z);
        if (d3 <= d2 || d3 <= 1.0E-6) {
            return VanillaChestLootTableGenerator;
        }
        double d4 = d2 / d3;
        return new Vec3d(VanillaChestLootTableGenerator.x * d4, VanillaChestLootTableGenerator.y, VanillaChestLootTableGenerator.z * d4);
    }

    private static float a(Vec3d VanillaChestLootTableGenerator, Vec3d WallPlayerSkullBlock) {
        double d2 = WallPlayerSkullBlock.x - VanillaChestLootTableGenerator.x;
        double d3 = WallPlayerSkullBlock.z - VanillaChestLootTableGenerator.z;
        return (float)(Math.toDegrees(Math.atan2(d3, d2)) - 90.0);
    }

    private float a(float f2) {
        if (TweenUtil.b.options == null) {
            return f2;
        }
        float f3 = ((Double)TweenUtil.b.options.getMouseSensitivity().getValue()).floatValue();
        float f4 = f3 * 0.6f + 0.2f;
        float f5 = f4 * f4 * f4 * 8.0f;
        if (f5 <= 0.0f) {
            return f2;
        }
        float f6 = f2 + this.q;
        float f7 = (float)Math.round(f6 / f5) * f5;
        this.q = f6 - f7;
        return f7;
    }
}

