/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.util.BindManager;
import itz.vrgn1337.groovclient.api.util.TickWaitCondition;
import itz.vrgn1337.groovclient.api.util.TimeoutWaitCondition;
import itz.vrgn1337.groovclient.api.util.WaitCondition;
import itz.vrgn1337.groovclient.api.util.WaitEntry;
import itz.vrgn1337.groovclient.api.util.item.SlotUtils;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.entrypoint.Main;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.function.BooleanSupplier;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;

public final class ActionQueue {
    private static ActionQueue a = new ActionQueue();
    private static final Deque<WaitEntry> b = new ArrayDeque();

    public static ActionQueue getInstance() {
        return a;
    }

    public void b() {
        a = this;
        Main.eventBus().register(a);
    }

    private ActionQueue() {
    }

    public static boolean c() {
        return !b.isEmpty();
    }

    public static boolean a(Object object) {
        for (WaitEntry waitEntry : b) {
            if (waitEntry.a() != object) continue;
            return true;
        }
        return false;
    }

    public static int d() {
        return b.size();
    }

    public static void b(Object object) {
        b.removeIf(arg_0 -> a.lambda$cancel$0((Object)object, arg_0));
    }

    public static void e() {
        b.clear();
    }

    public static void a(Object object, WaitCondition[] waitConditionArray) {
        if (object == null || waitConditionArray == null) {
            return;
        }
        for (WaitCondition waitCondition : waitConditionArray) {
            if (waitCondition == null) continue;
            b.offer(new WaitEntry(object, waitCondition));
        }
    }

    public static void a(Object object, WaitCondition waitCondition) {
        if (object == null || waitCondition == null) {
            return;
        }
        b.offer(new WaitEntry(object, waitCondition));
    }

    public static void a(Object object, int n2) {
        ActionQueue.a(object, ActionQueue.a(n2));
    }

    public static void a(Object object, Runnable runnable) {
        ActionQueue.a(object, ActionQueue.a(runnable));
    }

    public static void a(Object object, Hand mc8) {
        ActionQueue.a(object, ActionQueue.a(mc8));
    }

    public static void a(Object object, Entity mc2) {
        ActionQueue.a(object, ActionQueue.a(mc2));
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Priority(value=-100)
    private void onUpdateEventPre(UpdateEvent.Pre updateEvent$Pre) {
        boolean bl;
        if (b.isEmpty()) {
            return;
        }
        if (Main.mc.player == null || Main.mc.world == null) {
            b.clear();
            return;
        }
        WaitEntry waitEntry = (WaitEntry)b.peek();
        BindManager.j();
        try {
            bl = waitEntry.b().a();
        }
        catch (Throwable throwable) {
            bl = true;
        }
        finally {
            BindManager.k();
        }
        if (bl) {
            b.poll();
        }
    }

    public static WaitCondition a(int n2) {
        return () -> a.lambda$swap$1((int)n2);
    }

    public static WaitCondition a(Item mc17) {
        return () -> a.lambda$swapTo$2((Item)mc17);
    }

    public static WaitCondition a(Hand mc8) {
        return () -> a.lambda$use$3((Hand)mc8);
    }

    public static WaitCondition a(Entity mc2) {
        return () -> a.lambda$attack$4((Entity)mc2);
    }

    public static WaitCondition a(Runnable runnable) {
        return () -> a.lambda$run$5((Runnable)runnable);
    }

    public static WaitCondition b(int n2) {
        return new TickWaitCondition(Math.max(0, n2));
    }

    public static WaitCondition a(BooleanSupplier booleanSupplier) {
        return () -> a.lambda$waitUntil$6((BooleanSupplier)booleanSupplier);
    }

    public static WaitCondition a(BooleanSupplier booleanSupplier, int n2) {
        return new TimeoutWaitCondition(booleanSupplier, Math.max(0, n2));
    }

    private static boolean lambda$waitUntil$6(BooleanSupplier booleanSupplier) {
        return booleanSupplier == null || booleanSupplier.getAsBoolean();
    }

    private static boolean lambda$run$5(Runnable runnable) {
        if (runnable != null) {
            runnable.run();
        }
        return true;
    }

    private static boolean lambda$attack$4(Entity mc2) {
        if (Main.mc.player == null || Main.mc.interactionManager == null || mc2 == null) {
            return true;
        }
        Main.mc.interactionManager.attackEntity((PlayerEntity)Main.mc.player, mc2);
        Main.mc.player.swingHand(Hand.MAIN_HAND);
        return true;
    }

    private static boolean lambda$use$3(Hand mc8) {
        if (Main.mc.player == null) {
            return true;
        }
        RotationManager.getInstance().a(mc8);
        Main.mc.player.swingHand(mc8);
        return true;
    }

    private static boolean lambda$swapTo$2(Item mc17) {
        if (Main.mc.player == null || mc17 == null) {
            return true;
        }
        for (int j = 0; j < 9; ++j) {
            if (!Main.mc.player.getInventory().getStack(j).isOf(mc17)) continue;
            if (Main.mc.player.getInventory().getSelectedSlot() != j) {
                Main.mc.player.getInventory().setSelectedSlot(j);
            }
            return true;
        }
        return true;
    }

    private static boolean lambda$swap$1(int n2) {
        if (Main.mc.player == null) {
            return true;
        }
        if (n2 < 0 || n2 >= 9) {
            return true;
        }
        if (Main.mc.player.getInventory().getSelectedSlot() != n2) {
            SlotUtils.c(n2);
        }
        return true;
    }

    private static boolean lambda$cancel$0(Object object, WaitEntry waitEntry) {
        return waitEntry.a() == object;
    }
}

