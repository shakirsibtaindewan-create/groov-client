/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

public enum RenderLayerMode {
    BASE, OVERLAY, FEATURE;

    private RenderLayerMode() {

    }

}

