/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

public enum Shape {
    CYLINDER(48), TRIANGLE(3), QUAD(4), PENTAGON(5), HEXAGON(6), STAR(5), FLOWER(6);
    public final int segments;

    private Shape(int segments) {
        this.segments = segments;

    }

}

