/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.rotation;

import itz.vrgn1337.groovclient.entrypoint.Main;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class RotationJitter {
    private static double a = -1.0;
    private static double b = 0.0;
    private static final List c = new ArrayList();
    private static final List d = new ArrayList();
    private static final int e = 30;

    public static double a() {
        double d2 = (Double)Main.mc.options.getMouseSensitivity().getValue();
        if (d2 == a) {
            return b;
        }
        a = d2;
        double d3 = d2 * 0.6 + 0.2;
        b = d3 * d3 * d3 * 8.0;
        return b;
    }

    public static void a(float f2, float f3) {
        float f4 = (float)Math.sqrt(f2 * f2 + f3 * f3);
        c.add(Float.valueOf(f4));
        d.add(System.currentTimeMillis());
        if (c.size() > 30) {
            c.remove(0);
            d.remove(0);
        }
    }

    public static float b() {
        if (c.size() < 2) {
            return 5.0f;
        }
        float f2 = 0.0f;
        float f3 = 0.0f;
        for (int j = 0; j < c.size(); ++j) {
            float f4 = (float)(j + 1) / (float)c.size();
            f2 += ((Float)c.get(j)).floatValue() * f4;
            f3 += f4;
        }
        return f3 > 0.0f ? f2 / f3 : 5.0f;
    }

    public static float c() {
        if (c.size() < 10) {
            return 1.0f;
        }
        float f2 = RotationJitter.b();
        float f3 = 0.0f;
        Iterator iterator = c.iterator();
        while (iterator.hasNext()) {
            float f4 = ((Float)iterator.next()).floatValue();
            f3 += (f4 - f2) * (f4 - f2);
        }
        float f5 = (float)Math.sqrt(f3 /= (float)c.size());
        return Math.max(0.3f, 1.0f - f5 / f2);
    }
}

