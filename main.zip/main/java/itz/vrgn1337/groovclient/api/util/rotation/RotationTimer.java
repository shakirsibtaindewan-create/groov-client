/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.rotation;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationState;
import itz.vrgn1337.groovclient.entrypoint.Main;
import java.util.Random;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;
import itz.vrgn1337.groovclient.api.event.hooks.PacketSendEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketSendEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;

public class RotationTimer {
    private static RotationTimer a = null;
    private static final Random b = new Random();
    private volatile RotationState c = RotationState.IDLE;
    private Rotation d;
    private final float e;
    private final float f;
    private final int g;
    private final Runnable h;
    private final Runnable i;
    private Runnable j;
    private final int k;
    private final long l;
    private final boolean m;
    private final float n;
    private final float o;
    private final int p;
    private boolean q = true;
    private float r;
    private float s;
    private long t;
    private int u = 0;
    private float v = 0.0f;
    private float w = 0.0f;
    private long x = 0L;
    private float y = 0.0f;
    private int z = 0;
    private float A = 0.0f;
    private float B = 0.0f;
    private float C = 0.0f;
    private float D = 0.0f;
    private float E = 1.0f;
    private long F = 0L;
    private boolean G = false;
    private static double H = -1.0;
    private static double I = 0.0;

    public static RotationTimer a(Rotation rotation, Runnable runnable) {
        return RotationTimer.a(rotation, runnable, 100L, 0);
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, int n2) {
        return RotationTimer.a(rotation, runnable, 100L, n2);
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, long l2) {
        return RotationTimer.a(rotation, runnable, l2, 0);
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, long l2, int n2) {
        if (RotationTimer.k()) {
            return null;
        }
        a = new RotationTimer(rotation.a(), rotation.b(), rotation.c(), runnable, null, 0, l2, false, 0.0f, 0.0f, n2);
        return a;
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, float f2, float f3) {
        return RotationTimer.a(rotation, runnable, 100L, f2, f3, 0);
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, float f2, float f3, int n2) {
        return RotationTimer.a(rotation, runnable, 100L, f2, f3, n2);
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, long l2, float f2, float f3) {
        return RotationTimer.a(rotation, runnable, l2, f2, f3, 0);
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, long l2, float f2, float f3, int n2) {
        if (RotationTimer.k()) {
            return null;
        }
        a = new RotationTimer(rotation.a(), rotation.b(), rotation.c(), runnable, null, 0, l2, false, f2, f3, n2);
        return a;
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, Runnable runnable2, int n2) {
        return RotationTimer.a(rotation, runnable, runnable2, n2, 100L, 0);
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, Runnable runnable2, int n2, int n3) {
        return RotationTimer.a(rotation, runnable, runnable2, n2, 100L, n3);
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, Runnable runnable2, int n2, long l2) {
        return RotationTimer.a(rotation, runnable, runnable2, n2, l2, 0);
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, Runnable runnable2, int n2, long l2, int n3) {
        if (RotationTimer.k()) {
            return null;
        }
        a = new RotationTimer(rotation.a(), rotation.b(), rotation.c(), runnable, runnable2, n2, l2, false, 0.0f, 0.0f, n3);
        return a;
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, Runnable runnable2, int n2, long l2, float f2, float f3) {
        return RotationTimer.a(rotation, runnable, runnable2, n2, l2, f2, f3, 0);
    }

    public static RotationTimer a(Rotation rotation, Runnable runnable, Runnable runnable2, int n2, long l2, float f2, float f3, int n3) {
        if (RotationTimer.k()) {
            return null;
        }
        a = new RotationTimer(rotation.a(), rotation.b(), rotation.c(), runnable, runnable2, n2, l2, false, f2, f3, n3);
        return a;
    }

    public static RotationTimer b(Rotation rotation, Runnable runnable, float f2, float f3) {
        return RotationTimer.b(rotation, runnable, 100L, f2, f3, 0);
    }

    public static RotationTimer b(Rotation rotation, Runnable runnable, float f2, float f3, int n2) {
        return RotationTimer.b(rotation, runnable, 100L, f2, f3, n2);
    }

    public static RotationTimer b(Rotation rotation, Runnable runnable, long l2, float f2, float f3) {
        return RotationTimer.b(rotation, runnable, l2, f2, f3, 0);
    }

    public static RotationTimer b(Rotation rotation, Runnable runnable, long l2, float f2, float f3, int n2) {
        if (RotationTimer.k()) {
            return null;
        }
        a = new RotationTimer(rotation.a(), rotation.b(), rotation.c(), runnable, null, 0, l2, true, f2, f3, n2);
        return a;
    }

    public RotationTimer a(boolean bl) {
        this.q = bl;
        return this;
    }

    public RotationTimer a(Runnable runnable) {
        this.j = runnable;
        return this;
    }

    public void a() {
        if (this.j == null) {
            return;
        }
        this.j.run();
        this.j = null;
    }

    private RotationTimer(float f2, float f3, int n2, Runnable runnable, Runnable runnable2, int n3, long l2, boolean bl, float f4, float f5, int n4) {
        this.e = f2;
        this.f = f3;
        this.g = n2;
        this.h = runnable;
        this.i = runnable2;
        this.k = n3;
        this.l = l2;
        this.m = bl;
        this.n = f4;
        this.o = f5;
        this.p = MathHelper.clamp((int)n4, (int)0, (int)10);
        if (Main.mc.player != null) {
            this.r = Main.mc.player.getYaw();
            this.s = Main.mc.player.getPitch();
            this.A = Math.abs(this.b(this.r, f2));
            this.B = Math.abs(this.b(this.s, f3));
        }
        this.b();
        Main.eventBus().register(this);
        this.c = this.p > 0 && this.z > 0 ? RotationState.REACTION_DELAY : RotationState.ROTATING;
    }

    private void b() {
        if (this.p == 0) {
            return;
        }
        float f2 = (float)this.p / 10.0f;
        int n2 = (int)(f2 * 5.0f);
        this.z = n2 > 0 ? b.nextInt(n2) + 1 : 0;
        float f3 = f2 * 3.0f;
        this.C = (b.nextFloat() * 2.0f - 1.0f) * f3;
        this.D = (b.nextFloat() * 2.0f - 1.0f) * f3 * 0.5f;
        this.c();
    }

    private void c() {
        if (this.p == 0) {
            this.E = 1.0f;
            return;
        }
        float f2 = (float)this.p / 10.0f;
        float f3 = f2 * 0.3f;
        this.E = 1.0f - f3 + b.nextFloat() * f3 * 2.0f;
    }

    @Priority(value=0)
    private void onRenderWorldEventPre(RenderWorldEvent.Pre renderWorldEvent$Pre) {
        float f2;
        float f3;
        float f4;
        float f5;
        float f6;
        float f7;
        if (Main.mc.player == null || Main.mc.world == null) {
            return;
        }
        if (this.c == RotationState.IDLE || this.c == RotationState.REACTION_DELAY) {
            return;
        }
        if (this.p > 0 && this.d()) {
            return;
        }
        if (this.p > 0 && System.currentTimeMillis() - this.F > (long)(100 + b.nextInt(200))) {
            this.c();
            this.F = System.currentTimeMillis();
        }
        RotationManager rotationManager = RotationManager.getInstance();
        if (this.c == RotationState.ROTATING || this.c == RotationState.OVERSHOOTING || this.c == RotationState.CORRECTING || this.c == RotationState.READY || this.c == RotationState.WAITING_POST || this.c == RotationState.HOLDING) {
            f7 = this.e;
            f6 = this.f;
            if (this.p > 0 && this.c == RotationState.ROTATING && !this.G) {
                f5 = Math.abs(this.b(Main.mc.player.getYaw(), this.e));
                f4 = Math.abs(this.b(Main.mc.player.getPitch(), this.f));
                if (f5 < this.A * 0.2f && f4 < this.B * 0.2f) {
                    f7 = this.e + this.C;
                    f6 = this.f + this.D;
                    this.c = RotationState.OVERSHOOTING;
                }
            }
            if (this.c == RotationState.OVERSHOOTING) {
                f7 = this.e + this.C;
                f6 = this.f + this.D;
                f5 = Math.abs(this.b(Main.mc.player.getYaw(), f7));
                f4 = Math.abs(this.b(Main.mc.player.getPitch(), f6));
                if (f5 < 1.0f && f4 < 1.0f) {
                    this.G = true;
                    this.c = RotationState.CORRECTING;
                }
            }
            if (this.m) {
                this.d = this.a(f7, f6);
                Main.mc.player.setYaw(this.d.a());
                Main.mc.player.setHeadYaw(this.d.a());
                Main.mc.player.setPitch(this.d.b());
            } else {
                f5 = 25.0f * this.E;
                if (this.p > 0) {
                    f4 = this.e();
                    f3 = 1.0f - (float)this.p / 10.0f * 0.5f * this.b(f4);
                    f5 *= f3;
                }
                f4 = Math.max(1.0f, (float)Main.mc.getCurrentFps());
                f3 = MathHelper.lerpAngleDegrees((float)(Math.abs(f5) / f4), (float)rotationManager.k(), (float)f7);
                f2 = MathHelper.lerpAngleDegrees((float)(Math.abs(f5) / f4), (float)rotationManager.l(), (float)f6);
                this.d = new Rotation(f3, f2);
                rotationManager.a(this.d, this.g);
            }
        }
        if (this.c == RotationState.ROTATING_BACK) {
            float f8;
            f7 = this.b(rotationManager.k(), this.r);
            f6 = this.b(rotationManager.l(), this.s);
            if (Math.abs(f7) < 1.0f && Math.abs(f6) < 1.0f) {
                rotationManager.c();
                this.h();
                return;
            }
            f5 = 10.0f * this.E;
            f4 = 10.0f * this.E;
            f3 = MathHelper.clamp((float)f7, (float)(-f5), (float)f5);
            f2 = MathHelper.clamp((float)f6, (float)(-f4), (float)f4);
            if (this.p > 0) {
                f8 = (float)this.p / 10.0f * 0.3f;
                f3 += (b.nextFloat() * 2.0f - 1.0f) * f8;
                f2 += (b.nextFloat() * 2.0f - 1.0f) * f8 * 0.5f;
            }
            f8 = rotationManager.k() + f3;
            float f9 = MathHelper.clamp((float)(rotationManager.l() + f2), (float)-90.0f, (float)90.0f);
            this.d = new Rotation(f8, f9);
            rotationManager.a(this.d, Integer.MAX_VALUE);
        }
        if (this.c == RotationState.HOLDING && System.currentTimeMillis() - this.t >= this.l) {
            if (this.q) {
                this.f();
                this.c = RotationState.ROTATING_BACK;
            } else {
                rotationManager.c();
                this.h();
            }
        }
    }

    private boolean d() {
        float f2 = (float)this.p / 10.0f;
        float f3 = f2 * 0.05f;
        return b.nextFloat() < f3;
    }

    private float e() {
        if (this.A == 0.0f && this.B == 0.0f) {
            return 1.0f;
        }
        float f2 = Math.abs(this.b(Main.mc.player.getYaw(), this.e));
        float f3 = Math.abs(this.b(Main.mc.player.getPitch(), this.f));
        float f4 = this.A > 0.0f ? 1.0f - f2 / this.A : 1.0f;
        float f5 = this.B > 0.0f ? 1.0f - f3 / this.B : 1.0f;
        return MathHelper.clamp((float)((f4 + f5) / 2.0f), (float)0.0f, (float)1.0f);
    }

    private void onPacketSendEventPre(PacketSendEvent.Pre packetSendEvent$Pre) {
        if (this.c != RotationState.ROTATING && this.c != RotationState.CORRECTING) {
            return;
        }
        Object object = packetSendEvent$Pre.getPacket();
        if (object instanceof PlayerMoveC2SPacket) {
            PlayerMoveC2SPacket mc56 = (PlayerMoveC2SPacket)object;
            if (!mc56.changesLook()) {
                return;
            }
            object = RotationManager.getInstance();
            float f2 = this.b(mc56.getYaw(((RotationManager)object).k()), this.e);
            float f3 = this.b(mc56.getPitch(((RotationManager)object).l()), this.f);
            float f4 = 5.0f + (float)this.p * 0.5f;
            float f5 = 2.5f + (float)this.p * 0.25f;
            if (Math.abs(f2) < f4 && Math.abs(f3) < f5) {
                this.c = RotationState.READY;
            }
        }
    }

    private void onUpdateEventPre(UpdateEvent.Pre updateEvent$Pre) {
        if (Main.mc.player == null || Main.mc.world == null) {
            return;
        }
        if (this.c == RotationState.REACTION_DELAY) {
            --this.z;
            if (this.z <= 0) {
                this.c = RotationState.ROTATING;
            }
            return;
        }
        if (this.c == RotationState.READY) {
            if (this.h != null) {
                this.h.run();
            }
            if (this.i != null && this.k > 0) {
                this.u = 0;
                this.c = RotationState.WAITING_POST;
            } else if (this.i != null) {
                this.i.run();
                this.t = System.currentTimeMillis();
                this.c = RotationState.HOLDING;
            } else {
                this.t = System.currentTimeMillis();
                this.c = RotationState.HOLDING;
            }
            return;
        }
        if (this.c == RotationState.WAITING_POST) {
            ++this.u;
            if (this.u >= this.k) {
                if (this.i != null) {
                    this.i.run();
                }
                this.t = System.currentTimeMillis();
                this.c = RotationState.HOLDING;
            }
        }
    }

    private Rotation a(float f2, float f3) {
        float f4;
        float f5;
        float f6;
        long l2 = System.currentTimeMillis();
        float f7 = Math.min(0.1f, (float)(l2 - this.x) / 1000.0f);
        if (this.x == 0L) {
            f7 = 0.016f;
        }
        this.x = l2;
        float f8 = Main.mc.player.getYaw();
        float f9 = Main.mc.player.getPitch();
        float f10 = this.b(f8, f2) / 2.0f;
        float f11 = this.b(f9, f3) / 2.0f;
        double d2 = this.g();
        double d3 = (double)((Integer)Main.mc.options.getFov().getValue()).intValue() / 90.0;
        float f12 = Math.max(1.0f, (float)Main.mc.getCurrentFps());
        float f13 = this.n * 100.0f / f12;
        float f14 = this.o * 100.0f / f12;
        f13 *= this.E;
        f14 *= this.E;
        float f15 = this.a(Math.min(1.0f, Math.abs(f10) / 45.0f));
        float f16 = this.a(Math.min(1.0f, Math.abs(f11) / 30.0f));
        if (this.p > 0) {
            f6 = this.e();
            f5 = 1.0f - (float)this.p / 10.0f * 0.4f * this.b(f6);
            f15 *= f5;
            f16 *= f5;
        }
        f6 = f10 * f13 * (float)(d2 * d3) * (0.3f + f15 * 0.7f);
        f5 = f11 * f14 * (float)(d2 * d3) * (0.3f + f16 * 0.7f);
        float f17 = 1.0f - (float)Math.exp(-12.0f * f7);
        this.v += (f6 - this.v) * f17;
        this.w += (f5 - this.w) * f17;
        float f18 = f7 * 60.0f;
        float f19 = this.v * f18 * 0.15f;
        float f20 = this.w * f18 * 0.15f;
        float f21 = (float)this.p / 10.0f;
        this.y += f7 * 8.0f;
        float f22 = (float)(Math.sin((double)this.y * 2.3) * 0.02 + Math.sin((double)this.y * 5.7) * 0.01) * (1.0f + f21);
        float f23 = (float)(Math.sin((double)this.y * 1.9) * 0.015 + Math.sin((double)this.y * 4.3) * 0.008) * (1.0f + f21);
        if (this.p > 0) {
            f4 = f21 * 0.3f;
            f22 += (b.nextFloat() * 2.0f - 1.0f) * f4;
            f23 += (b.nextFloat() * 2.0f - 1.0f) * f4 * 0.5f;
        }
        f19 += f22;
        f20 += f23;
        if (Math.abs(f19) > Math.abs(f10)) {
            f19 = f10;
        }
        if (Math.abs(f20) > Math.abs(f11)) {
            f20 = f11;
        }
        f4 = f8 + f19;
        float f24 = MathHelper.clamp((float)(f9 + f20), (float)-90.0f, (float)90.0f);
        return new Rotation(f4, f24);
    }

    private void f() {
        this.v = 0.0f;
        this.w = 0.0f;
        this.x = 0L;
        this.y = 0.0f;
    }

    private float a(float f2) {
        return f2 * f2 * (3.0f - 2.0f * f2);
    }

    private float b(float f2) {
        return 1.0f - (1.0f - f2) * (1.0f - f2);
    }

    private float b(float f2, float f3) {
        return MathHelper.wrapDegrees((float)(f3 - f2));
    }

    private double g() {
        double d2 = (Double)Main.mc.options.getMouseSensitivity().getValue();
        if (d2 == H) {
            return I;
        }
        H = d2;
        double d3 = d2 * 0.6 + 0.2;
        I = d3 * d3 * d3 * 8.0;
        return I;
    }

    private void h() {
        this.c = RotationState.IDLE;
        Main.eventBus().unregister(this);
        if (this == a) {
            a = null;
        }
    }

    public void i() {
        RotationManager.getInstance().c();
        this.h();
    }

    public boolean j() {
        return this.c == RotationState.IDLE;
    }

    public static boolean k() {
        return a != null && !a.j();
    }

    public static void l() {
        if (a != null) {
            a.i();
        }
    }
}

