/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.input;

import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class MouseUtils {
    public static boolean a(int n2) {
        return GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)n2) == 1;
    }

    public static boolean b(int n2) {
        long l2 = MinecraftClient.getInstance().getWindow().getHandle();
        if (KeybindSetting.currentTimeMillis(n2)) {
            return GLFW.glfwGetMouseButton((long)l2, (int)KeybindSetting.h(n2)) == 1;
        }
        if (KeybindSetting.g(n2)) {
            return GLFW.glfwGetKey((long)l2, (int)KeybindSetting.i(n2)) == 1;
        }
        return false;
    }
}

