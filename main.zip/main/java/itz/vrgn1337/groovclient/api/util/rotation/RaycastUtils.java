/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.rotation;

import itz.vrgn1337.groovclient.api.util.rotation.RayTraceTarget;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.entrypoint.Main;
import java.util.Optional;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;

public class RaycastUtils {
    public static HitResult a(double d2) {
        return RaycastUtils.b(d2, RayTraceTarget.ALL);
    }

    private static HitResult a(double d2, RayTraceTarget rayTraceTarget) {
        if (Main.mc.player == null || Main.mc.world == null) {
            return null;
        }
        Vec3d VanillaChestLootTableGenerator = Main.mc.player.getEyePos();
        float f2 = Main.mc.player.getYaw() * ((float)Math.PI / 180);
        float f3 = Main.mc.player.getPitch() * ((float)Math.PI / 180);
        float f4 = MathHelper.cos((double)f2);
        float f5 = MathHelper.sin((double)f2);
        float f6 = MathHelper.cos((double)f3);
        float f7 = MathHelper.sin((double)f3);
        Vec3d WallPlayerSkullBlock = new Vec3d((double)(-f5 * f6), (double)(-f7), (double)(f4 * f6));
        Vec3d VanillaEntityLootTableGenerator = VanillaChestLootTableGenerator.add(WallPlayerSkullBlock.multiply(d2));
        return switch (rayTraceTarget.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> RaycastUtils.a(VanillaChestLootTableGenerator, VanillaEntityLootTableGenerator);
            case 1 -> RaycastUtils.a(VanillaChestLootTableGenerator, VanillaEntityLootTableGenerator, d2);
            case 2 -> RaycastUtils.b(VanillaChestLootTableGenerator, VanillaEntityLootTableGenerator, d2);
        };
    }

    public static HitResult b(double d2) {
        return RaycastUtils.b(d2, RayTraceTarget.ALL);
    }

    public static HitResult b(double d2, RayTraceTarget rayTraceTarget) {
        if (Main.mc.player == null || Main.mc.world == null) {
            return null;
        }
        float f2 = RotationUtils.a() ? RotationManager.r() : RotationManager.p();
        float f3 = RotationUtils.a() ? RotationManager.s() : RotationManager.q();
        return RaycastUtils.a(Main.mc.player.getEyePos(), f2, f3, d2, rayTraceTarget);
    }

    public static HitResult a(Vec3d VanillaChestLootTableGenerator, double d2) {
        return RaycastUtils.a(VanillaChestLootTableGenerator, d2, RayTraceTarget.ALL);
    }

    public static HitResult a(Vec3d VanillaChestLootTableGenerator, double d2, RayTraceTarget rayTraceTarget) {
        if (Main.mc.player == null || Main.mc.world == null) {
            return null;
        }
        float f2 = RotationUtils.a() ? RotationManager.r() : RotationManager.p();
        float f3 = RotationUtils.a() ? RotationManager.s() : RotationManager.q();
        return RaycastUtils.a(VanillaChestLootTableGenerator, f2, f3, d2, rayTraceTarget);
    }

    private static HitResult a(Vec3d VanillaChestLootTableGenerator, float f2, float f3, double d2, RayTraceTarget rayTraceTarget) {
        if (Main.mc.player == null || Main.mc.world == null) {
            return null;
        }
        float f4 = f2 * ((float)Math.PI / 180);
        float f5 = f3 * ((float)Math.PI / 180);
        float f6 = MathHelper.cos((double)f4);
        float f7 = MathHelper.sin((double)f4);
        float f8 = MathHelper.cos((double)f5);
        float f9 = MathHelper.sin((double)f5);
        Vec3d WallPlayerSkullBlock = new Vec3d((double)(-f7 * f8), (double)(-f9), (double)(f6 * f8));
        Vec3d VanillaEntityLootTableGenerator = VanillaChestLootTableGenerator.add(WallPlayerSkullBlock.multiply(d2));
        return switch (rayTraceTarget.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> RaycastUtils.a(VanillaChestLootTableGenerator, VanillaEntityLootTableGenerator);
            case 1 -> RaycastUtils.a(VanillaChestLootTableGenerator, VanillaEntityLootTableGenerator, d2);
            case 2 -> RaycastUtils.b(VanillaChestLootTableGenerator, VanillaEntityLootTableGenerator, d2);
        };
    }

    private static BlockHitResult a(Vec3d VanillaChestLootTableGenerator, Vec3d WallPlayerSkullBlock) {
        return Main.mc.world.raycast(new RaycastContext(VanillaChestLootTableGenerator, WallPlayerSkullBlock, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, (Entity)Main.mc.player));
    }

    private static EntityHitResult a(Vec3d VanillaChestLootTableGenerator, Vec3d WallPlayerSkullBlock, double d2) {
        Entity mc2 = null;
        Vec3d VanillaEntityLootTableGenerator = null;
        double d3 = d2 * d2;
        Box HorizontalFacingBlock = new Box(VanillaChestLootTableGenerator, WallPlayerSkullBlock).expand(2.0);
        Box InfestedBlock = new Box(VanillaChestLootTableGenerator.x - 1.0, VanillaChestLootTableGenerator.y - 1.0, VanillaChestLootTableGenerator.z - 1.0, VanillaChestLootTableGenerator.x + 1.0, VanillaChestLootTableGenerator.y + 1.0, VanillaChestLootTableGenerator.z + 1.0);
        for (Entity mc55 : Main.mc.world.getOtherEntities((Entity)Main.mc.player, HorizontalFacingBlock.union(InfestedBlock))) {
            double d4;
            Box MutableRegistry = mc55.getBoundingBox().expand((double)mc55.getTargetingMargin());
            if (MutableRegistry.contains(VanillaChestLootTableGenerator)) {
                mc2 = mc55;
                VanillaEntityLootTableGenerator = VanillaChestLootTableGenerator;
                d3 = 0.0;
                continue;
            }
            Optional optional = MutableRegistry.raycast(VanillaChestLootTableGenerator, WallPlayerSkullBlock);
            if (!optional.isPresent() || !((d4 = VanillaChestLootTableGenerator.squaredDistanceTo((Vec3d)optional.get())) < d3)) continue;
            d3 = d4;
            mc2 = mc55;
            VanillaEntityLootTableGenerator = (Vec3d)optional.get();
        }
        return mc2 != null ? new EntityHitResult(mc2, VanillaEntityLootTableGenerator) : null;
    }

    private static HitResult b(Vec3d VanillaChestLootTableGenerator, Vec3d WallPlayerSkullBlock, double d2) {
        double d3;
        BlockHitResult mc7 = RaycastUtils.a(VanillaChestLootTableGenerator, WallPlayerSkullBlock);
        double d4 = VanillaChestLootTableGenerator.squaredDistanceTo(mc7.getPos());
        EntityHitResult mc26 = RaycastUtils.a(VanillaChestLootTableGenerator, WallPlayerSkullBlock, d2);
        if (mc26 != null && (d3 = VanillaChestLootTableGenerator.squaredDistanceTo(mc26.getPos())) < d4) {
            return mc26;
        }
        return mc7;
    }
}

