/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util;

import itz.vrgn1337.groovclient.api.util.ActionQueue;
import itz.vrgn1337.groovclient.entrypoint.Main;

public final class BindManager {
    private static BindManager a = new BindManager();
    private static boolean b = false;
    private static int c = 0;

    public static BindManager getInstance() {
        return a;
    }

    public void b() {
        a = this;
    }

    private BindManager() {
    }

    public static boolean c() {
        if (Main.mc.player == null) {
            return true;
        }
        if (b) {
            return true;
        }
        return !ActionQueue.c();
    }

    public static boolean d() {
        return BindManager.c();
    }

    public static boolean e() {
        return BindManager.c();
    }

    public static boolean f() {
        if (c > 0) {
            return false;
        }
        return BindManager.d();
    }

    public static void g() {
        ++c;
    }

    public static void h() {
        if (c > 0) {
            --c;
        }
    }

    public static boolean i() {
        return c > 0;
    }

    public static void j() {
        b = true;
    }

    public static void k() {
        b = false;
    }

    public static boolean l() {
        return b;
    }

    public static void m() {
        b = false;
        c = 0;
        ActionQueue.e();
    }
}

