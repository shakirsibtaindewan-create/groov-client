/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.input;

import itz.vrgn1337.groovclient.mixin.accessor.KeyboardHandlerInvoker;
import itz.vrgn1337.groovclient.mixin.accessor.MouseHandlerInvoker;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.input.MouseInput;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public final class InputUtils {
    private static final MinecraftClient a = MinecraftClient.getInstance();
    private static long b = 0L;
    private static long c = 0L;

    private InputUtils() {
    }

    public static boolean a(int n2) {
        if (InputUtils.a.keyboard == null || a.getWindow() == null) {
            return false;
        }
        long l2 = a.getWindow().getHandle();
        int n3 = GLFW.glfwGetKeyScancode((int)n2);
        KeyInput mc27 = new KeyInput(n2, n3, 0);
        KeyboardHandlerInvoker keyboardHandlerInvoker = (KeyboardHandlerInvoker)InputUtils.a.keyboard;
        keyboardHandlerInvoker.onKey(l2, 1, mc27);
        keyboardHandlerInvoker.onKey(l2, 0, mc27);
        return true;
    }

    public static boolean a() {
        return InputUtils.b(0);
    }

    public static boolean b() {
        return InputUtils.c(0);
    }

    public static boolean b(int n2) {
        return InputUtils.a(0, n2);
    }

    public static boolean c(int n2) {
        return InputUtils.a(1, n2);
    }

    public static void a(boolean bl) {
        if (InputUtils.a.options == null) {
            return;
        }
        InputUtils.a.options.attackKey.setPressed(bl);
    }

    public static void b(boolean bl) {
        if (InputUtils.a.options == null) {
            return;
        }
        InputUtils.a.options.useKey.setPressed(bl);
    }

    private static boolean a(int n2, int n3) {
        if (n3 > 0 && !InputUtils.b(n2, n3)) {
            return false;
        }
        long l2 = GLFW.glfwGetCurrentContext();
        MouseHandlerInvoker mouseHandlerInvoker = (MouseHandlerInvoker)InputUtils.a.mouse;
        MouseInput mc28 = new MouseInput(n2, 0);
        mouseHandlerInvoker.invokeOnButton(l2, mc28, 1);
        mouseHandlerInvoker.invokeOnButton(l2, mc28, 0);
        return true;
    }

    private static boolean b(int n2, int n3) {
        long l2 = Math.max(1L, Math.round(1.0E9 / (double)n3));
        long l3 = System.nanoTime();
        if (n2 == 0) {
            if (l3 - b < l2) {
                return false;
            }
            b = l3;
        } else {
            if (l3 - c < l2) {
                return false;
            }
            c = l3;
        }
        return true;
    }
}

