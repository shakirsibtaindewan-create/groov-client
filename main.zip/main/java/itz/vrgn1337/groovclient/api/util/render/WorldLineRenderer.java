/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import com.mojang.blaze3d.vertex.VertexFormat;
import itz.vrgn1337.groovclient.api.util.bridge.GameRendererMixinBridge;
import itz.vrgn1337.groovclient.api.util.render.GLStateSnapshot;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import java.awt.Color;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.render.BuiltBuffer;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.opengl.GL11;

public class WorldLineRenderer {
    private final MatrixStack a;
    private float b;
    private float c;
    private float d;
    private float e;
    private float f;
    private float g;
    private Color h = Color.WHITE;
    private boolean i = true;
    private float j = 1.0f;
    private boolean k = false;
    private float l = 1.0f;
    private Color m = null;
    private boolean n = false;
    private float o = 2.0f;
    private float p = 0.5f;
    private boolean q = false;
    private Color r = Color.BLACK;
    private float s = 2.0f;
    private boolean t = false;
    private Color u = null;
    private boolean v = false;
    private float w = 0.3f;
    private Color x = null;
    private boolean y = true;

    public WorldLineRenderer(MatrixStack mc13) {
        this.a = mc13;
    }

    public WorldLineRenderer a() {
        this.y = true;
        return this;
    }

    public WorldLineRenderer a(boolean bl) {
        this.y = bl;
        return this;
    }

    public WorldLineRenderer a(PlayerEntity mc6) {
        double d2 = GuiRenderer.a(mc6.getX(), mc6.lastRenderX);
        double d3 = GuiRenderer.a(mc6.getY(), mc6.lastRenderY);
        double d4 = GuiRenderer.a(mc6.getZ(), mc6.lastRenderZ);
        float f2 = mc6.getWidth() / 1.5f;
        this.b = (float)d2 - f2;
        this.c = (float)d3;
        this.d = (float)d4 - f2;
        this.e = (float)d2 + f2;
        this.f = (float)d3 + mc6.getHeight();
        this.g = (float)d4 + f2;
        return this;
    }

    public WorldLineRenderer a(PlayerEntity mc6, Vec3d VanillaChestLootTableGenerator) {
        double d2 = GuiRenderer.a(mc6.getX(), mc6.lastRenderX) + VanillaChestLootTableGenerator.x;
        double d3 = GuiRenderer.a(mc6.getY(), mc6.lastRenderY) + VanillaChestLootTableGenerator.y;
        double d4 = GuiRenderer.a(mc6.getZ(), mc6.lastRenderZ) + VanillaChestLootTableGenerator.z;
        float f2 = mc6.getWidth() / 1.5f;
        this.b = (float)d2 - f2;
        this.c = (float)d3;
        this.d = (float)d4 - f2;
        this.e = (float)d2 + f2;
        this.f = (float)d3 + mc6.getHeight();
        this.g = (float)d4 + f2;
        return this;
    }

    public WorldLineRenderer a(Box HorizontalFacingBlock) {
        this.b = (float)HorizontalFacingBlock.minX;
        this.c = (float)HorizontalFacingBlock.minY;
        this.d = (float)HorizontalFacingBlock.minZ;
        this.e = (float)HorizontalFacingBlock.maxX;
        this.f = (float)HorizontalFacingBlock.maxY;
        this.g = (float)HorizontalFacingBlock.maxZ;
        return this;
    }

    public WorldLineRenderer a(Box HorizontalFacingBlock, Vec3d VanillaChestLootTableGenerator) {
        this.b = (float)(HorizontalFacingBlock.minX + VanillaChestLootTableGenerator.x);
        this.c = (float)(HorizontalFacingBlock.minY + VanillaChestLootTableGenerator.y);
        this.d = (float)(HorizontalFacingBlock.minZ + VanillaChestLootTableGenerator.z);
        this.e = (float)(HorizontalFacingBlock.maxX + VanillaChestLootTableGenerator.x);
        this.f = (float)(HorizontalFacingBlock.maxY + VanillaChestLootTableGenerator.y);
        this.g = (float)(HorizontalFacingBlock.maxZ + VanillaChestLootTableGenerator.z);
        return this;
    }

    public WorldLineRenderer a(Vec3d VanillaChestLootTableGenerator, Vec3d WallPlayerSkullBlock) {
        this.b = (float)GuiRenderer.a(VanillaChestLootTableGenerator.x, WallPlayerSkullBlock.x);
        this.c = (float)GuiRenderer.a(VanillaChestLootTableGenerator.y, WallPlayerSkullBlock.y);
        this.d = (float)GuiRenderer.a(VanillaChestLootTableGenerator.z, WallPlayerSkullBlock.z);
        this.e = (float)GuiRenderer.a(VanillaChestLootTableGenerator.x, WallPlayerSkullBlock.x);
        this.f = (float)GuiRenderer.a(VanillaChestLootTableGenerator.y, WallPlayerSkullBlock.y);
        this.g = (float)GuiRenderer.a(VanillaChestLootTableGenerator.z, WallPlayerSkullBlock.z);
        return this;
    }

    public WorldLineRenderer a(float f2, float f3, float f4, float f5, float f6, float f7) {
        this.b = f2;
        this.c = f3;
        this.d = f4;
        this.e = f5;
        this.f = f6;
        this.g = f7;
        return this;
    }

    public WorldLineRenderer a(Color color) {
        this.h = color;
        return this;
    }

    public WorldLineRenderer a(int n2, int n3, int n4, int n5) {
        this.h = new Color(n2, n3, n4, n5);
        return this;
    }

    public WorldLineRenderer b(boolean bl) {
        this.i = bl;
        return this;
    }

    public WorldLineRenderer a(float f2) {
        this.j = f2;
        return this;
    }

    public WorldLineRenderer b(float f2) {
        this.k = true;
        this.l = f2;
        return this;
    }

    public WorldLineRenderer a(float f2, Color color) {
        this.k = true;
        this.l = f2;
        this.m = color;
        return this;
    }

    public WorldLineRenderer a(float f2, float f3) {
        this.n = true;
        this.o = f2;
        this.p = f3;
        return this;
    }

    public WorldLineRenderer a(Color color, float f2) {
        this.q = true;
        this.r = color;
        this.s = f2;
        return this;
    }

    public WorldLineRenderer b(Color color) {
        this.t = true;
        this.u = color;
        return this;
    }

    public WorldLineRenderer b() {
        this.v = true;
        this.w = 0.3f;
        return this;
    }

    public WorldLineRenderer c(float f2) {
        this.v = true;
        this.w = Math.max(0.1f, Math.min(1.0f, f2));
        return this;
    }

    public WorldLineRenderer b(float f2, Color color) {
        this.v = true;
        this.w = Math.max(0.1f, Math.min(1.0f, f2));
        this.x = color;
        return this;
    }

    public void c() {
        GLStateSnapshot gLStateSnapshot = null;
        if (this.y) {
            gLStateSnapshot = GLStateSnapshot.getInstance();
            GL11.glDisable((int)2929);
            GL11.glDepthMask((boolean)false);
        }
        try {
            if (this.n) {
                this.d();
            }
            if (this.k) {
                this.e();
            }
            if (this.v) {
                this.j();
            } else if (this.i) {
                this.g();
            } else {
                this.i();
            }
            if (this.q && this.i) {
                this.f();
            }
        }
        finally {
            if (gLStateSnapshot != null) {
                gLStateSnapshot.b();
            }
        }
    }

    private void d() {
        MatrixStack mc13 = new MatrixStack();
        mc13.push();
        mc13.translate(this.o, -this.o, this.o);
        WorldLineRenderer.a(mc13, this.b, this.c, this.d, this.e, this.f, this.g, new Color(0, 0, 0, (int)(this.p * 255.0f)));
        mc13.pop();
    }

    private void e() {
        Color color = this.m != null ? this.m : this.h;
        float f2 = (float)color.getAlpha() / 255.0f;
        float f3 = 5.2f * this.l;
        for (int j = 0; j < 28; ++j) {
            float f4 = (float)j / 27.0f;
            float f5 = (float)Math.exp((double)(-f4 * f4) * 3.5);
            float f6 = f2 * (0.23f * f5) * this.l;
            float f7 = 0.11f + 0.5f * f4;
            Color color2 = new Color(Math.min(1.0f, WorldLineRenderer.b((float)color.getRed() / 255.0f, f7)), Math.min(1.0f, WorldLineRenderer.b((float)color.getGreen() / 255.0f, f7)), Math.min(1.0f, WorldLineRenderer.b((float)color.getBlue() / 255.0f, f7)), Math.min(1.0f, f6));
            float f8 = GuiRenderer.a(0.0f, f3, f4 * (1.05f + f4 * 0.12f));
            WorldLineRenderer.a(this.a, this.b - f8, this.c - f8, this.d - f8, this.e + f8, this.f + f8, this.g + f8, color2);
        }
    }

    private static float b(float f2, float f3) {
        return f2 + (1.0f - f2) * f3;
    }

    private void f() {
        GL11.glLineWidth((float)this.s);
        WorldLineRenderer.b(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.r);
        GL11.glLineWidth((float)1.0f);
    }

    private void g() {
        if (this.t && this.u != null) {
            this.h();
        } else {
            WorldLineRenderer.a(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void h() {
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            GL11.glEnable((int)3042);
            GL11.glDisable((int)2929);
            Matrix4f matrix4f = this.a.peek().getPositionMatrix();
            float f2 = (float)this.h.getRed() / 255.0f;
            float f3 = (float)this.h.getGreen() / 255.0f;
            float f4 = (float)this.h.getBlue() / 255.0f;
            float f5 = (float)this.h.getAlpha() / 255.0f;
            float f6 = (float)this.u.getRed() / 255.0f;
            float f7 = (float)this.u.getGreen() / 255.0f;
            float f8 = (float)this.u.getBlue() / 255.0f;
            float f9 = (float)this.u.getAlpha() / 255.0f;
            BufferBuilder mc23 = new BufferBuilder(new BufferAllocator(2048), VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
            mc23.vertex((Matrix4fc)matrix4f, this.b, this.c, this.d).color(f2, f3, f4, f5);
            mc23.vertex((Matrix4fc)matrix4f, this.b, this.c, this.g).color(f2, f3, f4, f5);
            mc23.vertex((Matrix4fc)matrix4f, this.e, this.c, this.d).color(f2, f3, f4, f5);
            mc23.vertex((Matrix4fc)matrix4f, this.e, this.c, this.g).color(f2, f3, f4, f5);
            mc23.vertex((Matrix4fc)matrix4f, this.e, this.f, this.g).color(f6, f7, f8, f9);
            mc23.vertex((Matrix4fc)matrix4f, this.b, this.c, this.g).color(f2, f3, f4, f5);
            mc23.vertex((Matrix4fc)matrix4f, this.b, this.f, this.g).color(f6, f7, f8, f9);
            mc23.vertex((Matrix4fc)matrix4f, this.b, this.c, this.d).color(f2, f3, f4, f5);
            mc23.vertex((Matrix4fc)matrix4f, this.b, this.f, this.d).color(f6, f7, f8, f9);
            mc23.vertex((Matrix4fc)matrix4f, this.e, this.c, this.d).color(f2, f3, f4, f5);
            mc23.vertex((Matrix4fc)matrix4f, this.e, this.f, this.d).color(f6, f7, f8, f9);
            mc23.vertex((Matrix4fc)matrix4f, this.e, this.c, this.g).color(f2, f3, f4, f5);
            mc23.vertex((Matrix4fc)matrix4f, this.e, this.f, this.g).color(f6, f7, f8, f9);
            mc23.vertex((Matrix4fc)matrix4f, this.b, this.f, this.g).color(f6, f7, f8, f9);
            mc23.vertex((Matrix4fc)matrix4f, this.e, this.f, this.d).color(f6, f7, f8, f9);
            mc23.vertex((Matrix4fc)matrix4f, this.b, this.f, this.d).color(f6, f7, f8, f9);
            BuiltBuffer mc25 = mc23.endNullable();
            if (mc25 != null) {
                GuiRenderer.a(mc25, new Matrix4f(), GameRendererMixinBridge.getProjection());
            }
        }
        finally {
            gLStateSnapshot.b();
        }
    }

    private void i() {
        GL11.glLineWidth((float)this.j);
        WorldLineRenderer.b(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h);
        GL11.glLineWidth((float)1.0f);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void j() {
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glDisable((int)2929);
            GL11.glDepthMask((boolean)false);
            GL11.glDisable((int)2884);
            Color color = this.x != null ? this.x : this.h;
            WorldLineRenderer.a(this.a, this.b, this.c, this.d, this.e, this.f, this.g, new Color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, this.w));
            GL11.glBlendFunc((int)770, (int)1);
            float f2 = this.w * 0.3f;
            float f3 = 0.02f;
            WorldLineRenderer.a(this.a, this.b + f3, this.c + f3, this.d + f3, this.e - f3, this.f - f3, this.g - f3, new Color(Math.min(1.0f, (float)color.getRed() / 255.0f + 0.3f), Math.min(1.0f, (float)color.getGreen() / 255.0f + 0.3f), Math.min(1.0f, (float)color.getBlue() / 255.0f + 0.3f), f2));
        }
        finally {
            gLStateSnapshot.b();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, float f7, Color color) {
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glDisable((int)2929);
            GL11.glDisable((int)2884);
            float f8 = (float)color.getRed() / 255.0f;
            float f9 = (float)color.getGreen() / 255.0f;
            float f10 = (float)color.getBlue() / 255.0f;
            float f11 = (float)color.getAlpha() / 255.0f;
            Matrix4f matrix4f = mc13.peek().getPositionMatrix();
            BufferBuilder mc23 = new BufferBuilder(new BufferAllocator(2048), VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f6, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f6, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f6, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f6, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f3, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f3, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f3, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f6, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f6, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f6, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f3, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f6, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f3, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f3, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f3, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f6, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f6, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f6, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f6, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f6, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f6, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f6, f7).color(f8, f9, f10, f11);
            BuiltBuffer mc25 = mc23.endNullable();
            if (mc25 != null) {
                GuiRenderer.a(mc25, new Matrix4f(), GameRendererMixinBridge.getProjection());
            }
        }
        finally {
            gLStateSnapshot.b();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void b(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, float f7, Color color) {
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            GL11.glEnable((int)3042);
            GL11.glDisable((int)2929);
            float f8 = (float)color.getRed() / 255.0f;
            float f9 = (float)color.getGreen() / 255.0f;
            float f10 = (float)color.getBlue() / 255.0f;
            float f11 = (float)color.getAlpha() / 255.0f;
            Matrix4f matrix4f = mc13.peek().getPositionMatrix();
            BufferBuilder mc23 = new BufferBuilder(new BufferAllocator(1024), VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f3, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f3, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f6, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f6, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f3, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f3, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f6, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f6, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f6, f7).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f6, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f3, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f5, f6, f4).color(f8, f9, f10, f11);
            mc23.vertex((Matrix4fc)matrix4f, f2, f6, f4).color(f8, f9, f10, f11);
            BuiltBuffer mc25 = mc23.endNullable();
            if (mc25 != null) {
                GuiRenderer.a(mc25, new Matrix4f(), GameRendererMixinBridge.getProjection());
            }
        }
        finally {
            gLStateSnapshot.b();
        }
    }
}

