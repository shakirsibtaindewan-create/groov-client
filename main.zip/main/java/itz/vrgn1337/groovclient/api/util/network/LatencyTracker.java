/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.network;

import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;

public class LatencyTracker {
    private static final LatencyTracker a = new LatencyTracker();
    private long b = -1L;
    private float c = 20.0f;

    public static LatencyTracker getInstance() {
        return a;
    }

    private LatencyTracker() {
        Main.eventBus().register(this);
    }

    private void onPacketReceiveEventPost(PacketReceiveEvent.Post packetReceiveEvent$Post) {
        long l2;
        Packet mc14 = packetReceiveEvent$Post.getPacket();
        if (!(mc14 instanceof WorldTimeUpdateS2CPacket)) {
            return;
        }
        long l3 = System.currentTimeMillis();
        if (this.b > 0L && (l2 = l3 - this.b) > 0L) {
            float f2 = 20.0f * (1000.0f / (float)l2);
            this.c = Math.max(1.0f, Math.min(20.0f, f2));
        }
        this.b = l3;
    }

    public float b() {
        return this.c;
    }
}

