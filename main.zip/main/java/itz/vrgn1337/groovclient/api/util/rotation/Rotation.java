/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.rotation;

import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.util.math.MathHelper;

public class Rotation {
    private static final AtomicLong a = new AtomicLong(0L);
    private float b;
    private float c;
    private int d;
    private final long e;
    private Runnable f;

    public Rotation() {
        this(-1.0f, -1.0f);
    }

    public Rotation(float f2, float f3) {
        this.b = f2;
        this.c = MathHelper.clamp((float)f3, (float)-90.0f, (float)90.0f);
        this.e = a.incrementAndGet();
    }

    public Rotation a(float f2, float f3) {
        this.b = f2;
        this.c = MathHelper.clamp((float)f3, (float)-90.0f, (float)90.0f);
        return this;
    }

    public float a() {
        return this.b;
    }

    public float b() {
        return this.c;
    }

    public void a(float f2) {
        this.b = f2;
    }

    public void b(float f2) {
        this.c = MathHelper.clamp((float)f2, (float)-90.0f, (float)90.0f);
    }

    public int c() {
        return this.d;
    }

    public void a(int n2) {
        this.d = n2;
    }

    public long d() {
        return this.e;
    }

    public boolean e() {
        return RotationManager.f.contains(this.e);
    }

    public void f() {
        RotationManager rotationManager = RotationManager.getInstance();
        if (!RotationManager.f.contains(this.e)) {
            RotationManager.f.add(this.e);
            if (rotationManager.e()) {
                rotationManager.b();
            }
        }
    }

    public void g() {
        RotationManager.f.remove(this.e);
    }

    public Rotation a(Runnable runnable) {
        this.f = runnable;
        return this;
    }

    public void h() {
        if (this.f != null) {
            this.f.run();
            this.f = null;
        }
    }
}

