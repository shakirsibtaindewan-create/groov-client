/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.combat;

public enum ProjectileType {
    ARROW(3.0f, 0.05f, 0.99f, 0.5f), TRIDENT(2.5f, 0.05f, 0.99f, 0.5f), ENDER_PEARL(1.5f, 0.03f, 0.99f, 0.25f), SNOWBALL(1.5f, 0.03f, 0.99f, 0.25f), EGG(1.5f, 0.03f, 0.99f, 0.25f), POTION(0.5f, 0.05f, 0.99f, 0.25f), EXP_BOTTLE(0.7f, 0.07f, 0.99f, 0.25f), FIREWORK(1.6f, 0.0f, 0.99f, 0.25f), FISHING_BOBBER(1.5f, 0.03f, 0.92f, 0.25f), WIND_CHARGE(1.5f, 0.0f, 1.0f, 0.3125f);
    public final float initialVelocity;
    public final float gravity;
    public final float drag;
    public final float size;

    private ProjectileType(float initialVelocity, float gravity, float drag, float size) {
        this.initialVelocity = initialVelocity;
        this.gravity = gravity;
        this.drag = drag;
        this.size = size;

    }

}

