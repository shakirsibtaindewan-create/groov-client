/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.protection;

public class StringConstant {
    private String a;
    private String b;
    private int c;

    public StringConstant(String string) {
        this.d(string);
    }

    public static StringConstant a(String string) {
        return new StringConstant(string);
    }

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public StringConstant b(String string) {
        this.b = string;
        return this;
    }

    public boolean c(String string) {
        if (string == null || string.isEmpty()) {
            return false;
        }
        int n2 = string.length();
        int n3 = this.a.length();
        for (int j = 0; j <= n3 - n2; ++j) {
            boolean bl = true;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (this.a.charAt(j + i2) == string.charAt(i2)) continue;
                bl = false;
                break;
            }
            if (!bl) continue;
            return true;
        }
        return false;
    }

    public CharSequence[] a(char c2) {
        CharSequence[] charSequenceArray = new CharSequence[2];
        for (int j = 0; j < this.a.length(); ++j) {
            if (this.a.charAt(j) != c2) continue;
            charSequenceArray[0] = this.a.subSequence(0, j);
            charSequenceArray[1] = this.a.subSequence(j + 1, this.a.length());
            return new CharSequence[]{charSequenceArray[0], charSequenceArray[1]};
        }
        return new CharSequence[]{this.a};
    }

    public CharSequence a(CharSequence charSequence, CharSequence charSequence2) {
        if (charSequence == null || charSequence2 == null) {
            return this.a;
        }
        StringBuilder stringBuilder = new StringBuilder();
        int n2 = charSequence.length();
        int n3 = 0;
        while (n3 <= this.a.length() - n2) {
            boolean bl = true;
            for (int j = 0; j < n2; ++j) {
                if (this.a.charAt(n3 + j) == charSequence.charAt(j)) continue;
                bl = false;
                break;
            }
            if (bl) {
                stringBuilder.append(charSequence2);
                n3 += n2;
                continue;
            }
            stringBuilder.append(this.a.charAt(n3));
            ++n3;
        }
        while (n3 < this.a.length()) {
            stringBuilder.append(this.a.charAt(n3++));
        }
        return stringBuilder;
    }

    public boolean a(StringConstant stringConstant) {
        if (stringConstant == null || stringConstant.a().length() > this.a.length()) {
            return false;
        }
        for (int j = 0; j < stringConstant.a().length(); ++j) {
            if (this.a.charAt(j) == stringConstant.a().charAt(j)) continue;
            return false;
        }
        return true;
    }

    public int a(int n2) {
        if (n2 < 0 || n2 >= this.a.length()) {
            return -1;
        }
        return Character.codePointAt(this.a, n2);
    }

    public int c() {
        return this.c;
    }

    public void d(String string) {
        this.a = string;
    }

    public void b(int n2) {
        this.c = n2;
    }
}

