/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.bridge;

import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.mixin.accessor.GameRendererAccessor;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector4f;

public final class GameRendererMixinBridge {
    private static final Matrix4f PROJECTION = new Matrix4f();
    private static final Matrix4f MODEL_VIEW = new Matrix4f();
    private static final Matrix4f MVP = new Matrix4f();
    private static Vec3d cameraPos = Vec3d.ZERO;
    private static boolean ready = false;

    private GameRendererMixinBridge() {
    }

    public static void capture(GameRenderer mc21, RenderTickCounter mc16) {
        if (Main.mc == null || Main.mc.player == null || mc21 == null || mc16 == null) {
            ready = false;
            return;
        }
        Camera mc22 = mc21.getCamera();
        float f2 = mc16.getTickProgress(true);
        float f3 = ((GameRendererAccessor)mc21).invokeGetFov(mc22, f2, true);
        PROJECTION.set((Matrix4fc)mc21.getBasicProjectionMatrix(f3));
        MODEL_VIEW.set((Matrix4fc)new Matrix4f().rotation((Quaternionfc)mc22.getRotation().conjugate(new Quaternionf())));
        MVP.set((Matrix4fc)PROJECTION).mul((Matrix4fc)MODEL_VIEW);
        cameraPos = mc22.getCameraPos();
        ready = true;
    }

    public static boolean isReady() {
        return ready;
    }

    public static Matrix4f getProjection() {
        return PROJECTION;
    }

    public static Matrix4f getModelView() {
        return MODEL_VIEW;
    }

    public static Vec3d getCameraPos() {
        return cameraPos;
    }

    public static float[] worldToScreen(Vec3d VanillaChestLootTableGenerator) {
        if (!ready || VanillaChestLootTableGenerator == null || Main.mc == null || Main.mc.getWindow() == null) {
            return new float[]{-1.0f, -1.0f, -1.0f};
        }
        float f2 = (float)(VanillaChestLootTableGenerator.x - GameRendererMixinBridge.cameraPos.x);
        float f3 = (float)(VanillaChestLootTableGenerator.y - GameRendererMixinBridge.cameraPos.y);
        float f4 = (float)(VanillaChestLootTableGenerator.z - GameRendererMixinBridge.cameraPos.z);
        Vector4f vector4f = new Vector4f(f2, f3, f4, 1.0f).mul((Matrix4fc)MVP);
        if (vector4f.w <= 0.0f) {
            return new float[]{-1.0f, -1.0f, -1.0f};
        }
        float f5 = vector4f.x / vector4f.w;
        float f6 = vector4f.y / vector4f.w;
        int n2 = Main.mc.getWindow().getScaledWidth();
        int n3 = Main.mc.getWindow().getScaledHeight();
        float f7 = (f5 + 1.0f) * 0.5f * (float)n2;
        float f8 = (1.0f - f6) * 0.5f * (float)n3;
        return new float[]{f7, f8, vector4f.w};
    }
}

