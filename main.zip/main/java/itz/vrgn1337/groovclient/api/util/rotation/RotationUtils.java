/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.rotation;

import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import net.minecraft.util.math.Vec3d;

public final class RotationUtils {
    private RotationUtils() {
    }

    public static boolean a() {
        RotationManager rotationManager = RotationManager.getInstance();
        return rotationManager.e() || rotationManager.h() || rotationManager.f();
    }

    public static Rotation a(Vec3d VanillaChestLootTableGenerator, Vec3d WallPlayerSkullBlock) {
        double d2 = VanillaChestLootTableGenerator.x - WallPlayerSkullBlock.x;
        double d3 = VanillaChestLootTableGenerator.y - WallPlayerSkullBlock.y;
        double d4 = VanillaChestLootTableGenerator.z - WallPlayerSkullBlock.z;
        double d5 = Math.sqrt(d2 * d2 + d4 * d4);
        float f2 = (float)Math.toDegrees(Math.atan2(d4, d2)) - 90.0f;
        float f3 = (float)(-Math.toDegrees(Math.atan2(d3, d5)));
        return new Rotation(f2, f3);
    }
}

