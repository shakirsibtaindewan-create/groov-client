/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.bridge;

import net.minecraft.util.Hand;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionfc;

public final class ViewModelBridge {
    public static volatile boolean enabled = false;
    public static volatile boolean oldBlockSwing = false;
    public static volatile boolean swordBlock = false;
    public static volatile float mainX = 0.0f;
    public static volatile float mainY = 0.0f;
    public static volatile float mainZ = 0.0f;
    public static volatile float mainRotX = 0.0f;
    public static volatile float mainRotY = 0.0f;
    public static volatile float mainRotZ = 0.0f;
    public static volatile float mainScale = 1.0f;
    public static volatile float offX = 0.0f;
    public static volatile float offY = 0.0f;
    public static volatile float offZ = 0.0f;
    public static volatile float offRotX = 0.0f;
    public static volatile float offRotY = 0.0f;
    public static volatile float offRotZ = 0.0f;
    public static volatile float offScale = 1.0f;

    private ViewModelBridge() {
    }

    public static void applyTransform(MatrixStack mc13, Hand mc8) {
        float f2;
        if (!enabled || mc13 == null) {
            return;
        }
        boolean bl = mc8 == Hand.MAIN_HAND;
        float f3 = bl ? mainX : offX;
        float f4 = bl ? mainY : offY;
        float f5 = bl ? mainZ : offZ;
        float f6 = bl ? mainRotX : offRotX;
        float f7 = bl ? mainRotY : offRotY;
        float f8 = bl ? mainRotZ : offRotZ;
        float f9 = f2 = bl ? mainScale : offScale;
        if (f3 != 0.0f || f4 != 0.0f || f5 != 0.0f) {
            mc13.translate(f3, f4, f5);
        }
        if (f6 != 0.0f) {
            mc13.multiply((Quaternionfc)RotationAxis.POSITIVE_X.rotationDegrees(f6));
        }
        if (f7 != 0.0f) {
            mc13.multiply((Quaternionfc)RotationAxis.POSITIVE_Y.rotationDegrees(f7));
        }
        if (f8 != 0.0f) {
            mc13.multiply((Quaternionfc)RotationAxis.POSITIVE_Z.rotationDegrees(f8));
        }
        if (f2 != 1.0f) {
            mc13.scale(f2, f2, f2);
        }
    }
}

