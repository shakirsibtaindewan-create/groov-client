/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util;

import itz.vrgn1337.groovclient.api.util.WaitCondition;
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;

record WaitEntry(Object a, WaitCondition b) {

    Object a() {
        return this.a;
    }

    WaitCondition b() {
        return this.b;
    }

}