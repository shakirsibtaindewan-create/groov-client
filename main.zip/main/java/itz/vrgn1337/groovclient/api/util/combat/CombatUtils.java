/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.combat;

import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.component.DataComponentTypes;

public class CombatUtils {
    public static boolean a(Entity mc2) {
        Vec3d VanillaChestLootTableGenerator;
        Box HorizontalFacingBlock = mc2.getBoundingBox().expand((double)mc2.getTargetingMargin());
        double d2 = Math.sqrt(HorizontalFacingBlock.squaredMagnitude(VanillaChestLootTableGenerator = Main.mc.player.getEyePos()));
        return d2 <= Main.mc.player.getEntityInteractionRange();
    }

    public static boolean a(double d2) {
        return !Main.mc.player.isOnGround() && Main.mc.player.getVelocity().y < -d2;
    }

    public static boolean a(PlayerEntity mc6) {
        return mc6 != null && mc6.isUsingItem() && mc6.getStackInHand(mc6.getActiveHand()).get(DataComponentTypes.BLOCKS_ATTACKS) != null;
    }
}

