/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.combat;

import itz.vrgn1337.groovclient.api.util.combat.ProjectileType;
import java.util.List;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;

public class ProjectilePrediction {
    private final List a;
    private final HitResult b;
    private final Vec3d c;
    private final int d;
    private final ProjectileType e;

    public ProjectilePrediction(List list, HitResult ItemStackParticleEffect, Vec3d VanillaChestLootTableGenerator, int n2, ProjectileType projectileType) {
        this.a = list;
        this.b = ItemStackParticleEffect;
        this.c = VanillaChestLootTableGenerator;
        this.d = n2;
        this.e = projectileType;
    }

    public List a() {
        return this.a;
    }

    public HitResult b() {
        return this.b;
    }

    public Vec3d c() {
        return this.c;
    }

    public int d() {
        return this.d;
    }

    public float e() {
        return (float)this.d / 20.0f;
    }

    public ProjectileType f() {
        return this.e;
    }

    public boolean g() {
        return this.b instanceof EntityHitResult;
    }

    public boolean h() {
        return this.b instanceof BlockHitResult;
    }

    public boolean i() {
        return this.c != null;
    }
}

