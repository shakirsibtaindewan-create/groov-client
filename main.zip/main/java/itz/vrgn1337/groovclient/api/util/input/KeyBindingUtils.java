/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.input;

import itz.vrgn1337.groovclient.mixin.accessor.KeyMappingAccessor;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

public class KeyBindingUtils {
    public static InputUtil.Key a(KeyBinding mc32) {
        return ((KeyMappingAccessor)mc32).getKey();
    }

    public static int b(KeyBinding mc32) {
        return ((KeyMappingAccessor)mc32).getKey().getCode();
    }
}

