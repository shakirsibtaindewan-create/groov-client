/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.combat;

import itz.vrgn1337.groovclient.api.util.combat.ProjectilePrediction;
import itz.vrgn1337.groovclient.api.util.combat.ProjectileType;
import java.util.ArrayList;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.EggItem;
import net.minecraft.item.EnderPearlItem;
import net.minecraft.item.ExperienceBottleItem;
import net.minecraft.item.FireworkRocketItem;
import net.minecraft.item.FishingRodItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.LingeringPotionItem;
import net.minecraft.item.SnowballItem;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.math.Box;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.item.WindChargeItem;

public class ProjectilePredictor {
    private static final MinecraftClient a = MinecraftClient.getInstance();
    private static final int b = 300;
    private static final double c = 0.01;

    public static ProjectilePrediction a() {
        if (ProjectilePredictor.a.player == null || ProjectilePredictor.a.world == null) {
            return null;
        }
        return ProjectilePredictor.a((PlayerEntity)ProjectilePredictor.a.player, ProjectilePredictor.a.player.getMainHandStack().getItem());
    }

    public static ProjectilePrediction a(Item mc17) {
        if (ProjectilePredictor.a.player == null || ProjectilePredictor.a.world == null) {
            return null;
        }
        return ProjectilePredictor.a((PlayerEntity)ProjectilePredictor.a.player, mc17);
    }

    public static ProjectilePrediction a(PlayerEntity mc6, Item mc17) {
        if (mc6 == null || ProjectilePredictor.a.world == null) {
            return null;
        }
        ProjectileType projectileType = ProjectilePredictor.b(mc17);
        if (projectileType == null) {
            return null;
        }
        float f2 = ProjectilePredictor.a(mc6, mc17, projectileType);
        Vec3d VanillaChestLootTableGenerator = mc6.getEyePos();
        float f3 = mc6.getYaw();
        float f4 = mc6.getPitch();
        Vec3d WallPlayerSkullBlock = ProjectilePredictor.a(f3, f4);
        Vec3d VanillaEntityLootTableGenerator = WallPlayerSkullBlock.multiply((double)f2);
        return ProjectilePredictor.a(VanillaChestLootTableGenerator, VanillaEntityLootTableGenerator, projectileType, mc6);
    }

    public static ProjectilePrediction a(PlayerEntity mc6, Item mc17, float f2, float f3) {
        if (mc6 == null || ProjectilePredictor.a.world == null) {
            return null;
        }
        ProjectileType projectileType = ProjectilePredictor.b(mc17);
        if (projectileType == null) {
            return null;
        }
        float f4 = ProjectilePredictor.a(mc6, mc17, projectileType);
        Vec3d VanillaChestLootTableGenerator = mc6.getEyePos();
        Vec3d WallPlayerSkullBlock = ProjectilePredictor.a(f2, f3);
        Vec3d VanillaEntityLootTableGenerator = WallPlayerSkullBlock.multiply((double)f4);
        return ProjectilePredictor.a(VanillaChestLootTableGenerator, VanillaEntityLootTableGenerator, projectileType, mc6);
    }

    public static ProjectilePrediction a(Vec3d VanillaChestLootTableGenerator, Vec3d WallPlayerSkullBlock, ProjectileType projectileType, PlayerEntity mc6) {
        ArrayList<Vec3d> arrayList = new ArrayList<Vec3d>();
        arrayList.add(VanillaChestLootTableGenerator);
        Vec3d VanillaEntityLootTableGenerator = VanillaChestLootTableGenerator;
        Vec3d PlayerSkullBlock = WallPlayerSkullBlock;
        for (int j = 0; j < 300; ++j) {
            Vec3d RedstoneBlock = VanillaEntityLootTableGenerator.add(PlayerSkullBlock);
            BlockHitResult mc7 = ProjectilePredictor.a.world.raycast(new RaycastContext(VanillaEntityLootTableGenerator, RedstoneBlock, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, (Entity)ProjectilePredictor.a.player));
            Box HorizontalFacingBlock = new Box(VanillaEntityLootTableGenerator, RedstoneBlock).expand((double)projectileType.size);
            EntityHitResult mc26 = ProjectileUtil.raycast((Entity)ProjectilePredictor.a.player, (Vec3d)VanillaEntityLootTableGenerator, (Vec3d)RedstoneBlock, (Box)HorizontalFacingBlock, arg_0 -> c.lambda$simulate$0((PlayerEntity)mc6, arg_0), (double)VanillaEntityLootTableGenerator.squaredDistanceTo(RedstoneBlock));
            if (mc26 != null) {
                double d2;
                double d3 = VanillaEntityLootTableGenerator.squaredDistanceTo(mc26.getPos());
                double d4 = d2 = mc7.getType() != HitResult.Type.MISS ? VanillaEntityLootTableGenerator.squaredDistanceTo(mc7.getPos()) : Double.MAX_VALUE;
                if (d3 < d2) {
                    arrayList.add(mc26.getPos());
                    return new ProjectilePrediction(arrayList, (HitResult)mc26, mc26.getPos(), j, projectileType);
                }
            }
            if (mc7.getType() != HitResult.Type.MISS) {
                arrayList.add(mc7.getPos());
                return new ProjectilePrediction(arrayList, (HitResult)mc7, mc7.getPos(), j, projectileType);
            }
            PlayerSkullBlock = PlayerSkullBlock.multiply((double)projectileType.drag);
            PlayerSkullBlock = PlayerSkullBlock.subtract(0.0, (double)projectileType.gravity, 0.0);
            VanillaEntityLootTableGenerator = RedstoneBlock;
            arrayList.add(VanillaEntityLootTableGenerator);
            if (PlayerSkullBlock.lengthSquared() < 1.0E-4) {
                return new ProjectilePrediction(arrayList, null, VanillaEntityLootTableGenerator, j, projectileType);
            }
            if (!(VanillaEntityLootTableGenerator.y < (double)(ProjectilePredictor.a.world.getBottomY() - 64))) continue;
            return new ProjectilePrediction(arrayList, null, VanillaEntityLootTableGenerator, j, projectileType);
        }
        return new ProjectilePrediction(arrayList, null, VanillaEntityLootTableGenerator, 300, projectileType);
    }

    public static ProjectileType b(Item mc17) {
        if (mc17 instanceof BowItem || mc17 instanceof CrossbowItem) {
            return ProjectileType.ARROW;
        }
        if (mc17 instanceof TridentItem) {
            return ProjectileType.TRIDENT;
        }
        if (mc17 instanceof EnderPearlItem) {
            return ProjectileType.ENDER_PEARL;
        }
        if (mc17 instanceof SnowballItem) {
            return ProjectileType.SNOWBALL;
        }
        if (mc17 instanceof EggItem) {
            return ProjectileType.EGG;
        }
        if (mc17 instanceof SplashPotionItem || mc17 instanceof LingeringPotionItem) {
            return ProjectileType.POTION;
        }
        if (mc17 instanceof ExperienceBottleItem) {
            return ProjectileType.EXP_BOTTLE;
        }
        if (mc17 instanceof FireworkRocketItem) {
            return ProjectileType.FIREWORK;
        }
        if (mc17 instanceof FishingRodItem) {
            return ProjectileType.FISHING_BOBBER;
        }
        if (mc17 instanceof WindChargeItem) {
            return ProjectileType.WIND_CHARGE;
        }
        return null;
    }

    public static boolean c(Item mc17) {
        return ProjectilePredictor.b(mc17) != null;
    }

    private static float a(PlayerEntity mc6, Item mc17, ProjectileType projectileType) {
        if (mc17 instanceof BowItem) {
            int n2 = mc6.getItemUseTime();
            float f2 = BowItem.getPullProgress((int)n2);
            return projectileType.initialVelocity * f2;
        }
        if (mc17 instanceof CrossbowItem) {
            return CrossbowItem.isCharged((ItemStack)mc6.getActiveItem()) ? 3.15f : 0.0f;
        }
        if (mc17 instanceof TridentItem) {
            return projectileType.initialVelocity;
        }
        return projectileType.initialVelocity;
    }

    private static Vec3d a(float f2, float f3) {
        float f4 = (float)Math.toRadians(f2);
        float f5 = (float)Math.toRadians(f3);
        float f6 = -MathHelper.sin((double)f4) * MathHelper.cos((double)f5);
        float f7 = -MathHelper.sin((double)f5);
        float f8 = MathHelper.cos((double)f4) * MathHelper.cos((double)f5);
        return new Vec3d((double)f6, (double)f7, (double)f8).normalize();
    }

    public static float a(Vec3d VanillaChestLootTableGenerator, Item mc17) {
        double d2;
        double d3;
        float f2;
        double d4;
        if (ProjectilePredictor.a.player == null) {
            return Float.NaN;
        }
        ProjectileType projectileType = ProjectilePredictor.b(mc17);
        if (projectileType == null) {
            return Float.NaN;
        }
        Vec3d WallPlayerSkullBlock = ProjectilePredictor.a.player.getEyePos();
        double d5 = VanillaChestLootTableGenerator.x - WallPlayerSkullBlock.x;
        double d6 = VanillaChestLootTableGenerator.y - WallPlayerSkullBlock.y;
        double d7 = VanillaChestLootTableGenerator.z - WallPlayerSkullBlock.z;
        double d8 = Math.sqrt(d5 * d5 + d7 * d7);
        float f3 = ProjectilePredictor.a((PlayerEntity)ProjectilePredictor.a.player, mc17, projectileType);
        double d9 = f3 * f3;
        double d10 = d9 * d9;
        double d11 = d10 - (d4 = (double)((f2 = projectileType.gravity) * 20.0f)) * (d4 * (d3 = d8) * d3 + 2.0 * (d2 = d6) * d9);
        if (d11 < 0.0) {
            return Float.NaN;
        }
        double d12 = Math.sqrt(d11);
        double d13 = Math.atan((d9 - d12) / (d4 * d3));
        double d14 = Math.atan((d9 + d12) / (d4 * d3));
        return (float)Math.toDegrees(-d13);
    }

    public static float a(Vec3d VanillaChestLootTableGenerator) {
        if (ProjectilePredictor.a.player == null) {
            return Float.NaN;
        }
        Vec3d WallPlayerSkullBlock = ProjectilePredictor.a.player.getEyePos();
        double d2 = VanillaChestLootTableGenerator.x - WallPlayerSkullBlock.x;
        double d3 = VanillaChestLootTableGenerator.z - WallPlayerSkullBlock.z;
        return (float)Math.toDegrees(Math.atan2(-d2, d3));
    }

    public static float[] b(Vec3d VanillaChestLootTableGenerator, Item mc17) {
        float f2 = ProjectilePredictor.a(VanillaChestLootTableGenerator);
        float f3 = ProjectilePredictor.a(VanillaChestLootTableGenerator, mc17);
        if (Float.isNaN(f2) || Float.isNaN(f3)) {
            return null;
        }
        return new float[]{f2, f3};
    }

    public static double a(double d2, Item mc17) {
        ProjectileType projectileType = ProjectilePredictor.b(mc17);
        if (projectileType == null) {
            return 0.0;
        }
        float f2 = projectileType.initialVelocity;
        float f3 = projectileType.gravity;
        double d3 = d2 / (double)f2;
        return 0.5 * (double)f3 * d3 * d3 * 400.0;
    }

    private static boolean lambda$simulate$0(PlayerEntity mc6, Entity mc2) {
        return !mc2.isSpectator() && mc2.canHit() && mc2 != mc6;
    }
}

