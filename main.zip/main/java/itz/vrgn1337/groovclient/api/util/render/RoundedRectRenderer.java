/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import com.mojang.blaze3d.vertex.VertexFormat;
import itz.vrgn1337.groovclient.api.util.render.GLStateSnapshot;
import itz.vrgn1337.groovclient.api.util.render.GlProgram;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.api.util.render.Shaders;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.render.BuiltBuffer;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public final class RoundedRectRenderer {
    private static final float[] a = new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
    private int b = -1;
    private int c = -1;
    private int d = -1;
    private int e = -1;
    private int f = -1;
    private int g = -1;
    private int h = -1;
    private int i = -1;
    private int j = -1;
    private int k = -1;
    private int l = -1;
    private int m = -1;
    private int n = -1;
    private float o = 10.0f;

    public void a(float f2) {
        this.o = f2;
    }

    public float a() {
        return this.o;
    }

    public void a(float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9) {
        this.a(null, f2, f3, f4, f5, f6, f7, f8, f9, this.o, 0.8f);
    }

    public void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9) {
        this.a(mc13, f2, f3, f4, f5, f6, f7, f8, f9, this.o, 0.8f);
    }

    public void a(float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10, float f11) {
        this.a(null, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10, float f11) {
        if (f4 <= 0.0f || f5 <= 0.0f || f10 <= 0.0f) {
            return;
        }
        GlProgram glProgram = Shaders.e();
        if (glProgram == null) {
            return;
        }
        int n2 = Main.mc.getWindow().getWidth();
        int n3 = Main.mc.getWindow().getHeight();
        if (n2 <= 0 || n3 <= 0) {
            return;
        }
        int n4 = GL11.glGetInteger((int)36006);
        int n5 = GuiRenderer.d();
        if (n5 < 0) {
            n5 = n4;
        }
        GL30.glBindFramebuffer((int)36160, (int)n5);
        int[] nArray = new int[1];
        GL30.glGetFramebufferAttachmentParameteriv((int)36160, (int)36064, (int)36049, (int[])nArray);
        if (nArray[0] == 0) {
            GL30.glBindFramebuffer((int)36160, (int)n4);
            return;
        }
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glDisable((int)2929);
            GL13.glActiveTexture((int)33984);
            GL11.glBindTexture((int)3553, (int)nArray[0]);
            GL30.glBindFramebuffer((int)36160, (int)n5);
            GL11.glViewport((int)0, (int)0, (int)n2, (int)n3);
            glProgram.a();
            this.a(glProgram);
            float f12 = RenderScale.g();
            if (this.c >= 0) {
                GL20.glUniform2f((int)this.c, (float)n2, (float)n3);
            }
            if (this.d >= 0) {
                GL20.glUniform2f((int)this.d, (float)(f2 * f12), (float)((float)n3 - f3 * f12 - f5 * f12));
            }
            if (this.e >= 0) {
                GL20.glUniform2f((int)this.e, (float)(f4 * f12), (float)(f5 * f12));
            }
            if (this.f >= 0) {
                GL20.glUniform1f((int)this.f, (float)(f6 * f12));
            }
            if (this.g >= 0) {
                GL20.glUniform1f((int)this.g, (float)(f7 * f12));
            }
            if (this.h >= 0) {
                GL20.glUniform1f((int)this.h, (float)(f8 * f12));
            }
            if (this.i >= 0) {
                GL20.glUniform1f((int)this.i, (float)(f9 * f12));
            }
            if (this.j >= 0) {
                GL20.glUniform1f((int)this.j, (float)f11);
            }
            if (this.k >= 0) {
                GL20.glUniform1f((int)this.k, (float)f10);
            }
            if (this.l >= 0) {
                GL20.glUniform1i((int)this.l, (int)0);
            }
            float f13 = Main.mc.getWindow().getScaledWidth();
            float f14 = Main.mc.getWindow().getScaledHeight();
            float[] fArray = new float[]{2.0f / f13, 0.0f, 0.0f, 0.0f, 0.0f, -2.0f / f14, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, -1.0f, 1.0f, 0.0f, 1.0f};
            if (this.m >= 0) {
                GL20.glUniformMatrix4fv((int)this.m, (boolean)false, (float[])a);
            }
            if (this.n >= 0) {
                GL20.glUniformMatrix4fv((int)this.n, (boolean)false, (float[])fArray);
            }
            Matrix4f matrix4f = new Matrix4f();
            float f15 = Main.mc.getWindow().getScaledWidth();
            float f16 = Main.mc.getWindow().getScaledHeight();
            BufferBuilder mc23 = new BufferBuilder(new BufferAllocator(384), VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
            mc23.vertex((Matrix4fc)matrix4f, -1.0f, -1.0f, 0.0f).color(1.0f, 1.0f, 1.0f, 1.0f);
            mc23.vertex((Matrix4fc)matrix4f, -1.0f, f16 * 2.0f + 1.0f, 0.0f).color(1.0f, 1.0f, 1.0f, 1.0f);
            mc23.vertex((Matrix4fc)matrix4f, f15 * 2.0f + 1.0f, -1.0f, 0.0f).color(1.0f, 1.0f, 1.0f, 1.0f);
            BuiltBuffer mc25 = mc23.endNullable();
            if (mc25 != null) {
                GuiRenderer.a(mc25);
            }
        }
        finally {
            glProgram.b();
            gLStateSnapshot.b();
            GL30.glBindFramebuffer((int)36160, (int)n4);
        }
    }

    private void a(GlProgram glProgram) {
        int n2 = glProgram.c();
        if (n2 == this.b) {
            return;
        }
        this.b = n2;
        this.c = glProgram.a("InputResolution");
        this.d = glProgram.a("uLocation");
        this.e = glProgram.a("uSize");
        this.f = glProgram.a("RadiusTopLeft");
        this.g = glProgram.a("RadiusTopRight");
        this.h = glProgram.a("RadiusBottomLeft");
        this.i = glProgram.a("RadiusBottomRight");
        this.j = glProgram.a("Brightness");
        this.k = glProgram.a("Quality");
        this.l = glProgram.a("InputSampler");
        this.m = glProgram.a("ModelViewMat");
        this.n = glProgram.a("ProjMat");
    }

    public void b() {
        this.b = -1;
    }
}

