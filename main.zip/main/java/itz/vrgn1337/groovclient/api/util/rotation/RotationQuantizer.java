/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.rotation;

import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.util.math.MathHelper;

public final class RotationQuantizer {
    private static double a() {
        double d2 = (Double)Main.mc.options.getMouseSensitivity().getValue();
        return Math.pow(d2 * 0.6 + 0.2, 3.0) * 1.2;
    }

    public static float[] a(float f2, float f3) {
        double d2 = RotationQuantizer.a();
        float f4 = Main.mc.player.getYaw();
        float f5 = Main.mc.player.getPitch();
        float f6 = MathHelper.wrapDegrees((float)(f2 - f4));
        float f7 = f3 - f5;
        float f8 = (float)((double)Math.round((double)f6 / d2) * d2);
        float f9 = (float)((double)Math.round((double)f7 / d2) * d2);
        float f10 = f4 + f8;
        float f11 = MathHelper.clamp((float)(f5 + f9), (float)-90.0f, (float)90.0f);
        return new float[]{f10, f11};
    }

    public static float a(float f2, float f3, float f4, float f5) {
        float f6 = MathHelper.wrapDegrees((float)(f4 - f2));
        float f7 = f5 - f3;
        double d2 = Math.sqrt(f6 * f6 + f7 * f7);
        return (float)Math.min(d2, 180.0);
    }

    public static boolean a(float f2, float f3, float f4, float f5, float f6) {
        return RotationQuantizer.a(f2, f3, f4, f5) <= f6;
    }

    public static boolean b(float f2, float f3, float f4, float f5) {
        return RotationQuantizer.a(f2, f3, f4, f5, 2.0f);
    }
}

