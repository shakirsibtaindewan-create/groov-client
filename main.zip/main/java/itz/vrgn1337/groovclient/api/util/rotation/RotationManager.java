/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.rotation;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.PlayerRenderEvent;
import itz.vrgn1337.groovclient.api.util.BindManager;
import itz.vrgn1337.groovclient.api.util.Stopwatch;
import itz.vrgn1337.groovclient.api.util.input.InputUtils;
import itz.vrgn1337.groovclient.api.util.rotation.RandomRotation;
import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationJitter;
import itz.vrgn1337.groovclient.api.util.rotation.RotationMode;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.api.util.world.RaycastHit;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.mixin.accessor.MultiPlayerGameModeInvoker;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.world.GameMode;
import net.minecraft.world.World;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.packet.Packet;
import net.minecraft.block.BlockState;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.client.network.ClientPlayerEntity;
import org.apache.commons.lang3.mutable.MutableObject;
import itz.vrgn1337.groovclient.api.event.hooks.InteractItemEvent;
import itz.vrgn1337.groovclient.api.event.hooks.MovementPacketEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketSendEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractItemEvent;
import itz.vrgn1337.groovclient.api.event.hooks.MovementPacketEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketSendEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;

public class RotationManager {
    private static final RotationManager a = new RotationManager();
    public static RotationMode b = RotationMode.PROPER;
    private static final float c = 22.5f;
    private static final int d = 2;
    private static final int e = 25;
    public static final List f = new ArrayList();
    private boolean g;
    private boolean h;
    private boolean i;
    private Rotation j;
    private Rotation k;
    private float l;
    private float m;
    private float n;
    private float o;
    private float p;
    private float q;
    private float r;
    private float s;
    private boolean t;
    private boolean u;
    private int v;
    private int w;
    private final Random x = new Random();
    private float y;
    private float z;
    private int A;
    private int B;
    private float C = 6.0f;
    private float D = 3.5f;
    private float E;
    private float F;
    private static final float G = 15.0f;
    private float H;
    private float I;
    private float J;
    private float K;
    private float L;
    private float M;
    private float N;
    private long O;
    private boolean P;
    private static final float Q = 6.0f;
    private static final float R = 15.0f;
    private boolean S = false;
    private long T = 0L;
    private float U = 0.0f;
    private float V = 0.0f;
    private long W = 0L;
    private float X = 0.0f;
    private float Y = 0.0f;
    private float Z = 0.0f;
    private float aa = 0.0f;
    private float ab = (float)(Math.random() * 100.0);
    private float ac = (float)(Math.random() * 100.0);
    private float ad = 0.0f;
    private float ae = 0.0f;
    private float af = 0.0f;
    private boolean ag = false;
    private final Random ah = new Random();
    private boolean ai = false;
    private final Stopwatch aj = new Stopwatch();
    private static boolean ak = false;
    private static final Direction[] al = new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, Direction.UP};

    public static RotationManager getInstance() {
        return a;
    }

    private RotationManager() {
        Main.eventBus().register(this);
    }

    public void a(Rotation rotation, int n2) {
        if (Main.mc.player == null || Main.mc.player.isSpectator()) {
            return;
        }
        if (!this.b(rotation)) {
            return;
        }
        if (this.h) {
            this.h = false;
            this.i = false;
            this.g = true;
            this.t();
        }
        if (this.j != null && this.d() && this.j.c() > n2) {
            return;
        }
        if (this.k != null && this.k != rotation && this.k.c() < n2) {
            this.k.f();
        }
        this.k = rotation;
        this.j = rotation;
        this.j.a(n2);
        this.x.getValue();
        this.c(RandomRotation.a(rotation));
    }

    public void a(Rotation rotation) {
        this.a(rotation, 0);
    }

    public void b(Rotation rotation, int n2) {
        if (Main.mc.player == null || Main.mc.player.isSpectator()) {
            return;
        }
        if (!this.b(rotation)) {
            return;
        }
        if (this.h) {
            this.h = false;
            this.i = false;
            this.g = true;
            this.t();
        }
        if (this.j != null && this.d() && this.j.c() > n2) {
            return;
        }
        if (this.k != null && this.k != rotation && this.k.c() < n2) {
            this.k.f();
        }
        this.k = rotation;
        this.j = rotation;
        this.j.a(n2);
        if (!Main.mc.isWindowFocused() || Main.mc.currentScreen != null || this.i) {
            this.b();
            return;
        }
        if (!this.g) {
            this.g = true;
        }
        Rotation rotation2 = RandomRotation.a(rotation);
        float f2 = RotationManager.a(rotation2.a(), this.n);
        float f3 = MathHelper.clamp((float)rotation2.b(), (float)-90.0f, (float)90.0f);
        float[] fArray = RandomRotation.a(f2, f3, 2, 1);
        f2 = fArray[0];
        f3 = fArray[1];
        this.l = f2;
        this.m = f3;
        this.n = f2;
        this.o = f3;
        this.w = this.v;
    }

    public void a(Rotation rotation, int n2, boolean bl) {
        if (bl) {
            this.b(rotation, n2);
            return;
        }
        if (Main.mc.player == null || Main.mc.player.isSpectator()) {
            return;
        }
        if (!this.b(rotation)) {
            return;
        }
        if (this.j != null && this.d() && this.j.c() > n2) {
            return;
        }
        if (this.k != null && this.k != rotation && this.k.c() < n2) {
            this.k.f();
        }
        this.k = rotation;
        this.j = rotation;
        this.j.a(n2);
        Rotation rotation2 = RandomRotation.a(rotation);
        float f2 = RotationManager.a(rotation2.a(), Main.mc.player.getYaw());
        float f3 = MathHelper.clamp((float)rotation2.b(), (float)-90.0f, (float)90.0f);
        float[] fArray = RandomRotation.a(f2, f3, 2, 1);
        Main.mc.player.setYaw(fArray[0]);
        Main.mc.player.setPitch(fArray[1]);
    }

    public void a(Rotation rotation, boolean bl) {
        this.a(rotation, 0, bl);
    }

    private static float a(float f2, float f3) {
        float f4 = MathHelper.wrapDegrees((float)(f2 - f3));
        return f3 + f4;
    }

    public void b() {
        if (this.g) {
            this.g = false;
            this.i = true;
            if (this.k != null && !this.k.e()) {
                this.k.f();
            }
        }
    }

    public void c() {
        this.g = false;
        this.h = false;
        this.i = false;
        this.j = null;
        this.k = null;
        this.t();
    }

    public boolean b(Rotation rotation) {
        if (rotation == null) {
            return false;
        }
        return !f.contains(rotation.d());
    }

    public boolean d() {
        return RotationUtils.a();
    }

    public boolean e() {
        return this.g;
    }

    public boolean f() {
        return this.t;
    }

    public static boolean g() {
        RotationManager rotationManager = a;
        if (rotationManager.w <= 0) {
            return true;
        }
        return rotationManager.v - rotationManager.w > 2;
    }

    public void a(boolean bl) {
        if (this.e() && !bl) {
            this.h = true;
            this.t();
            this.B = this.x.nextInt(2);
            this.C = 5.0f + this.x.nextFloat() * 3.0f;
            this.D = 3.0f + this.x.nextFloat() * 1.5f;
            if (Main.mc.player != null) {
                this.E = Main.mc.player.getYaw();
                this.F = Main.mc.player.getPitch();
            }
        } else if (!this.e() && bl) {
            if (this.h) {
                this.h = false;
                this.t();
            }
            this.i = false;
        }
        this.g = bl;
    }

    public boolean h() {
        return this.h;
    }

    public float i() {
        return this.d() || this.h ? this.l : (Main.mc.player != null ? Main.mc.player.getYaw() : 0.0f);
    }

    public float j() {
        return this.d() || this.h ? this.m : (Main.mc.player != null ? Main.mc.player.getPitch() : 0.0f);
    }

    public float k() {
        return this.n;
    }

    public float l() {
        return this.o;
    }

    public float m() {
        return this.p;
    }

    public float n() {
        return this.q;
    }

    public Rotation o() {
        return this.j;
    }

    public static float p() {
        return a.i();
    }

    public static float q() {
        return a.j();
    }

    public static float r() {
        return a.k();
    }

    public static float s() {
        return a.l();
    }

    private void c(Rotation rotation) {
        if (!Main.mc.isWindowFocused() || Main.mc.currentScreen != null || this.i) {
            this.b();
            return;
        }
        if (!this.g) {
            this.g = true;
        }
        float f2 = MathHelper.wrapDegrees((float)(rotation.a() - this.n));
        float f3 = rotation.b() - this.o;
        f2 = MathHelper.clamp((float)f2, (float)-22.5f, (float)22.5f);
        f3 = MathHelper.clamp((float)f3, (float)-22.5f, (float)22.5f);
        float f4 = this.n + f2;
        float f5 = MathHelper.clamp((float)(this.o + f3), (float)-90.0f, (float)90.0f);
        float[] fArray = RandomRotation.a(f4, f5, 3, 2);
        f4 = fArray[0];
        f5 = fArray[1];
        this.l = f4;
        this.m = f5;
        this.n = f4;
        this.o = f5;
        this.w = this.v;
    }

    private void t() {
        this.y = 0.0f;
        this.z = 0.0f;
        this.A = 0;
        this.B = 0;
    }

    private void u() {
        if (Main.mc.player == null) {
            return;
        }
        this.h = true;
        this.t();
        this.B = this.x.nextInt(2);
        this.C = 5.0f + this.x.nextFloat() * 3.0f;
        this.D = 3.0f + this.x.nextFloat() * 1.5f;
        this.E = Main.mc.player.getYaw();
        this.F = Main.mc.player.getPitch();
    }

    private void v() {
        if (Main.mc.player == null) {
            return;
        }
        this.E = Main.mc.player.getYaw();
        this.F = Main.mc.player.getPitch();
        float f2 = MathHelper.wrapDegrees((float)(this.E - this.n));
        float f3 = this.F - this.o;
        float f4 = (float)Math.sqrt(f2 * f2 + f3 * f3);
        ++this.A;
        if (f4 < 1.5f || this.A > 25) {
            float f5;
            this.h = false;
            this.g = false;
            this.t();
            this.w = 0;
            this.l = f5 = RotationManager.a(this.E, this.n);
            this.m = this.F;
            this.n = f5;
            this.o = this.F;
            return;
        }
        if (this.A <= this.B) {
            this.l = this.n;
            this.m = this.o;
            return;
        }
        if (this.x.nextFloat() < 0.12f && f4 > 5.0f) {
            this.l = this.n;
            this.m = this.o;
            this.y *= 0.5f + this.x.nextFloat() * 0.4f;
            this.z *= 0.5f + this.x.nextFloat() * 0.4f;
            return;
        }
        float f6 = Math.min(1.0f, (float)this.A / 8.0f);
        float f7 = f6 * f6;
        float f8 = 22.5f * (0.6f + this.x.nextFloat() * 0.8f);
        float f9 = 22.5f * (0.6f + this.x.nextFloat() * 0.8f);
        float f10 = this.a(Math.min(1.0f, Math.abs(f2) / 30.0f));
        float f11 = this.a(Math.min(1.0f, Math.abs(f3) / 20.0f));
        float f12 = f8 * (0.15f + 0.85f * f7) * (0.2f + 0.8f * f10);
        float f13 = f9 * (0.15f + 0.85f * f7) * (0.2f + 0.8f * f11);
        float f14 = this.C * (0.8f + this.x.nextFloat() * 0.4f);
        float f15 = this.D * (0.8f + this.x.nextFloat() * 0.4f);
        float f16 = f2 * f14;
        float f17 = this.y * f15;
        this.y += (f16 - f17) * 0.05f;
        this.y = MathHelper.clamp((float)this.y, (float)(-f12), (float)f12);
        float f18 = f3 * f14;
        float f19 = this.z * f15;
        this.z += (f18 - f19) * 0.05f;
        this.z = MathHelper.clamp((float)this.z, (float)(-f13), (float)f13);
        float f20 = this.y;
        float f21 = this.z;
        if (Math.abs(f20) > Math.abs(f2)) {
            f20 = f2;
        }
        if (Math.abs(f21) > Math.abs(f3)) {
            f21 = f3;
        }
        float f22 = this.n + (f20 += (this.x.nextFloat() * 2.0f - 1.0f) * 0.4f);
        float f23 = MathHelper.clamp((float)(this.o + (f21 += (this.x.nextFloat() * 2.0f - 1.0f) * 0.2f)), (float)-90.0f, (float)90.0f);
        this.l = f22;
        this.m = f23;
        this.n = f22;
        this.o = f23;
    }

    private float a(float f2) {
        return f2 * f2 * (3.0f - 2.0f * f2);
    }

    @Priority(value=200)
    private void onInteractItemEventPre(InteractItemEvent.Pre interactItemEvent$Pre) {
        if (this.d()) {
            interactItemEvent$Pre.cancel();
            RotationManager.getInstance().a(interactItemEvent$Pre.hand);
        }
    }

    @Priority(value=200)
    private void onUpdateEventPre(UpdateEvent.Pre updateEvent$Pre) {
        if (Main.mc.player == null) {
            return;
        }
        ++this.v;
        this.u = false;
        if (this.g && !this.h && this.v - this.w > 2) {
            this.g = false;
            this.i = true;
            this.u();
        }
        if (Main.mc.player.isDead() || Main.mc.player.isSpectator()) {
            this.c();
        }
        if (!this.g && !this.h) {
            this.l = Main.mc.player.getYaw();
            this.m = Main.mc.player.getPitch();
        }
        if (this.h) {
            this.v();
            this.u = true;
        }
    }

    @Priority(value=-200)
    private void onMovementPacketEventPre(MovementPacketEvent.Pre movementPacketEvent$Pre) {
        if (Main.mc.player == null) {
            return;
        }
        this.r = Main.mc.player.getYaw();
        this.s = Main.mc.player.getPitch();
        this.t = false;
        if (this.h && !this.u) {
            this.B = 0;
            float f2 = this.l;
            this.v();
            this.u = true;
            double d2 = (Double)Main.mc.options.getMouseSensitivity().getValue();
            double d3 = d2 * 0.6 + 0.2;
            double d4 = d3 * d3 * d3 * 8.0;
            if (Math.abs(this.l - f2) < (float)d4) {
                float f3 = (float)d4;
                if (Math.random() > 0.5) {
                    f3 = -f3;
                }
                this.n = this.l = f2 + f3;
            }
            this.t = true;
            Main.mc.player.setYaw(this.l);
            Main.mc.player.setPitch(this.m);
            this.n = Main.mc.player.getYaw();
            this.o = Main.mc.player.getPitch();
            return;
        }
        if (!this.g && !this.h) {
            return;
        }
        this.t = true;
        Main.mc.player.setYaw(this.l);
        Main.mc.player.setPitch(this.m);
        this.n = Main.mc.player.getYaw();
        this.o = Main.mc.player.getPitch();
    }

    @Priority(value=200)
    private void onMovementPacketEventPost(MovementPacketEvent.Post movementPacketEvent$Post) {
        if (Main.mc.player == null) {
            return;
        }
        this.H = this.w();
        if (this.t) {
            Main.mc.player.setYaw(this.r);
            Main.mc.player.setPitch(this.s);
            this.t = false;
        }
        if (this.k != null) {
            this.k.h();
        }
    }

    private float w() {
        float f2;
        float f3;
        if (Main.mc.player == null) {
            return this.H;
        }
        double d2 = Main.mc.player.getX() - Main.mc.player.lastX;
        double d3 = Main.mc.player.getZ() - Main.mc.player.lastZ;
        float f4 = (float)Math.sqrt(d2 * d2 + d3 * d3);
        float f5 = this.H;
        if (f4 > 0.0025f) {
            f5 = (float)(MathHelper.atan2((double)d3, (double)d2) * 57.29577951308232) - 90.0f;
        }
        if ((f3 = MathHelper.wrapDegrees((float)((f2 = this.d() ? this.n : Main.mc.player.getYaw()) - f5))) > 15.0f) {
            f5 = f2 - 15.0f;
        } else if (f3 < -15.0f) {
            f5 = f2 + 15.0f;
        }
        float f6 = MathHelper.wrapDegrees((float)(f5 - this.H));
        return this.H + f6;
    }

    @Priority(value=200)
    private void onPlayerRender(PlayerRenderEvent playerRenderEvent) {
        float f2;
        float f3;
        if (Main.mc.player == null || Main.mc.currentScreen != null) {
            return;
        }
        if (playerRenderEvent.player != Main.mc.player) {
            return;
        }
        boolean bl = this.d();
        long l2 = System.currentTimeMillis();
        float f4 = this.O == 0L ? 0.0064f : Math.min(1.0f, (float)(l2 - this.O) / 250.0f);
        this.O = l2;
        if (!this.P) {
            f3 = bl ? this.n : Main.mc.player.getYaw();
            f2 = bl ? this.o : Main.mc.player.getPitch();
            this.I = f3;
            this.J = f2;
            this.K = Main.mc.player.bodyYaw;
            this.L = 0.0f;
            this.M = 0.0f;
            this.N = 0.0f;
            this.P = true;
        }
        if (bl && !this.h) {
            f3 = this.n;
            f2 = this.o;
            float f5 = this.w();
            float f6 = 10.0f;
            float f7 = 4.0f;
            float f8 = MathHelper.wrapDegrees((float)(f3 - this.I));
            float f9 = f8 * f6;
            float f10 = this.L * f7;
            this.L += (f9 - f10) * f4;
            this.L = MathHelper.clamp((float)this.L, (float)-180.0f, (float)180.0f);
            this.I += this.L * f4;
            float f11 = f2 - this.J;
            float f12 = f11 * f6;
            float f13 = this.M * f7;
            this.M += (f12 - f13) * f4;
            this.M = MathHelper.clamp((float)this.M, (float)-90.0f, (float)90.0f);
            this.J += this.M * f4;
            this.J = MathHelper.clamp((float)this.J, (float)-90.0f, (float)90.0f);
            float f14 = 8.0f;
            float f15 = 3.0f;
            float f16 = MathHelper.wrapDegrees((float)(f5 - this.K));
            float f17 = f16 * f14;
            float f18 = this.N * f15;
            this.N += (f17 - f18) * f4;
            this.N = MathHelper.clamp((float)this.N, (float)-120.0f, (float)120.0f);
            this.K += this.N * f4;
            float f19 = 1.0f - (float)Math.exp(-8.0f * f4);
            this.I += MathHelper.wrapDegrees((float)(f3 - this.I)) * f19 * 0.3f;
            this.J += (f2 - this.J) * f19 * 0.3f;
            this.K += MathHelper.wrapDegrees((float)(f5 - this.K)) * f19 * 0.2f;
            Main.mc.player.lastBodyYaw = this.K;
            Main.mc.player.lastHeadYaw = this.I;
            Main.mc.player.setBodyYaw(this.K);
            playerRenderEvent.renderState.pitch = this.J;
            playerRenderEvent.renderState.relativeHeadYaw = MathHelper.wrapDegrees((float)(this.I - this.K));
        } else if (this.h) {
            f3 = Main.mc.player.getYaw();
            f2 = Main.mc.player.getPitch();
            float f20 = Main.mc.player.bodyYaw;
            float f21 = 1.0f - (float)Math.exp(-7.0f * f4);
            this.I += MathHelper.wrapDegrees((float)(f3 - this.I)) * f21;
            this.J += (f2 - this.J) * f21;
            this.J = MathHelper.clamp((float)this.J, (float)-90.0f, (float)90.0f);
            this.K += MathHelper.wrapDegrees((float)(f20 - this.K)) * f21;
            Main.mc.player.lastBodyYaw = this.K;
            Main.mc.player.lastHeadYaw = this.I;
            Main.mc.player.setBodyYaw(this.K);
            playerRenderEvent.renderState.pitch = this.J;
            playerRenderEvent.renderState.relativeHeadYaw = MathHelper.wrapDegrees((float)(this.I - this.K));
        } else {
            f3 = 1.0f - (float)Math.exp(-5.0f * f4);
            this.I += MathHelper.wrapDegrees((float)(Main.mc.player.getYaw() - this.I)) * f3;
            this.J += (Main.mc.player.getPitch() - this.J) * f3;
            this.K += MathHelper.wrapDegrees((float)(Main.mc.player.bodyYaw - this.K)) * f3;
        }
    }

    private void onPacketSendEventPre(PacketSendEvent.Pre packetSendEvent$Pre) {
        Packet mc14 = packetSendEvent$Pre.getPacket();
        if (mc14 instanceof PlayerMoveC2SPacket) {
            PlayerMoveC2SPacket mc56 = (PlayerMoveC2SPacket)mc14;
            this.p = this.n;
            this.q = this.o;
            this.n = mc56.getYaw(this.n);
            this.o = mc56.getPitch(this.o);
        }
    }

    private void onPacketReceiveEventPre(PacketReceiveEvent.Pre packetReceiveEvent$Pre) {
        Packet mc14 = packetReceiveEvent$Pre.getPacket();
        if (mc14 instanceof PlayerPositionLookS2CPacket) {
            PlayerPositionLookS2CPacket mc57 = (PlayerPositionLookS2CPacket)mc14;
            this.p = this.n;
            this.q = this.o;
            this.n = mc57.change().yaw();
            this.o = mc57.change().pitch();
        }
    }

    public void x() {
        this.ai = true;
        this.aj.b();
    }

    public void a(LivingEntity mc58, float f2, boolean bl) {
        this.a(mc58.getEyePos(), f2, bl);
    }

    public void a(Vec3d VanillaChestLootTableGenerator, float f2, boolean bl) {
        float f3;
        float f4;
        float f5;
        float f6;
        float f7;
        float f8;
        float f9;
        if (this.ai && !this.aj.a(100.0)) {
            return;
        }
        long l2 = System.currentTimeMillis();
        if (!this.S) {
            this.S = true;
            this.T = l2;
            this.U = 0.0f;
            this.V = 0.0f;
            this.W = 0L;
            this.ad = 0.0f;
            this.ae = 0.0f;
            this.af = 0.0f;
            this.ag = false;
            this.X = 0.0f;
            this.Y = 0.0f;
            this.Z = 0.0f;
            this.aa = 0.0f;
            this.ab = (float)(Math.random() * 100.0);
            this.ac = (float)(Math.random() * 100.0);
        }
        float f10 = Math.min(0.1f, (float)(l2 - this.W) / 1000.0f);
        if (this.W == 0L) {
            f10 = 0.016f;
        }
        this.W = l2;
        Vec3d WallPlayerSkullBlock = Main.mc.player.getEyePos();
        double d2 = VanillaChestLootTableGenerator.x - WallPlayerSkullBlock.x;
        double d3 = VanillaChestLootTableGenerator.y - WallPlayerSkullBlock.y;
        double d4 = VanillaChestLootTableGenerator.z - WallPlayerSkullBlock.z;
        double d5 = Math.sqrt(d2 * d2 + d4 * d4);
        float f11 = (float)(Math.toDegrees(Math.atan2(d4, d2)) - 90.0);
        float f12 = (float)(-Math.toDegrees(Math.atan2(d3, d5)));
        float f13 = bl ? this.n : Main.mc.player.getYaw();
        float f14 = bl ? this.o : Main.mc.player.getPitch();
        float f15 = MathHelper.wrapDegrees((float)(f11 - f13));
        float f16 = MathHelper.wrapDegrees((float)(f12 - f14));
        float f17 = (float)Math.sqrt(f15 * f15 + f16 * f16);
        double d6 = RotationJitter.a();
        double d7 = (double)((Integer)Main.mc.options.getFov().getValue()).intValue() / 90.0;
        float f18 = RotationJitter.c();
        float f19 = f2;
        if (f17 > 6.0f) {
            f9 = Math.min(1.0f, f17 / 90.0f);
            f8 = (float)(1.0 - Math.pow(1.0 - (double)f9, 2.5));
            f7 = 0.15f + f8 * 0.85f;
            f6 = this.a(Math.min(1.0f, Math.abs(f15) / 45.0f));
            float var35_26;
            var35_26 = this.a(Math.min(1.0f, Math.abs(f16) / 30.0f));
            float f20 = f15 * f19 * (float)(d6 * d7) * (0.2f + f6 * 0.8f) * f7;
            float var37_30;
            var37_30 = f16 * f19 * (float)(d6 * d7) * (0.2f + var35_26 * 0.8f) * f7;
            float f21 = 16.0f + this.ah.nextFloat() * 6.0f;
            float f22 = 1.0f - (float)Math.exp(-f21 * f10);
            this.U += (f20 - this.U) * f22;
            this.V += (var37_30 - this.V) * f22;
            float f23 = f10 * 60.0f;
            f5 = this.U * f23 * 0.15f;
            f4 = this.V * f23 * 0.15f;
            f3 = 0.015f * (1.0f - f8);
            f5 += this.a(true, f10) * f3;
            f4 += this.a(false, f10) * f3;
            this.ag = f17 > 15.0f;
        } else {
            if (this.ag) {
                this.ag = false;
                f9 = 0.015f + (float)Math.random() * 0.15f;
                this.ad = this.U * f9 * 0.3f;
                this.ae = this.V * f9 * 0.3f;
                this.af = 1.0f;
            }
            if (this.af > 0.01f) {
                this.af *= (float)Math.exp(-8.0f * f10);
                f5 = this.ad * this.af;
                f4 = this.ae * this.af;
            } else {
                f5 = 0.0f;
                f4 = 0.0f;
            }
            f9 = 0.35f + f18 * 0.25f;
            f8 = f15 * f9 * (float)(d6 * d7);
            f7 = f16 * f9 * (float)(d6 * d7);
            f6 = 6.0f * (0.5f + f18 * 0.5f);
            float var35_26;
            var35_26 = 1.0f - (float)Math.exp(-f6 * f10);
            this.U += (f8 - this.U) * var35_26;
            this.V += (f7 - this.V) * var35_26;
            float f24 = f10 * 60.0f;
            f5 += this.U * f24 * 0.08f;
            f4 += this.V * f24 * 0.08f;
            float var37_30;
            var37_30 = 0.6f + f18 * 0.4f;
            f5 += this.a(true, f10) * var37_30;
            f4 += this.a(false, f10) * var37_30;
        }
        f9 = Math.min(1.0f, (float)(l2 - this.T) / 180.0f);
        f8 = this.a(f9);
        f5 *= f8;
        f4 *= f8;
        if (f17 > 6.0f) {
            if (Math.abs(f5) > Math.abs(f15)) {
                f5 = f15;
            }
            if (Math.abs(f4) > Math.abs(f16)) {
                f4 = f16;
            }
        }
        f7 = f13 + f5 * 0.2f;
        f6 = MathHelper.clamp((float)(f14 + f4 * 0.2f), (float)-90.0f, (float)90.0f);
        double d8 = (Double)Main.mc.options.getMouseSensitivity().getValue();
        double d9 = d8 * 0.6 + 0.2;
        double d10 = d9 * d9 * d9 * 8.0;
        f3 = MathHelper.wrapDegrees((float)(f7 - f13));
        float f25 = f6 - f14;
        f3 = (float)((double)Math.round((double)f3 / d10) * d10);
        f25 = (float)((double)Math.round((double)f25 / d10) * d10);
        float[] fArray = new float[]{f13 + f3, MathHelper.clamp((float)(f14 + f25), (float)-90.0f, (float)90.0f)};
        RotationJitter.a(fArray[0], fArray[1]);
        if (bl) {
            this.n = fArray[0];
            this.o = fArray[1];
            this.l = fArray[0];
            this.m = fArray[1];
            if (!this.g) {
                this.g = true;
            }
            this.w = this.v;
        } else {
            Main.mc.player.setYaw(fArray[0]);
            Main.mc.player.setPitch(fArray[1]);
        }
    }

    public void y() {
        this.S = false;
        this.U = 0.0f;
        this.V = 0.0f;
        this.W = 0L;
        this.ad = 0.0f;
        this.ae = 0.0f;
        this.af = 0.0f;
        this.ag = false;
    }

    private float a(boolean bl, float f2) {
        if (bl) {
            this.X += f2 * 2.7f;
            this.Y += f2 * 5.9f;
            this.Z += f2 * 12.3f;
            this.aa += f2 * 25.1f;
        }
        float f3 = bl ? this.ab : this.ac;
        float f4 = (float)Math.sin(this.X + f3) * 0.022f;
        f4 += (float)Math.sin(this.Y + f3 * 1.3f) * 0.011f;
        f4 += (float)Math.sin(this.Z + f3 * 2.1f) * 0.0055f;
        f4 += (float)Math.sin(this.aa + f3 * 3.7f) * 0.0028f;
        if (!bl) {
            f4 *= 0.75f;
        }
        return f4;
    }

    public void b(float f2) {
        this.n += f2;
        this.l += f2;
    }

    public static boolean z() {
        return ak;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public ActionResult a(BlockHitResult mc7, Hand mc8, boolean bl) {
        boolean bl2;
        if (Main.mc.player == null || Main.mc.world == null || Main.mc.interactionManager == null || mc7 == null) {
            return ActionResult.PASS;
        }
        if (!Main.mc.world.getWorldBorder().contains(mc7.getBlockPos())) {
            return ActionResult.FAIL;
        }
        Main.mc.options.useKey.setPressed(false);
        float f2 = Main.mc.player.getYaw();
        float f3 = Main.mc.player.getPitch();
        boolean bl3 = bl2 = this.g || this.h;
        if (bl2) {
            Main.mc.player.setYaw(this.n);
            Main.mc.player.setPitch(this.o);
        }
        MultiPlayerGameModeInvoker multiPlayerGameModeInvoker = (MultiPlayerGameModeInvoker)Main.mc.interactionManager;
        multiPlayerGameModeInvoker.ensureHasSentCarriedItem();
        ak = true;
        MutableObject mutableObject = new MutableObject((Object)ActionResult.PASS);
        try {
            multiPlayerGameModeInvoker.startPrediction(Main.mc.world, arg_0 -> ((RotationManager)this).lambda$interactBlock$0((MutableObject)mutableObject, (Hand)mc8, (BlockHitResult)mc7, arg_0));
            if (bl && ((ActionResult)mutableObject.getValue()).isAccepted()) {
                Main.mc.player.swingHand(mc8);
            }
        }
        finally {
            ak = false;
            if (bl2) {
                Main.mc.player.setYaw(f2);
                Main.mc.player.setPitch(f3);
            }
        }
        return (ActionResult)mutableObject.getValue();
    }

    private ActionResult a(ClientPlayerEntity mc59, Hand mc8, BlockHitResult mc7) {
        ActionResult mc60;
        BlockState mc1;
        boolean bl;
        if (Main.mc.interactionManager.getCurrentGameMode() == GameMode.SPECTATOR) {
            return ActionResult.CONSUME;
        }
        BlockPos mc0 = mc7.getBlockPos();
        ItemStack mc33 = mc59.getStackInHand(mc8);
        boolean bl2 = !mc59.getMainHandStack().isEmpty() || !mc59.getOffHandStack().isEmpty();
        boolean bl3 = bl = mc59.shouldCancelInteraction() && bl2;
        if (!bl) {
            mc1 = Main.mc.world.getBlockState(mc0);
            if (Main.mc.getNetworkHandler() != null && !Main.mc.getNetworkHandler().hasFeature(mc1.getBlock().getRequiredFeatures())) {
                return ActionResult.FAIL;
            }
            ActionResult mc61 = mc1.onUseWithItem(mc33, (World)Main.mc.world, (PlayerEntity)mc59, mc8, mc7);
            if (mc61.isAccepted()) {
                return mc61;
            }
            if (mc61 instanceof ActionResult.PassToDefaultBlockAction && mc8 == Hand.MAIN_HAND && (mc60 = mc1.onUse((World)Main.mc.world, (PlayerEntity)mc59, mc7)).isAccepted()) {
                return mc60;
            }
        }
        if (!mc33.isEmpty() && !mc59.getItemCooldownManager().isCoolingDown(mc33)) {
            mc1 = new ItemUsageContext((PlayerEntity)mc59, mc8, mc7);
            if (mc59.isInCreativeMode()) {
                int n2 = mc33.getCount();
                mc60 = mc33.useOnBlock((ItemUsageContext)mc1);
                mc33.setCount(n2);
                return mc60;
            }
            return mc33.useOnBlock((ItemUsageContext)mc1);
        }
        return ActionResult.PASS;
    }

    public ActionResult b(BlockHitResult mc7, Hand mc8, boolean bl) {
        return this.a(mc7, mc8, bl);
    }

    public boolean a(BlockPos mc0) {
        if (Main.mc.world == null) {
            return false;
        }
        BlockState mc1 = Main.mc.world.getBlockState(mc0);
        Block mc62 = mc1.getBlock();
        if (mc62 == Blocks.FIRE || mc62 == Blocks.SOUL_FIRE) {
            return true;
        }
        if (mc62 == Blocks.SNOW || mc62 == Blocks.SNOW_BLOCK || mc62 == Blocks.POWDER_SNOW) {
            return true;
        }
        return mc1.isReplaceable();
    }

    public boolean b(BlockPos mc0) {
        if (Main.mc.player == null || Main.mc.world == null) {
            return false;
        }
        return this.a(mc0) && !Main.mc.player.getBoundingBox().intersects(new Box(mc0)) && Main.mc.player.canInteractWithBlockAt(mc0, 0.0);
    }

    public static Vec3d a(BlockPos mc0, Direction mc63) {
        return Vec3d.ofCenter((Vec3i)mc0).add(Vec3d.of((Vec3i)mc63.getVector()).multiply(0.45));
    }

    public boolean a(BlockPos mc0, Direction mc63, Vec3d VanillaChestLootTableGenerator) {
        if (Main.mc.player == null || Main.mc.world == null) {
            return false;
        }
        BlockHitResult mc7 = Main.mc.world.raycast(new RaycastContext(Main.mc.player.getEyePos(), VanillaChestLootTableGenerator, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, (Entity)Main.mc.player));
        return mc7.getType() == HitResult.Type.BLOCK && mc7.getBlockPos().equals((Object)mc0) && mc7.getSide() == mc63;
    }

    public RaycastHit a(BlockPos mc0, BlockPos mc64, Direction mc63) {
        if (Main.mc.player == null || Main.mc.world == null) {
            return null;
        }
        RaycastHit raycastHit = null;
        double d2 = Double.MAX_VALUE;
        for (Direction mc65 : al) {
            Vec3d VanillaChestLootTableGenerator;
            BlockPos mc66 = mc0.offset(mc65.getOpposite());
            if (mc64 != null && mc66.equals((Object)mc64) || this.a(mc66) || !Main.mc.player.canInteractWithBlockAt(mc66, 0.0) || !this.a(mc66, mc65, VanillaChestLootTableGenerator = RotationManager.a(mc66, mc65))) continue;
            Rotation rotation = RotationUtils.a(VanillaChestLootTableGenerator, Main.mc.player.getEyePos());
            float f2 = Math.abs(MathHelper.wrapDegrees((float)(Main.mc.player.getYaw() - rotation.a())));
            float f3 = MathHelper.clamp((float)rotation.b(), (float)-90.0f, (float)90.0f);
            float f4 = Math.abs(Main.mc.player.getPitch() - f3);
            double d3 = (double)f2 + (double)f4 * 0.6 + Main.mc.player.getEyePos().squaredDistanceTo(VanillaChestLootTableGenerator) * 0.12;
            if (mc63 != null && mc64 != null && mc0.equals((Object)mc64.offset(mc63))) {
                d3 -= 2.0;
            }
            if (!(d3 < d2)) continue;
            d2 = d3;
            raycastHit = new RaycastHit(mc66, mc65, VanillaChestLootTableGenerator);
        }
        return raycastHit;
    }

    public void a(RaycastHit raycastHit, Rotation rotation, int n2) {
        if (Main.mc.player == null || raycastHit == null || rotation == null) {
            return;
        }
        Rotation rotation2 = RotationUtils.a(raycastHit.c(), Main.mc.player.getEyePos());
        float f2 = 0.6f + (float)(Math.random() * 0.35);
        float f3 = MathHelper.lerpAngleDegrees((float)f2, (float)this.k(), (float)rotation2.a());
        float f4 = MathHelper.clamp((float)rotation2.b(), (float)-90.0f, (float)90.0f);
        float f5 = this.l() + (f4 - this.l()) * f2;
        f5 = MathHelper.clamp((float)f5, (float)-90.0f, (float)90.0f);
        float f6 = 1.9f;
        float f7 = MathHelper.wrapDegrees((float)(f3 - this.k()));
        if (f7 > f6) {
            f3 = this.k() + f6;
        } else if (f7 < -f6) {
            f3 = this.k() - f6;
        }
        float f8 = f5 - this.l();
        if (f8 > f6) {
            f5 = this.l() + f6;
        } else if (f8 < -f6) {
            f5 = this.l() - f6;
        }
        f5 = MathHelper.clamp((float)f5, (float)-90.0f, (float)90.0f);
        if (!this.e()) {
            this.a(true);
        }
        rotation.a(f3, f5).g();
        this.a(rotation, n2);
    }

    public boolean a(RaycastHit raycastHit) {
        if (Main.mc.player == null || raycastHit == null) {
            return false;
        }
        if (!Main.mc.player.canInteractWithBlockAt(raycastHit.a(), 0.0)) {
            return false;
        }
        HitResult ItemStackParticleEffect = Main.mc.crosshairTarget;
        if (!(ItemStackParticleEffect instanceof BlockHitResult)) {
            return false;
        }
        BlockHitResult mc7 = (BlockHitResult)ItemStackParticleEffect;
        if (!mc7.getBlockPos().equals((Object)raycastHit.a())) {
            return false;
        }
        if (mc7.getSide() != raycastHit.b()) {
            return false;
        }
        InputUtils.c(0);
        return true;
    }

    public RaycastHit a(BlockPos mc0, BlockPos mc64, Direction mc63, Rotation rotation, int n2, Hand mc8, boolean bl) {
        if (Main.mc.player == null || Main.mc.world == null || Main.mc.interactionManager == null) {
            return null;
        }
        if (mc0 == null) {
            return null;
        }
        if (!this.b(mc0)) {
            return null;
        }
        RaycastHit raycastHit = this.a(mc0, mc64, mc63);
        if (raycastHit == null) {
            return null;
        }
        if (mc64 != null && raycastHit.a().equals((Object)mc64)) {
            return null;
        }
        if (rotation != null) {
            this.a(raycastHit, rotation, n2);
        }
        BlockHitResult mc7 = new BlockHitResult(raycastHit.c(), raycastHit.b(), raycastHit.a(), false);
        this.a(mc7, mc8, bl);
        return raycastHit;
    }

    public RaycastHit a(BlockPos mc0, Rotation rotation) {
        return this.a(mc0, null, null, rotation, 0, Hand.MAIN_HAND, true);
    }

    public ActionResult a(Hand mc8) {
        if (Main.mc.player.getGameMode() == GameMode.SPECTATOR) {
            return ActionResult.PASS;
        }
        if (!BindManager.c()) {
            return ActionResult.FAIL;
        }
        ((MultiPlayerGameModeInvoker)Main.mc.interactionManager).ensureHasSentCarriedItem();
        MutableObject mutableObject = new MutableObject();
        boolean bl = this.d();
        float f2 = bl ? this.n : Main.mc.player.getYaw();
        float f3 = bl ? this.o : Main.mc.player.getPitch();
        ((MultiPlayerGameModeInvoker)Main.mc.interactionManager).startPrediction(Main.mc.world, arg_0 -> h.lambda$interact$2((Hand)mc8, (float)f2, (float)f3, (MutableObject)mutableObject, arg_0));
        return (ActionResult)mutableObject.get();
    }

    private static Packet lambda$interact$2(Hand mc8, float f2, float f3, MutableObject mutableObject, int n2) {
        ItemStack mc33;
        PlayerInteractItemC2SPacket mc67 = new PlayerInteractItemC2SPacket(mc8, n2, f2, f3);
        ItemStack mc68 = Main.mc.player.getStackInHand(mc8);
        if (Main.mc.player.getItemCooldownManager().isCoolingDown(mc68)) {
            mutableObject.setValue((Object)ActionResult.PASS);
            return mc67;
        }
        ActionResult mc60 = mc68.use((World)Main.mc.world, (PlayerEntity)Main.mc.player, mc8);
        if (mc60 instanceof ActionResult.Success) {
            ActionResult.Success mc69 = (ActionResult.Success)mc60;
            mc33 = Objects.requireNonNullElseGet(mc69.getNewHandStack(), () -> h.lambda$interact$1((Hand)mc8));
        } else {
            mc33 = Main.mc.player.getStackInHand(mc8);
        }
        if (mc33 != mc68) {
            Main.mc.player.setStackInHand(mc8, mc33);
        }
        mutableObject.setValue((Object)mc60);
        return mc67;
    }

    private static ItemStack lambda$interact$1(Hand mc8) {
        return Main.mc.player.getStackInHand(mc8);
    }

    private Packet lambda$interactBlock$0(MutableObject mutableObject, Hand mc8, BlockHitResult mc7, int n2) {
        mutableObject.setValue((Object)this.a(Main.mc.player, mc8, mc7));
        return new PlayerInteractBlockC2SPacket(mc8, mc7, n2);
    }
}

