/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

public enum ThemeVariant {
    LIGHT, DARK, VIBRANT;

    private ThemeVariant() {

    }

}

