/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import itz.vrgn1337.groovclient.api.util.bridge.GameRendererMixinBridge;
import itz.vrgn1337.groovclient.api.util.render.GlProgram;
import itz.vrgn1337.groovclient.api.util.render.RenderLayerMode;
import itz.vrgn1337.groovclient.api.util.render.RenderQuad;
import java.nio.FloatBuffer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.model.BakedQuad;
import org.joml.Matrix3x2fc;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL33;

public class ShaderVertexConsumer
implements VertexConsumer {
    private static final int a = 5;
    private static final int b = 20;
    private static final int c = 4096;
    private static final int d = 32;
    private static final ArrayDeque e = new ArrayDeque();
    private static int f = -1;
    private static int g = -1;
    private static boolean h = false;
    private static FloatBuffer i = BufferUtils.createFloatBuffer((int)4096);
    private float[] j = new float[4096];
    private int k = 0;
    private final float[] l = new float[20];
    private int m = 0;
    private boolean n = false;
    private boolean o = false;
    private Matrix4f p;
    private float q;
    private float r;
    private float s;
    private float t;
    private float u;
    private int v = -1;
    private boolean w = false;
    private RenderLayerMode x = RenderLayerMode.BASE;
    private final List<RenderQuad> y = new ArrayList();
    private int z = 0;

    private ShaderVertexConsumer(Matrix4f matrix4f) {
        this.p = new Matrix4f((Matrix4fc)matrix4f);
        if (!h) {
            ShaderVertexConsumer.e();
        }
    }

    public static ShaderVertexConsumer a(Matrix4f matrix4f) {
        ShaderVertexConsumer shaderVertexConsumer;
        if (!h) {
            ShaderVertexConsumer.e();
        }
        if ((shaderVertexConsumer = (ShaderVertexConsumer)e.pollFirst()) != null) {
            shaderVertexConsumer.b(matrix4f);
            return shaderVertexConsumer;
        }
        return new ShaderVertexConsumer(matrix4f);
    }

    public void a() {
        this.k = 0;
        this.m = 0;
        this.n = false;
        this.v = -1;
        this.y.clear();
        this.z = 0;
        this.o = false;
        this.w = false;
        this.x = RenderLayerMode.BASE;
        if (e.size() < 32) {
            e.offerLast(this);
        }
    }

    private void b(Matrix4f matrix4f) {
        this.p.set((Matrix4fc)matrix4f);
        this.k = 0;
        this.m = 0;
        this.n = false;
        this.q = 0.0f;
        this.r = 0.0f;
        this.s = 0.0f;
        this.t = 0.0f;
        this.u = 0.0f;
        this.v = -1;
        this.y.clear();
        this.z = 0;
        this.o = false;
        this.w = false;
        this.x = RenderLayerMode.BASE;
    }

    public Matrix4f b() {
        return this.p;
    }

    public int c() {
        return this.v;
    }

    public void a(boolean bl) {
        this.w = bl;
    }

    public void a(RenderLayerMode renderLayerMode) {
        if (renderLayerMode == this.x) {
            return;
        }
        this.f();
        if (this.v > 0 && this.k > this.z) {
            this.y.add(new RenderQuad(this.z, this.k, this.v, this.x));
            this.z = this.k;
        }
        this.x = renderLayerMode;
    }

    public void a(int n2) {
        if (n2 == this.v) {
            return;
        }
        this.f();
        if (this.v > 0 && this.k > this.z) {
            this.y.add(new RenderQuad(this.z, this.k, this.v, this.x));
            this.z = this.k;
        }
        this.v = n2;
    }

    public boolean d() {
        this.f();
        return this.k > 0;
    }

    private static void e() {
        int n2 = GL30.glGetInteger((int)34229);
        int n3 = GL30.glGetInteger((int)34964);
        f = GL30.glGenVertexArrays();
        g = GL30.glGenBuffers();
        GL30.glBindVertexArray((int)f);
        GL30.glBindBuffer((int)34962, (int)g);
        GL30.glEnableVertexAttribArray((int)0);
        GL30.glVertexAttribPointer((int)0, (int)3, (int)5126, (boolean)false, (int)20, (long)0L);
        GL30.glEnableVertexAttribArray((int)2);
        GL30.glVertexAttribPointer((int)2, (int)2, (int)5126, (boolean)false, (int)20, (long)12L);
        GL30.glBindVertexArray((int)n2);
        GL30.glBindBuffer((int)34962, (int)n3);
        h = true;
    }

    public VertexConsumer vertex(float f2, float f3, float f4) {
        if (this.n) {
            this.b(this.q, this.r, this.s, this.t, this.u);
        }
        this.q = f2;
        this.r = f3;
        this.s = f4;
        this.t = 0.0f;
        this.u = 0.0f;
        this.n = true;
        return this;
    }

    public VertexConsumer color(int n2, int n3, int n4, int n5) {
        return this;
    }

    public VertexConsumer texture(float f2, float f3) {
        this.t = f2;
        this.u = f3;
        return this;
    }

    public VertexConsumer overlay(int n2, int n3) {
        return this;
    }

    public VertexConsumer light(int n2, int n3) {
        return this;
    }

    public VertexConsumer normal(float f2, float f3, float f4) {
        if (this.n) {
            this.b(this.q, this.r, this.s, this.t, this.u);
            this.n = false;
        }
        return this;
    }

    public void vertex(float f2, float f3, float f4, int n2, float f5, float f6, int n3, int n4, float f7, float f8, float f9) {
        if (this.n) {
            this.b(this.q, this.r, this.s, this.t, this.u);
            this.n = false;
        }
        this.q = f2;
        this.r = f3;
        this.s = f4;
        this.t = f5;
        this.u = f6;
        this.b(f2, f3, f4, f5, f6);
    }

    public VertexConsumer color(float f2, float f3, float f4, float f5) {
        return this;
    }

    public VertexConsumer color(int n2) {
        return this;
    }

    public VertexConsumer lineWidth(float f2) {
        return this;
    }

    public VertexConsumer light(int n2) {
        return this;
    }

    public VertexConsumer overlay(int n2) {
        return this;
    }

    public void quad(MatrixStack.Entry mc54, BakedQuad mc43, float f2, float f3, float f4, float f5, int n2, int n3) {
        this.quad(mc54, mc43, f2, f3, f4, f5, n2, n3);
    }

    public void quad(MatrixStack.Entry mc54, BakedQuad mc43, float[] fArray, float f2, float f3, float f4, float f5, int[] nArray, int n2) {
        this.quad(mc54, mc43, fArray, f2, f3, f4, f5, nArray, n2);
    }

    public VertexConsumer vertex(Vector3fc vector3fc) {
        return this;
    }

    public VertexConsumer vertex(MatrixStack.Entry mc54, Vector3f vector3f) {
        return this;
    }

    public VertexConsumer vertex(MatrixStack.Entry mc54, float f2, float f3, float f4) {
        return this;
    }

    public VertexConsumer vertex(Matrix4fc matrix4fc, float f2, float f3, float f4) {
        return this;
    }

    public VertexConsumer vertex(Matrix3x2fc matrix3x2fc, float f2, float f3) {
        return this;
    }

    public VertexConsumer normal(MatrixStack.Entry mc54, float f2, float f3, float f4) {
        return this;
    }

    public VertexConsumer normal(MatrixStack.Entry mc54, Vector3f vector3f) {
        return this;
    }

    private void b(int n2) {
        int n3;
        if (n2 <= this.j.length) {
            return;
        }
        for (n3 = this.j.length; n3 < n2; n3 <<= 1) {
        }
        float[] fArray = new float[n3];
        System.arraycopy(this.j, 0, fArray, 0, this.k);
        this.j = fArray;
    }

    private void a(float f2, float f3, float f4, float f5, float f6) {
        this.b(this.k + 5);
        this.j[this.k++] = f2;
        this.j[this.k++] = f3;
        this.j[this.k++] = f4;
        this.j[this.k++] = f5;
        this.j[this.k++] = f6;
    }

    private void b(float f2, float f3, float f4, float f5, float f6) {
        this.l[this.m++] = f2;
        this.l[this.m++] = f3;
        this.l[this.m++] = f4;
        this.l[this.m++] = f5;
        this.l[this.m++] = f6;
        if (this.m == 20) {
            this.a(this.l[0], this.l[1], this.l[2], this.l[3], this.l[4]);
            this.a(this.l[5], this.l[6], this.l[7], this.l[8], this.l[9]);
            this.a(this.l[10], this.l[11], this.l[12], this.l[13], this.l[14]);
            this.a(this.l[0], this.l[1], this.l[2], this.l[3], this.l[4]);
            this.a(this.l[10], this.l[11], this.l[12], this.l[13], this.l[14]);
            this.a(this.l[15], this.l[16], this.l[17], this.l[18], this.l[19]);
            if (this.w) {
                this.a(this.l[10], this.l[11], this.l[12], this.l[13], this.l[14]);
                this.a(this.l[5], this.l[6], this.l[7], this.l[8], this.l[9]);
                this.a(this.l[0], this.l[1], this.l[2], this.l[3], this.l[4]);
                this.a(this.l[15], this.l[16], this.l[17], this.l[18], this.l[19]);
                this.a(this.l[10], this.l[11], this.l[12], this.l[13], this.l[14]);
                this.a(this.l[0], this.l[1], this.l[2], this.l[3], this.l[4]);
            }
            this.m = 0;
        }
    }

    public void f() {
        if (this.n) {
            this.b(this.q, this.r, this.s, this.t, this.u);
            this.n = false;
        }
        if (this.m != 0 && this.m != 20) {
            this.m = 0;
        }
    }

    private void g() {
        if (this.o) {
            return;
        }
        this.f();
        if (this.k > this.z && this.v > 0) {
            this.y.add(new RenderQuad(this.z, this.k, this.v, this.x));
        } else if (this.y.isEmpty() && this.k > 0) {
            this.y.add(new RenderQuad(0, this.k, Math.max(this.v, 0), this.x));
        }
        this.o = true;
    }

    public void h() {
        this.g();
        if (this.k == 0 || this.y.isEmpty()) {
            return;
        }
        if (i.capacity() < this.k) {
            int n2;
            for (n2 = i.capacity(); n2 < this.k; n2 <<= 1) {
            }
            i = BufferUtils.createFloatBuffer((int)n2);
        }
        i.clear();
        i.put(this.j, 0, this.k);
        i.flip();
        GL30.glBindVertexArray((int)f);
        GL30.glBindBuffer((int)34962, (int)g);
        GL30.glBufferData((int)34962, (FloatBuffer)i, (int)35040);
        GL30.glEnableVertexAttribArray((int)0);
        GL30.glVertexAttribPointer((int)0, (int)3, (int)5126, (boolean)false, (int)20, (long)0L);
        GL30.glDisableVertexAttribArray((int)1);
        GL30.glVertexAttrib4f((int)1, (float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL30.glEnableVertexAttribArray((int)2);
        GL30.glVertexAttribPointer((int)2, (int)2, (int)5126, (boolean)false, (int)20, (long)12L);
    }

    public void a(GlProgram glProgram, Matrix4f matrix4f) {
        int n2;
        if (this.k == 0 || glProgram == null || this.y.isEmpty()) {
            return;
        }
        GL30.glBindVertexArray((int)f);
        float[] fArray = new float[16];
        this.p.get(fArray);
        float[] fArray2 = new float[16];
        (matrix4f != null ? matrix4f : GameRendererMixinBridge.getModelView()).get(fArray2);
        int n3 = glProgram.a("ModelViewMat");
        if (n3 >= 0) {
            GL30.glUniformMatrix4fv((int)n3, (boolean)false, (float[])fArray2);
        }
        if ((n2 = glProgram.a("ProjMat")) >= 0) {
            GL30.glUniformMatrix4fv((int)n2, (boolean)false, (float[])fArray);
        }
        int n4 = glProgram.a("entityTexture");
        int n5 = GL30.glGetInteger((int)35097);
        GL33.glBindSampler((int)0, (int)0);
        for (RenderQuad renderQuad : this.y) {
            int n6;
            int n7;
            if (renderQuad.c > 0) {
                GL30.glActiveTexture((int)33984);
                GL30.glBindTexture((int)3553, (int)renderQuad.c);
                GL30.glTexParameteri((int)3553, (int)10241, (int)9728);
                GL30.glTexParameteri((int)3553, (int)10240, (int)9728);
                if (n4 >= 0) {
                    GL30.glUniform1i((int)n4, (int)0);
                }
                n7 = renderQuad.a / 5;
                n6 = (renderQuad.b - renderQuad.a) / 5;
                if (n6 <= 0) continue;
                GL30.glDrawArrays((int)4, (int)n7, (int)n6);
                continue;
            }
            n7 = renderQuad.a / 5;
            n6 = (renderQuad.b - renderQuad.a) / 5;
            if (n6 <= 0) continue;
            GL30.glDrawArrays((int)4, (int)n7, (int)n6);
        }
        GL33.glBindSampler((int)0, (int)n5);
    }

    public void a(GlProgram glProgram, Matrix4f matrix4f, RenderLayerMode renderLayerMode) {
        int n2;
        if (this.k == 0 || glProgram == null || this.y.isEmpty()) {
            return;
        }
        GL30.glBindVertexArray((int)f);
        float[] fArray = new float[16];
        this.p.get(fArray);
        float[] fArray2 = new float[16];
        (matrix4f != null ? matrix4f : GameRendererMixinBridge.getModelView()).get(fArray2);
        int n3 = glProgram.a("ModelViewMat");
        if (n3 >= 0) {
            GL30.glUniformMatrix4fv((int)n3, (boolean)false, (float[])fArray2);
        }
        if ((n2 = glProgram.a("ProjMat")) >= 0) {
            GL30.glUniformMatrix4fv((int)n2, (boolean)false, (float[])fArray);
        }
        int n4 = glProgram.a("entityTexture");
        int n5 = GL30.glGetInteger((int)35097);
        GL33.glBindSampler((int)0, (int)0);
        for (RenderQuad renderQuad : this.y) {
            int n6;
            int n7;
            if (renderQuad.d != renderLayerMode) continue;
            if (renderQuad.c > 0) {
                GL30.glActiveTexture((int)33984);
                GL30.glBindTexture((int)3553, (int)renderQuad.c);
                GL30.glTexParameteri((int)3553, (int)10241, (int)9728);
                GL30.glTexParameteri((int)3553, (int)10240, (int)9728);
                if (n4 >= 0) {
                    GL30.glUniform1i((int)n4, (int)0);
                }
                n7 = renderQuad.a / 5;
                n6 = (renderQuad.b - renderQuad.a) / 5;
                if (n6 <= 0) continue;
                GL30.glDrawArrays((int)4, (int)n7, (int)n6);
                continue;
            }
            n7 = renderQuad.a / 5;
            n6 = (renderQuad.b - renderQuad.a) / 5;
            if (n6 <= 0) continue;
            GL30.glDrawArrays((int)4, (int)n7, (int)n6);
        }
        GL33.glBindSampler((int)0, (int)n5);
    }

    public void a(GlProgram glProgram) {
        this.h();
        this.a(glProgram, null);
    }

    public static void i() {
        if (f != -1) {
            GL30.glDeleteVertexArrays((int)f);
        }
        if (g != -1) {
            GL30.glDeleteBuffers((int)g);
        }
        h = false;
        f = -1;
        g = -1;
        e.clear();
    }
}

