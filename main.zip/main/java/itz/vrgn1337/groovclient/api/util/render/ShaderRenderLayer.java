/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import com.mojang.blaze3d.textures.GpuTexture;
import itz.vrgn1337.groovclient.api.util.render.RenderLayerMode;
import itz.vrgn1337.groovclient.api.util.render.ShaderVertexConsumer;
import java.nio.ByteBuffer;
import java.util.List;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.client.render.model.BlockStateModel;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.command.ModelCommandRenderer;
import net.minecraft.client.render.command.RenderCommandQueue;
import net.minecraft.client.render.block.MovingBlockRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import net.minecraft.block.BlockState;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.model.Model;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.text.OrderedText;
import net.minecraft.client.util.math.Vector2f;
import net.minecraft.client.render.entity.model.ShieldEntityModel;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.item.ItemDisplayContext;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;

public class ShaderRenderLayer
implements OrderedRenderCommandQueue {
    private final OrderedRenderCommandQueue a;
    private final ShaderVertexConsumer b;
    private int c = -1;
    private boolean d = false;
    private int e = -1;
    private boolean f = false;
    private boolean g = false;
    private static int h = -1;

    public static int a() {
        if (h <= 0) {
            int n2 = GL11.glGetInteger((int)32873);
            h = GL11.glGenTextures();
            GL11.glBindTexture((int)3553, (int)h);
            ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4);
            byteBuffer.put((byte)-1).put((byte)-1).put((byte)-1).put((byte)-1).flip();
            GL11.glTexImage2D((int)3553, (int)0, (int)32856, (int)1, (int)1, (int)0, (int)6408, (int)5121, (ByteBuffer)byteBuffer);
            GL11.glTexParameteri((int)3553, (int)10241, (int)9728);
            GL11.glTexParameteri((int)3553, (int)10240, (int)9728);
            GL11.glTexParameteri((int)3553, (int)10242, (int)33071);
            GL11.glTexParameteri((int)3553, (int)10243, (int)33071);
            GL11.glBindTexture((int)3553, (int)n2);
        }
        return h;
    }

    private static boolean a(String string, String string2) {
        if (string != null && (string.contains("shield") || string.contains("banner"))) {
            return true;
        }
        return string2 != null && (string2.contains("shield") || string2.contains("banner"));
    }

    private static boolean a(Object object) {
        if (object == null) {
            return false;
        }
        if (object instanceof ShieldEntityModel) {
            return true;
        }
        for (Class<?> clazz = object.getClass(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
            String string = clazz.getSimpleName().toLowerCase();
            String string2 = clazz.getName().toLowerCase();
            if (!string.contains("shield") && !string2.contains("shield") && !string.contains("bannerflag") && !string2.contains("bannerflag")) continue;
            return true;
        }
        return false;
    }

    private static boolean b(Object object) {
        if (object == null) {
            return false;
        }
        String string = object.getClass().getSimpleName().toLowerCase();
        return string.contains("shield") || string.contains("banner");
    }

    public ShaderRenderLayer(OrderedRenderCommandQueue mc11, ShaderVertexConsumer shaderVertexConsumer) {
        this.a = mc11;
        this.b = shaderVertexConsumer;
    }

    public ShaderRenderLayer a(int n2) {
        this.e = n2;
        return this;
    }

    public ShaderRenderLayer a(boolean bl) {
        this.g = bl;
        return this;
    }

    public ShaderVertexConsumer b() {
        return this.b;
    }

    public RenderCommandQueue getBatchingQueue(int n2) {
        return this;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void submitModel(Model mc12, Object object, MatrixStack mc13, RenderLayer mc39, int n2, int n3, int n4, @Nullable Sprite EquipmentDropChances, int n5, @Nullable ModelCommandRenderer.CrumblingOverlayCommand mc40) {
        this.a.submitModel(mc12, object, mc13, mc39, n2, n3, n4, EquipmentDropChances, n5, mc40);
        try {
            boolean bl;
            boolean bl2;
            String string = mc39 != null ? mc39.toString().toLowerCase() : "";
            String string2 = ShaderRenderLayer.b(string);
            String string3 = mc12.getClass().getSimpleName().toLowerCase();
            boolean bl3 = string2 != null && (string2.contains("glint") || string2.contains("enchant"));
            boolean bl4 = bl2 = bl3 || string.contains("armor_entity_glint") || string.contains("glint") || string.contains("foil") || string.contains("enchant");
            if (bl2) {
                return;
            }
            boolean bl5 = string.contains("elytra") || string3.contains("elytra");
            boolean bl6 = string.contains("cape") || string3.contains("cape") || string2 != null && string2.contains("cape");
            boolean bl7 = ShaderRenderLayer.a(mc12) || ShaderRenderLayer.b(object) || ShaderRenderLayer.a(string, string2);
            boolean bl8 = string2 != null && string2.contains("trims/");
            boolean bl9 = string2 != null && string2.contains("armor/");
            boolean bl10 = bl = string.contains("armor_cutout") || bl9;
            if (!bl7) {
                this.f = false;
            }
            int n6 = ShaderRenderLayer.a(string2);
            if (bl7) {
                this.f = true;
                this.b.a(ShaderRenderLayer.a());
                this.b.a(RenderLayerMode.FEATURE);
                try {
                    try {
                        mc12.setAngles(object);
                    }
                    catch (Exception exception) {
                        try {
                            mc12.getRootPart().traverse().forEach((arg_0) -> ((ShaderRenderLayer)this).lambda$submitModel$0(arg_0));
                        }
                        catch (Exception exception2) {
                            // empty catch block
                        }
                    }
                    try {
                        mc12.getRootPart().traverse().forEach((arg_0) -> ((ShaderRenderLayer)this).lambda$submitModel$1(arg_0));
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                    mc12.render(mc13, (VertexConsumer)this.b, n2, n3, n4);
                }
                finally {
                    this.b.a(RenderLayerMode.BASE);
                }
                return;
            }
            if (bl8) {
                this.b.a(ShaderRenderLayer.a());
                ShaderRenderLayer.a(mc12, object);
                mc12.render(mc13, (VertexConsumer)this.b, n2, n3, n4);
                return;
            }
            if (bl) {
                if (n6 > 0) {
                    this.c = n6;
                    this.b.a(n6);
                }
                ShaderRenderLayer.a(mc12, object);
                mc12.render(mc13, (VertexConsumer)this.b, n2, n3, n4);
                return;
            }
            if (bl5) {
                if (n6 > 0) {
                    this.b.a(n6);
                }
                this.b.a(true);
                ShaderRenderLayer.a(mc12, object);
                mc12.render(mc13, (VertexConsumer)this.b, n2, n3, n4);
                this.b.a(false);
                return;
            }
            if (bl6) {
                if (n6 > 0) {
                    this.b.a(n6);
                }
                ShaderRenderLayer.a(mc12, object);
                mc12.render(mc13, (VertexConsumer)this.b, n2, n3, n4);
                return;
            }
            if (this.g) {
                if (n6 > 0) {
                    this.b.a(n6);
                }
                ShaderRenderLayer.a(mc12, object);
                mc12.render(mc13, (VertexConsumer)this.b, n2, n3, n4);
            } else if (!this.d) {
                int n7;
                int n8 = n7 = this.e > 0 ? this.e : n6;
                if (n7 > 0) {
                    this.b.a(n7);
                }
                ShaderRenderLayer.a(mc12, object);
                mc12.render(mc13, (VertexConsumer)this.b, n2, n3, n4);
                this.d = true;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void submitModelPart(ModelPart mc41, MatrixStack mc13, RenderLayer mc39, int n2, int n3, @Nullable Sprite EquipmentDropChances, boolean bl, boolean bl2, int n4, @Nullable ModelCommandRenderer.CrumblingOverlayCommand mc40, int n5) {
        this.a.submitModelPart(mc41, mc13, mc39, n2, n3, EquipmentDropChances, bl, bl2, n4, mc40, n5);
        try {
            String string = mc39 != null ? mc39.toString().toLowerCase() : "";
            String string2 = ShaderRenderLayer.b(string);
            if (string2 != null && (string2.contains("glint") || string2.contains("enchant"))) {
                return;
            }
            if (string.contains("glint") || string.contains("foil") || string.contains("enchant")) {
                return;
            }
            boolean bl3 = ShaderRenderLayer.a(string, string2) || this.f;
            try {
                if (bl3) {
                    this.b.a(ShaderRenderLayer.a());
                    this.b.a(RenderLayerMode.FEATURE);
                } else {
                    int n6 = ShaderRenderLayer.a(string2);
                    if (n6 > 0) {
                        this.b.a(n6);
                    }
                }
                mc41.render(mc13, (VertexConsumer)this.b, n2, n3, n4);
            }
            finally {
                if (bl3) {
                    this.b.a(RenderLayerMode.BASE);
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void submitItem(MatrixStack mc13, ItemDisplayContext DeathMessageType, int n2, int n3, int n4, int[] nArray, List list, RenderLayer mc39, ItemRenderState.Glint mc42) {
        this.a.submitItem(mc13, DeathMessageType, n2, n3, n4, nArray, list, mc39, mc42);
        if (list == null || list.isEmpty()) {
            return;
        }
        try {
            String string;
            String string2 = string = mc39 != null ? mc39.toString().toLowerCase() : "";
            if (string.contains("glint") || string.contains("foil") || string.contains("enchant")) {
                return;
            }
            String string3 = ShaderRenderLayer.b(string);
            if (string3 != null && (string3.contains("glint") || string3.contains("enchant"))) {
                return;
            }
            boolean bl = ShaderRenderLayer.a(string, string3) || this.f;
            try {
                if (bl) {
                    this.b.a(ShaderRenderLayer.a());
                    this.b.a(RenderLayerMode.FEATURE);
                } else {
                    int n5 = ShaderRenderLayer.a(string3);
                    if (n5 <= 0) {
                        n5 = ShaderRenderLayer.c();
                    }
                    if (n5 > 0) {
                        this.b.a(n5);
                    }
                }
                Matrix4f matrix4f = new Matrix4f((Matrix4fc)mc13.peek().getPositionMatrix());
                for (BakedQuad mc43 : list) {
                    this.a(matrix4f, mc43);
                }
            }
            finally {
                if (bl) {
                    this.b.a(RenderLayerMode.BASE);
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void a(Matrix4f matrix4f, BakedQuad mc43) {
        Vector3f vector3f = new Vector3f();
        float[] fArray = new float[4];
        float[] fArray2 = new float[4];
        float[] fArray3 = new float[4];
        float[] fArray4 = new float[4];
        float[] fArray5 = new float[4];
        for (int j = 0; j < 4; ++j) {
            matrix4f.transformPosition(mc43.getPosition(j), vector3f);
            fArray[j] = vector3f.x;
            fArray2[j] = vector3f.y;
            fArray3[j] = vector3f.z;
            long l2 = mc43.getTexcoords(j);
            fArray4[j] = Vector2f.getX((long)l2);
            fArray5[j] = Vector2f.getY((long)l2);
        }
        this.b.vertex(fArray[0], fArray2[0], fArray3[0]).texture(fArray4[0], fArray5[0]).normal(0.0f, 1.0f, 0.0f);
        this.b.vertex(fArray[1], fArray2[1], fArray3[1]).texture(fArray4[1], fArray5[1]).normal(0.0f, 1.0f, 0.0f);
        this.b.vertex(fArray[2], fArray2[2], fArray3[2]).texture(fArray4[2], fArray5[2]).normal(0.0f, 1.0f, 0.0f);
        this.b.vertex(fArray[3], fArray2[3], fArray3[3]).texture(fArray4[3], fArray5[3]).normal(0.0f, 1.0f, 0.0f);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void submitCustom(MatrixStack mc13, RenderLayer mc39, OrderedRenderCommandQueue.Custom mc44) {
        String string;
        this.a.submitCustom(mc13, mc39, mc44);
        String string2 = string = mc39 != null ? mc39.toString().toLowerCase() : "";
        if (string.contains("glint") || string.contains("foil") || string.contains("enchant")) {
            return;
        }
        String string3 = ShaderRenderLayer.b(string);
        boolean bl = ShaderRenderLayer.a(string, string3) || this.f;
        try {
            try {
                if (bl) {
                    this.b.a(ShaderRenderLayer.a());
                    this.b.a(RenderLayerMode.FEATURE);
                }
                mc44.render(mc13.peek(), (VertexConsumer)this.b);
            }
            finally {
                if (bl) {
                    this.b.a(RenderLayerMode.BASE);
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public void submitShadowPieces(MatrixStack mc13, float f2, List list) {
        this.a.submitShadowPieces(mc13, f2, list);
    }

    public void submitLabel(MatrixStack mc13, @Nullable Vec3d VanillaChestLootTableGenerator, int n2, Text mc45, boolean bl, int n3, double d2, CameraRenderState mc46) {
        this.a.submitLabel(mc13, VanillaChestLootTableGenerator, n2, mc45, bl, n3, d2, mc46);
    }

    public void submitText(MatrixStack mc13, float f2, float f3, OrderedText mc47, boolean bl, TextRenderer.TextLayerType mc48, int n2, int n3, int n4, int n5) {
        this.a.submitText(mc13, f2, f3, mc47, bl, mc48, n2, n3, n4, n5);
    }

    public void submitFire(MatrixStack mc13, EntityRenderState mc49, Quaternionf quaternionf) {
        this.a.submitFire(mc13, mc49, quaternionf);
    }

    public void submitLeash(MatrixStack mc13, EntityRenderState.LeashData mc50) {
        this.a.submitLeash(mc13, mc50);
    }

    public void submitBlock(MatrixStack mc13, BlockState mc1, int n2, int n3, int n4) {
        this.a.submitBlock(mc13, mc1, n2, n3, n4);
    }

    public void submitMovingBlock(MatrixStack mc13, MovingBlockRenderState mc51) {
        this.a.submitMovingBlock(mc13, mc51);
    }

    public void submitBlockStateModel(MatrixStack mc13, RenderLayer mc39, BlockStateModel mc52, float f2, float f3, float f4, int n2, int n3, int n4) {
        this.a.submitBlockStateModel(mc13, mc39, mc52, f2, f3, f4, n2, n3, n4);
    }

    public void submitCustom(OrderedRenderCommandQueue.LayeredCustom mc53) {
        this.a.submitCustom(mc53);
    }

    private static void a(Model mc12, Object object) {
        try {
            mc12.setAngles(object);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static int a(String string) {
        return ShaderRenderLayer.c(string);
    }

    private static String b(String string) {
        if (string == null || string.isEmpty()) {
            return null;
        }
        int n2 = string.indexOf("location=");
        if (n2 < 0) {
            return null;
        }
        int n3 = string.length();
        int n4 = string.indexOf(93, n2 += "location=".length());
        int n5 = string.indexOf(44, n2);
        if (n4 > n2 && n4 < n3) {
            n3 = n4;
        }
        if (n5 > n2 && n5 < n3) {
            n3 = n5;
        }
        if (n3 <= n2) {
            return null;
        }
        return string.substring(n2, n3).trim();
    }

    private static int c() {
        try {
            TextureManager BabyModelPair = MinecraftClient.getInstance().getTextureManager();
            for (String string : new String[]{"textures/atlas/blocks.png", "textures/atlas/blocks"}) {
                try {
                    GlTexture mc18;
                    GpuTexture gpuTexture;
                    AbstractTexture ItemModelManager = BabyModelPair.getTexture(Identifier.ofVanilla((String)string));
                    if (ItemModelManager == null || !((gpuTexture = ItemModelManager.getGlTexture()) instanceof GlTexture) || (mc18 = (GlTexture)gpuTexture).getGlId() <= 0) continue;
                    return mc18.getGlId();
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return -1;
    }

    private static int c(String string) {
        if (string == null) {
            return -1;
        }
        try {
            GlTexture mc18;
            int n2;
            GpuTexture gpuTexture;
            Identifier mc19 = Identifier.of((String)string);
            AbstractTexture ItemModelManager = MinecraftClient.getInstance().getTextureManager().getTexture(mc19);
            if (ItemModelManager != null && (gpuTexture = ItemModelManager.getGlTexture()) instanceof GlTexture && (n2 = (mc18 = (GlTexture)gpuTexture).getGlId()) > 0) {
                return n2;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return -1;
    }

    private static void lambda$submitModel$1(ModelPart mc41) {
        mc41.visible = true;
    }

    private static void lambda$submitModel$0(ModelPart mc41) {
        mc41.visible = true;
    }
}

