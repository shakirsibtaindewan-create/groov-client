/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import itz.vrgn1337.groovclient.entrypoint.Main;

public class RenderScale {
    private static int a = 0;

    public static void a(int n2) {
        a = Math.max(0, Math.min(5, n2));
    }

    public static int a() {
        return a;
    }

    private static float b() {
        if (a > 0) {
            return a;
        }
        return Main.mc.getWindow().getScaleFactor();
    }

    public static float c() {
        if (a > 0) {
            return (float)RenderScale.e() / (float)a;
        }
        return Main.mc.getWindow().getScaledWidth();
    }

    public static float d() {
        if (a > 0) {
            return (float)RenderScale.f() / (float)a;
        }
        return Main.mc.getWindow().getScaledHeight();
    }

    public static int e() {
        return Main.mc.getWindow().getWidth();
    }

    public static int f() {
        return Main.mc.getWindow().getHeight();
    }

    public static float g() {
        return RenderScale.b();
    }

    public static float h() {
        return RenderScale.b() / (float)Main.mc.getWindow().getScaleFactor();
    }

    public static float i() {
        return RenderScale.b();
    }

    public static void a(float f2) {
    }

    public static double j() {
        return Main.mc.mouse.getX() / (double)RenderScale.b();
    }

    public static double k() {
        return Main.mc.mouse.getY() / (double)RenderScale.b();
    }

    public static int l() {
        return (int)RenderScale.j();
    }

    public static int m() {
        return (int)RenderScale.k();
    }

    public static boolean a(float f2, float f3, float f4, float f5) {
        double d2 = RenderScale.j();
        double d3 = RenderScale.k();
        return d2 >= (double)f2 && d2 <= (double)(f2 + f4) && d3 >= (double)f3 && d3 <= (double)(f3 + f5);
    }

    public static boolean b(float f2, float f3, float f4, float f5) {
        double d2 = RenderScale.j();
        double d3 = RenderScale.k();
        return d2 >= (double)f2 && d2 <= (double)f4 && d3 >= (double)f3 && d3 <= (double)f5;
    }

    public static boolean a(float[] fArray) {
        if (fArray == null || fArray.length < 4) {
            return false;
        }
        return RenderScale.b(fArray[0], fArray[1], fArray[2], fArray[3]);
    }

    public static float b(float f2) {
        return (RenderScale.c() - f2) / 2.0f;
    }

    public static float c(float f2) {
        return (RenderScale.d() - f2) / 2.0f;
    }

    public static float d(float f2) {
        return RenderScale.c() - f2;
    }

    public static float e(float f2) {
        return RenderScale.d() - f2;
    }

    public static float f(float f2) {
        return RenderScale.c() * f2 / 100.0f;
    }

    public static float g(float f2) {
        return RenderScale.d() * f2 / 100.0f;
    }
}

