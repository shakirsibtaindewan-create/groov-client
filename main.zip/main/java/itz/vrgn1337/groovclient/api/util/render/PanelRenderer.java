/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GlassPanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.GlassStyle;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.api.util.render.ThemeVariant;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.font.MsdfFont;
import java.awt.Color;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;

public final class PanelRenderer {
    private static final boolean[] a = new boolean[8];
    private static final boolean[] b = new boolean[8];
    private static final double[] c = new double[8];
    private static final double[] d = new double[8];
    private static final Runnable[] e = new Runnable[8];
    private static long f = -1L;
    private static long g = -1L;
    private static boolean h;
    private static float i;
    private static float j;
    private static float k;
    private static float l;
    private static float m;
    private static float n;
    private static float o;
    private static float p;
    private static float q;
    private static float r;
    private static float s;
    private static float t;
    private static float u;
    private static float v;
    private static float w;
    private static float x;
    private static float y;
    private static float z;
    private static float A;
    private static Color B;
    private static boolean C;
    private final float D;
    private final float E;
    private final float F;
    private final float G;
    private MatrixStack H;
    private Color I = Color.WHITE;
    private Color J = Color.WHITE;
    private Color K = Color.WHITE;
    private Color L = Color.WHITE;
    private float M;
    private float N;
    private float O;
    private float P;
    private boolean Q;
    private float R = 12.0f;
    private float S = 0.8f;
    private boolean T;
    private GlassStyle U;
    private boolean V;
    private float W = 1.0f;
    private float X = 3.0f;
    private float Y = 4.0f;
    private float Z = 0.12f;
    private int aa = 5;
    private int ab = 0;
    private float ac = 6.0f;
    private float ad = 0.08f;
    private float ae = 0.22f;
    private boolean af;
    private float ag = 3.2f;
    private Color ah = new Color(255, 255, 255, 220);
    private float ai = 0.22f;
    private StringConstant aj;
    private boolean ak;
    private boolean al;
    private Color am;
    private Color an = Color.WHITE;
    private float ao = 7.0f;
    private float ap;
    private float aq;
    private float ar;
    private float as;
    private float at;
    private float au;
    private boolean av;

    public PanelRenderer(MatrixStack mc13, float f2, float f3, float f4, float f5) {
        this.H = mc13;
        this.D = f2;
        this.E = f3;
        this.F = f4;
        this.G = f5;
    }

    public PanelRenderer a(MatrixStack mc13) {
        this.H = mc13;
        return this;
    }

    public PanelRenderer a(Color color) {
        this.I = color;
        this.J = color;
        this.K = color;
        this.L = color;
        return this;
    }

    public PanelRenderer a(Color color, Color color2, Color color3, Color color4) {
        this.I = color;
        this.J = color2;
        this.K = color3;
        this.L = color4;
        return this;
    }

    public PanelRenderer a() {
        return this.a(12.0f);
    }

    public PanelRenderer b() {
        return this.a(6.0f);
    }

    public PanelRenderer a(float f2) {
        return this.a(f2, f2, f2, f2);
    }

    public PanelRenderer a(float f2, float f3, float f4, float f5) {
        this.M = f2;
        this.N = f3;
        this.O = f4;
        this.P = f5;
        return this;
    }

    public PanelRenderer c() {
        this.Q = true;
        return this;
    }

    public PanelRenderer a(float f2, float f3) {
        this.Q = true;
        this.R = f2;
        this.S = f3;
        return this;
    }

    public PanelRenderer d() {
        return this.a(GlassStyle.getInstance());
    }

    public PanelRenderer a(ThemeVariant themeVariant) {
        return this.a(GlassStyle.getInstance().a(themeVariant));
    }

    public PanelRenderer a(GlassStyle glassStyle) {
        this.T = true;
        this.U = glassStyle;
        return this;
    }

    public PanelRenderer e() {
        this.V = true;
        this.ab = 0;
        return this;
    }

    public PanelRenderer b(float f2) {
        this.V = true;
        this.W = f2;
        this.ab = 0;
        return this;
    }

    public PanelRenderer b(float f2, float f3) {
        this.V = true;
        this.W = f2;
        this.X = f3;
        this.ab = 0;
        return this;
    }

    public PanelRenderer b(float f2, float f3, float f4, float f5) {
        this.V = true;
        this.W = f2;
        this.X = f3;
        this.Y = f4;
        this.Z = f5;
        this.ab = 0;
        return this;
    }

    public PanelRenderer a(float f2, float f3, float f4, float f5, int n2) {
        this.V = true;
        this.W = f2;
        this.X = f3;
        this.Y = f4;
        this.Z = f5;
        this.aa = n2;
        this.ab = 0;
        return this;
    }

    public PanelRenderer f() {
        this.V = true;
        this.ab = 1;
        return this;
    }

    public PanelRenderer c(float f2, float f3) {
        this.V = true;
        this.ab = 1;
        this.W = f2;
        this.ac = f3;
        return this;
    }

    public PanelRenderer c(float f2, float f3, float f4, float f5) {
        this.V = true;
        this.ab = 1;
        this.W = f2;
        this.ac = f3;
        this.ad = f4;
        this.ae = f5;
        return this;
    }

    public PanelRenderer a(float f2, float f3, float f4, float f5, int n2, float f6, float f7, float f8) {
        this.V = true;
        this.ab = 1;
        this.W = f2;
        this.X = f3;
        this.Y = f4;
        this.Z = f5;
        this.aa = n2;
        this.ac = f6;
        this.ad = f7;
        this.ae = f8;
        return this;
    }

    public PanelRenderer g() {
        this.af = true;
        return this;
    }

    public PanelRenderer c(float f2) {
        this.af = true;
        this.ag = f2;
        return this;
    }

    public PanelRenderer a(float f2, Color color) {
        this.af = true;
        this.ag = f2;
        if (color != null) {
            this.ah = color;
        }
        return this;
    }

    public PanelRenderer a(float f2, Color color, float f3) {
        this.af = true;
        this.ag = f2;
        if (color != null) {
            this.ah = color;
        }
        this.ai = f3;
        return this;
    }

    public PanelRenderer a(StringConstant stringConstant) {
        this.aj = stringConstant;
        return this;
    }

    public PanelRenderer a(StringConstant stringConstant, float f2) {
        this.aj = stringConstant;
        this.ao = f2;
        return this;
    }

    public PanelRenderer a(StringConstant stringConstant, Color color, float f2, boolean bl) {
        this.aj = stringConstant;
        this.an = color;
        this.ao = f2;
        this.ak = bl;
        return this;
    }

    public PanelRenderer a(StringConstant stringConstant, Color color, float f2, boolean bl, boolean bl2) {
        this.aj = stringConstant;
        this.an = color;
        this.ao = f2;
        this.ak = bl;
        this.al = bl2;
        return this;
    }

    public PanelRenderer a(StringConstant stringConstant, Color color, float f2, boolean bl, boolean bl2, Color color2) {
        this.aj = stringConstant;
        this.an = color;
        this.ao = f2;
        this.ak = bl;
        this.al = bl2;
        this.am = color2;
        return this;
    }

    public PanelRenderer h() {
        this.ak = true;
        return this;
    }

    public PanelRenderer d(float f2, float f3) {
        this.ap = f2;
        this.aq = f3;
        return this;
    }

    public PanelRenderer i() {
        if (this.aj != null && this.H != null) {
            float f2;
            MsdfFont msdfFont = FontManager.a();
            float f3 = f2 = this.al ? 0.32f : 0.0f;
            if (this.ak) {
                msdfFont.b(this.H, this.aj, this.D + this.ap, this.E + this.aq, this.ao, this.an, f2, this.am);
            } else {
                msdfFont.a(this.H, this.aj, this.D + this.ap, this.E + this.aq, this.ao, this.an, f2, this.am);
            }
        }
        return this;
    }

    public PanelRenderer j() {
        long l2 = System.currentTimeMillis();
        if (l2 != g) {
            g = l2;
            h = false;
        }
        float f2 = Math.min(this.D, this.D + this.F);
        float f3 = Math.min(this.E, this.E + this.G);
        float f4 = Math.max(this.D, this.D + this.F);
        float f5 = Math.max(this.E, this.E + this.G);
        if (this.T) {
            GlassPanelRenderer.a(this.H, this.D, this.E, this.F, this.G, this.M, this.N, this.O, this.P, this.U);
        } else {
            if (this.Q) {
                GuiRenderer.a().a(this.H, this.D, this.E, this.F, this.G, this.M, this.N, this.O, this.P, this.R, this.S);
            }
            if (this.V) {
                GuiRenderer.a(this.H, this.D, this.E, this.F, this.G, this.M, this.N, this.O, this.P, this.I, this.J, this.K, this.L, this.W, this.X, this.Y, this.Z, this.aa, this.ab, this.ac, this.ad, this.ae);
            } else {
                GuiRenderer.a(this.H, this.D, this.E, this.F, this.G, this.M, this.N, this.O, this.P, this.I, this.J, this.K, this.L);
            }
        }
        if (this.af) {
            boolean bl = RenderScale.b(f2, f3, f4, f5);
            if (bl) {
                q = this.D;
                r = this.E;
                s = this.F;
                t = this.G;
                u = this.M;
                v = this.N;
                w = this.O;
                x = this.P;
                z = 1.0f;
                A = this.ag;
                Color color = B = this.ah != null ? this.ah : Color.WHITE;
                if (!C) {
                    i = q;
                    j = r;
                    k = s;
                    l = t;
                    m = u;
                    n = v;
                    o = w;
                    p = x;
                    y = 0.0f;
                    C = true;
                }
            } else if (!h) {
                z = 0.0f;
            }
            if (C && (!h || bl)) {
                float f6 = 0.28f;
                i = GuiRenderer.a(i, q, f6);
                j = GuiRenderer.a(j, r, f6);
                k = GuiRenderer.a(k, s, f6);
                l = GuiRenderer.a(l, t, f6);
                m = GuiRenderer.a(m, u, f6);
                n = GuiRenderer.a(n, v, f6);
                o = GuiRenderer.a(o, w, f6);
                p = GuiRenderer.a(p, x, f6);
                y = GuiRenderer.a(y, z, GuiRenderer.b(this.ai, 0.0f, 1.0f));
                Color color = new Color(0, 0, 0, 0);
                GuiRenderer.a(this.H, i, j, k, l, m, n, o, p, color, color, color, color, A, B, y);
                h = true;
            }
        }
        this.ar = f2;
        this.as = f3;
        this.at = f4;
        this.au = f5;
        this.av = true;
        return this;
    }

    public PanelRenderer a(int n2, Runnable runnable) {
        int n3;
        if (!this.av || runnable == null || n2 < 0 || n2 >= a.length) {
            return this;
        }
        long l2 = System.currentTimeMillis();
        if (l2 != f) {
            f = l2;
            for (n3 = 0; n3 < e.length; ++n3) {
                Runnable runnable2 = e[n3];
                if (runnable2 == null) continue;
                PanelRenderer.e[n3] = null;
                PanelRenderer.a[n3] = true;
                runnable2.run();
            }
        }
        if (!Main.mc.isWindowFocused() || Main.mc.currentScreen == null) {
            PanelRenderer.a[n2] = false;
            PanelRenderer.b[n2] = false;
            PanelRenderer.e[n2] = null;
            return this;
        }
        int n4 = n3 = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)n2) == 1 ? 1 : 0;
        if (n3 != 0 && !b[n2]) {
            PanelRenderer.c[n2] = RenderScale.j();
            PanelRenderer.d[n2] = RenderScale.k();
        }
        PanelRenderer.b[n2] = n3;
        if (n3 == 0) {
            PanelRenderer.a[n2] = false;
            PanelRenderer.e[n2] = null;
            return this;
        }
        if (a[n2]) {
            return this;
        }
        double d2 = c[n2];
        double d3 = d[n2];
        if (d2 < (double)this.ar || d2 > (double)this.at || d3 < (double)this.as || d3 > (double)this.au) {
            return this;
        }
        PanelRenderer.e[n2] = runnable;
        return this;
    }

    static {
        A = 3.2f;
        B = new Color(255, 255, 255, 220);
    }
}

