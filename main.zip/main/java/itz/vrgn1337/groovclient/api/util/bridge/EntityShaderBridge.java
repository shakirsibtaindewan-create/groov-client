/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.bridge;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.vertex.VertexFormat;
import itz.vrgn1337.groovclient.api.util.bridge.GameRendererMixinBridge;
import itz.vrgn1337.groovclient.api.util.render.GLStateSnapshot;
import itz.vrgn1337.groovclient.api.util.render.GlProgram;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.api.util.render.ShaderRenderLayer;
import itz.vrgn1337.groovclient.api.util.render.ShaderVertexConsumer;
import itz.vrgn1337.groovclient.api.util.render.Shaders;
import itz.vrgn1337.groovclient.mixin.accessor.GameRendererAccessor;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.render.BuiltBuffer;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import itz.vrgn1337.groovclient.api.util.bridge.EntityShaderBridge;

public final class EntityShaderBridge {
    private static volatile EntityShaderBridge.EntityFilter filter = null;
    private static volatile EntityShaderBridge.ShaderMode mode = EntityShaderBridge.ShaderMode.SOLID;
    private static volatile EntityShaderBridge.BlendMode blendMode = EntityShaderBridge.BlendMode.ALPHA;
    private static volatile Color outlineColor = Color.WHITE;
    private static volatile float outlineWidth = 2.0f;
    private static volatile boolean fillEnabled = false;
    private static volatile Color fillColor = new Color(255, 255, 255, 128);
    private static volatile float fillAlpha = 0.3f;
    private static volatile float chromaSpeed = 1.0f;
    private static volatile float chromaScale = 0.5f;
    private static volatile boolean gradientEnabled = false;
    private static volatile Color gradientColor2 = Color.WHITE;
    private static volatile Color gradientColor3 = Color.WHITE;
    private static volatile Color gradientColor4 = Color.WHITE;
    private static volatile float outerGlow = 0.0f;
    private static volatile float innerGlow = 0.0f;
    private static volatile boolean glowSparkle = false;
    private static volatile boolean shadeItemEntities = false;
    private static volatile boolean shadeHeldItems = false;
    private static volatile boolean shadeNonLiving = false;
    private static volatile float lgBlur = 14.0f;
    private static volatile float lgRefraction = 18.0f;
    private static volatile float lgChroma = 8.0f;
    private static volatile float lgSaturation = 1.55f;
    private static volatile float lgBrightness = 1.08f;
    private static volatile float lgRimThickness = 1.6f;
    private static volatile float lgSpecular = 0.22f;
    private static volatile float lgSheen = 0.08f;
    private static volatile float lgShadow = 0.3f;
    private static volatile float lgFrost = 0.35f;
    private static volatile float sfCellSize = 54.0f;
    private static volatile float sfStarSize = 16.0f;
    private static volatile float sfSpeed = 0.6f;
    private static volatile Color sfColor = new Color(255, 240, 200, 230);
    private static volatile float sfMoonRatio = 0.35f;
    private static volatile float sfGlow = 14.0f;
    private static volatile float lensStrength = 40.0f;
    private static volatile float lensMagnify = 2.2f;
    private static volatile float lensChroma = 8.0f;
    private static volatile float lensSpecular = 0.35f;
    private static volatile float lensRim = 1.2f;
    private static volatile float auraRadius = 66.0f;
    private static volatile float auraSpeed = 1.2f;
    private static volatile float auraTurbulence = 1.5f;
    private static volatile float auraIntensity = 1.1f;
    private static volatile Color auraInner = new Color(255, 210, 90, 255);
    private static volatile Color auraOuter = new Color(255, 70, 20, 0);
    private static final ThreadLocal currentConsumer = new ThreadLocal();
    private static final ThreadLocal pendingSkinTexId = new ThreadLocal();
    private static final List<PendingDraw> pendingDraws = new ArrayList<>();
    private static final Object drawLock = new Object();
    private static int silhouetteFbo = -1;
    private static int silhouetteColorTex = -1;
    private static int silhouetteDepthRbo = -1;
    private static int silhouetteW = 0;
    private static int silhouetteH = 0;

    private EntityShaderBridge() {
    }

    public static void setFilter(EntityShaderBridge.EntityFilter entityShaderBridge$EntityFilter) {
        filter = entityShaderBridge$EntityFilter;
    }

    public static EntityShaderBridge.EntityFilter getFilter() {
        return filter;
    }

    public static void setMode(EntityShaderBridge.ShaderMode entityShaderBridge$ShaderMode) {
        mode = entityShaderBridge$ShaderMode;
    }

    public static void setBlendMode(EntityShaderBridge.BlendMode entityShaderBridge$BlendMode) {
        if (entityShaderBridge$BlendMode != null) {
            blendMode = entityShaderBridge$BlendMode;
        }
    }

    public static void setOutlineColor(Color color) {
        if (color != null) {
            outlineColor = color;
        }
    }

    public static void setOutlineWidth(float f2) {
        outlineWidth = f2;
    }

    public static void setFill(boolean bl, Color color, float f2) {
        fillEnabled = bl;
        if (color != null) {
            fillColor = color;
        }
        fillAlpha = f2;
    }

    public static void setChromaParams(float f2, float f3) {
        chromaSpeed = f2;
        chromaScale = f3;
    }

    public static void setGradient(boolean bl, Color color, Color color2, Color color3) {
        gradientEnabled = bl;
        if (color != null) {
            gradientColor2 = color;
        }
        if (color2 != null) {
            gradientColor3 = color2;
        }
        if (color3 != null) {
            gradientColor4 = color3;
        }
    }

    public static void setGlow(float f2, float f3, boolean bl) {
        outerGlow = f2;
        innerGlow = f3;
        glowSparkle = bl;
    }

    public static void setShadeItemEntities(boolean bl) {
        shadeItemEntities = bl;
    }

    public static void setShadeHeldItems(boolean bl) {
        shadeHeldItems = bl;
    }

    public static void setShadeNonLiving(boolean bl) {
        shadeNonLiving = bl;
    }

    public static void setLiquidGlassParams(float f2, float f3, float f4, float f5) {
        lgBlur = Math.max(0.0f, f2);
        lgRefraction = Math.max(0.0f, f3);
        lgChroma = Math.max(0.0f, f4);
        lgFrost = Math.max(0.0f, f5);
    }

    public static void setStarfieldParams(float f2, float f3, float f4, Color color, float f5, float f6) {
        sfCellSize = Math.max(8.0f, f2);
        sfStarSize = Math.max(0.5f, f3);
        sfSpeed = f4;
        if (color != null) {
            sfColor = color;
        }
        sfMoonRatio = Math.max(0.0f, Math.min(1.0f, f5));
        sfGlow = Math.max(0.0f, f6);
    }

    public static void setLensParams(float f2, float f3, float f4, float f5, float f6) {
        lensStrength = Math.max(0.0f, f2);
        lensMagnify = Math.max(0.0f, f3);
        lensChroma = Math.max(0.0f, f4);
        lensSpecular = Math.max(0.0f, f5);
        lensRim = Math.max(0.0f, f6);
    }

    public static void setAuraParams(float f2, float f3, float f4, float f5, Color color, Color color2) {
        auraRadius = Math.max(0.0f, f2);
        auraSpeed = f3;
        auraTurbulence = Math.max(0.1f, f4);
        auraIntensity = Math.max(0.0f, f5);
        if (color != null) {
            auraInner = color;
        }
        if (color2 != null) {
            auraOuter = color2;
        }
    }

    public static void setLiquidGlassLook(float f2, float f3, float f4, float f5, float f6, float f7) {
        lgSaturation = f2;
        lgBrightness = f3;
        lgRimThickness = Math.max(0.0f, f4);
        lgSpecular = Math.max(0.0f, f5);
        lgSheen = Math.max(0.0f, f6);
        lgShadow = Math.max(0.0f, f7);
    }

    public static void cacheSkinTexture(AbstractClientPlayerEntity TrackedPosition) {
        try {
            GlTexture mc18;
            int n2;
            GpuTexture gpuTexture;
            Identifier mc19 = TrackedPosition.getSkin().body().texturePath();
            if (mc19 == null) {
                return;
            }
            AbstractTexture ItemModelManager = MinecraftClient.getInstance().getTextureManager().getTexture(mc19);
            if (ItemModelManager != null && (gpuTexture = ItemModelManager.getGlTexture()) instanceof GlTexture && (n2 = (mc18 = (GlTexture)gpuTexture).getGlId()) > 0) {
                pendingSkinTexId.set(n2);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static OrderedRenderCommandQueue tryWrapCollector(LivingEntityRenderState mc10, OrderedRenderCommandQueue mc11) {
        if (filter == null || !filter.shouldShade(mc10)) {
            return mc11;
        }
        if (!GameRendererMixinBridge.isReady()) {
            return mc11;
        }
        Matrix4f matrix4f = new Matrix4f((Matrix4fc)GameRendererMixinBridge.getProjection());
        ShaderVertexConsumer shaderVertexConsumer = ShaderVertexConsumer.a(matrix4f);
        currentConsumer.set(shaderVertexConsumer);
        ShaderRenderLayer shaderRenderLayer = new ShaderRenderLayer(mc11, shaderVertexConsumer);
        Integer n2 = (Integer)pendingSkinTexId.get();
        if (n2 != null && n2 > 0) {
            shaderRenderLayer.a(n2);
        }
        pendingSkinTexId.remove();
        return shaderRenderLayer;
    }

    public static OrderedRenderCommandQueue tryWrapItemCollector(OrderedRenderCommandQueue mc11) {
        if (!shadeItemEntities || filter == null) {
            return mc11;
        }
        if (!GameRendererMixinBridge.isReady()) {
            return mc11;
        }
        Matrix4f matrix4f = new Matrix4f((Matrix4fc)GameRendererMixinBridge.getProjection());
        ShaderVertexConsumer shaderVertexConsumer = ShaderVertexConsumer.a(matrix4f);
        currentConsumer.set(shaderVertexConsumer);
        return new ShaderRenderLayer(mc11, shaderVertexConsumer).a(true);
    }

    public static OrderedRenderCommandQueue tryWrapNonLivingCollector(OrderedRenderCommandQueue mc11) {
        if (!shadeNonLiving || filter == null) {
            return mc11;
        }
        if (!GameRendererMixinBridge.isReady()) {
            return mc11;
        }
        Matrix4f matrix4f = new Matrix4f((Matrix4fc)GameRendererMixinBridge.getProjection());
        ShaderVertexConsumer shaderVertexConsumer = ShaderVertexConsumer.a(matrix4f);
        currentConsumer.set(shaderVertexConsumer);
        return new ShaderRenderLayer(mc11, shaderVertexConsumer).a(true);
    }

    public static OrderedRenderCommandQueue tryWrapHeldItemCollector(OrderedRenderCommandQueue mc11) {
        if (!shadeHeldItems || filter == null) {
            return mc11;
        }
        if (!GameRendererMixinBridge.isReady()) {
            return mc11;
        }
        try {
            MinecraftClient mc20 = MinecraftClient.getInstance();
            GameRenderer mc21 = mc20.gameRenderer;
            Camera mc22 = mc21.getCamera();
            if (mc22.isThirdPerson()) {
                return mc11;
            }
            float f2 = mc20.getRenderTickCounter().getTickProgress(true);
            float f3 = ((GameRendererAccessor)mc21).invokeGetFov(mc22, f2, false);
            Matrix4f matrix4f = mc21.getBasicProjectionMatrix(f3);
            ShaderVertexConsumer shaderVertexConsumer = ShaderVertexConsumer.a(matrix4f);
            currentConsumer.set(shaderVertexConsumer);
            return new ShaderRenderLayer(mc11, shaderVertexConsumer).a(true);
        }
        catch (Exception exception) {
            return mc11;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void onRenderComplete() {
        ShaderVertexConsumer shaderVertexConsumer = (ShaderVertexConsumer)currentConsumer.get();
        currentConsumer.remove();
        if (shaderVertexConsumer != null && shaderVertexConsumer.d()) {
            Object object = drawLock;
            synchronized (object) {
                pendingDraws.add(new EntityShaderBridge.PendingDraw(shaderVertexConsumer));
            }
        } else if (shaderVertexConsumer != null) {
            shaderVertexConsumer.a();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void drawAllPending() {
        int n2;
        ArrayList<PendingDraw> arrayList;
        Object object = drawLock;
        synchronized (object) {
            if (pendingDraws.isEmpty()) {
                return;
            }
            arrayList = new ArrayList<>(pendingDraws);
            pendingDraws.clear();
        }
        object = Shaders.o();
        Object object2 = Shaders.p();
        GlProgram glProgram = Shaders.s();
        if (object == null || glProgram == null) {
            for (EntityShaderBridge.PendingDraw entityShaderBridge$PendingDraw : arrayList) {
                entityShaderBridge$PendingDraw.consumer.a();
            }
            return;
        }
        if (object2 == null) {
            object2 = object;
        }
        if ((n2 = GuiRenderer.d()) < 0) {
            for (EntityShaderBridge.PendingDraw entityShaderBridge$PendingDraw : arrayList) {
                entityShaderBridge$PendingDraw.consumer.a();
            }
            return;
        }
        MinecraftClient mc20 = MinecraftClient.getInstance();
        int n3 = mc20.getWindow().getFramebufferWidth();
        int n4 = mc20.getWindow().getFramebufferHeight();
        if (n3 <= 0 || n4 <= 0) {
            for (EntityShaderBridge.PendingDraw entityShaderBridge$PendingDraw : arrayList) {
                entityShaderBridge$PendingDraw.consumer.a();
            }
            return;
        }
        EntityShaderBridge.ensureSilhouetteFbo(n3, n4);
        if (silhouetteFbo == -1) {
            for (EntityShaderBridge.PendingDraw entityShaderBridge$PendingDraw : arrayList) {
                entityShaderBridge$PendingDraw.consumer.a();
            }
            return;
        }
        int n5 = GL11.glGetInteger((int)36006);
        GLStateSnapshot gLStateSnapshot = GLStateSnapshot.getInstance();
        try {
            GL30.glBindFramebuffer((int)36160, (int)silhouetteFbo);
            GL11.glDisable((int)3089);
            GL11.glColorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
            GL11.glDisable((int)2960);
            GL11.glStencilMask((int)255);
            GL11.glViewport((int)0, (int)0, (int)n3, (int)n4);
            GL11.glClearColor((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
            GL11.glDepthMask((boolean)true);
            GL11.glClearDepth((double)1.0);
            GL11.glClear((int)16640);
            GL13.glActiveTexture((int)33984);
            GL11.glDisable((int)3042);
            GL11.glEnable((int)2929);
            GL11.glDepthFunc((int)515);
            GL11.glDepthMask((boolean)true);
            GL11.glDisable((int)2884);
            Object object3 = Shaders.r();
            if (object3 == null) {
                object3 = object;
            }
            ((GlProgram)object3).a();
            EntityShaderBridge.setColorUniform((GlProgram)object3, "color1", new Color(255, 255, 255, 255));
            ((GlProgram)object3).b("uOutlineOffset").a(0.0f, 0.0f);
            for (Object object4 : arrayList) {
                ((EntityShaderBridge.PendingDraw)object4).consumer.h();
                ((EntityShaderBridge.PendingDraw)object4).consumer.a((GlProgram)object3, null);
                ((EntityShaderBridge.PendingDraw)object4).consumer.a();
            }
            ((GlProgram)object3).b();
            GL30.glBindFramebuffer((int)36160, (int)n2);
            GL11.glViewport((int)0, (int)0, (int)n3, (int)n4);
            GL11.glDisable((int)3089);
            GL11.glEnable((int)3042);
            if (blendMode == EntityShaderBridge.BlendMode.ADDITIVE) {
                GL14.glBlendFuncSeparate((int)770, (int)1, (int)1, (int)771);
            } else {
                GL14.glBlendFuncSeparate((int)770, (int)771, (int)1, (int)771);
            }
            GL11.glDisable((int)2929);
            GL11.glDisable((int)2884);
            int n6 = 8;
            GL13.glActiveTexture((int)(33984 + n6));
            GL11.glBindTexture((int)3553, (int)silhouetteColorTex);
            if (mode == EntityShaderBridge.ShaderMode.LIQUID_GLASS) {
                int n7;
                GlProgram object4;
                object4 = Shaders.t();
                if (object4 != null && (n7 = EntityShaderBridge.getMainColorTexture(n2)) > 0) {
                    GL13.glActiveTexture((int)33984);
                    GL11.glBindTexture((int)3553, (int)n7);
                    GL14.glBlendFuncSeparate((int)770, (int)771, (int)1, (int)771);
                    ((GlProgram)object4).a();
                    int n8 = ((GlProgram)object4).a("InputSampler");
                    int n9 = ((GlProgram)object4).a("uSilhouette");
                    if (n8 >= 0) {
                        GL20.glUniform1i((int)n8, (int)0);
                    }
                    if (n9 >= 0) {
                        GL20.glUniform1i((int)n9, (int)n6);
                    }
                    ((GlProgram)object4).b("uResolution").a(n3, n4);
                    ((GlProgram)object4).b("uBlur").a(lgBlur);
                    ((GlProgram)object4).b("uRefraction").a(lgRefraction);
                    ((GlProgram)object4).b("uChroma").a(lgChroma);
                    EntityShaderBridge.setColorUniform((GlProgram)object4, "uTint", fillColor);
                    ((GlProgram)object4).b("uTintStrength").a(fillEnabled ? fillAlpha : 0.0f);
                    ((GlProgram)object4).b("uSaturation").a(lgSaturation);
                    ((GlProgram)object4).b("uBrightness").a(lgBrightness);
                    ((GlProgram)object4).b("uRimThickness").a(lgRimThickness);
                    EntityShaderBridge.setColorUniform((GlProgram)object4, "uRimColor", outlineColor);
                    ((GlProgram)object4).b("uSpecular").a(lgSpecular);
                    ((GlProgram)object4).b("uSheen").a(lgSheen);
                    ((GlProgram)object4).b("uShadow").a(lgShadow);
                    ((GlProgram)object4).b("uFrost").a(lgFrost);
                    EntityShaderBridge.drawFullscreenQuad((GlProgram)object4);
                    ((GlProgram)object4).b();
                    GL13.glActiveTexture((int)33984);
                    GL11.glBindTexture((int)3553, (int)0);
                }
            } else if (mode == EntityShaderBridge.ShaderMode.LENS) {
                int n10;
                GlProgram object4;
                object4 = Shaders.v();
                if (object4 != null && (n10 = EntityShaderBridge.getMainColorTexture(n2)) > 0) {
                    GL13.glActiveTexture((int)33984);
                    GL11.glBindTexture((int)3553, (int)n10);
                    GL14.glBlendFuncSeparate((int)770, (int)771, (int)1, (int)771);
                    ((GlProgram)object4).a();
                    int n11 = ((GlProgram)object4).a("InputSampler");
                    int n12 = ((GlProgram)object4).a("uSilhouette");
                    if (n11 >= 0) {
                        GL20.glUniform1i((int)n11, (int)0);
                    }
                    if (n12 >= 0) {
                        GL20.glUniform1i((int)n12, (int)n6);
                    }
                    ((GlProgram)object4).b("uResolution").a(n3, n4);
                    ((GlProgram)object4).b("uOutlineWidth").a(outlineWidth);
                    EntityShaderBridge.setColorUniform((GlProgram)object4, "uOutlineColor", outlineColor);
                    ((GlProgram)object4).b("uLensStrength").a(lensStrength);
                    ((GlProgram)object4).b("uLensMagnify").a(lensMagnify);
                    ((GlProgram)object4).b("uLensChroma").a(lensChroma);
                    ((GlProgram)object4).b("uLensSpecular").a(lensSpecular);
                    EntityShaderBridge.setColorUniform((GlProgram)object4, "uRimColor", outlineColor);
                    ((GlProgram)object4).b("uRimThickness").a(lensRim);
                    EntityShaderBridge.drawFullscreenQuad((GlProgram)object4);
                    ((GlProgram)object4).b();
                    GL13.glActiveTexture((int)33984);
                    GL11.glBindTexture((int)3553, (int)0);
                }
            } else if (mode == EntityShaderBridge.ShaderMode.STARFIELD) {
                GlProgram object4;
                object4 = Shaders.u();
                if (object4 != null) {
                    ((GlProgram)object4).a();
                    int n13 = ((GlProgram)object4).a("uSilhouette");
                    if (n13 >= 0) {
                        GL20.glUniform1i((int)n13, (int)n6);
                    }
                    ((GlProgram)object4).b("uResolution").a(n3, n4);
                    ((GlProgram)object4).b("uTime").a((float)(System.currentTimeMillis() % 100000L) / 1000.0f);
                    ((GlProgram)object4).b("uOutlineWidth").a(outlineWidth);
                    EntityShaderBridge.setColorUniform((GlProgram)object4, "uOutlineColor", outlineColor);
                    EntityShaderBridge.setColorUniform((GlProgram)object4, "uFillColor", fillColor);
                    ((GlProgram)object4).b("uFillAlpha").a(fillEnabled ? fillAlpha : 0.0f);
                    ((GlProgram)object4).b("uStarCellSize").a(sfCellSize);
                    ((GlProgram)object4).b("uStarSize").a(sfStarSize);
                    ((GlProgram)object4).b("uStarSpeed").a(sfSpeed);
                    EntityShaderBridge.setColorUniform((GlProgram)object4, "uStarColor", sfColor);
                    ((GlProgram)object4).b("uMoonRatio").a(sfMoonRatio);
                    ((GlProgram)object4).b("uStarGlow").a(sfGlow);
                    EntityShaderBridge.drawFullscreenQuad((GlProgram)object4);
                    ((GlProgram)object4).b();
                }
            } else if (mode == EntityShaderBridge.ShaderMode.AURA) {
                GlProgram object4;
                object4 = Shaders.w();
                if (object4 != null) {
                    ((GlProgram)object4).a();
                    int n14 = ((GlProgram)object4).a("uSilhouette");
                    if (n14 >= 0) {
                        GL20.glUniform1i((int)n14, (int)n6);
                    }
                    ((GlProgram)object4).b("uResolution").a(n3, n4);
                    ((GlProgram)object4).b("uTime").a((float)(System.currentTimeMillis() % 100000L) / 1000.0f);
                    ((GlProgram)object4).b("uOutlineWidth").a(outlineWidth);
                    EntityShaderBridge.setColorUniform((GlProgram)object4, "uOutlineColor", outlineColor);
                    EntityShaderBridge.setColorUniform((GlProgram)object4, "uFillColor", fillColor);
                    ((GlProgram)object4).b("uFillAlpha").a(fillEnabled ? fillAlpha : 0.0f);
                    ((GlProgram)object4).b("uAuraRadius").a(auraRadius);
                    ((GlProgram)object4).b("uAuraSpeed").a(auraSpeed);
                    ((GlProgram)object4).b("uAuraTurbulence").a(auraTurbulence);
                    ((GlProgram)object4).b("uAuraIntensity").a(auraIntensity);
                    EntityShaderBridge.setColorUniform((GlProgram)object4, "uAuraInner", auraInner);
                    EntityShaderBridge.setColorUniform((GlProgram)object4, "uAuraOuter", auraOuter);
                    EntityShaderBridge.drawFullscreenQuad((GlProgram)object4);
                    ((GlProgram)object4).b();
                }
            } else {
                glProgram.a();
                int n15 = glProgram.a("uSilhouette");
                if (n15 >= 0) {
                    GL20.glUniform1i((int)n15, (int)n6);
                }
                glProgram.b("uResolution").a(n3, n4);
                glProgram.b("uOutlineWidth").a(outlineWidth);
                EntityShaderBridge.setColorUniform(glProgram, "uOutlineColor", outlineColor);
                EntityShaderBridge.setColorUniform(glProgram, "uOutlineColor2", gradientColor2);
                EntityShaderBridge.setColorUniform(glProgram, "uOutlineColor3", gradientColor3);
                EntityShaderBridge.setColorUniform(glProgram, "uOutlineColor4", gradientColor4);
                glProgram.b("uGradientMode").a(gradientEnabled && mode == EntityShaderBridge.ShaderMode.SOLID ? 1 : 0);
                EntityShaderBridge.setColorUniform(glProgram, "uFillColor", fillColor);
                glProgram.b("uFillAlpha").a(fillEnabled ? fillAlpha : 0.0f);
                glProgram.b("uChromaMode").a(mode == EntityShaderBridge.ShaderMode.CHROMA ? 1 : 0);
                glProgram.b("uTime").a((float)(System.currentTimeMillis() % 100000L) / 1000.0f);
                glProgram.b("uChromaSpeed").a(chromaSpeed);
                glProgram.b("uChromaScale").a(chromaScale);
                glProgram.b("uOuterGlow").a(outerGlow);
                glProgram.b("uInnerGlow").a(innerGlow);
                glProgram.b("uGlowSparkle").a(glowSparkle ? 1 : 0);
                EntityShaderBridge.drawFullscreenQuad(glProgram);
                glProgram.b();
            }
        }
        finally {
            GL13.glActiveTexture((int)33992);
            GL11.glBindTexture((int)3553, (int)0);
            GL13.glActiveTexture((int)33984);
            GL11.glBindTexture((int)3553, (int)0);
            GL11.glDepthMask((boolean)true);
            GL20.glUseProgram((int)0);
            gLStateSnapshot.b();
            GL30.glBindFramebuffer((int)36160, (int)n5);
        }
    }

    private static int getMainColorTexture(int n2) {
        int n3 = GL11.glGetInteger((int)36006);
        GL30.glBindFramebuffer((int)36160, (int)n2);
        int[] nArray = new int[1];
        try {
            GL30.glGetFramebufferAttachmentParameteriv((int)36160, (int)36064, (int)36049, (int[])nArray);
        }
        catch (Exception exception) {
            nArray[0] = 0;
        }
        GL30.glBindFramebuffer((int)36160, (int)n3);
        return nArray[0];
    }

    private static void drawFullscreenQuad(GlProgram glProgram) {
        int n2;
        float f2 = RenderScale.c();
        float f3 = RenderScale.d();
        float[] fArray = new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
        float[] fArray2 = new float[]{2.0f / f2, 0.0f, 0.0f, 0.0f, 0.0f, -2.0f / f3, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, -1.0f, 1.0f, 0.0f, 1.0f};
        int n3 = glProgram.a("ModelViewMat");
        if (n3 >= 0) {
            GL20.glUniformMatrix4fv((int)n3, (boolean)false, (float[])fArray);
        }
        if ((n2 = glProgram.a("ProjMat")) >= 0) {
            GL20.glUniformMatrix4fv((int)n2, (boolean)false, (float[])fArray2);
        }
        BufferBuilder mc23 = new BufferBuilder(new BufferAllocator(256), VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        mc23.vertex(0.0f, 0.0f, 0.0f).color(255, 255, 255, 255);
        mc23.vertex(0.0f, f3, 0.0f).color(255, 255, 255, 255);
        mc23.vertex(f2, f3, 0.0f).color(255, 255, 255, 255);
        mc23.vertex(f2, 0.0f, 0.0f).color(255, 255, 255, 255);
        BuiltBuffer mc25 = mc23.endNullable();
        if (mc25 != null) {
            GuiRenderer.a(mc25);
        }
    }

    private static void ensureSilhouetteFbo(int n2, int n3) {
        if (silhouetteFbo == -1) {
            silhouetteFbo = GL30.glGenFramebuffers();
            silhouetteColorTex = GL11.glGenTextures();
            silhouetteDepthRbo = GL30.glGenRenderbuffers();
        }
        if (n2 != silhouetteW || n3 != silhouetteH) {
            GL11.glBindTexture((int)3553, (int)silhouetteColorTex);
            GL11.glTexImage2D((int)3553, (int)0, (int)32856, (int)n2, (int)n3, (int)0, (int)6408, (int)5121, (ByteBuffer)null);
            GL11.glTexParameteri((int)3553, (int)10241, (int)9728);
            GL11.glTexParameteri((int)3553, (int)10240, (int)9728);
            GL11.glTexParameteri((int)3553, (int)10242, (int)33071);
            GL11.glTexParameteri((int)3553, (int)10243, (int)33071);
            GL30.glBindRenderbuffer((int)36161, (int)silhouetteDepthRbo);
            GL30.glRenderbufferStorage((int)36161, (int)33190, (int)n2, (int)n3);
            GL30.glBindFramebuffer((int)36160, (int)silhouetteFbo);
            GL30.glFramebufferTexture2D((int)36160, (int)36064, (int)3553, (int)silhouetteColorTex, (int)0);
            GL30.glFramebufferRenderbuffer((int)36160, (int)36096, (int)36161, (int)silhouetteDepthRbo);
            silhouetteW = n2;
            silhouetteH = n3;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void clearPending() {
        Object object = drawLock;
        synchronized (object) {
            for (EntityShaderBridge.PendingDraw entityShaderBridge$PendingDraw : pendingDraws) {
                entityShaderBridge$PendingDraw.consumer.a();
            }
            pendingDraws.clear();
        }
    }

    public static void cleanup() {
        EntityShaderBridge.clearPending();
        if (silhouetteFbo != -1) {
            GL30.glDeleteFramebuffers((int)silhouetteFbo);
            silhouetteFbo = -1;
        }
        if (silhouetteColorTex != -1) {
            GL11.glDeleteTextures((int)silhouetteColorTex);
            silhouetteColorTex = -1;
        }
        if (silhouetteDepthRbo != -1) {
            GL30.glDeleteRenderbuffers((int)silhouetteDepthRbo);
            silhouetteDepthRbo = -1;
        }
        silhouetteW = 0;
        silhouetteH = 0;
    }

    private static void invalidateVanillaStateCache() {
        try {
            GlStateManager._enableBlend();
            GlStateManager._disableBlend();
            GlStateManager._enableDepthTest();
            GlStateManager._disableDepthTest();
            GlStateManager._glUseProgram((int)0);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static void setColorUniform(GlProgram glProgram, String string, Color color) {
        glProgram.b(string).a((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f);
    }

    public enum BlendMode {
    ALPHA,
    ADDITIVE;
    }

    public interface EntityFilter {
    public boolean shouldShade(LivingEntityRenderState var1);
    }

    public static class PendingDraw {
    final ShaderVertexConsumer consumer;

    PendingDraw(ShaderVertexConsumer shaderVertexConsumer) {
        this.consumer = shaderVertexConsumer;
    }
    }

    public enum ShaderMode {
    SOLID,
    CHROMA,
    LIQUID_GLASS,
    STARFIELD,
    LENS,
    AURA;
    }
}

