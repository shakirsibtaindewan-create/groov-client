/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import itz.vrgn1337.groovclient.api.util.render.RenderLayerMode;

final class RenderQuad {
    final int a;
    final int b;
    final int c;
    final RenderLayerMode d;

    RenderQuad(int n2, int n3, int n4, RenderLayerMode renderLayerMode) {
        this.a = n2;
        this.b = n3;
        this.c = n4;
        this.d = renderLayerMode;
    }
}

