/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util;

public class Stopwatch {
    private long a;

    public Stopwatch() {
        this.b();
    }

    public long a() {
        return System.nanoTime() / 1000000L;
    }

    public boolean a(double d2) {
        return (double)(this.a() - this.a) >= d2;
    }

    public void b() {
        this.a = this.a();
    }

    public boolean a(float f2) {
        return (float)(this.c() - this.a) >= f2;
    }

    public long c() {
        return System.currentTimeMillis() - this.a;
    }

    public void a(long l2) {
        this.a = l2;
    }
}

