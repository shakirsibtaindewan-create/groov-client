/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import itz.vrgn1337.groovclient.api.util.render.ThemeVariant;
import java.awt.Color;

public final class GlassStyle {
    public float a = 18.0f;
    public float b = 14.0f;
    public float c = 2.0f;
    public Color d = new Color(255, 255, 255, 38);
    public float e = 1.0f;
    public float f = 1.18f;
    public float g = 1.02f;
    public float h = 1.2f;
    public Color i = new Color(255, 255, 255, 210);
    public float j = 0.1f;
    public float k = 0.18f;
    public float l = 0.32f;
    public float m = 0.0f;

    public GlassStyle a(float f2) {
        this.a = f2;
        return this;
    }

    public GlassStyle b(float f2) {
        this.b = f2;
        return this;
    }

    public GlassStyle c(float f2) {
        this.c = f2;
        return this;
    }

    public GlassStyle a(Color color) {
        this.d = color;
        return this;
    }

    public GlassStyle d(float f2) {
        this.e = f2;
        return this;
    }

    public GlassStyle e(float f2) {
        this.f = f2;
        return this;
    }

    public GlassStyle f(float f2) {
        this.g = f2;
        return this;
    }

    public GlassStyle a(float f2, Color color) {
        this.h = f2;
        this.i = color;
        return this;
    }

    public GlassStyle g(float f2) {
        this.j = f2;
        return this;
    }

    public GlassStyle h(float f2) {
        this.k = f2;
        return this;
    }

    public GlassStyle i(float f2) {
        this.l = f2;
        return this;
    }

    public GlassStyle j(float f2) {
        this.m = f2;
        return this;
    }

    public GlassStyle a(ThemeVariant themeVariant) {
        switch (themeVariant.ordinal()) {
            case 0: {
                this.d = new Color(255, 255, 255, 38);
                this.i = new Color(255, 255, 255, 215);
                this.f = 1.18f;
                this.g = 1.03f;
                this.j = 0.1f;
                this.k = 0.18f;
                this.l = 0.3f;
                this.a = 18.0f;
                this.b = 14.0f;
                this.c = 2.0f;
                this.m = 0.0f;
                break;
            }
            case 1: {
                this.d = new Color(14, 18, 24, 170);
                this.i = new Color(255, 255, 255, 170);
                this.f = 1.2f;
                this.g = 0.95f;
                this.j = 0.14f;
                this.k = 0.05f;
                this.l = 0.55f;
                this.a = 20.0f;
                this.b = 20.0f;
                this.c = 5.0f;
                break;
            }
            case 2: {
                this.d = new Color(255, 255, 255, 28);
                this.i = new Color(255, 255, 255, 230);
                this.f = 1.85f;
                this.g = 1.12f;
                this.j = 0.28f;
                this.k = 0.1f;
                this.l = 0.28f;
                this.a = 14.0f;
                this.b = 22.0f;
                this.c = 10.0f;
            }
        }
        return this;
    }

    public static GlassStyle getInstance() {
        return new GlassStyle();
    }
}

