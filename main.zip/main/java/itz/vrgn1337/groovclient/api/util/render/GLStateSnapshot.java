/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.render;

import java.nio.ByteBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public final class GLStateSnapshot {
    private final int a = GL11.glGetInteger((int)35725);
    private final int b = GL11.glGetInteger((int)36006);
    private final int c = GL11.glGetInteger((int)34229);
    private final int d = GL11.glGetInteger((int)34964);
    private final int e = GL11.glGetInteger((int)34965);
    private final int f = GL11.glGetInteger((int)32873);
    private final boolean g = GL11.glIsEnabled((int)3042);
    private final boolean h = GL11.glIsEnabled((int)2929);
    private final boolean i = GL11.glIsEnabled((int)2884);
    private final ByteBuffer j = BufferUtils.createByteBuffer((int)4);

    private GLStateSnapshot() {
        GL11.glGetBooleanv((int)3107, (ByteBuffer)this.j);
    }

    public static GLStateSnapshot getInstance() {
        return new GLStateSnapshot();
    }

    public void b() {
        GL20.glUseProgram((int)this.a);
        GL30.glBindFramebuffer((int)36160, (int)this.b);
        GL30.glBindVertexArray((int)this.c);
        GL15.glBindBuffer((int)34962, (int)this.d);
        GL15.glBindBuffer((int)34963, (int)this.e);
        GL11.glBindTexture((int)3553, (int)this.f);
        if (this.g) {
            GL11.glEnable((int)3042);
        } else {
            GL11.glDisable((int)3042);
        }
        if (this.h) {
            GL11.glEnable((int)2929);
        } else {
            GL11.glDisable((int)2929);
        }
        if (this.i) {
            GL11.glEnable((int)2884);
        } else {
            GL11.glDisable((int)2884);
        }
        GL11.glColorMask((this.j.get(0) != 0 ? 1 : 0) != 0, (this.j.get(1) != 0 ? 1 : 0) != 0, (this.j.get(2) != 0 ? 1 : 0) != 0, (this.j.get(3) != 0 ? 1 : 0) != 0);
    }
}

