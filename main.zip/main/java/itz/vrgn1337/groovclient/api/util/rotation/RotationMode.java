/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.rotation;

public enum RotationMode {
    OFF, PROPER;

    private RotationMode() {

    }

}

