/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util;

import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;

public class TickCounter {
    private int a = 0;

    public TickCounter() {
        Main.eventBus().register(this);
    }

    private void onUpdateEventPre(UpdateEvent.Pre updateEvent$Pre) {
        if (Main.mc.world == null) {
            return;
        }
        ++this.a;
    }

    public boolean a(int n2) {
        return this.a >= n2;
    }

    public boolean b(int n2) {
        if (this.a(n2)) {
            this.b();
            return true;
        }
        return false;
    }

    public int a() {
        return this.a;
    }

    public void b() {
        this.a = 0;
    }

    public void c(int n2) {
        this.a = n2;
    }
}

