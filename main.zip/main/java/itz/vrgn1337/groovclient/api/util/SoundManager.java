/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

public final class SoundManager {
    private static byte[] a;
    private static byte[] b;
    private static byte[] c;
    private static AudioFormat d;
    private static AudioFormat e;
    private static AudioFormat f;
    private static volatile boolean g;

    private SoundManager() {
    }

    public static void a() {
        if (g) {
            return;
        }
        SoundManager.a("/assets/groovclient/sounds/ui_click.ogg", 0);
        SoundManager.a("/assets/groovclient/sounds/ui_toggle_on.ogg", 1);
        SoundManager.a("/assets/groovclient/sounds/ui_toggle_off.ogg", 2);
        g = true;
    }

    public static void b() {
        SoundManager.a(a, d);
    }

    public static void c() {
        SoundManager.a(b, e);
    }

    public static void d() {
        SoundManager.a(c, f);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void a(String string, int n2) {
        try (InputStream inputStream = SoundManager.class.getResourceAsStream(string);){
            int n3;
            if (inputStream == null) {
                return;
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] byArray = new byte[4096];
            while ((n3 = inputStream.read(byArray)) != -1) {
                byteArrayOutputStream.write(byArray, 0, n3);
            }
            byte[] byArray2 = byteArrayOutputStream.toByteArray();
            ByteBuffer byteBuffer = MemoryUtil.memAlloc((int)byArray2.length).put(byArray2).flip();
            try (MemoryStack memoryStack = MemoryStack.stackPush();){
                IntBuffer intBuffer = memoryStack.mallocInt(1);
                IntBuffer intBuffer2 = memoryStack.mallocInt(1);
                ShortBuffer shortBuffer = STBVorbis.stb_vorbis_decode_memory((ByteBuffer)byteBuffer, (IntBuffer)intBuffer, (IntBuffer)intBuffer2);
                MemoryUtil.memFree((Buffer)byteBuffer);
                if (shortBuffer == null) {
                    return;
                }
                int n4 = intBuffer.get(0);
                int n5 = intBuffer2.get(0);
                AudioFormat audioFormat = new AudioFormat(n5, 16, n4, true, false);
                byte[] byArray3 = new byte[shortBuffer.remaining() * 2];
                for (int j = 0; j < shortBuffer.remaining(); ++j) {
                    short s2 = shortBuffer.get(shortBuffer.position() + j);
                    byArray3[j * 2] = (byte)(s2 & 0xFF);
                    byArray3[j * 2 + 1] = (byte)(s2 >> 8 & 0xFF);
                }
                MemoryUtil.memFree((Buffer)shortBuffer);
                switch (n2) {
                    case 0: {
                        a = byArray3;
                        d = audioFormat;
                        return;
                    }
                    case 1: {
                        b = byArray3;
                        e = audioFormat;
                        return;
                    }
                    case 2: {
                        c = byArray3;
                        f = audioFormat;
                        return;
                    }
                }
                return;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static void a(byte[] byArray, AudioFormat audioFormat) {
        if (byArray == null || audioFormat == null) {
            return;
        }
        Thread.ofVirtual().start(() -> a.lambda$play$1((AudioFormat)audioFormat, (byte[])byArray));
    }

    private static void lambda$play$1(AudioFormat audioFormat, byte[] byArray) {
        try {
            Clip clip = AudioSystem.getClip();
            clip.open(audioFormat, byArray, 0, byArray.length);
            clip.addLineListener(arg_0 -> a.lambda$play$0((Clip)clip, arg_0));
            clip.start();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static void lambda$play$0(Clip clip, LineEvent lineEvent) {
        if (lineEvent.getType() == LineEvent.Type.STOP) {
            clip.close();
        }
    }
}

