/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util.item;

import itz.vrgn1337.groovclient.api.util.ActionQueue;
import itz.vrgn1337.groovclient.api.util.BindManager;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;

public final class SlotUtils {
    private static long a = 0L;

    private SlotUtils() {
    }

    public static int a() {
        return Main.mc.player == null ? -1 : Main.mc.player.getInventory().getSelectedSlot();
    }

    public static boolean a(int n2) {
        return SlotUtils.a() == n2;
    }

    public static boolean b() {
        return BindManager.f();
    }

    public static boolean b(int n2) {
        if (Main.mc.player == null) {
            return false;
        }
        if (n2 < 0 || n2 >= 9) {
            return false;
        }
        PlayerInventory mc34 = Main.mc.player.getInventory();
        if (mc34.getSelectedSlot() == n2) {
            return true;
        }
        mc34.setSelectedSlot(n2);
        return mc34.getSelectedSlot() == n2;
    }

    public static boolean a(Item mc17) {
        int n2 = ItemUtils.f(mc17);
        if (n2 < 0) {
            return false;
        }
        return SlotUtils.b(n2);
    }

    public static boolean a(Item mc17, long l2) {
        if (Main.mc.player == null) {
            return false;
        }
        int n2 = ItemUtils.f(mc17);
        if (n2 < 0) {
            return false;
        }
        PlayerInventory mc34 = Main.mc.player.getInventory();
        if (mc34.getSelectedSlot() == n2) {
            return true;
        }
        long l3 = System.currentTimeMillis();
        if (l3 - a < l2) {
            return false;
        }
        mc34.setSelectedSlot(n2);
        if (mc34.getSelectedSlot() != n2) {
            return false;
        }
        a = l3;
        return true;
    }

    public static boolean c(int n2) {
        if (Main.mc.player == null) {
            return false;
        }
        if (n2 < 0) {
            return false;
        }
        PlayerInventory mc34 = Main.mc.player.getInventory();
        if (mc34.getSelectedSlot() == n2) {
            return true;
        }
        long l2 = System.currentTimeMillis();
        if (l2 - a < 75L) {
            return false;
        }
        mc34.setSelectedSlot(n2);
        if (mc34.getSelectedSlot() != n2) {
            return false;
        }
        a = l2;
        return true;
    }

    public static boolean b(Item mc17) {
        if (Main.mc.player == null) {
            return false;
        }
        int n2 = ItemUtils.f(mc17);
        if (n2 < 0) {
            return false;
        }
        PlayerInventory mc34 = Main.mc.player.getInventory();
        if (mc34.getSelectedSlot() == n2) {
            return true;
        }
        long l2 = System.currentTimeMillis();
        if (l2 - a < 75L) {
            return false;
        }
        mc34.setSelectedSlot(n2);
        if (mc34.getSelectedSlot() != n2) {
            return false;
        }
        a = l2;
        return true;
    }

    public static boolean d(int n2) {
        if (n2 < 0) {
            return false;
        }
        ActionQueue.e();
        BindManager.g();
        try {
            boolean bl = SlotUtils.b(n2);
            return bl;
        }
        finally {
            BindManager.h();
        }
    }

    public static boolean c(Item mc17) {
        int n2 = ItemUtils.f(mc17);
        if (n2 < 0) {
            return false;
        }
        ActionQueue.e();
        BindManager.g();
        try {
            boolean bl = SlotUtils.b(n2);
            return bl;
        }
        finally {
            BindManager.h();
        }
    }

    public static boolean e(int n2) {
        if (Main.mc.player == null) {
            return false;
        }
        if (n2 < 0 || n2 >= 9) {
            return false;
        }
        BindManager.j();
        try {
            PlayerInventory mc34 = Main.mc.player.getInventory();
            if (mc34.getSelectedSlot() == n2) {
                boolean bl = true;
                return bl;
            }
            mc34.setSelectedSlot(n2);
            boolean bl = mc34.getSelectedSlot() == n2;
            return bl;
        }
        finally {
            BindManager.k();
        }
    }

    public static boolean d(Item mc17) {
        int n2 = ItemUtils.f(mc17);
        if (n2 < 0) {
            return false;
        }
        return SlotUtils.e(n2);
    }

    public static void a(Runnable runnable) {
        BindManager.j();
        try {
            runnable.run();
        }
        finally {
            BindManager.k();
        }
    }

    public static void a(Object object, int n2) {
        ActionQueue.a(object, n2);
    }

    public static void a(Object object, Item mc17) {
        int n2 = ItemUtils.f(mc17);
        if (n2 < 0) {
            return;
        }
        ActionQueue.a(object, n2);
    }

    public static void a(Object object, Runnable runnable) {
        ActionQueue.a(object, runnable);
    }

    public static void a(Object object, Hand mc8) {
        ActionQueue.a(object, mc8);
    }

    public static void a(Object object, Entity mc2) {
        ActionQueue.a(object, mc2);
    }

    public static boolean a(Object object) {
        return ActionQueue.a(object);
    }

    public static boolean c() {
        return ActionQueue.c();
    }

    public static void b(Object object) {
        ActionQueue.b(object);
    }
}

