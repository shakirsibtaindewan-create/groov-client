/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.util;

import itz.vrgn1337.groovclient.api.util.WaitCondition;

final class TickWaitCondition
implements WaitCondition {
    private int a;

    TickWaitCondition(int n2) {
        this.a = n2;
    }

    public boolean a() {
        if (this.a <= 0) {
            return true;
        }
        --this.a;
        return this.a <= 0;
    }
}

