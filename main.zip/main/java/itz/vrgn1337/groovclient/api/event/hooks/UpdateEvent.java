/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class UpdateEvent
extends Event {

    public static class Post extends UpdateEvent {
    private static final UpdateEvent.Post INSTANCE = new UpdateEvent.Post();

    public static UpdateEvent.Post getInstance() {
        return INSTANCE;
    }
    }

    public static class Pre extends UpdateEvent {
    private static final UpdateEvent.Pre INSTANCE = new UpdateEvent.Pre();

    public static UpdateEvent.Pre getInstance() {
        return INSTANCE;
    }
    }
}

