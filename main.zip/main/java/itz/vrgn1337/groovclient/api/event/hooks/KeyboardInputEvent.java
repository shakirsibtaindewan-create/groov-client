/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.util.PlayerInput;

public class KeyboardInputEvent
extends Event {

    public static class Post extends KeyboardInputEvent {
    public static final KeyboardInputEvent.Post INSTANCE = new KeyboardInputEvent.Post();

    public static KeyboardInputEvent.Post getInstance() {
        return INSTANCE;
    }
    }

    public static class Pre extends KeyboardInputEvent {
    public static final KeyboardInputEvent.Pre INSTANCE = new KeyboardInputEvent.Pre();
    public PlayerInput input;

    public static KeyboardInputEvent.Pre get(PlayerInput mc9) {
        KeyboardInputEvent.Pre.INSTANCE.input = mc9;
        return INSTANCE;
    }
    }
}

