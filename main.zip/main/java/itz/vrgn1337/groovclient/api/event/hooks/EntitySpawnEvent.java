/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.entity.Entity;

public class EntitySpawnEvent
extends Event {

    public static class Post extends EntitySpawnEvent {
    private static final EntitySpawnEvent.Post INSTANCE = new EntitySpawnEvent.Post();
    public Entity entity;

    public static EntitySpawnEvent.Post get(Entity mc2) {
        EntitySpawnEvent.Post.INSTANCE.entity = mc2;
        return INSTANCE;
    }
    }

    public static class Pre extends EntitySpawnEvent {
    private static final EntitySpawnEvent.Pre INSTANCE = new EntitySpawnEvent.Pre();
    public Entity entity;

    public static EntitySpawnEvent.Pre get(Entity mc2) {
        EntitySpawnEvent.Pre.INSTANCE.entity = mc2;
        return INSTANCE;
    }
    }
}

