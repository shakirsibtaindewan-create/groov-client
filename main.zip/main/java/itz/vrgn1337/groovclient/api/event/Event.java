/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event;

public abstract class Event {
    private boolean cancelled;
    private boolean undo;
    private long time;
    private long threshold;

    public void cancel() {
        this.cancelled = true;
        this.undo = true;
    }

    public void manualCancel() {
        this.cancelled = true;
        this.undo = false;
    }

    public void scheduleCancel(long l2) {
        this.manualCancel();
        this.threshold = l2;
        this.time = System.currentTimeMillis();
    }

    public void reset() {
        this.cancelled = false;
        this.undo = false;
        this.time = 0L;
        this.threshold = 0L;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public boolean isUndo() {
        return this.undo;
    }

    public long getTime() {
        return this.time;
    }

    public long getThreshold() {
        return this.threshold;
    }
}

