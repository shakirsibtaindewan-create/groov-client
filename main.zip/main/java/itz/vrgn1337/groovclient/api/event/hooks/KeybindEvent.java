/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class KeybindEvent
extends Event {

    public static class Post extends KeybindEvent {
    private static final KeybindEvent.Post INSTANCE = new KeybindEvent.Post();
    public int key;
    public InputUtil.Key bind;

    public static KeybindEvent.Post get(int n2) {
        KeybindEvent.Post.INSTANCE.key = n2;
        return INSTANCE;
    }
    }

    public static class Pre extends KeybindEvent {
    private static final KeybindEvent.Pre INSTANCE = new KeybindEvent.Pre();
    public int key;
    public InputUtil.Key bind;

    public static KeybindEvent.Pre get(int n2) {
        KeybindEvent.Pre.INSTANCE.key = n2;
        return INSTANCE;
    }
    }
}

