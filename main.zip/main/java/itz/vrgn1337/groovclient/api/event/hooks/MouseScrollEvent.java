/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class MouseScrollEvent
extends Event {
    private static final MouseScrollEvent INSTANCE = new MouseScrollEvent();
    public double horizontal;
    public double vertical;

    public static MouseScrollEvent get(double d2, double d3) {
        MouseScrollEvent.INSTANCE.horizontal = d2;
        MouseScrollEvent.INSTANCE.vertical = d3;
        return INSTANCE;
    }
}

