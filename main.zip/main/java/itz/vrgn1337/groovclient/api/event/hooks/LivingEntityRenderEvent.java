/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.model.Model;
import net.minecraft.client.util.math.MatrixStack;

public class LivingEntityRenderEvent
extends Event {
    private static final LivingEntityRenderEvent INSTANCE = new LivingEntityRenderEvent();
    public LivingEntityRenderState renderState;
    public OrderedRenderCommandQueue renderQueue;
    public Model model;
    public MatrixStack matrices;

    public static LivingEntityRenderEvent get(LivingEntityRenderState mc10, OrderedRenderCommandQueue mc11, Model mc12, MatrixStack mc13) {
        LivingEntityRenderEvent.INSTANCE.renderState = mc10;
        LivingEntityRenderEvent.INSTANCE.renderQueue = mc11;
        LivingEntityRenderEvent.INSTANCE.model = mc12;
        LivingEntityRenderEvent.INSTANCE.matrices = mc13;
        return INSTANCE;
    }
}

