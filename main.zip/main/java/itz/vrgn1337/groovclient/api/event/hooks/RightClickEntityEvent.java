/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

public class RightClickEntityEvent
extends Event {
    public PlayerEntity player;
    public Entity entity;
    public Hand hand;

    public static class Post extends RightClickEntityEvent {
    private static final RightClickEntityEvent.Post INSTANCE = new RightClickEntityEvent.Post();

    public static RightClickEntityEvent.Post get(PlayerEntity mc6, Entity mc2, Hand mc8) {
        RightClickEntityEvent.Post.INSTANCE.player = mc6;
        RightClickEntityEvent.Post.INSTANCE.entity = mc2;
        RightClickEntityEvent.Post.INSTANCE.hand = mc8;
        return INSTANCE;
    }
    }

    public static class Pre extends RightClickEntityEvent {
    private static final RightClickEntityEvent.Pre INSTANCE = new RightClickEntityEvent.Pre();

    public static RightClickEntityEvent.Pre get(PlayerEntity mc6, Entity mc2, Hand mc8) {
        RightClickEntityEvent.Pre.INSTANCE.player = mc6;
        RightClickEntityEvent.Pre.INSTANCE.entity = mc2;
        RightClickEntityEvent.Pre.INSTANCE.hand = mc8;
        return INSTANCE;
    }
    }
}

