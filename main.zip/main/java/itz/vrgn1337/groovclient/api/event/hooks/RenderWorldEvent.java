/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;

public class RenderWorldEvent
extends Event {

    public static class Post extends RenderWorldEvent {
    private static final RenderWorldEvent.Post INSTANCE = new RenderWorldEvent.Post();
    public MatrixStack matrices;
    public RenderTickCounter tickCounter;

    public static RenderWorldEvent.Post get(MatrixStack mc13, RenderTickCounter mc16) {
        RenderWorldEvent.Post.INSTANCE.matrices = mc13;
        RenderWorldEvent.Post.INSTANCE.tickCounter = mc16;
        return INSTANCE;
    }
    }

    public static class Pre extends RenderWorldEvent {
    private static final RenderWorldEvent.Pre INSTANCE = new RenderWorldEvent.Pre();
    public MatrixStack matrices;
    public RenderTickCounter tickCounter;

    public static RenderWorldEvent.Pre get(MatrixStack mc13, RenderTickCounter mc16) {
        RenderWorldEvent.Pre.INSTANCE.matrices = mc13;
        RenderWorldEvent.Pre.INSTANCE.tickCounter = mc16;
        return INSTANCE;
    }
    }
}

