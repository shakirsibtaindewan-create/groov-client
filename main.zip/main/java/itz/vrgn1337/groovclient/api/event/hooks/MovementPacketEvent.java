/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class MovementPacketEvent
extends Event {

    public static class Post extends MovementPacketEvent {
    private static final MovementPacketEvent.Post INSTANCE = new MovementPacketEvent.Post();

    public static MovementPacketEvent.Post getInstance() {
        return INSTANCE;
    }
    }

    public static class Pre extends MovementPacketEvent {
    private static final MovementPacketEvent.Pre INSTANCE = new MovementPacketEvent.Pre();

    public static MovementPacketEvent.Pre getInstance() {
        return INSTANCE;
    }
    }
}

