/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.util.math.ChunkPos;

public class ChunkEvent
extends Event {

    public static class Post extends ChunkEvent {
    private static final ChunkEvent.Post INSTANCE = new ChunkEvent.Post();
    public ChunkPos pos;

    public static ChunkEvent.Post get(ChunkPos mc4) {
        ChunkEvent.Post.INSTANCE.pos = mc4;
        return INSTANCE;
    }
    }

    public static class Pre extends ChunkEvent {
    private static final ChunkEvent.Pre INSTANCE = new ChunkEvent.Pre();
    public ChunkPos pos;

    public static ChunkEvent.Pre get(ChunkPos mc4) {
        ChunkEvent.Pre.INSTANCE.pos = mc4;
        return INSTANCE;
    }
    }
}

