/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class KeyEvent
extends Event {
    private static final KeyEvent INSTANCE = new KeyEvent();
    public long window;
    public int key;
    public int scancode;
    public int action;
    public int mods;

    public static KeyEvent get(long l2, int n2, int n3, int n4, int n5) {
        KeyEvent.INSTANCE.window = l2;
        KeyEvent.INSTANCE.key = n2;
        KeyEvent.INSTANCE.scancode = n3;
        KeyEvent.INSTANCE.action = n4;
        KeyEvent.INSTANCE.mods = n5;
        return INSTANCE;
    }
}

