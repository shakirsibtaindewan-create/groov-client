/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class MouseButtonEvent
extends Event {
    private static final MouseButtonEvent INSTANCE = new MouseButtonEvent();
    public long window;
    public int button;
    public int action;
    public int mods;

    public static MouseButtonEvent get(long l2, int n2, int n3, int n4) {
        MouseButtonEvent.INSTANCE.window = l2;
        MouseButtonEvent.INSTANCE.button = n2;
        MouseButtonEvent.INSTANCE.action = n3;
        MouseButtonEvent.INSTANCE.mods = n4;
        return INSTANCE;
    }
}

