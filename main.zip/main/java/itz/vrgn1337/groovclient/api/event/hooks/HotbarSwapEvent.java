/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class HotbarSwapEvent
extends Event {

    public static class Pre extends HotbarSwapEvent {
    private static final HotbarSwapEvent.Pre INSTANCE = new HotbarSwapEvent.Pre();
    public int slot;

    public static HotbarSwapEvent.Pre get(int n2) {
        INSTANCE.reset();
        HotbarSwapEvent.Pre.INSTANCE.slot = n2;
        return INSTANCE;
    }
    }
}

