/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.network.packet.Packet;

public class PacketReceiveEvent
extends Event {

    public static class Post extends PacketReceiveEvent {
    private static final PacketReceiveEvent.Post INSTANCE = new PacketReceiveEvent.Post();
    private Packet packet;

    public static PacketReceiveEvent.Post get(Packet mc14) {
        PacketReceiveEvent.Post.INSTANCE.packet = mc14;
        return INSTANCE;
    }

    public Packet getPacket() {
        return this.packet;
    }
    }

    public static class Pre extends PacketReceiveEvent {
    private static final PacketReceiveEvent.Pre INSTANCE = new PacketReceiveEvent.Pre();
    private Packet packet;

    public static PacketReceiveEvent.Pre get(Packet mc14) {
        PacketReceiveEvent.Pre.INSTANCE.packet = mc14;
        return INSTANCE;
    }

    public Packet getPacket() {
        return this.packet;
    }
    }
}

