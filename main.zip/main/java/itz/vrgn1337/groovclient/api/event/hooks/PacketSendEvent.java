/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.network.packet.Packet;

public class PacketSendEvent
extends Event {

    public static class Post extends PacketSendEvent {
    private static final PacketSendEvent.Post INSTANCE = new PacketSendEvent.Post();
    private Packet packet;

    public static PacketSendEvent.Post get(Packet mc14) {
        PacketSendEvent.Post.INSTANCE.packet = mc14;
        return INSTANCE;
    }

    public Packet getPacket() {
        return this.packet;
    }
    }

    public static class Pre extends PacketSendEvent {
    private static final PacketSendEvent.Pre INSTANCE = new PacketSendEvent.Pre();
    private Packet packet;

    public static PacketSendEvent.Pre get(Packet mc14) {
        PacketSendEvent.Pre.INSTANCE.packet = mc14;
        return INSTANCE;
    }

    public Packet getPacket() {
        return this.packet;
    }
    }
}

