/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.screen.slot.SlotActionType;

public class ClickSlotEvent
extends Event {

    public static class Post extends ClickSlotEvent {
    private static final ClickSlotEvent.Post INSTANCE = new ClickSlotEvent.Post();
    private int slotId;
    private int button;
    private SlotActionType actionType;

    public static ClickSlotEvent.Post get(int n2, int n3, SlotActionType mc5) {
        ClickSlotEvent.Post.INSTANCE.slotId = n2;
        ClickSlotEvent.Post.INSTANCE.button = n3;
        ClickSlotEvent.Post.INSTANCE.actionType = mc5;
        return INSTANCE;
    }

    public int getSlotId() {
        return this.slotId;
    }

    public int getButton() {
        return this.button;
    }

    public SlotActionType getActionType() {
        return this.actionType;
    }
    }

    public static class Pre extends ClickSlotEvent {
    private static final ClickSlotEvent.Pre INSTANCE = new ClickSlotEvent.Pre();
    private int slotId;
    private int button;
    private SlotActionType actionType;

    public static ClickSlotEvent.Pre get(int n2, int n3, SlotActionType mc5) {
        ClickSlotEvent.Pre.INSTANCE.slotId = n2;
        ClickSlotEvent.Pre.INSTANCE.button = n3;
        ClickSlotEvent.Pre.INSTANCE.actionType = mc5;
        return INSTANCE;
    }

    public int getSlotId() {
        return this.slotId;
    }

    public int getButton() {
        return this.button;
    }

    public SlotActionType getActionType() {
        return this.actionType;
    }
    }
}

