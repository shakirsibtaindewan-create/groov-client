/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.entity.player.PlayerEntity;

public class InteractEntityEvent
extends Event {

    public static class Post extends InteractEntityEvent {
    private static final InteractEntityEvent.Post INSTANCE = new InteractEntityEvent.Post();
    public PlayerEntity player;

    public static InteractEntityEvent.Post get(PlayerEntity mc6) {
        InteractEntityEvent.Post.INSTANCE.player = mc6;
        return INSTANCE;
    }
    }

    public static class Pre extends InteractEntityEvent {
    private static final InteractEntityEvent.Pre INSTANCE = new InteractEntityEvent.Pre();
    public PlayerEntity player;

    public static InteractEntityEvent.Pre get(PlayerEntity mc6) {
        InteractEntityEvent.Pre.INSTANCE.player = mc6;
        return INSTANCE;
    }
    }
}

