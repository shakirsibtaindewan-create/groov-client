/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class AnchorInteractEvent
extends Event {

    public static class Charge extends AnchorInteractEvent {
    private static final AnchorInteractEvent.Charge INSTANCE = new AnchorInteractEvent.Charge();

    public static AnchorInteractEvent.Charge getInstance() {
        return INSTANCE;
    }
    }

    public static class Explode extends AnchorInteractEvent {
    private static final AnchorInteractEvent.Explode INSTANCE = new AnchorInteractEvent.Explode();

    public static AnchorInteractEvent.Explode getInstance() {
        return INSTANCE;
    }
    }
}

