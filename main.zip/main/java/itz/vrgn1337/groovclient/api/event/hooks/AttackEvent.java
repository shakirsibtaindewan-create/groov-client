/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class AttackEvent
extends Event {

    public static class ManualCalledAttack extends AttackEvent {
    private static final AttackEvent.ManualCalledAttack INSTANCE = new AttackEvent.ManualCalledAttack();

    public static AttackEvent.ManualCalledAttack getInstance() {
        return INSTANCE;
    }
    }

    public static class Post extends AttackEvent {
    private static final AttackEvent.Post INSTANCE = new AttackEvent.Post();

    public static AttackEvent.Post getInstance() {
        return INSTANCE;
    }
    }

    public static class Pre extends AttackEvent {
    private static final AttackEvent.Pre INSTANCE = new AttackEvent.Pre();

    public static AttackEvent.Pre getInstance() {
        return INSTANCE;
    }
    }
}

