/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public class RenderHUDEvent
extends Event {

    public static class Post extends RenderHUDEvent {
    private static final RenderHUDEvent.Post INSTANCE = new RenderHUDEvent.Post();
    public DrawContext context;
    public RenderTickCounter tickCounter;

    public static RenderHUDEvent.Post get(DrawContext mc15, RenderTickCounter mc16) {
        RenderHUDEvent.Post.INSTANCE.context = mc15;
        RenderHUDEvent.Post.INSTANCE.tickCounter = mc16;
        return INSTANCE;
    }
    }

    public static class Pre extends RenderHUDEvent {
    private static final RenderHUDEvent.Pre INSTANCE = new RenderHUDEvent.Pre();
    public DrawContext context;
    public RenderTickCounter tickCounter;

    public static RenderHUDEvent.Pre get(DrawContext mc15, RenderTickCounter mc16) {
        RenderHUDEvent.Pre.INSTANCE.context = mc15;
        RenderHUDEvent.Pre.INSTANCE.tickCounter = mc16;
        return INSTANCE;
    }
    }
}

