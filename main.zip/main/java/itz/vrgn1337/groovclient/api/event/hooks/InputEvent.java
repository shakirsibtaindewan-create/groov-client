/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class InputEvent
extends Event {

    public static class CancellableInput extends InputEvent {
    private static final InputEvent.CancellableInput INSTANCE = new InputEvent.CancellableInput();
    public long window;
    public int key;
    public int action;

    public static InputEvent.CancellableInput get(long l2, int n2, int n3) {
        InputEvent.CancellableInput.INSTANCE.window = l2;
        InputEvent.CancellableInput.INSTANCE.key = n2;
        InputEvent.CancellableInput.INSTANCE.action = n3;
        return INSTANCE;
    }
    }

    public static class Press extends InputEvent {
    private static final InputEvent.Press INSTANCE = new InputEvent.Press();
    public long window;
    public int key;
    private boolean simulated;

    public static InputEvent.Press get(long l2, int n2, boolean bl) {
        InputEvent.Press.INSTANCE.window = l2;
        InputEvent.Press.INSTANCE.key = n2;
        InputEvent.Press.INSTANCE.simulated = bl;
        return INSTANCE;
    }

    public boolean isSimulated() {
        boolean bl = this.simulated;
        this.simulated = false;
        return bl;
    }
    }

    public static class Release extends InputEvent {
    private static final InputEvent.Release INSTANCE = new InputEvent.Release();
    public long window;
    public int key;
    private boolean simulated;

    public static InputEvent.Release get(long l2, int n2, boolean bl) {
        InputEvent.Release.INSTANCE.window = l2;
        InputEvent.Release.INSTANCE.key = n2;
        InputEvent.Release.INSTANCE.simulated = bl;
        return INSTANCE;
    }

    public boolean isSimulated() {
        boolean bl = this.simulated;
        this.simulated = false;
        return bl;
    }
    }
}

