/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class ItemUseEvent
extends Event {

    public static class Post extends ItemUseEvent {
    private static final ItemUseEvent.Post INSTANCE = new ItemUseEvent.Post();

    public static ItemUseEvent.Post getInstance() {
        return INSTANCE;
    }
    }

    public static class Pre extends ItemUseEvent {
    private static final ItemUseEvent.Pre INSTANCE = new ItemUseEvent.Pre();

    public static ItemUseEvent.Pre getInstance() {
        return INSTANCE;
    }
    }
}

