/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.network.AbstractClientPlayerEntity;

public class PlayerRenderEvent
extends Event {
    private static final PlayerRenderEvent INSTANCE = new PlayerRenderEvent();
    public AbstractClientPlayerEntity player;
    public LivingEntityRenderState renderState;

    public static PlayerRenderEvent get(AbstractClientPlayerEntity TrackedPosition, LivingEntityRenderState mc10) {
        PlayerRenderEvent.INSTANCE.player = TrackedPosition;
        PlayerRenderEvent.INSTANCE.renderState = mc10;
        return INSTANCE;
    }
}

