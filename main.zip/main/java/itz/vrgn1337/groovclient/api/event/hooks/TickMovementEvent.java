/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class TickMovementEvent
extends Event {

    public static class Post extends TickMovementEvent {
    private static final TickMovementEvent.Post INSTANCE = new TickMovementEvent.Post();

    public static TickMovementEvent.Post getInstance() {
        return INSTANCE;
    }
    }

    public static class Pre extends TickMovementEvent {
    private static final TickMovementEvent.Pre INSTANCE = new TickMovementEvent.Pre();

    public static TickMovementEvent.Pre getInstance() {
        return INSTANCE;
    }
    }
}

