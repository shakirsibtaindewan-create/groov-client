/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;

public class BlockStateEvent
extends Event {

    public static class Post extends BlockStateEvent {
    private static final BlockStateEvent.Post INSTANCE = new BlockStateEvent.Post();
    public BlockPos pos;
    public BlockState state;

    public static BlockStateEvent.Post get(BlockPos mc0, BlockState mc1) {
        BlockStateEvent.Post.INSTANCE.pos = mc0;
        BlockStateEvent.Post.INSTANCE.state = mc1;
        return INSTANCE;
    }
    }

    public static class Pre extends BlockStateEvent {
    private static final BlockStateEvent.Pre INSTANCE = new BlockStateEvent.Pre();
    public BlockPos pos;
    public BlockState state;

    public static BlockStateEvent.Pre get(BlockPos mc0, BlockState mc1) {
        BlockStateEvent.Pre.INSTANCE.pos = mc0;
        BlockStateEvent.Pre.INSTANCE.state = mc1;
        return INSTANCE;
    }
    }
}

