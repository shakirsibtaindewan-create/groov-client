/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event;

import itz.vrgn1337.groovclient.api.event.Event;
import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.SubscriberMethod;
import itz.vrgn1337.groovclient.entrypoint.Main;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

public final class EventBus {
    private final Map<Class<?>, List<SubscriberMethod>> handlerMap = new HashMap<>();
    private final Map<Object, List<SubscriberMethod>> registered = new HashMap<>();

    public void register(Object object) {
        this.register(object, 100);
    }

    public void register(Object object, int n2) {
        if (this.registered.containsKey(object)) {
            return;
        }
        ArrayList<SubscriberMethod> arrayList = new ArrayList<SubscriberMethod>();
        MethodHandles.Lookup lookup = MethodHandles.lookup();
        for (Method method : object.getClass().getDeclaredMethods()) {
            MethodHandle methodHandle;
            Class<?> clazz;
            if (method.getParameterCount() != 1 || !Event.class.isAssignableFrom(clazz = method.getParameterTypes()[0])) continue;
            method.setAccessible(true);
            int n3 = n2;
            Priority priority = method.getAnnotation(Priority.class);
            if (priority != null) {
                n3 = priority.value();
            }
            try {
                methodHandle = lookup.unreflect(method);
            }
            catch (IllegalAccessException illegalAccessException) {
                continue;
            }
            SubscriberMethod subscriberMethod = new SubscriberMethod(object, methodHandle, clazz, n3);
            this.handlerMap.computeIfAbsent(clazz, EventBus::lambda$register$0).add(subscriberMethod);
            arrayList.add(subscriberMethod);
        }
        for (SubscriberMethod subscriberMethod : arrayList) {
            this.handlerMap.get(subscriberMethod.c).sort(EventBus::lambda$register$1);
        }
        if (!arrayList.isEmpty()) {
            this.registered.put(object, arrayList);
        }
    }

    public void unregister(Object object) {
        List<SubscriberMethod> list = this.registered.remove(object);
        if (list == null) {
            return;
        }
        for (SubscriberMethod subscriberMethod : list) {
            List<SubscriberMethod> list2 = this.handlerMap.get(subscriberMethod.c);
            if (list2 == null) continue;
            list2.removeIf((Predicate<SubscriberMethod>)(SubscriberMethod p0) -> EventBus.lambda$unregister$2(object, p0));
        }
    }

    public void unregisterAll() {
        this.handlerMap.clear();
        this.registered.clear();
    }

    public Event post(Event event) {
        List<SubscriberMethod> list;
        if (Main.destroyed) {
            return event;
        }
        if (event.isUndo() && event.isCancelled()) {
            event.reset();
        }
        if (event.getTime() != 0L && System.currentTimeMillis() >= event.getTime() + event.getThreshold()) {
            event.reset();
        }
        if ((list = this.handlerMap.get(event.getClass())) == null) {
            return event;
        }
        ArrayList<SubscriberMethod> arrayList = new ArrayList(list);
        for (SubscriberMethod subscriberMethod : arrayList) {
            try {
                subscriberMethod.b.invoke(subscriberMethod.a, event);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (!event.isCancelled()) continue;
            return event;
        }
        return event;
    }

    private static boolean lambda$unregister$2(Object object, SubscriberMethod subscriberMethod) {
        return subscriberMethod.a == object;
    }

    private static int lambda$register$1(SubscriberMethod subscriberMethod, SubscriberMethod subscriberMethod2) {
        return Integer.compare(subscriberMethod2.d, subscriberMethod.d);
    }

    private static List lambda$register$0(Class clazz) {
        return new ArrayList();
    }
}

