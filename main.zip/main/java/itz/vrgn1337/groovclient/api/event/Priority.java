/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.METHOD})
public @interface Priority {
    public int value() default 100;
}

