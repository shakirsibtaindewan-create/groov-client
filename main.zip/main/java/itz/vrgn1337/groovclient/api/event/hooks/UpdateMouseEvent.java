/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class UpdateMouseEvent
extends Event {

    public static class Post extends UpdateMouseEvent {
    private static final UpdateMouseEvent.Post INSTANCE = new UpdateMouseEvent.Post();

    public static UpdateMouseEvent.Post getInstance() {
        return INSTANCE;
    }
    }

    public static class Pre extends UpdateMouseEvent {
    private static final UpdateMouseEvent.Pre INSTANCE = new UpdateMouseEvent.Pre();

    public static UpdateMouseEvent.Pre getInstance() {
        return INSTANCE;
    }
    }
}

