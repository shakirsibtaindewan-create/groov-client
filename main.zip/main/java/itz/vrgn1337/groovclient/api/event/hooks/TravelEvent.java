/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class TravelEvent
extends Event {

    public static class Post extends TravelEvent {
    private static final TravelEvent.Post INSTANCE = new TravelEvent.Post();

    public static TravelEvent.Post getInstance() {
        return INSTANCE;
    }
    }

    public static class Pre extends TravelEvent {
    private static final TravelEvent.Pre INSTANCE = new TravelEvent.Pre();

    public static TravelEvent.Pre getInstance() {
        return INSTANCE;
    }
    }
}

