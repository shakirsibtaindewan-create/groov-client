/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.util.math.BlockPos;

public class DestroyBlockEvent
extends Event {

    public static class Post extends DestroyBlockEvent {
    private static final DestroyBlockEvent.Post INSTANCE = new DestroyBlockEvent.Post();
    public BlockPos pos;

    public static DestroyBlockEvent.Post get(BlockPos mc0) {
        DestroyBlockEvent.Post.INSTANCE.pos = mc0;
        return INSTANCE;
    }
    }

    public static class Pre extends DestroyBlockEvent {
    private static final DestroyBlockEvent.Pre INSTANCE = new DestroyBlockEvent.Pre();
    public BlockPos pos;

    public static DestroyBlockEvent.Pre get(BlockPos mc0) {
        DestroyBlockEvent.Pre.INSTANCE.pos = mc0;
        return INSTANCE;
    }
    }
}

