/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class PlayerJumpEvent
extends Event {

    public static class Post extends PlayerJumpEvent {
    private static final PlayerJumpEvent.Post INSTANCE = new PlayerJumpEvent.Post();

    public static PlayerJumpEvent.Post getInstance() {
        return INSTANCE;
    }
    }

    public static class Pre extends PlayerJumpEvent {
    private static final PlayerJumpEvent.Pre INSTANCE = new PlayerJumpEvent.Pre();

    public static PlayerJumpEvent.Pre getInstance() {
        return INSTANCE;
    }
    }
}

