/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.util.math.Vec3d;

public class VelocityEvent
extends Event {

    public static class Post extends VelocityEvent {
    private static final VelocityEvent.Post INSTANCE = new VelocityEvent.Post();
    private double x;
    private double y;
    private double z;
    private float speed;
    private Vec3d velocity;

    public static VelocityEvent.Post get(double d2, double d3, double d4, float f2, Vec3d VanillaChestLootTableGenerator) {
        VelocityEvent.Post.INSTANCE.x = d2;
        VelocityEvent.Post.INSTANCE.y = d3;
        VelocityEvent.Post.INSTANCE.z = d4;
        VelocityEvent.Post.INSTANCE.speed = f2;
        VelocityEvent.Post.INSTANCE.velocity = VanillaChestLootTableGenerator;
        return INSTANCE;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    public double getZ() {
        return this.z;
    }

    public float getSpeed() {
        return this.speed;
    }

    public Vec3d getVelocity() {
        return this.velocity;
    }

    public void setX(double d2) {
        this.x = d2;
    }

    public void setY(double d2) {
        this.y = d2;
    }

    public void setZ(double d2) {
        this.z = d2;
    }

    public void setSpeed(float f2) {
        this.speed = f2;
    }

    public void setVelocity(Vec3d VanillaChestLootTableGenerator) {
        this.velocity = VanillaChestLootTableGenerator;
    }
    }

    public static class Pre extends VelocityEvent {
    private static final VelocityEvent.Pre INSTANCE = new VelocityEvent.Pre();
    private double x;
    private double y;
    private double z;
    private float speed;
    private Vec3d velocity;

    public static VelocityEvent.Pre get(double d2, double d3, double d4, float f2, Vec3d VanillaChestLootTableGenerator) {
        VelocityEvent.Pre.INSTANCE.x = d2;
        VelocityEvent.Pre.INSTANCE.y = d3;
        VelocityEvent.Pre.INSTANCE.z = d4;
        VelocityEvent.Pre.INSTANCE.speed = f2;
        VelocityEvent.Pre.INSTANCE.velocity = VanillaChestLootTableGenerator;
        return INSTANCE;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    public double getZ() {
        return this.z;
    }

    public float getSpeed() {
        return this.speed;
    }

    public Vec3d getVelocity() {
        return this.velocity;
    }

    public void setX(double d2) {
        this.x = d2;
    }

    public void setY(double d2) {
        this.y = d2;
    }

    public void setZ(double d2) {
        this.z = d2;
    }

    public void setSpeed(float f2) {
        this.speed = f2;
    }

    public void setVelocity(Vec3d VanillaChestLootTableGenerator) {
        this.velocity = VanillaChestLootTableGenerator;
    }
    }
}

