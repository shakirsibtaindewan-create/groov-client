/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class RenderSkyEvent
extends Event {
    private static final RenderSkyEvent INSTANCE = new RenderSkyEvent();

    public static RenderSkyEvent getInstance() {
        INSTANCE.reset();
        return INSTANCE;
    }
}

