/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.world.World;

public class ChangeWorldEvent
extends Event {

    public static class Post extends ChangeWorldEvent {
    private static final ChangeWorldEvent.Post INSTANCE = new ChangeWorldEvent.Post();
    public World world;

    public static ChangeWorldEvent.Post get(World mc3) {
        ChangeWorldEvent.Post.INSTANCE.world = mc3;
        return INSTANCE;
    }
    }

    public static class Pre extends ChangeWorldEvent {
    private static final ChangeWorldEvent.Pre INSTANCE = new ChangeWorldEvent.Pre();
    public World world;

    public static ChangeWorldEvent.Pre get(World mc3) {
        ChangeWorldEvent.Pre.INSTANCE.world = mc3;
        return INSTANCE;
    }
    }
}

