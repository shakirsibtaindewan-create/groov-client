/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;

public class BreakBlockEvent
extends Event {

    public static class Post extends BreakBlockEvent {
    private static final BreakBlockEvent.Post INSTANCE = new BreakBlockEvent.Post();

    public static BreakBlockEvent.Post getInstance() {
        return INSTANCE;
    }
    }

    public static class Pre extends BreakBlockEvent {
    private static final BreakBlockEvent.Pre INSTANCE = new BreakBlockEvent.Pre();

    public static BreakBlockEvent.Pre getInstance() {
        return INSTANCE;
    }
    }
}

