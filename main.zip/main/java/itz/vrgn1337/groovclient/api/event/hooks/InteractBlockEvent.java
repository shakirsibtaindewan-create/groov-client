/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;

public class InteractBlockEvent
extends Event {

    public static class Post extends InteractBlockEvent {
    private static final InteractBlockEvent.Post INSTANCE = new InteractBlockEvent.Post();
    public PlayerEntity player;
    public BlockHitResult hitResult;

    public static InteractBlockEvent.Post get(PlayerEntity mc6, BlockHitResult mc7) {
        InteractBlockEvent.Post.INSTANCE.player = mc6;
        InteractBlockEvent.Post.INSTANCE.hitResult = mc7;
        return INSTANCE;
    }
    }

    public static class Pre extends InteractBlockEvent {
    private static final InteractBlockEvent.Pre INSTANCE = new InteractBlockEvent.Pre();
    public PlayerEntity player;
    public BlockHitResult hitResult;

    public static InteractBlockEvent.Pre get(PlayerEntity mc6, BlockHitResult mc7) {
        InteractBlockEvent.Pre.INSTANCE.player = mc6;
        InteractBlockEvent.Pre.INSTANCE.hitResult = mc7;
        return INSTANCE;
    }
    }
}

