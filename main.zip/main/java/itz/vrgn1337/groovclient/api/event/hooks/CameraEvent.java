/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

public class CameraEvent
extends Event {

    public static class Post extends CameraEvent {
    private static final CameraEvent.Post INSTANCE = new CameraEvent.Post();
    public double x;
    public double y;
    public double z;
    public float yaw;
    public float pitch;
    private boolean posModified;
    private boolean rotationModified;

    public static CameraEvent.Post get(double d2, double d3, double d4, float f2, float f3) {
        CameraEvent.Post.INSTANCE.x = d2;
        CameraEvent.Post.INSTANCE.y = d3;
        CameraEvent.Post.INSTANCE.z = d4;
        CameraEvent.Post.INSTANCE.yaw = f2;
        CameraEvent.Post.INSTANCE.pitch = f3;
        CameraEvent.Post.INSTANCE.posModified = false;
        CameraEvent.Post.INSTANCE.rotationModified = false;
        INSTANCE.reset();
        return INSTANCE;
    }

    public void setPos(double d2, double d3, double d4) {
        this.x = d2;
        this.y = d3;
        this.z = d4;
        this.posModified = true;
    }

    public void setPos(Vec3d VanillaChestLootTableGenerator) {
        this.setPos(VanillaChestLootTableGenerator.x, VanillaChestLootTableGenerator.y, VanillaChestLootTableGenerator.z);
    }

    public void setRotation(float f2, float f3) {
        this.yaw = f2;
        this.pitch = f3;
        this.rotationModified = true;
    }

    public boolean isPosModified() {
        return this.posModified;
    }

    public boolean isRotationModified() {
        return this.rotationModified;
    }

    public Vec3d getPos() {
        return new Vec3d(this.x, this.y, this.z);
    }
    }

    public static class Pre extends CameraEvent {
    private static final CameraEvent.Pre INSTANCE = new CameraEvent.Pre();
    public Entity focusedEntity;
    public boolean thirdPerson;
    public boolean inverseView;
    public float tickDelta;

    public static CameraEvent.Pre get(Entity mc2, boolean bl, boolean bl2, float f2) {
        CameraEvent.Pre.INSTANCE.focusedEntity = mc2;
        CameraEvent.Pre.INSTANCE.thirdPerson = bl;
        CameraEvent.Pre.INSTANCE.inverseView = bl2;
        CameraEvent.Pre.INSTANCE.tickDelta = f2;
        INSTANCE.reset();
        return INSTANCE;
    }
    }
}

