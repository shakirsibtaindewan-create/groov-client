/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event.hooks;

import itz.vrgn1337.groovclient.api.event.Event;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

public class InteractItemEvent
extends Event {

    public static class Post extends InteractItemEvent {
    private static final InteractItemEvent.Post INSTANCE = new InteractItemEvent.Post();
    public PlayerEntity player;
    public Hand hand;

    public static InteractItemEvent.Post get(PlayerEntity mc6, Hand mc8) {
        InteractItemEvent.Post.INSTANCE.player = mc6;
        InteractItemEvent.Post.INSTANCE.hand = mc8;
        return INSTANCE;
    }
    }

    public static class Pre extends InteractItemEvent {
    private static final InteractItemEvent.Pre INSTANCE = new InteractItemEvent.Pre();
    public PlayerEntity player;
    public Hand hand;

    public static InteractItemEvent.Pre get(PlayerEntity mc6, Hand mc8) {
        InteractItemEvent.Pre.INSTANCE.player = mc6;
        InteractItemEvent.Pre.INSTANCE.hand = mc8;
        return INSTANCE;
    }
    }
}

