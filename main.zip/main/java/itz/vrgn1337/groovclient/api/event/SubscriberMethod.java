/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.api.event;

import java.lang.invoke.MethodHandle;

final class SubscriberMethod {
    final Object a;
    final MethodHandle b;
    final Class c;
    final int d;

    SubscriberMethod(Object object, MethodHandle methodHandle, Class clazz, int n2) {
        this.a = object;
        this.b = methodHandle;
        this.c = clazz;
        this.d = n2;
    }
}

