/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.entrypoint;

import itz.vrgn1337.groovclient.api.backend.BackendClient;
import itz.vrgn1337.groovclient.api.event.EventBus;
import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.util.ActionQueue;
import itz.vrgn1337.groovclient.api.util.BindManager;
import itz.vrgn1337.groovclient.api.util.SoundManager;
import itz.vrgn1337.groovclient.api.util.protection.NativeObfuscate;
import itz.vrgn1337.groovclient.api.util.render.Shaders;
import itz.vrgn1337.groovclient.b.c.HudManager;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudConfigRegistry;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import itz.vrgn1337.groovclient.module.ModuleManager;
import net.fabricmc.api.ModInitializer;
import net.minecraft.client.MinecraftClient;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;

public class Main
implements ModInitializer {
    public static final MinecraftClient mc = MinecraftClient.getInstance();
    public static volatile boolean destroyed = false;
    public static volatile boolean initialized = false;
    private static final Main INSTANCE = new Main();
    private static final EventBus EVENT_BUS = new EventBus();
    private volatile boolean autoLoginTried = false;

    public static Main getInstance() {
        return INSTANCE;
    }

    public static EventBus eventBus() {
        return EVENT_BUS;
    }

    @NativeObfuscate
    public void onInitialize() {
        if (initialized) {
            return;
        }
        try {
            SoundManager.a();
        }
        catch (Exception exception) {
            // empty catch block
        }
        BackendClient.getInstance().b();
        EVENT_BUS.register(this);
        BindManager.getInstance().b();
        ActionQueue.getInstance().b();
        ModuleManager.getInstance().b();
        MenuGuiScreen.getInstance().init();
        HudManager.getInstance().b();
        VanillaHudConfigRegistry.getInstance().b();
        initialized = true;
    }

    @Priority(value=0)
    public void onUpdateEventPost(UpdateEvent.Post updateEvent$Post) {
        if (!Shaders.z()) {
            Shaders.x();
        }
        if (!this.autoLoginTried && mc != null && Main.mc.keyboard != null) {
            this.autoLoginTried = true;
            try {
                BackendClient.getInstance().d();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }
}

