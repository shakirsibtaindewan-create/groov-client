/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.config;
public 
enum ConfigScreenMode {
    NONE, CONFIRM_LOAD, CREATE, EDIT, IMPORT;

    private ConfigScreenMode() {

    }

}

