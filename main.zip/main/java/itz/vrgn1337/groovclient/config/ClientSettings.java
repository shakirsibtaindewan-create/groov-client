/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.config;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import itz.vrgn1337.groovclient.api.backend.SocialService;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.config.ConfigCloudClient;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import itz.vrgn1337.groovclient.social.FriendManager;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.MinecraftClient;

public class ClientSettings {
    private static final ClientSettings a = new ClientSettings();
    private Color b = new Color(103, 177, 237, 255);
    private boolean c = false;
    private int d = 0;
    private boolean e = false;
    private int f = 0;
    private String g = "regular";
    private boolean h = false;
    private boolean i = false;
    private String j = null;
    private final Map<String, Boolean> k = new HashMap<>();
    private final Map<String, Boolean> l = new HashMap<>();

    public static ClientSettings getInstance() {
        return a;
    }

    private ClientSettings() {
    }

    public Color b() {
        return this.b;
    }

    public boolean c() {
        return this.c;
    }

    public int d() {
        return this.d;
    }

    public boolean e() {
        return this.e;
    }

    public int f() {
        return this.f;
    }

    public String g() {
        return this.g;
    }

    public boolean h() {
        return this.h;
    }

    public boolean i() {
        return this.i;
    }

    public String j() {
        return this.j;
    }

    public void a(Color color) {
        this.b = color;
        MenuGuiScreen.getInstance().a(color);
        this.n();
    }

    public void a(boolean bl) {
        this.c = bl;
        MenuGuiScreen.getInstance().a(bl);
        this.n();
    }

    public void a(int n2) {
        this.d = n2;
        this.l();
        this.n();
    }

    public void b(boolean bl) {
        this.e = bl;
        this.n();
    }

    public void b(int n2) {
        this.f = n2;
        this.n();
    }

    public void a(String string) {
        this.g = FontManager.c(string);
        FontManager.b(this.g);
        this.n();
    }

    public void b(String string) {
        this.j = string;
        this.n();
    }

    public void c(boolean bl) {
        this.h = bl;
        SocialService.getInstance().a(bl, this.i);
        this.n();
    }

    public void d(boolean bl) {
        this.i = bl;
        SocialService.getInstance().a(this.h, bl);
        this.n();
    }

    public void a(String string, float f2, float f3, boolean bl) {
        this.k.put(string, new float[]{f2, f3});
        this.l.put(string, bl);
    }

    public float[] c(String string) {
        return (float[])this.k.get(string);
    }

    public Boolean d(String string) {
        return (Boolean)this.l.get(string);
    }

    public void k() {
        this.n();
    }

    public void l() {
        RenderScale.a(this.d);
    }

    public void m() {
        MenuGuiScreen.getInstance().a(this.b);
        MenuGuiScreen.getInstance().a(this.c);
        this.l();
        FontManager.b(this.g);
    }

    public void n() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("color", String.format("#%02X%02X%02X%02X", this.b.getRed(), this.b.getGreen(), this.b.getBlue(), this.b.getAlpha()));
        jsonObject.addProperty("blur", Boolean.valueOf(this.c));
        jsonObject.addProperty("guiScale", (Number)this.d);
        jsonObject.addProperty("scrollbar", Boolean.valueOf(this.e));
        jsonObject.addProperty("guiMode", (Number)this.f);
        jsonObject.addProperty("font", this.g);
        jsonObject.addProperty("alwaysOffline", Boolean.valueOf(this.h));
        jsonObject.addProperty("ghostMode", Boolean.valueOf(this.i));
        if (this.j != null) {
            jsonObject.addProperty("defaultConfig", this.j);
        }
        JsonObject jsonObject2 = new JsonObject();
        for (Map.Entry entry : this.k.entrySet()) {
            JsonObject jsonObject3 = new JsonObject();
            jsonObject3.addProperty("x", (Number)Float.valueOf(((float[])entry.getValue())[0]));
            jsonObject3.addProperty("y", (Number)Float.valueOf(((float[])entry.getValue())[1]));
            jsonObject3.addProperty("expanded", this.l.getOrDefault(entry.getKey(), true));
            jsonObject2.add((String)entry.getKey(), (JsonElement)jsonObject3);
        }
        jsonObject.add("clickGuiPanels", (JsonElement)jsonObject2);
        JsonArray jsonArray = FriendManager.getInstance().c();
        jsonObject.add("friends", (JsonElement)jsonArray);
        ConfigCloudClient.getInstance().b(jsonObject.toString(), this::lambda$save$0, this::lambda$save$1);
    }

    public void o() {
        ConfigCloudClient.getInstance().b(arg_0 -> ((ClientSettings)this).lambda$load$3(arg_0), this::lambda$load$4);
    }

    private void e(String string) {
        try {
            String string2;
            if (string == null || string.isBlank() || string.equals("{}")) {
                return;
            }
            JsonObject jsonObject = JsonParser.parseString((String)string).getAsJsonObject();
            if (jsonObject.has("color") && (string2 = jsonObject.get("color").getAsString()).startsWith("#") && (string2.length() == 7 || string2.length() == 9)) {
                int n2 = Integer.parseInt(string2.substring(1, 3), 16);
                int n3 = Integer.parseInt(string2.substring(3, 5), 16);
                int n4 = Integer.parseInt(string2.substring(5, 7), 16);
                int n5 = string2.length() == 9 ? Integer.parseInt(string2.substring(7, 9), 16) : 255;
                this.b = new Color(n2, n3, n4, n5);
            }
            if (jsonObject.has("blur")) {
                this.c = jsonObject.get("blur").getAsBoolean();
            }
            if (jsonObject.has("guiScale")) {
                this.d = jsonObject.get("guiScale").getAsInt();
            }
            if (jsonObject.has("scrollbar")) {
                this.e = jsonObject.get("scrollbar").getAsBoolean();
            }
            if (jsonObject.has("guiMode")) {
                this.f = jsonObject.get("guiMode").getAsInt();
            }
            if (jsonObject.has("font")) {
                this.g = FontManager.c(jsonObject.get("font").getAsString());
            }
            if (jsonObject.has("alwaysOffline")) {
                this.h = jsonObject.get("alwaysOffline").getAsBoolean();
            }
            if (jsonObject.has("ghostMode")) {
                this.i = jsonObject.get("ghostMode").getAsBoolean();
            }
            if (jsonObject.has("defaultConfig")) {
                this.j = jsonObject.get("defaultConfig").getAsString();
            }
            if (jsonObject.has("clickGuiPanels")) {
                string2 = jsonObject.getAsJsonObject("clickGuiPanels");
                this.k.clear();
                this.l.clear();
                for (Map.Entry entry : string2.entrySet()) {
                    JsonObject jsonObject2 = ((JsonElement)entry.getValue()).getAsJsonObject();
                    float f2 = jsonObject2.has("x") ? jsonObject2.get("x").getAsFloat() : 0.0f;
                    float f3 = jsonObject2.has("y") ? jsonObject2.get("y").getAsFloat() : 0.0f;
                    boolean bl = !jsonObject2.has("expanded") || jsonObject2.get("expanded").getAsBoolean();
                    this.k.put((String)entry.getKey(), new float[]{f2, f3});
                    this.l.put((String)entry.getKey(), bl);
                }
            }
            if (jsonObject.has("friends") && jsonObject.get("friends").isJsonArray()) {
                FriendManager.getInstance().a(jsonObject.getAsJsonArray("friends"));
            } else {
                FriendManager.getInstance().a(false);
            }
            SocialService.getInstance().a(this.h, this.i);
            this.m();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static void lambda$load$4(String string) {
    }

    private void lambda$load$3(String string) {
        MinecraftClient.getInstance().execute(() -> ((ClientSettings)this).lambda$load$2((String)string));
    }

    private void lambda$load$2(String string) {
        this.e(string);
    }

    private static void lambda$save$1(String string) {
    }

    private static void lambda$save$0(String string) {
    }
}

