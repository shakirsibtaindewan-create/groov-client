/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.config;

import itz.vrgn1337.groovclient.config.ConfigCloudClient;
import itz.vrgn1337.groovclient.config.ConfigEntry;
import itz.vrgn1337.groovclient.config.ConfigSerializer;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;

public class ConfigManager {
    private static final ConfigManager a = new ConfigManager();
    private final List b = new ArrayList();
    private ConfigEntry c = null;
    private volatile boolean d = false;

    public static ConfigManager getInstance() {
        return a;
    }

    private ConfigManager() {
    }

    public List b() {
        return this.b;
    }

    public ConfigEntry c() {
        return this.c;
    }

    public boolean d() {
        return this.d;
    }

    public void a(ConfigEntry configEntry) {
        this.b.add(configEntry);
    }

    public void b(ConfigEntry configEntry) {
        this.b.remove(configEntry);
        if (this.c == configEntry) {
            this.c = null;
        }
    }

    public void a(Runnable runnable, Consumer consumer) {
        this.d = true;
        ConfigCloudClient.getInstance().a(arg_0 -> ((ConfigManager)this).lambda$refreshFromCloud$1((Runnable)runnable, arg_0), arg_0 -> ((ConfigManager)this).lambda$refreshFromCloud$3((Consumer)consumer, arg_0));
    }

    public void a(ConfigEntry configEntry, Runnable runnable, Consumer consumer) {
        this.d = true;
        String string = ConfigSerializer.a();
        ConfigCloudClient.getInstance().a(configEntry.c(), configEntry.d() != null ? configEntry.d() : "", string, configEntry.b() ? configEntry.a() : null, arg_0 -> ((ConfigManager)this).lambda$cloudSave$5((ConfigEntry)configEntry, (Runnable)runnable, arg_0), arg_0 -> ((ConfigManager)this).lambda$cloudSave$7((Consumer)consumer, arg_0));
    }

    public void b(ConfigEntry configEntry, Runnable runnable, Consumer consumer) {
        if (!configEntry.b()) {
            if (consumer != null) {
                consumer.accept("Config not saved yet");
            }
            return;
        }
        this.d = true;
        ConfigCloudClient.getInstance().a(configEntry.a(), arg_0 -> ((ConfigManager)this).lambda$cloudLoad$9((ConfigEntry)configEntry, (Runnable)runnable, arg_0), arg_0 -> ((ConfigManager)this).lambda$cloudLoad$11((Consumer)consumer, arg_0));
    }

    public void a(String string, Runnable runnable, Consumer consumer) {
        if (string == null || string.isEmpty()) {
            if (consumer != null) {
                consumer.accept("Empty ID");
            }
            return;
        }
        this.d = true;
        ConfigCloudClient.getInstance().a(string, arg_0 -> ((ConfigManager)this).lambda$cloudImport$13((String)string, (Runnable)runnable, (Consumer)consumer, arg_0), arg_0 -> ((ConfigManager)this).lambda$cloudImport$15((Consumer)consumer, arg_0));
    }

    public void c(ConfigEntry configEntry, Runnable runnable, Consumer consumer) {
        if (!configEntry.b()) {
            this.b(configEntry);
            if (runnable != null) {
                runnable.run();
            }
            return;
        }
        this.d = true;
        ConfigCloudClient.getInstance().c(configEntry.a(), arg_0 -> ((ConfigManager)this).lambda$cloudDelete$17((ConfigEntry)configEntry, (Runnable)runnable, arg_0), arg_0 -> ((ConfigManager)this).lambda$cloudDelete$19((Consumer)consumer, arg_0));
    }

    private void lambda$cloudDelete$19(Consumer consumer, String string) {
        MinecraftClient.getInstance().execute(() -> ((ConfigManager)this).lambda$cloudDelete$18((Consumer)consumer, (String)string));
    }

    private void lambda$cloudDelete$18(Consumer consumer, String string) {
        this.d = false;
        if (consumer != null) {
            consumer.accept(string);
        }
    }

    private void lambda$cloudDelete$17(ConfigEntry configEntry, Runnable runnable, String string) {
        MinecraftClient.getInstance().execute(() -> ((ConfigManager)this).lambda$cloudDelete$16((ConfigEntry)configEntry, (Runnable)runnable));
    }

    private void lambda$cloudDelete$16(ConfigEntry configEntry, Runnable runnable) {
        this.b(configEntry);
        this.d = false;
        if (runnable != null) {
            runnable.run();
        }
    }

    private void lambda$cloudImport$15(Consumer consumer, String string) {
        MinecraftClient.getInstance().execute(() -> ((ConfigManager)this).lambda$cloudImport$14((Consumer)consumer, (String)string));
    }

    private void lambda$cloudImport$14(Consumer consumer, String string) {
        this.d = false;
        if (consumer != null) {
            consumer.accept(string);
        }
    }

    private void lambda$cloudImport$13(String string, Runnable runnable, Consumer consumer, String string2) {
        MinecraftClient.getInstance().execute(() -> ((ConfigManager)this).lambda$cloudImport$12((String)string2, (String)string, (Runnable)runnable, (Consumer)consumer));
    }

    private void lambda$cloudImport$12(String string, String string2, Runnable runnable, Consumer consumer) {
        ConfigSerializer.a(string);
        String string3 = string2.length() >= 8 ? string2.substring(0, 8) : string2;
        ConfigEntry configEntry = new ConfigEntry("Imported " + string3, "");
        this.run(configEntry, runnable, consumer);
    }

    private void lambda$cloudLoad$11(Consumer consumer, String string) {
        MinecraftClient.getInstance().execute(() -> ((ConfigManager)this).lambda$cloudLoad$10((Consumer)consumer, (String)string));
    }

    private void lambda$cloudLoad$10(Consumer consumer, String string) {
        this.d = false;
        if (consumer != null) {
            consumer.accept(string);
        }
    }

    private void lambda$cloudLoad$9(ConfigEntry configEntry, Runnable runnable, String string) {
        MinecraftClient.getInstance().execute(() -> ((ConfigManager)this).lambda$cloudLoad$8((String)string, (ConfigEntry)configEntry, (Runnable)runnable));
    }

    private void lambda$cloudLoad$8(String string, ConfigEntry configEntry, Runnable runnable) {
        ConfigSerializer.a(string);
        this.c = configEntry;
        this.d = false;
        if (runnable != null) {
            runnable.run();
        }
    }

    private void lambda$cloudSave$7(Consumer consumer, String string) {
        MinecraftClient.getInstance().execute(() -> ((ConfigManager)this).lambda$cloudSave$6((Consumer)consumer, (String)string));
    }

    private void lambda$cloudSave$6(Consumer consumer, String string) {
        this.d = false;
        if (consumer != null) {
            consumer.accept(string);
        }
    }

    private void lambda$cloudSave$5(ConfigEntry configEntry, Runnable runnable, String string) {
        MinecraftClient.getInstance().execute(() -> ((ConfigManager)this).lambda$cloudSave$4((ConfigEntry)configEntry, (String)string, (Runnable)runnable));
    }

    private void lambda$cloudSave$4(ConfigEntry configEntry, String string, Runnable runnable) {
        configEntry.a(string);
        if (!this.b.contains(configEntry)) {
            this.b.add(configEntry);
        }
        this.c = configEntry;
        this.d = false;
        if (runnable != null) {
            runnable.run();
        }
    }

    private void lambda$refreshFromCloud$3(Consumer consumer, String string) {
        MinecraftClient.getInstance().execute(() -> ((ConfigManager)this).lambda$refreshFromCloud$2((Consumer)consumer, (String)string));
    }

    private void lambda$refreshFromCloud$2(Consumer consumer, String string) {
        this.d = false;
        if (consumer != null) {
            consumer.accept(string);
        }
    }

    private void lambda$refreshFromCloud$1(Runnable runnable, List list) {
        MinecraftClient.getInstance().execute(() -> ((ConfigManager)this).lambda$refreshFromCloud$0((List)list, (Runnable)runnable));
    }

    private void lambda$refreshFromCloud$0(List list, Runnable runnable) {
        this.b.clear();
        this.b.addAll(list);
        this.d = false;
        if (runnable != null) {
            runnable.run();
        }
    }
}

