/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.config;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import itz.vrgn1337.groovclient.b.c.HudElementSettings;
import itz.vrgn1337.groovclient.b.c.HudManager;
import itz.vrgn1337.groovclient.b.c.HudWidget;
import itz.vrgn1337.groovclient.config.ClientSettings;
import itz.vrgn1337.groovclient.gui.hud.CrosshairConfig;
import itz.vrgn1337.groovclient.gui.hud.CrosshairShape;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudConfigRegistry;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudElementSettings;
import itz.vrgn1337.groovclient.macro.MacroInputAction;
import itz.vrgn1337.groovclient.macro.MacroProfile;
import itz.vrgn1337.groovclient.macro.MacroStep;
import itz.vrgn1337.groovclient.macro.MacroStepType;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleManager;
import itz.vrgn1337.groovclient.module.utility.Macros;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.HotbarSlotSetting;
import itz.vrgn1337.groovclient.setting.ItemListSetting;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.awt.Color;
import java.util.List;
import java.util.Map;
import net.minecraft.client.MinecraftClient;

public final class ConfigSerializer {
    private static final Gson a = new Gson();
    private static final String b = "";

    private static String a(Module module) {
        String string = module.getName().a();
        StringBuilder stringBuilder = new StringBuilder();
        for (int j = 0; j < string.length(); ++j) {
            char c2 = string.charAt(j);
            if (b.indexOf(c2) >= 0) continue;
            if (stringBuilder.length() > 0) {
                stringBuilder.append(';');
            }
            stringBuilder.append((int)c2);
        }
        return stringBuilder.toString();
    }

    private ConfigSerializer() {
    }

    public static String a() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.add("modules", (JsonElement)ConfigSerializer.b());
        jsonObject.add("hud", (JsonElement)ConfigSerializer.c());
        jsonObject.add("vanillaHud", (JsonElement)ConfigSerializer.d());
        jsonObject.add("crosshair", (JsonElement)ConfigSerializer.e());
        jsonObject.add("macros", (JsonElement)ConfigSerializer.f());
        Color color = ClientSettings.getInstance().b();
        jsonObject.addProperty("themeColor", String.format("#%02X%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()));
        return a.toJson((JsonElement)jsonObject);
    }

    private static JsonObject b() {
        JsonObject jsonObject = new JsonObject();
        for (Module module : ModuleManager.c()) {
            JsonObject jsonObject2 = new JsonObject();
            jsonObject2.addProperty("e", Boolean.valueOf(module.isEnabled()));
            JsonArray jsonArray = new JsonArray();
            for (Setting setting : module.getSettings()) {
                jsonArray.add(ConfigSerializer.a(setting));
            }
            jsonObject2.add("s", (JsonElement)jsonArray);
            jsonObject.add(ConfigSerializer.a(module), (JsonElement)jsonObject2);
        }
        return jsonObject;
    }

    private static JsonElement a(Setting setting) {
        if (setting instanceof KeybindSetting) {
            KeybindSetting keybindSetting = (KeybindSetting)setting;
            return new JsonPrimitive((Number)keybindSetting.getKey());
        }
        if (setting instanceof FloatSetting) {
            FloatSetting floatSetting = (FloatSetting)setting;
            return new JsonPrimitive((Number)Float.valueOf(floatSetting.getValue()));
        }
        if (setting instanceof BooleanSetting) {
            BooleanSetting booleanSetting = (BooleanSetting)setting;
            return new JsonPrimitive(Boolean.valueOf(booleanSetting.getValue()));
        }
        if (setting instanceof ColorSetting) {
            ColorSetting colorSetting = (ColorSetting)setting;
            Color color = colorSetting.d();
            return new JsonPrimitive(String.format("#%02X%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()));
        }
        if (setting instanceof DoubleSetting) {
            DoubleSetting doubleSetting = (DoubleSetting)setting;
            return new JsonPrimitive(doubleSetting.d() + ";" + doubleSetting.f());
        }
        if (setting instanceof HotbarSlotSetting) {
            HotbarSlotSetting hotbarSlotSetting = (HotbarSlotSetting)setting;
            boolean[] blArray = hotbarSlotSetting.d();
            StringBuilder stringBuilder = new StringBuilder();
            for (int j = 0; j < blArray.length; ++j) {
                if (j > 0) {
                    stringBuilder.append(';');
                }
                stringBuilder.append(blArray[j]);
            }
            return new JsonPrimitive(stringBuilder.toString());
        }
        if (setting instanceof ItemListSetting) {
            ItemListSetting itemListSetting = (ItemListSetting)setting;
            return new JsonPrimitive(itemListSetting.d());
        }
        if (setting instanceof ModeSetting) {
            ModeSetting modeSetting = (ModeSetting)setting;
            if (modeSetting.isMulti()) {
                StringBuilder stringBuilder = new StringBuilder();
                for (int j = 0; j < modeSetting.getModes().length; ++j) {
                    if (!modeSetting.isSelected(j)) continue;
                    if (stringBuilder.length() > 0) {
                        stringBuilder.append(';');
                    }
                    stringBuilder.append(j);
                }
                return new JsonPrimitive(stringBuilder.toString());
            }
            return new JsonPrimitive((Number)modeSetting.getIndex());
        }
        return JsonNull.INSTANCE;
    }

    private static JsonArray c() {
        JsonArray jsonArray = new JsonArray();
        for (HudElementSettings hudElementSettings : HudManager.getInstance().c()) {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("type", (Number)hudElementSettings.a().ordinal());
            jsonObject.addProperty("x", (Number)Float.valueOf(hudElementSettings.b()));
            jsonObject.addProperty("y", (Number)Float.valueOf(hudElementSettings.c()));
            jsonObject.addProperty("w", (Number)Float.valueOf(hudElementSettings.d()));
            jsonObject.addProperty("h", (Number)Float.valueOf(hudElementSettings.e()));
            Map map = hudElementSettings.f();
            if (!map.isEmpty()) {
                JsonObject jsonObject2 = new JsonObject();
                map.forEach((arg_0, arg_1) -> ((JsonObject)jsonObject2).addProperty(arg_0, arg_1));
                jsonObject.add("options", (JsonElement)jsonObject2);
            }
            jsonArray.add((JsonElement)jsonObject);
        }
        return jsonArray;
    }

    public static void a(String string) {
        if (string == null || string.isBlank()) {
            return;
        }
        try {
            Object object;
            JsonObject jsonObject = JsonParser.parseString((String)string).getAsJsonObject();
            if (jsonObject.has("modules")) {
                ConfigSerializer.a(jsonObject.getAsJsonObject("modules"));
            }
            if (jsonObject.has("hud")) {
                ConfigSerializer.a(jsonObject.getAsJsonArray("hud"));
            }
            if (jsonObject.has("vanillaHud")) {
                ConfigSerializer.b(jsonObject.getAsJsonObject("vanillaHud"));
            }
            if (jsonObject.has("crosshair")) {
                ConfigSerializer.c(jsonObject.getAsJsonObject("crosshair"));
            }
            if (jsonObject.has("macros")) {
                ConfigSerializer.b(jsonObject.getAsJsonArray("macros"));
            }
            if (jsonObject.has("themeColor") && ((String)(object = jsonObject.get("themeColor").getAsString())).startsWith("#") && (((String)object).length() == 7 || ((String)object).length() == 9)) {
                int n2 = Integer.parseInt(((String)object).substring(1, 3), 16);
                int n3 = Integer.parseInt(((String)object).substring(3, 5), 16);
                int n4 = Integer.parseInt(((String)object).substring(5, 7), 16);
                int n5 = ((String)object).length() == 9 ? Integer.parseInt(((String)object).substring(7, 9), 16) : 255;
                ClientSettings.getInstance().a(new Color(n2, n3, n4, n5));
            }
            object = MinecraftClient.getInstance();
            object.execute(() -> this.lambda$deserialize$0((MinecraftClient)object));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static void a(JsonObject jsonObject) {
        List list = ModuleManager.c();
        for (int j = 0; j < list.size(); ++j) {
            JsonArray jsonArray;
            String string = ConfigSerializer.a((Module)list.get(j));
            if (!jsonObject.has(string)) continue;
            JsonObject jsonObject2 = jsonObject.getAsJsonObject(string);
            Module module = (Module)list.get(j);
            if (jsonObject2.has("e")) {
                module.b(jsonObject2.get("e").getAsBoolean());
            }
            if ((jsonArray = jsonObject2.getAsJsonArray("s")) == null) continue;
            List list2 = module.getSettings();
            for (int i2 = 0; i2 < Math.min(jsonArray.size(), list2.size()); ++i2) {
                JsonElement jsonElement = jsonArray.get(i2);
                if (jsonElement.isJsonNull()) continue;
                ConfigSerializer.a((Setting)list2.get(i2), jsonElement);
            }
        }
    }

    private static void a(Setting setting, JsonElement jsonElement) {
        try {
            if (setting instanceof KeybindSetting) {
                KeybindSetting keybindSetting = (KeybindSetting)setting;
                keybindSetting.setKey(jsonElement.getAsInt());
            } else if (setting instanceof FloatSetting) {
                FloatSetting floatSetting = (FloatSetting)setting;
                floatSetting.setValue(jsonElement.getAsFloat());
            } else if (setting instanceof BooleanSetting) {
                BooleanSetting booleanSetting = (BooleanSetting)setting;
                booleanSetting.setValue(jsonElement.getAsBoolean());
            } else if (setting instanceof ColorSetting) {
                ColorSetting colorSetting = (ColorSetting)setting;
                String string = jsonElement.getAsString();
                if (string.startsWith("#") && (string.length() == 7 || string.length() == 9)) {
                    int n2 = Integer.parseInt(string.substring(1, 3), 16);
                    int n3 = Integer.parseInt(string.substring(3, 5), 16);
                    int n4 = Integer.parseInt(string.substring(5, 7), 16);
                    int n5 = string.length() == 9 ? Integer.parseInt(string.substring(7, 9), 16) : 255;
                    colorSetting.a(new Color(n2, n3, n4, n5));
                }
            } else if (setting instanceof DoubleSetting) {
                DoubleSetting doubleSetting = (DoubleSetting)setting;
                String[] stringArray = jsonElement.getAsString().split(";");
                if (stringArray.length == 2) {
                    doubleSetting.a(Float.parseFloat(stringArray[0]), Float.parseFloat(stringArray[1]));
                }
            } else if (setting instanceof HotbarSlotSetting) {
                HotbarSlotSetting hotbarSlotSetting = (HotbarSlotSetting)setting;
                String[] stringArray = jsonElement.getAsString().split(";");
                for (int j = 0; j < Math.min(stringArray.length, 9); ++j) {
                    hotbarSlotSetting.a(j, Boolean.parseBoolean(stringArray[j]));
                }
            } else if (setting instanceof ItemListSetting) {
                ItemListSetting itemListSetting = (ItemListSetting)setting;
                itemListSetting.a(jsonElement.getAsString());
            } else if (setting instanceof ModeSetting) {
                ModeSetting modeSetting = (ModeSetting)setting;
                if (modeSetting.isMulti()) {
                    modeSetting.getSelectedSet().clear();
                    String string = jsonElement.getAsString();
                    if (!string.isEmpty()) {
                        for (String string2 : string.split(";")) {
                            int n6;
                            if (string2.isEmpty() || (n6 = Integer.parseInt(string2.trim())) < 0 || n6 >= modeSetting.getModes().length) continue;
                            modeSetting.toggleIndex(n6);
                        }
                    }
                    if (modeSetting.getSelectedSet().isEmpty()) {
                        modeSetting.toggleIndex(modeSetting.getIndex());
                    }
                } else {
                    modeSetting.setIndex(jsonElement.getAsInt());
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static JsonObject d() {
        JsonObject jsonObject = new JsonObject();
        for (VanillaHudElementSettings vanillaHudElementSettings : VanillaHudConfigRegistry.getInstance().c()) {
            JsonObject jsonObject2 = new JsonObject();
            jsonObject2.addProperty("x", (Number)Float.valueOf(vanillaHudElementSettings.h()));
            jsonObject2.addProperty("y", (Number)Float.valueOf(vanillaHudElementSettings.i()));
            jsonObject2.addProperty("s", (Number)Float.valueOf(vanillaHudElementSettings.j()));
            jsonObject2.addProperty("bgColor", String.format("#%08X", vanillaHudElementSettings.k()));
            jsonObject2.addProperty("bgRadius", (Number)Float.valueOf(vanillaHudElementSettings.l()));
            jsonObject2.addProperty("bgPadding", (Number)Float.valueOf(vanillaHudElementSettings.m()));
            JsonObject jsonObject3 = new JsonObject();
            vanillaHudElementSettings.o().forEach((arg_0, arg_1) -> ((JsonObject)jsonObject3).addProperty(arg_0, arg_1));
            jsonObject2.add("opts", (JsonElement)jsonObject3);
            if (!vanillaHudElementSettings.p().isEmpty()) {
                JsonObject jsonObject4 = new JsonObject();
                vanillaHudElementSettings.p().forEach((arg_0, arg_1) -> ((JsonObject)jsonObject4).addProperty(arg_0, arg_1));
                jsonObject2.add("extras", (JsonElement)jsonObject4);
            }
            jsonObject.add(vanillaHudElementSettings.g().name(), (JsonElement)jsonObject2);
        }
        return jsonObject;
    }

    private static void b(JsonObject jsonObject) {
        for (VanillaHudElementSettings vanillaHudElementSettings : VanillaHudConfigRegistry.getInstance().c()) {
            String string;
            String string2 = vanillaHudElementSettings.g().name();
            if (!jsonObject.has(string2)) continue;
            JsonObject jsonObject2 = jsonObject.getAsJsonObject(string2);
            if (jsonObject2.has("x")) {
                vanillaHudElementSettings.a(jsonObject2.get("x").getAsFloat());
            }
            if (jsonObject2.has("y")) {
                vanillaHudElementSettings.b(jsonObject2.get("y").getAsFloat());
            }
            if (jsonObject2.has("s")) {
                vanillaHudElementSettings.c(jsonObject2.get("s").getAsFloat());
            }
            if (jsonObject2.has("bgColor") && (string = jsonObject2.get("bgColor").getAsString()) != null && string.startsWith("#")) {
                try {
                    vanillaHudElementSettings.a((int)Long.parseLong(string.substring(1), 16));
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            if (jsonObject2.has("bgRadius")) {
                vanillaHudElementSettings.d(jsonObject2.get("bgRadius").getAsFloat());
            }
            if (jsonObject2.has("bgPadding")) {
                vanillaHudElementSettings.e(jsonObject2.get("bgPadding").getAsFloat());
            }
            if (jsonObject2.has("opts")) {
                string = jsonObject2.getAsJsonObject("opts");
                for (Map.Entry entry : string.entrySet()) {
                    try {
                        vanillaHudElementSettings.a((String)entry.getKey(), ((JsonElement)entry.getValue()).getAsBoolean());
                    }
                    catch (Exception exception) {}
                }
            }
            if (!jsonObject2.has("extras")) continue;
            string = jsonObject2.getAsJsonObject("extras");
            for (Map.Entry entry : string.entrySet()) {
                try {
                    vanillaHudElementSettings.b((String)entry.getKey(), ((JsonElement)entry.getValue()).getAsString());
                }
                catch (Exception exception) {}
            }
        }
    }

    private static JsonObject e() {
        CrosshairConfig crosshairConfig = CrosshairConfig.getInstance();
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("enabled", Boolean.valueOf(crosshairConfig.b()));
        jsonObject.addProperty("shape", crosshairConfig.c().name());
        jsonObject.addProperty("length", (Number)Float.valueOf(crosshairConfig.d()));
        jsonObject.addProperty("thickness", (Number)Float.valueOf(crosshairConfig.e()));
        jsonObject.addProperty("gap", (Number)Float.valueOf(crosshairConfig.f()));
        jsonObject.addProperty("color", ConfigSerializer.a(crosshairConfig.g()));
        jsonObject.addProperty("hitMarker", Boolean.valueOf(crosshairConfig.h()));
        jsonObject.addProperty("hitFadeMs", (Number)Float.valueOf(crosshairConfig.i()));
        jsonObject.addProperty("hitColor", ConfigSerializer.a(crosshairConfig.j()));
        jsonObject.addProperty("dot", Boolean.valueOf(crosshairConfig.k()));
        jsonObject.addProperty("dotSize", (Number)Float.valueOf(crosshairConfig.l()));
        jsonObject.addProperty("dynamic", Boolean.valueOf(crosshairConfig.m()));
        jsonObject.addProperty("dynamicSpread", (Number)Float.valueOf(crosshairConfig.n()));
        return jsonObject;
    }

    private static void c(JsonObject jsonObject) {
        CrosshairConfig crosshairConfig = CrosshairConfig.getInstance();
        try {
            if (jsonObject.has("enabled")) {
                crosshairConfig.getInstance(jsonObject.get("enabled").getAsBoolean());
            }
            if (jsonObject.has("shape")) {
                try {
                    crosshairConfig.getInstance(CrosshairShape.valueOf(jsonObject.get("shape").getAsString()));
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            if (jsonObject.has("length")) {
                crosshairConfig.getInstance(jsonObject.get("length").getAsFloat());
            }
            if (jsonObject.has("thickness")) {
                crosshairConfig.b(jsonObject.get("thickness").getAsFloat());
            }
            if (jsonObject.has("gap")) {
                crosshairConfig.c(jsonObject.get("gap").getAsFloat());
            }
            if (jsonObject.has("color")) {
                crosshairConfig.getInstance(ConfigSerializer.a(jsonObject.get("color").getAsString(), Color.WHITE));
            }
            if (jsonObject.has("hitMarker")) {
                crosshairConfig.b(jsonObject.get("hitMarker").getAsBoolean());
            }
            if (jsonObject.has("hitFadeMs")) {
                crosshairConfig.d(jsonObject.get("hitFadeMs").getAsFloat());
            }
            if (jsonObject.has("hitColor")) {
                crosshairConfig.b(ConfigSerializer.a(jsonObject.get("hitColor").getAsString(), new Color(255, 60, 60)));
            }
            if (jsonObject.has("dot")) {
                crosshairConfig.c(jsonObject.get("dot").getAsBoolean());
            }
            if (jsonObject.has("dotSize")) {
                crosshairConfig.e(jsonObject.get("dotSize").getAsFloat());
            }
            if (jsonObject.has("dynamic")) {
                crosshairConfig.d(jsonObject.get("dynamic").getAsBoolean());
            }
            if (jsonObject.has("dynamicSpread")) {
                crosshairConfig.f(jsonObject.get("dynamicSpread").getAsFloat());
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static String a(Color color) {
        return String.format("#%02X%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }

    private static Color a(String string, Color color) {
        if (string == null || !string.startsWith("#")) {
            return color;
        }
        try {
            if (string.length() == 7) {
                int n2 = Integer.parseInt(string.substring(1, 3), 16);
                int n3 = Integer.parseInt(string.substring(3, 5), 16);
                int n4 = Integer.parseInt(string.substring(5, 7), 16);
                return new Color(n2, n3, n4, 255);
            }
            if (string.length() == 9) {
                int n5 = Integer.parseInt(string.substring(1, 3), 16);
                int n6 = Integer.parseInt(string.substring(3, 5), 16);
                int n7 = Integer.parseInt(string.substring(5, 7), 16);
                int n8 = Integer.parseInt(string.substring(7, 9), 16);
                return new Color(n5, n6, n7, n8);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return color;
    }

    private static void a(JsonArray jsonArray) {
        HudWidget[] hudWidgetArray = HudWidget.values();
        List list = HudManager.getInstance().c();
        list.clear();
        for (JsonElement jsonElement : jsonArray) {
            int n2;
            JsonObject jsonObject;
            if (!jsonElement.isJsonObject() || !(jsonObject = jsonElement.getAsJsonObject()).has("type") || (n2 = jsonObject.get("type").getAsInt()) < 0 || n2 >= hudWidgetArray.length) continue;
            HudWidget hudWidget = hudWidgetArray[n2];
            float f2 = jsonObject.has("x") ? jsonObject.get("x").getAsFloat() : 10.0f;
            float f3 = jsonObject.has("y") ? jsonObject.get("y").getAsFloat() : 10.0f;
            HudElementSettings hudElementSettings = new HudElementSettings(hudWidget, f2, f3);
            if (jsonObject.has("w")) {
                hudElementSettings.c(jsonObject.get("w").getAsFloat());
            }
            if (jsonObject.has("h")) {
                hudElementSettings.d(jsonObject.get("h").getAsFloat());
            }
            if (jsonObject.has("options")) {
                JsonObject jsonObject2 = jsonObject.getAsJsonObject("options");
                for (Map.Entry entry : jsonObject2.entrySet()) {
                    hudElementSettings.a((String)entry.getKey(), ((JsonElement)entry.getValue()).getAsBoolean());
                }
            }
            list.add(hudElementSettings);
        }
    }

    private static JsonArray f() {
        JsonArray jsonArray = new JsonArray();
        for (MacroProfile macroProfile : Macros.s()) {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("name", macroProfile.a());
            jsonObject.addProperty("bind", (Number)macroProfile.b());
            JsonArray jsonArray2 = new JsonArray();
            for (MacroStep macroStep : macroProfile.c()) {
                JsonObject jsonObject2 = new JsonObject();
                jsonObject2.addProperty("t", (Number)macroStep.a().ordinal());
                jsonObject2.addProperty("s", (Number)macroStep.b());
                jsonObject2.addProperty("m", (Number)macroStep.c());
                jsonObject2.addProperty("a", (Number)macroStep.d().ordinal());
                jsonArray2.add((JsonElement)jsonObject2);
            }
            jsonObject.add("steps", (JsonElement)jsonArray2);
            jsonArray.add((JsonElement)jsonObject);
        }
        return jsonArray;
    }

    private static void b(JsonArray jsonArray) {
        Macros.s().clear();
        MacroStepType[] macroStepTypeArray = MacroStepType.values();
        MacroInputAction[] macroInputActionArray = MacroInputAction.values();
        for (JsonElement jsonElement : jsonArray) {
            if (!jsonElement.isJsonObject()) continue;
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            String string = jsonObject.has("name") ? jsonObject.get("name").getAsString() : "Macro";
            MacroProfile macroProfile = new MacroProfile(string);
            if (jsonObject.has("bind")) {
                macroProfile.a(jsonObject.get("bind").getAsInt());
            }
            if (jsonObject.has("steps")) {
                JsonArray jsonArray2 = jsonObject.getAsJsonArray("steps");
                for (JsonElement jsonElement2 : jsonArray2) {
                    int n2;
                    JsonObject jsonObject2;
                    int n3;
                    if (!jsonElement2.isJsonObject() || (n3 = (jsonObject2 = jsonElement2.getAsJsonObject()).has("t") ? jsonObject2.get("t").getAsInt() : 0) < 0 || n3 >= macroStepTypeArray.length) continue;
                    MacroStep macroStep = new MacroStep(macroStepTypeArray[n3]);
                    if (jsonObject2.has("s")) {
                        macroStep.a(jsonObject2.get("s").getAsInt());
                    }
                    if (jsonObject2.has("m")) {
                        macroStep.b(jsonObject2.get("m").getAsInt());
                    }
                    if (jsonObject2.has("a") && (n2 = jsonObject2.get("a").getAsInt()) >= 0 && n2 < macroInputActionArray.length) {
                        macroStep.a(macroInputActionArray[n2]);
                    }
                    macroProfile.a(macroStep);
                }
            }
            Macros.s().add(macroProfile);
        }
    }

    private static void lambda$deserialize$0(MinecraftClient mc20) {
        if (mc20.worldRenderer != null) {
            mc20.worldRenderer.reload();
        }
    }
}

