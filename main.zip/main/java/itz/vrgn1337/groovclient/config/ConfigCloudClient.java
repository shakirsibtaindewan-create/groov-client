/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.config;

import itz.vrgn1337.groovclient.api.backend.BackendClient;
import itz.vrgn1337.groovclient.api.backend.WebSocketClient;
import itz.vrgn1337.groovclient.config.ConfigEntry;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

public final class ConfigCloudClient {
    private static final ConfigCloudClient a = new ConfigCloudClient();
    private volatile Consumer b = null;
    private volatile Consumer c = null;
    private volatile Consumer d = null;
    private volatile Consumer e = null;
    private volatile Consumer f = null;
    private volatile Consumer g = null;
    private volatile Consumer h = null;

    public static ConfigCloudClient getInstance() {
        return a;
    }

    private ConfigCloudClient() {
    }

    public void a(Consumer consumer, Consumer consumer2) {
        if (!this.a(consumer2)) {
            return;
        }
        this.b = consumer;
        this.f = consumer2;
        WebSocketClient.getInstance().a("{\"type\":\"config_list\"}");
    }

    public void a(String string, String string2, String string3, String string4, Consumer consumer, Consumer consumer2) {
        if (!this.a(consumer2)) {
            return;
        }
        this.c = consumer;
        this.f = consumer2;
        String string5 = ConfigCloudClient.g(string);
        String string6 = ConfigCloudClient.g(string2);
        String string7 = ConfigCloudClient.g(string3);
        String string8 = string4 != null ? ",\"uuid\":\"" + ConfigCloudClient.g(string4) + "\"" : "";
        WebSocketClient.getInstance().a("{\"type\":\"config_save\",\"name\":\"" + string5 + "\",\"description\":\"" + string6 + "\",\"config_json\":\"" + string7 + "\"" + string8 + "}");
    }

    public void a(String string, Consumer consumer, Consumer consumer2) {
        if (!this.a(consumer2)) {
            return;
        }
        this.d = consumer;
        this.f = consumer2;
        WebSocketClient.getInstance().a("{\"type\":\"config_load\",\"uuid\":\"" + ConfigCloudClient.g(string) + "\"}");
    }

    public void b(String string, Consumer consumer, Consumer consumer2) {
        if (!this.a(consumer2)) {
            return;
        }
        this.h = consumer;
        this.f = consumer2;
        WebSocketClient.getInstance().a("{\"type\":\"settings_save\",\"settings_json\":\"" + ConfigCloudClient.g(string) + "\"}");
    }

    public void b(Consumer consumer, Consumer consumer2) {
        if (!this.a(consumer2)) {
            return;
        }
        this.g = consumer;
        this.f = consumer2;
        WebSocketClient.getInstance().a("{\"type\":\"settings_load\"}");
    }

    public void c(String string, Consumer consumer, Consumer consumer2) {
        if (!this.a(consumer2)) {
            return;
        }
        this.e = consumer;
        this.f = consumer2;
        WebSocketClient.getInstance().a("{\"type\":\"config_delete\",\"uuid\":\"" + ConfigCloudClient.g(string) + "\"}");
    }

    public void a(String string, String string2) {
        switch (string) {
            case "config_list_result": {
                this.getInstance(string2);
                break;
            }
            case "config_save_result": {
                this.b(string2);
                break;
            }
            case "config_load_result": {
                this.c(string2);
                break;
            }
            case "config_delete_result": {
                this.d(string2);
                break;
            }
            case "settings_save_result": {
                this.e(string2);
                break;
            }
            case "settings_load_result": {
                this.f(string2);
                break;
            }
            case "error": {
                String string3 = WebSocketClient.a(string2, "detail");
                Consumer consumer = this.f;
                this.b();
                if (consumer == null) break;
                consumer.accept(string3 != null ? string3 : "error");
            }
        }
    }

    private void a(String string) {
        Consumer consumer = this.b;
        this.b = null;
        if (consumer == null) {
            return;
        }
        CopyOnWriteArrayList<ConfigEntry> copyOnWriteArrayList = new CopyOnWriteArrayList<ConfigEntry>();
        int n2 = string.indexOf("[");
        int n3 = string.lastIndexOf("]");
        if (n2 < 0 || n3 < n2) {
            consumer.accept(copyOnWriteArrayList);
            return;
        }
        String string2 = string.substring(n2 + 1, n3);
        for (String string3 : ConfigCloudClient.h(string2)) {
            String string4 = WebSocketClient.a(string3, "uuid");
            String string5 = WebSocketClient.a(string3, "name");
            String string6 = WebSocketClient.a(string3, "description");
            String string7 = WebSocketClient.a(string3, "likes");
            String string8 = WebSocketClient.a(string3, "downloads");
            String string9 = WebSocketClient.a(string3, "published");
            String string10 = WebSocketClient.a(string3, "official");
            if (string4 == null || string5 == null) continue;
            copyOnWriteArrayList.add(new ConfigEntry(string4, string5, string6 != null ? string6 : "", ConfigCloudClient.i(string7), ConfigCloudClient.i(string8), "1".equals(string9), "1".equals(string10)));
        }
        consumer.accept(copyOnWriteArrayList);
    }

    private void b(String string) {
        Consumer consumer = this.c;
        this.c = null;
        if (consumer == null) {
            return;
        }
        String string2 = WebSocketClient.a(string, "uuid");
        consumer.accept(string2 != null ? string2 : "");
    }

    private void c(String string) {
        Consumer consumer = this.d;
        this.d = null;
        if (consumer == null) {
            return;
        }
        String string2 = ConfigCloudClient.b(string, "config_json");
        consumer.accept(string2 != null ? string2 : "{}");
    }

    private void d(String string) {
        Consumer consumer = this.e;
        this.e = null;
        if (consumer == null) {
            return;
        }
        String string2 = WebSocketClient.a(string, "uuid");
        consumer.accept(string2 != null ? string2 : "");
    }

    private void e(String string) {
        Consumer consumer = this.h;
        this.h = null;
        if (consumer != null) {
            consumer.accept("ok");
        }
    }

    private void f(String string) {
        Consumer consumer = this.g;
        this.g = null;
        if (consumer == null) {
            return;
        }
        String string2 = ConfigCloudClient.b(string, "settings_json");
        consumer.accept(string2 != null ? string2 : "{}");
    }

    private boolean a(Consumer consumer) {
        if (!BackendClient.getInstance().i()) {
            if (consumer != null) {
                consumer.accept("Not authenticated");
            }
            return false;
        }
        return true;
    }

    private void b() {
        this.b = null;
        this.c = null;
        this.d = null;
        this.e = null;
        this.g = null;
        this.h = null;
        this.f = null;
    }

    private static String g(String string) {
        if (string == null) {
            return "";
        }
        return string.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    private static List<String> h(String string) {
        CopyOnWriteArrayList<String> copyOnWriteArrayList = new CopyOnWriteArrayList<String>();
        int n2 = 0;
        int n3 = -1;
        for (int j = 0; j < string.length(); ++j) {
            char c2 = string.charAt(j);
            if (c2 == '{') {
                if (n2++ != 0) continue;
                n3 = j;
                continue;
            }
            if (c2 != '}' || --n2 != 0 || n3 < 0) continue;
            copyOnWriteArrayList.add(string.substring(n3, j + 1));
            n3 = -1;
        }
        return copyOnWriteArrayList;
    }

    private static int i(String string) {
        if (string == null) {
            return 0;
        }
        try {
            return Integer.parseInt(string.trim());
        }
        catch (Exception exception) {
            return 0;
        }
    }

    private static String b(String string, String string2) {
        String string3 = "\"" + string2 + "\"";
        int n2 = string.indexOf(string3);
        if (n2 < 0) {
            return null;
        }
        n2 += string3.length();
        while (n2 < string.length() && (string.charAt(n2) == ' ' || string.charAt(n2) == ':')) {
            ++n2;
        }
        if (n2 >= string.length() || string.charAt(n2) != '\"') {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        ++n2;
        while (n2 < string.length()) {
            char c2 = string.charAt(n2);
            if (c2 == '\\' && n2 + 1 < string.length()) {
                char c3 = string.charAt(n2 + 1);
                stringBuilder.append(switch (c3) {
                    case '\"' -> '\"';
                    case '\\' -> '\\';
                    case 'n' -> '\n';
                    case 'r' -> '\r';
                    case 't' -> '\t';
                    default -> c3;
                });
                n2 += 2;
                continue;
            }
            if (c2 == '\"') break;
            stringBuilder.append(c2);
            ++n2;
        }
        return stringBuilder.toString();
    }
}

