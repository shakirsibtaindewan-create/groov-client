/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.config;

public class ConfigEntry {
    private String a;
    private String b;
    private String c;
    private final long d;
    private int e;
    private int f;
    private boolean g;
    private boolean h;

    public ConfigEntry(String string, String string2) {
        this.b = string;
        this.c = string2;
        this.d = System.currentTimeMillis();
    }

    public ConfigEntry(String string, String string2, String string3, int n2, int n3, boolean bl, boolean bl2) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = System.currentTimeMillis();
        this.e = n2;
        this.f = n3;
        this.g = bl;
        this.h = bl2;
    }

    public String a() {
        return this.a;
    }

    public void a(String string) {
        this.a = string;
    }

    public boolean b() {
        return this.a != null && !this.a.isEmpty();
    }

    public String c() {
        return this.b;
    }

    public void b(String string) {
        this.b = string;
    }

    public String d() {
        return this.c;
    }

    public void c(String string) {
        this.c = string;
    }

    public long e() {
        return this.d;
    }

    public int f() {
        return this.e;
    }

    public int g() {
        return this.f;
    }

    public boolean h() {
        return this.g;
    }

    public boolean i() {
        return this.h;
    }

    public void a(boolean bl) {
        this.g = bl;
    }
}

