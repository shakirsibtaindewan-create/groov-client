/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.movement;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.mixin.accessor.LivingEntityAccessor;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;

public class NoJumpDelay
extends Module {
    public NoJumpDelay() {
        super(ModuleCategory.MOVEMENT, new StringConstant[]{new StringConstant("NoJumpDelay"), new StringConstant("Removes jump delay")});
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Main.mc.player == null) {
            return;
        }
        ((LivingEntityAccessor)Module.mc.player).setNoJumpDelay(0);
    }
}

