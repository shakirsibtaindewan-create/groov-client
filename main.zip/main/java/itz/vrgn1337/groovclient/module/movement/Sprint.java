/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.movement;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;

public class Sprint
extends Module {
    public Sprint() {
        super(ModuleCategory.MOVEMENT, new StringConstant[]{new StringConstant("Sprint"), new StringConstant("Automatically sprints")});
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        boolean bl;
        if (Module.mc.player == null || Module.mc.options == null || Module.mc.currentScreen != null) {
            return;
        }
        boolean bl2 = Module.mc.player.getHungerManager().getFoodLevel() > 6;
        boolean bl3 = bl = Module.mc.player.input != null && Module.mc.player.input.hasForwardMovement();
        if (bl && !Module.mc.player.isSneaking() && !Module.mc.player.isUsingItem() && bl2) {
            Module.mc.player.setSprinting(true);
        }
    }
}

