/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.movement;

public enum VelocityTarget {
    SELF, OTHERS;

    private VelocityTarget() {

    }

}

