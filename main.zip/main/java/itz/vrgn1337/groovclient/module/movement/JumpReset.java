/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.movement;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.Stopwatch;
import itz.vrgn1337.groovclient.api.util.math.RandomUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.RaycastUtils;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;

public class JumpReset
extends Module {
    private final DoubleSetting chance = new DoubleSetting(new StringConstant("Chance"), new StringConstant("Percentage to jump"), 20.0f, 60.0f, 0.0f, 100.0f, 1.0f, 100.0f);
    private final DoubleSetting delay = new DoubleSetting(new StringConstant("Delay"), new StringConstant("Delay to prevent detection by jumping at perfect time"), 250.0f, 300.0f, 0.0f, 500.0f, 10.0f, 500.0f);
    private final DoubleSetting cooldown = new DoubleSetting(new StringConstant("Cooldown"), new StringConstant("Wait time before jump again"), 250.0f, 300.0f, 0.0f, 500.0f, 10.0f, 500.0f);
    private final BooleanSetting checkTarget = new BooleanSetting(new StringConstant("Check Target"), new StringConstant("Only jumps while looking at enemy"), false);
    private boolean r;
    private final Stopwatch s = new Stopwatch();
    private final Stopwatch t = new Stopwatch();

    public JumpReset() {
        super(ModuleCategory.MOVEMENT, new StringConstant[]{new StringConstant("JumpReset"), new StringConstant("Automatically does jump reset")});
        this.registerSettings(new Setting[]{this.chance, this.delay, this.cooldown, this.checkTarget});
    }

    @Override
    public void onEnable() {
        this.s.b();
        this.t.b();
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        this.setSuffix(new StringConstant(this.chance.e() + "-" + this.chance.g() + "%"));
        if (Module.mc.player == null || Module.mc.currentScreen != null) {
            return;
        }
        if (this.r) {
            if (!this.t.a((double)this.delay.i())) {
                return;
            }
            this.r = false;
            this.b(150);
            Module.mc.player.input.jump();
            return;
        }
        if (!this.s.a((double)this.cooldown.i())) {
            return;
        }
        if (Module.mc.player.hurtTime != 9 || !Module.mc.player.isSprinting()) {
            return;
        }
        if ((float)RandomUtils.a(1, 100) > this.chance.i()) {
            return;
        }
        if (this.checkTarget.getValue()) {
            PlayerEntity mc6;
            EntityHitResult mc26;
            HitResult ItemStackParticleEffect = RaycastUtils.b(3.5);
            if (ItemStackParticleEffect instanceof EntityHitResult && (mc26 = (EntityHitResult) ItemStackParticleEffect).getEntity() instanceof PlayerEntity && TargetFilter.a((Entity)(mc6 = (PlayerEntity)ItemStackParticleEffect))) {
                this.s();
            }
            return;
        }
        this.s();
    }

    private void s() {
        if (this.delay.f() != 0.0f) {
            this.r = true;
            return;
        }
        this.b(150);
        Module.mc.player.input.jump();
    }
}

