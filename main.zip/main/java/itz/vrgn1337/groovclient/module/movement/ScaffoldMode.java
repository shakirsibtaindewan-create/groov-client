/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.movement;

enum ScaffoldMode {
    SCAFFOLD, CLUTCH;

    private ScaffoldMode() {

    }

}

