/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.movement;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.movement.FakeLagMode;
import itz.vrgn1337.groovclient.module.movement.VelocityTarget;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.network.packet.s2c.common.KeepAliveS2CPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;
import net.minecraft.network.packet.c2s.handshake.HandshakeC2SPacket;
import net.minecraft.network.packet.c2s.query.QueryPingC2SPacket;
import net.minecraft.network.packet.c2s.query.QueryRequestC2SPacket;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.network.packet.s2c.common.CommonPingS2CPacket;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketSendEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketSendEvent;

public class KnockbackDelay
extends Module {
    private final ModeSetting mode = new ModeSetting(new StringConstant("Mode"), new StringConstant("Delay mode"), FakeLagMode.LAG);
    private final ModeSetting target = new ModeSetting(new StringConstant("Target"), new StringConstant("Which velocity packets to delay"), VelocityTarget.SELF, true);
    private final FloatSetting delay = new FloatSetting(new StringConstant("Delay"), new StringConstant("Time to hold knockback before applying it"), 0.0f, 1000.0f, 250.0f, 10.0f);
    private final Object q = new Object();
    private volatile boolean r = false;
    private volatile boolean s = false;
    private final ConcurrentLinkedQueue t = new ConcurrentLinkedQueue();
    private final ConcurrentLinkedQueue u = new ConcurrentLinkedQueue();
    private volatile boolean v = false;
    private volatile boolean w = false;
    private long x = 0L;
    private int y = -1;
    private long z = 0L;
    private static final long A = 500L;

    public KnockbackDelay() {
        super(ModuleCategory.MOVEMENT, new StringConstant[]{new StringConstant("KnockbackDelay"), new StringConstant("Holds knockback packet")});
        this.registerSettings(new Setting[]{this.mode, this.target, this.delay});
    }

    @Override
    protected void onEnable() {
        this.s();
        this.u();
        this.x();
    }

    @Override
    protected void onDisable() {
        this.s();
        if (!(Module.mc.getNetworkHandler() == null || this.t.isEmpty() && this.u.isEmpty())) {
            this.t();
        }
        this.u();
        this.x();
        super.onDisable();
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        this.setSuffix(new StringConstant(this.mode.getValueName() + " " + this.delay.format() + "ms"));
        this.e(this.v);
        if (this.z != 0L && System.currentTimeMillis() - this.z > 500L) {
            this.x();
        }
        if (this.mode.getValue() != FakeLagMode.LATENCY || Module.mc.player == null) {
            return;
        }
        if (!this.v || this.w) {
            return;
        }
        if (System.currentTimeMillis() >= this.x + (long)this.delay.getValue()) {
            this.t();
        }
    }

    private void onPacketReceiveEventPre(PacketReceiveEvent.Pre packetReceiveEvent$Pre) {
        long l;
        boolean bl;
        if (Module.mc.player == null) {
            return;
        }
        Packet mc14 = packetReceiveEvent$Pre.getPacket();
        if (!(mc14 instanceof EntityVelocityUpdateS2CPacket)) {
            return;
        }
        EntityVelocityUpdateS2CPacket mc97 = (EntityVelocityUpdateS2CPacket)mc14;
        boolean bl2 = bl = mc97.getEntityId() == Module.mc.player.getId();
        if (bl) {
            if (!this.target.getSelectedSet().contains((Object)VelocityTarget.SELF)) {
                return;
            }
        } else {
            if (!this.target.getSelectedSet().contains((Object)VelocityTarget.OTHERS)) {
                return;
            }
            if (!this.c(mc97.getEntityId())) {
                return;
            }
        }
        if ((l = (long)this.delay.getValue()) <= 0L) {
            return;
        }
        if (this.mode.getValue() == FakeLagMode.LAG) {
            this.a(l);
        } else {
            packetReceiveEvent$Pre.cancel();
            this.u.add(mc97);
            this.x = System.currentTimeMillis();
            this.v = true;
        }
    }

    private void b(PacketReceiveEvent.Pre packetReceiveEvent$Pre) {
        if (this.mode.getValue() != FakeLagMode.LATENCY) {
            return;
        }
        if (!this.v || this.w) {
            return;
        }
        if (packetReceiveEvent$Pre.getPacket() instanceof EntityVelocityUpdateS2CPacket) {
            return;
        }
        if (KnockbackDelay.a(packetReceiveEvent$Pre.getPacket())) {
            return;
        }
        packetReceiveEvent$Pre.cancel();
        this.u.add(packetReceiveEvent$Pre.getPacket());
    }

    private void onPacketSendEventPre(PacketSendEvent.Pre packetSendEvent$Pre) {
        if (this.mode.getValue() != FakeLagMode.LATENCY) {
            return;
        }
        if (!this.v || this.w || Module.mc.getNetworkHandler() == null) {
            return;
        }
        if (KnockbackDelay.b(packetSendEvent$Pre.getPacket())) {
            return;
        }
        packetSendEvent$Pre.cancel();
        this.t.add(packetSendEvent$Pre.getPacket());
    }

    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        this.v();
        if (this.mode.getValue() == FakeLagMode.LAG) {
            this.s();
        } else {
            this.t();
        }
    }

    private void onAttackEventManualCalledAttack(AttackEvent.ManualCalledAttack attackEvent$ManualCalledAttack) {
        this.v();
        if (this.mode.getValue() == FakeLagMode.LAG) {
            this.s();
        } else {
            this.t();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void a(long l) {
        Object object = this.q;
        synchronized (object) {
            long l2;
            this.r = false;
            this.s = true;
            long l3 = System.currentTimeMillis() + l;
            while (!this.r && (l2 = l3 - System.currentTimeMillis()) > 0L) {
                try {
                    this.q.wait(l2);
                }
                catch (InterruptedException interruptedException) {
                    break;
                }
            }
            this.s = false;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void s() {
        Object object = this.q;
        synchronized (object) {
            this.r = true;
            this.q.notifyAll();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void t() {
        if (this.w || Module.mc.getNetworkHandler() == null) {
            return;
        }
        this.w = true;
        try {
            ArrayList<Packet> arrayList = new ArrayList(this.t);
            ArrayList<Packet> arrayList2 = new ArrayList(this.u);
            this.t.clear();
            this.u.clear();
            for (Packet mc14 : arrayList) {
                if (mc14 == null) continue;
                Module.mc.getNetworkHandler().sendPacket(mc14);
            }
            for (Packet mc14 : arrayList2) {
                if (mc14 == null || Module.mc.player == null || Module.mc.player.networkHandler == null) continue;
                Packet mc98 = mc14;
                mc98.apply((PacketListener)Module.mc.player.networkHandler);
            }
        }
        catch (Exception exception) {
        }
        finally {
            this.w = false;
            this.v = false;
            this.x = 0L;
        }
    }

    private void u() {
        this.t.clear();
        this.u.clear();
        this.v = false;
        this.w = false;
        this.x = 0L;
    }

    private void v() {
        if (Module.mc.player == null || Module.mc.crosshairTarget == null) {
            return;
        }
        if (Module.mc.crosshairTarget.getType() != HitResult.Type.ENTITY) {
            return;
        }
        Entity mc2 = ((EntityHitResult)Module.mc.crosshairTarget).getEntity();
        if (mc2 == null || mc2 == Module.mc.player) {
            return;
        }
        this.y = mc2.getId();
        this.z = System.currentTimeMillis();
    }

    private boolean w() {
        return this.y != -1 && this.z != 0L && System.currentTimeMillis() - this.z <= 500L;
    }

    private boolean c(int n) {
        return this.w() && this.y == n;
    }

    private void x() {
        this.y = -1;
        this.z = 0L;
    }

    private static boolean a(Packet mc14) {
        return mc14 instanceof KeepAliveS2CPacket || mc14 instanceof CommonPingS2CPacket || mc14 instanceof DisconnectS2CPacket || mc14 instanceof PlayerPositionLookS2CPacket || mc14 instanceof PlayerRespawnS2CPacket || mc14 instanceof GameJoinS2CPacket;
    }

    private static boolean b(Packet mc14) {
        return mc14 instanceof KeepAliveC2SPacket || mc14 instanceof ChatMessageC2SPacket || mc14 instanceof CommandExecutionC2SPacket || mc14 instanceof QueryPingC2SPacket || mc14 instanceof QueryRequestC2SPacket || mc14 instanceof HandshakeC2SPacket;
    }

    private boolean y() {
        return this.s || this.v;
    }

    public boolean z() {
        return this.s;
    }

    public boolean A() {
        return this.v;
    }
}

