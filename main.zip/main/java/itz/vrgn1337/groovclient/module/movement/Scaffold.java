/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.movement;

import com.google.common.collect.Streams;
import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.MovementPacketEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;
import itz.vrgn1337.groovclient.api.util.Stopwatch;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.RaycastUtils;
import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.api.util.world.RaycastHit;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.movement.ScaffoldMode;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.ItemListSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.registry.Registry;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.registry.Registries;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.ItemUseEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.ItemUseEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;

public class Scaffold
extends Module {
    private final ModeSetting mode = new ModeSetting(new StringConstant("Mode"), new StringConstant("Bridge or clutch"), ScaffoldMode.SCAFFOLD);
    private final DoubleSetting delay = new DoubleSetting(new StringConstant("Delay"), null, 0.0f, 50.0f, 0.0f, 500.0f, 10.0f, 250.0f);
    private final DoubleSetting failDelay = new DoubleSetting(new StringConstant("Fail Delay"), new StringConstant("Delay after server cancels placement"), 100.0f, 300.0f, 0.0f, 1000.0f, 50.0f, 500.0f);
    private final BooleanSetting blacklist = new BooleanSetting(new StringConstant("Blacklist"), new StringConstant("Avoid scaffolding with selected blocks"), false);
    private final ItemListSetting blacklisted = new ItemListSetting(new StringConstant("Blacklisted"), new StringConstant("Blocks to ignore"), (Registry)Registries.BLOCK, this::lambda$new$0, new ArrayList());
    private final Stopwatch s = new Stopwatch();
    private final Stopwatch t = new Stopwatch();
    private final Set u = new HashSet();
    private final Rotation v = new Rotation();
    private BlockHitResult w;
    private boolean x = false;
    private float y;
    private float z;
    private boolean A = false;

    public Scaffold() {
        super(ModuleCategory.MOVEMENT, new StringConstant[]{new StringConstant("Scaffold"), new StringConstant("Automatically bridges for you")});
        this.registerSettings(new Setting[]{this.mode, this.delay, this.failDelay, this.blacklist, this.blacklisted});
    }

    @Override
    protected void onDisable() {
        this.s.b();
        this.t.b();
        this.w = null;
        this.x = false;
        this.y = 0.0f;
        this.z = 0.0f;
        this.u.clear();
        this.A = false;
        if (!this.v.e()) {
            this.v.f();
        }
        super.onDisable();
    }

    private boolean a(ItemStack mc33) {
        Item mc17 = mc33.getItem();
        if (!(mc17 instanceof BlockItem)) {
            return true;
        }
        BlockItem mc107 = (BlockItem)mc17;
        if (!this.blacklist.getValue()) {
            return false;
        }
        return this.blacklisted.g().contains(mc107.getBlock());
    }

    private boolean s() {
        for (int i = 0; i < 9; ++i) {
            ItemStack mc33 = Module.mc.player.getInventory().getStack(i);
            Item mc17 = mc33.getItem();
            if (!(mc17 instanceof BlockItem)) continue;
            BlockItem mc107 = (BlockItem)mc17;
            if (this.blacklist.getValue() && this.blacklisted.g().contains(mc107.getBlock())) continue;
            Module.mc.player.getInventory().setSelectedSlot(i);
            return true;
        }
        return false;
    }

    private RaycastHit a(BlockPos mc0) {
        Direction[] class_2350Array = new Direction[]{Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};
        ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
        arrayList.add(mc0);
        arrayList.add(mc0.north());
        arrayList.add(mc0.east());
        arrayList.add(mc0.west());
        arrayList.add(mc0.south());
        arrayList.add(mc0.north().north());
        arrayList.add(mc0.east().east());
        arrayList.add(mc0.west().west());
        arrayList.add(mc0.south().south());
        arrayList.add(mc0.north().north().north());
        arrayList.add(mc0.east().east().east());
        arrayList.add(mc0.west().west().west());
        arrayList.add(mc0.south().south().south());
        for (BlockPos mc64 : arrayList) {
            for (Direction mc63 : class_2350Array) {
                BlockPos mc66 = mc64.offset(mc63.getOpposite());
                if (Module.mc.player.getBoundingBox(Module.mc.player.getPose()).contains(mc66.toCenterPos()) || Module.mc.world.isAir(mc66) || !Module.mc.player.canInteractWithBlockAt(mc66, 0.0)) continue;
                Vec3d VanillaChestLootTableGenerator = Vec3d.ofCenter((Vec3i)mc66).add(Vec3d.of((Vec3i)mc63.getVector()).multiply(0.499));
                return new RaycastHit(mc66, mc63, VanillaChestLootTableGenerator);
            }
        }
        return null;
    }

    private boolean t() {
        return this.mode.getValue() == ScaffoldMode.CLUTCH;
    }

    private boolean u() {
        if (Module.mc.player.isOnGround()) {
            return false;
        }
        if (Module.mc.player.getVelocity().y >= -0.08) {
            return false;
        }
        Box HorizontalFacingBlock = Module.mc.player.getBoundingBox().offset(0.0, -0.12, 0.0).expand(-0.05, 0.0, -0.05);
        return Streams.stream((Iterable)Module.mc.world.getBlockCollisions((Entity)Module.mc.player, HorizontalFacingBlock)).findAny().isEmpty();
    }

    private BlockPos v() {
        BlockPos mc0 = Module.mc.player.getBlockPos().down();
        for (int i = 0; i <= 4; ++i) {
            BlockPos mc64 = mc0.down(i);
            if (!Module.mc.world.isAir(mc64) || this.a(mc64) == null) continue;
            return mc64;
        }
        return null;
    }

    private BlockHitResult b(BlockPos mc0) {
        RaycastHit raycastHit = this.a(mc0);
        if (raycastHit == null) {
            return null;
        }
        return new BlockHitResult(raycastHit.c(), raycastHit.b(), raycastHit.a(), false);
    }

    private Box a(Box HorizontalFacingBlock, double d) {
        return new Box(HorizontalFacingBlock.minX, HorizontalFacingBlock.minY - d, HorizontalFacingBlock.minZ, HorizontalFacingBlock.maxX, HorizontalFacingBlock.maxY, HorizontalFacingBlock.maxZ);
    }

    @Priority(value=300)
    private void onPacketReceiveEventPre(PacketReceiveEvent.Pre packetReceiveEvent$Pre) {
        BlockUpdateS2CPacket mc108;
        if (Module.mc.player == null) {
            return;
        }
        Packet mc14 = packetReceiveEvent$Pre.getPacket();
        if (mc14 instanceof BlockUpdateS2CPacket && this.u.remove((mc108 = (BlockUpdateS2CPacket)mc14).getPos()) && mc108.getState().isAir()) {
            this.A = true;
            this.t.b();
        }
    }

    @Priority(value=300)
    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.x) {
            attackEvent$Pre.cancel();
        }
    }

    @Priority(value=300)
    private void onItemUseEventPre(ItemUseEvent.Pre itemUseEvent$Pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.x) {
            itemUseEvent$Pre.cancel();
        }
    }

    @Priority(value=300)
    private void onBreakBlock(BreakBlockEvent breakBlockEvent) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.x) {
            breakBlockEvent.cancel();
        }
    }

    @Priority(value=300)
    private void onMovementPacketEventPre(MovementPacketEvent.Pre pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.w != null) {
            this.x = true;
        }
    }

    @Priority(value=-250)
    private void b(MovementPacketEvent.Pre pre) {
        BlockHitResult mc7;
        if (Module.mc.player == null || Module.mc.world == null || Module.mc.interactionManager == null) {
            return;
        }
        if (this.A) {
            if (!this.t.a((double)this.failDelay.i())) {
                return;
            }
            this.A = false;
        }
        if (this.a(Module.mc.player.getMainHandStack()) && !this.s()) {
            this.onDisable();
            return;
        }
        if (this.w == null) {
            return;
        }
        HitResult ItemStackParticleEffect = RaycastUtils.a(4.5);
        if (ItemStackParticleEffect instanceof BlockHitResult && !(mc7 = (BlockHitResult)ItemStackParticleEffect).getBlockPos().equals((Object)this.w.getBlockPos())) {
            return;
        }
        float f = Math.abs(MathHelper.wrapDegrees((float)(RotationManager.getInstance().k() - this.y)));
        float f2 = Math.abs(RotationManager.getInstance().l() - this.z);
        if (f > 10.0f || f2 > 10.0f) {
            return;
        }
        if (!this.s.a((double)this.delay.i()) && this.delay.f() != 0.0f) {
            return;
        }
        if (Module.mc.world.isAir(this.w.getBlockPos())) {
            return;
        }
        if (Module.mc.player.getBlockPos().equals((Object)this.w.getBlockPos())) {
            return;
        }
        if (!Module.mc.player.canInteractWithBlockAt(this.w.getBlockPos(), 0.0)) {
            return;
        }
        Module.mc.options.useKey.setPressed(false);
        if (Module.mc.interactionManager.interactBlock(Module.mc.player, Hand.MAIN_HAND, this.w).isAccepted()) {
            Module.mc.player.swingHand(Hand.MAIN_HAND);
            BlockPos mc0 = this.w.getBlockPos().offset(this.w.getSide());
            this.u.add(mc0);
            this.s.b();
        }
    }

    @Priority(value=300)
    private void onRenderWorldEventPre(RenderWorldEvent.Pre pre) {
        BlockHitResult mc7;
        if (Module.mc.player == null || Module.mc.world == null || Module.mc.currentScreen != null) {
            return;
        }
        if (this.a(Module.mc.player.getMainHandStack()) && !this.s()) {
            if (!this.v.e()) {
                this.v.f();
            }
            return;
        }
        this.blacklisted.a(this.blacklist.getValue());
        Box HorizontalFacingBlock = Module.mc.player.getBoundingBox(Module.mc.player.getPose());
        Box InfestedBlock = this.a(HorizontalFacingBlock.offset(0.0, -0.5, 0.0).expand(-0.3, 0.0, -0.3), 0.0);
        Stream stream = Streams.stream((Iterable)Module.mc.world.getBlockCollisions((Entity)Module.mc.player, InfestedBlock));
        BlockPos mc0 = Module.mc.player.getBlockPos().down();
        if (!Module.mc.world.isAir(mc0) && !stream.findAny().isPresent()) {
            this.w = null;
        }
        BlockPos mc64 = mc0;
        if (this.t()) {
            if (!this.u()) {
                this.w = null;
                if (!this.v.e()) {
                    this.v.f();
                }
                return;
            }
            mc64 = this.v();
            if (mc64 == null) {
                this.w = null;
                if (!this.v.e()) {
                    this.v.f();
                }
                return;
            }
        }
        if ((mc7 = this.b(mc64)) == null) {
            return;
        }
        if (!Module.mc.player.canInteractWithBlockAt(mc7.getBlockPos(), 0.0)) {
            return;
        }
        Rotation rotation = RotationUtils.a(mc7.getPos(), Module.mc.player.getEyePos());
        float f = rotation.a();
        float f2 = MathHelper.clamp((float)rotation.b(), (float)-90.0f, (float)90.0f);
        this.w = mc7;
        this.y = MathHelper.lerpAngleDegrees((float)0.25f, (float)RotationManager.getInstance().k(), (float)f);
        this.z = MathHelper.lerpAngleDegrees((float)0.25f, (float)RotationManager.getInstance().l(), (float)f2);
        if (!RotationManager.getInstance().e()) {
            RotationManager.getInstance().a(true);
        }
        this.v.a(this.y, this.z).g();
        RotationManager.getInstance().a(this.v, 10);
    }

    private static boolean lambda$new$0(Block mc62) {
        return true;
    }
}

