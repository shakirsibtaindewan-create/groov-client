/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.movement;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.handshake.HandshakeC2SPacket;
import net.minecraft.network.packet.c2s.query.QueryPingC2SPacket;
import net.minecraft.network.packet.c2s.query.QueryRequestC2SPacket;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractEntityEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractItemEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketSendEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractEntityEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractItemEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketSendEvent;

public class FakeLag
extends Module {
    private final FloatSetting range = new FloatSetting(new StringConstant("Range"), new StringConstant("Lag only while an enemy is within this distance"), 0.0f, 12.0f, 6.0f, 0.5f);
    private final DoubleSetting delay = new DoubleSetting(new StringConstant("Delay"), new StringConstant("Packet hold time"), 50.0f, 100.0f, 0.0f, 1000.0f, 50.0f, 500.0f);
    private final ConcurrentLinkedQueue p = new ConcurrentLinkedQueue();
    private volatile boolean q = false;
    private long r = 0L;
    private long s = 0L;
    private long t = 0L;

    public FakeLag() {
        super(ModuleCategory.MOVEMENT, new StringConstant[]{new StringConstant("FakeLag"), new StringConstant("Dynamic lag \u2014 holds packets while an enemy is nearby")});
        this.registerSettings(new Setting[]{this.range, this.delay});
    }

    @Override
    protected void onEnable() {
        this.p.clear();
        this.q = false;
        this.r = 0L;
        this.s = 0L;
        this.t = System.currentTimeMillis();
    }

    @Override
    protected void onDisable() {
        this.u();
    }

    private boolean s() {
        return this.p != null && !this.p.isEmpty();
    }

    @Priority(value=-1200)
    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        this.t();
    }

    @Priority(value=-1200)
    private void onInteractEntityEventPre(InteractEntityEvent.Pre interactEntityEvent$Pre) {
        if (Module.mc.player != null && interactEntityEvent$Pre.player == Module.mc.player) {
            this.t();
        }
    }

    @Priority(value=-1200)
    private void onInteractItemEventPre(InteractItemEvent.Pre interactItemEvent$Pre) {
        if (Module.mc.player != null && interactItemEvent$Pre.player == Module.mc.player) {
            this.t();
        }
    }

    @Priority(value=-1200)
    private void onInteractBlockEventPre(InteractBlockEvent.Pre interactBlockEvent$Pre) {
        if (Module.mc.player != null && interactBlockEvent$Pre.player == Module.mc.player) {
            this.t();
        }
    }

    @Priority(value=-1200)
    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        boolean bl;
        this.setSuffix(new StringConstant(this.delay.e() + "-" + this.delay.g() + "ms"));
        this.e(this.s());
        if (Module.mc.player == null || Module.mc.world == null) {
            if (!this.p.isEmpty()) {
                this.u();
            }
            return;
        }
        if (this.q) {
            return;
        }
        if (System.currentTimeMillis() - this.t < 2000L) {
            return;
        }
        if (this.p.isEmpty()) {
            return;
        }
        long l = System.currentTimeMillis();
        long l2 = l - this.r;
        long l3 = this.delay.g();
        long l4 = this.delay.e();
        boolean bl2 = bl = this.v() != null;
        if (l2 >= l3 || !bl && l2 >= l4) {
            this.t();
        }
    }

    @Priority(value=-1200)
    private void onPacketSendEventPre(PacketSendEvent.Pre packetSendEvent$Pre) {
        ClientCommandC2SPacket mc105;
        ClientCommandC2SPacket.Mode mc106;
        if (Module.mc.player == null || Module.mc.world == null || this.q) {
            return;
        }
        if (Module.mc.getNetworkHandler() == null) {
            return;
        }
        if (System.currentTimeMillis() < this.s) {
            return;
        }
        if (System.currentTimeMillis() - this.t < 4000L) {
            return;
        }
        Packet mc14 = packetSendEvent$Pre.getPacket();
        if (mc14 instanceof KeepAliveC2SPacket || mc14 instanceof ChatMessageC2SPacket || mc14 instanceof CommandExecutionC2SPacket || mc14 instanceof QueryPingC2SPacket || mc14 instanceof QueryRequestC2SPacket || mc14 instanceof HandshakeC2SPacket) {
            return;
        }
        if (mc14 instanceof HandSwingC2SPacket) {
            this.t();
            return;
        }
        if (mc14 instanceof ClientCommandC2SPacket && ((mc106 = (mc105 = (ClientCommandC2SPacket)mc14).getMode()) == ClientCommandC2SPacket.Mode.START_SPRINTING || mc106 == ClientCommandC2SPacket.Mode.STOP_SPRINTING || mc106 == ClientCommandC2SPacket.Mode.OPEN_INVENTORY)) {
            this.t();
            return;
        }
        if (mc14 instanceof CloseHandledScreenC2SPacket) {
            this.t();
            return;
        }
        if (Module.mc.player.shouldSlowDown() || Module.mc.interactionManager.isBreakingBlock() || Module.mc.player.hurtTime == 9) {
            this.t();
            return;
        }
        if (this.v() == null) {
            return;
        }
        packetSendEvent$Pre.cancel();
        if (this.p.isEmpty()) {
            this.r = System.currentTimeMillis();
        }
        this.p.add(mc14);
    }

    @Priority(value=-1200)
    private void onPacketReceiveEventPre(PacketReceiveEvent.Pre packetReceiveEvent$Pre) {
        if (Module.mc.player == null || this.p.isEmpty()) {
            return;
        }
        if (packetReceiveEvent$Pre.getPacket() instanceof PlayerPositionLookS2CPacket || packetReceiveEvent$Pre.getPacket() instanceof ExplosionS2CPacket || packetReceiveEvent$Pre.getPacket() instanceof EntityDamageS2CPacket) {
            this.t();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void t() {
        if (this.q || Module.mc.getNetworkHandler() == null || this.p.isEmpty()) {
            return;
        }
        this.q = true;
        this.s = System.currentTimeMillis() + 250L;
        try {
            ArrayList<Packet> arrayList = new ArrayList(this.p);
            this.p.clear();
            for (Packet mc14 : arrayList) {
                if (mc14 == null) continue;
                Module.mc.getNetworkHandler().sendPacket(mc14);
            }
        }
        catch (Exception exception) {
        }
        finally {
            this.q = false;
            this.r = 0L;
        }
    }

    private void u() {
        this.q = true;
        try {
            for (Packet mc14 : this.p) {
                if (Module.mc.getNetworkHandler() == null) continue;
                Module.mc.getNetworkHandler().sendPacket(mc14);
            }
        }
        catch (Exception exception) {
        }
        finally {
            this.p.clear();
            this.q = false;
            this.r = 0L;
        }
    }

    private PlayerEntity v() {
        if (Module.mc.player == null || Module.mc.world == null) {
            return null;
        }
        double d = this.range.getValue();
        PlayerEntity mc6 = null;
        double d2 = Double.MAX_VALUE;
        for (PlayerEntity mc70 : Module.mc.world.getPlayers()) {
            double d3;
            if (mc70 == Module.mc.player || mc70.isDead() || mc70.isRemoved() || !TargetFilter.a((Entity)mc70) || !((d3 = (double)Module.mc.player.distanceTo((Entity)mc70)) <= d) || !(d3 < d2)) continue;
            d2 = d3;
            mc6 = mc70;
        }
        return mc6;
    }
}

