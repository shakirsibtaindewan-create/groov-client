/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.movement;

import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;
import net.minecraft.util.PlayerInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.KeyboardInputEvent;
import itz.vrgn1337.groovclient.api.event.hooks.KeyboardInputEvent;

public class WTap
extends Module {
    private final FloatSetting duration = new FloatSetting(new StringConstant("Duration"), new StringConstant("W release duration (ms)"), 50.0f, 500.0f, 100.0f, 10.0f);
    private final BooleanSetting onlyOnGround = new BooleanSetting(new StringConstant("Only On Ground"), new StringConstant("Only wtap while on ground"), false);
    private long p = 0L;
    private static final Field q;
    private boolean r;

    public WTap() {
        super(ModuleCategory.MOVEMENT, new StringConstant[]{new StringConstant("W-Tap"), new StringConstant("Automatically release and press W key on hit")});
        this.addSettings(List.of(this.duration, this.onlyOnGround));
    }

    @Override
    protected void onDisable() {
        this.r = false;
        if (this.p > 0L) {
            this.p = 0L;
            this.s();
        }
        super.onDisable();
    }

    private void onAttackEventManualCalledAttack(AttackEvent.ManualCalledAttack attackEvent$ManualCalledAttack) {
        this.r = true;
    }

    private void onAttackEventPost(AttackEvent.Post post) {
        if (Module.mc.player == null) {
            return;
        }
        if (!(Module.mc.crosshairTarget instanceof EntityHitResult)) {
            return;
        }
        if (this.onlyOnGround.getValue() && !Module.mc.player.isOnGround()) {
            return;
        }
        this.p = System.currentTimeMillis() + (long)this.duration.getValue();
    }

    private void onUpdateEventPost(UpdateEvent.Post post) {
        if (Module.mc.player == null || !this.r) {
            return;
        }
        this.r = false;
        if (!(Module.mc.crosshairTarget instanceof EntityHitResult)) {
            return;
        }
        if (this.onlyOnGround.getValue() && !Module.mc.player.isOnGround()) {
            return;
        }
        this.p = System.currentTimeMillis() + (long)this.duration.getValue();
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || q == null) {
            return;
        }
        long l = System.currentTimeMillis();
        if (l < this.p) {
            try {
                q.setBoolean(Module.mc.options.forwardKey, false);
            }
            catch (Exception exception) {}
        } else if (this.p > 0L) {
            this.p = 0L;
            this.s();
        }
    }

    private void onKeyboardInputEventPre(KeyboardInputEvent.Pre keyboardInputEvent$Pre) {
        if (keyboardInputEvent$Pre.input == null || this.p == 0L) {
            return;
        }
        if (System.currentTimeMillis() >= this.p) {
            return;
        }
        PlayerInput mc9 = keyboardInputEvent$Pre.input;
        keyboardInputEvent$Pre.input = new PlayerInput(false, mc9.backward(), mc9.left(), mc9.right(), mc9.jump(), mc9.sneak(), false);
    }

    private void s() {
        if (q == null || Module.mc.currentScreen != null) {
            return;
        }
        boolean bl = GLFW.glfwGetKey((long)Module.mc.getWindow().getHandle(), (int)87) == 1;
        try {
            q.setBoolean(Module.mc.options.forwardKey, bl);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    static {
        Field field = null;
        for (Field field2 : KeyBinding.class.getDeclaredFields()) {
            if (field2.getType() != Boolean.TYPE || Modifier.isStatic(field2.getModifiers())) continue;
            field2.setAccessible(true);
            field = field2;
            break;
        }
        q = field;
    }
}

