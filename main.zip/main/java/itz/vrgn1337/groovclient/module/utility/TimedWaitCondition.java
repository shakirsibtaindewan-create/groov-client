/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.util.WaitCondition;

class TimedWaitCondition
implements WaitCondition {
    long a;
    final int b;

    TimedWaitCondition(int n) {
        this.b = n;
        this.a = -1L;
    }

    public boolean a() {
        long l = System.currentTimeMillis();
        if (this.a < 0L) {
            this.a = l + (long)Math.max(0, this.b);
        }
        return l >= this.a;
    }
}

