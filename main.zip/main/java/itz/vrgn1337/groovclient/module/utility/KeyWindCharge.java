/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.ActionQueue;
import itz.vrgn1337.groovclient.api.util.WaitCondition;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.math.RandomUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import net.minecraft.util.Hand;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class KeyWindCharge
extends Module {
    private static final int n = 20;
    private final KeybindSetting key = new KeybindSetting(new StringConstant("Key"), new StringConstant("Trigger key"), 0);
    private final BooleanSetting switchBack = new BooleanSetting(new StringConstant("Switch Back"), new StringConstant("Switches to previous slot after use"), true);
    private final Rotation q = new Rotation();
    private boolean r;
    private boolean s;

    public KeyWindCharge() {
        super(ModuleCategory.Utility, true, new StringConstant[]{new StringConstant("KeyWindCharge"), new StringConstant("Wind charges on keybind press")});
        this.registerSettings(new Setting[]{this.key, this.switchBack});
    }

    @Override
    protected void onEnable() {
        this.r = false;
        this.s = false;
    }

    @Override
    protected void onDisable() {
        ActionQueue.b(this);
        this.s();
        this.r = false;
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.currentScreen != null) {
            this.r = false;
            return;
        }
        if (ActionQueue.a(this)) {
            if (!RotationManager.getInstance().e()) {
                RotationManager.getInstance().a(true);
            }
            this.q.g();
            RotationManager.getInstance().a(this.q);
            this.r = this.key.isBound();
            return;
        }
        boolean bl = this.key.isBound();
        boolean bl2 = bl && !this.r;
        this.r = bl;
        if (!bl2) {
            return;
        }
        if (ActionQueue.c()) {
            return;
        }
        if (!this.t()) {
            return;
        }
        int n = ItemUtils.f(Items.WIND_CHARGE);
        if (n < 0) {
            return;
        }
        int n2 = Module.mc.player.getInventory().getSelectedSlot();
        if (!RotationManager.getInstance().e()) {
            RotationManager.getInstance().a(true);
        }
        this.q.a(Module.mc.player.getYaw(), RandomUtils.a(85.0f, 90.0f)).g();
        RotationManager.getInstance().a(this.q);
        if (Module.mc.player.isGliding()) {
            Module.mc.player.input.jump();
            Module.mc.options.jumpKey.setPressed(true);
            this.s = true;
        }
        ActionQueue.a((Object)this, new WaitCondition[]{ActionQueue.a(n), ActionQueue.a(this::lambda$onUpdate$0, 20), ActionQueue.a(Hand.MAIN_HAND), ActionQueue.a(() -> ((KeyWindCharge)this).s()), this.switchBack.getValue() ? ActionQueue.a(n2) : null});
    }

    private void s() {
        if (!this.s) {
            return;
        }
        Module.mc.options.jumpKey.setPressed(false);
        this.s = false;
    }

    private boolean t() {
        if (!ItemUtils.g(Items.WIND_CHARGE)) {
            return false;
        }
        ItemStack mc33 = ItemUtils.a(Items.WIND_CHARGE);
        return mc33 != null && !Module.mc.player.getItemCooldownManager().isCoolingDown(mc33);
    }

    private static boolean lambda$onUpdate$0() {
        return RotationManager.getInstance().l() > 85.0f;
    }
}

