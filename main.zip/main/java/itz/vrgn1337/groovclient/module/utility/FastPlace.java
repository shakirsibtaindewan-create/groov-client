/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.mixin.accessor.MinecraftAccessor;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.ItemListSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.List;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registry;
import net.minecraft.registry.Registries;

public class FastPlace
extends Module {
    private final ItemListSetting items = new ItemListSetting(new StringConstant("Items"), new StringConstant("Items to activate"), (Registry)Registries.ITEM, this::lambda$new$0, List.of(Items.EXPERIENCE_BOTTLE));

    public FastPlace() {
        super(ModuleCategory.Utility, new StringConstant[]{new StringConstant("FastPlace"), new StringConstant("Removes right click delay")});
        this.registerSettings(new Setting[]{this.items});
    }

    private void s() {
        if (Module.mc.player == null) {
            return;
        }
        if (!this.items.a(Module.mc.player.getMainHandStack().getItem().asItem()) && !this.items.a(Module.mc.player.getOffHandStack().getItem().asItem())) {
            return;
        }
        ((MinecraftAccessor)Module.mc).setRightClickDelay(0);
    }

    private static boolean lambda$new$0(Item mc17) {
        return true;
    }
}

