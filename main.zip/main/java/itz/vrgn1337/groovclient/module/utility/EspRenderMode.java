/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

public enum EspRenderMode {
    Fill, Outline, Both;

    private EspRenderMode() {

    }

}

