/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

final class MiningTarget {
    final BlockPos a;
    final Direction b;
    final Vec3d c;

    MiningTarget(BlockPos mc0, Direction mc63, Vec3d VanillaChestLootTableGenerator) {
        this.a = mc0;
        this.b = mc63;
        this.c = VanillaChestLootTableGenerator;
    }
}

