/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.macro.MacroInputAction;
import itz.vrgn1337.groovclient.macro.MacroStepType;

class MacroInputActionSwitchMap {
    static final int[] a;
    static final int[] b;

    static {
        b = new int[MacroInputAction.values().length];
        try {
            MacroInputActionSwitchMap.b[MacroInputAction.Attack.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            MacroInputActionSwitchMap.b[MacroInputAction.Use.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            MacroInputActionSwitchMap.b[MacroInputAction.Jump.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            MacroInputActionSwitchMap.b[MacroInputAction.Sneak.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            MacroInputActionSwitchMap.b[MacroInputAction.Drop.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            MacroInputActionSwitchMap.b[MacroInputAction.Sprint.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        a = new int[MacroStepType.values().length];
        try {
            MacroInputActionSwitchMap.a[MacroStepType.Swap.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            MacroInputActionSwitchMap.a[MacroStepType.Wait.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            MacroInputActionSwitchMap.a[MacroStepType.Press.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            MacroInputActionSwitchMap.a[MacroStepType.Hold.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

