/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import net.minecraft.util.hit.EntityHitResult;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;

public class NoMiss
extends Module {
    public NoMiss() {
        super(ModuleCategory.Utility, new StringConstant[]{new StringConstant("NoMiss"), new StringConstant("Prevents swing on miss hit")});
    }

    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        if (Module.mc.crosshairTarget instanceof EntityHitResult) {
            return;
        }
        attackEvent$Pre.cancel();
    }
}

