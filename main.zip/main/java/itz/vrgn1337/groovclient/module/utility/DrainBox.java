/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import java.awt.Color;
import net.minecraft.util.math.BlockPos;

final class DrainBox {
    final float a;
    final float b;
    final float c;
    final float d;
    final float e;
    final float f;
    final Color g;

    DrainBox(BlockPos mc0, Color color) {
        this.a = mc0.getX();
        this.b = mc0.getY();
        this.c = mc0.getZ();
        this.d = this.a + 1.0f;
        this.e = this.b + 1.0f;
        this.f = this.c + 1.0f;
        this.g = color;
    }
}

