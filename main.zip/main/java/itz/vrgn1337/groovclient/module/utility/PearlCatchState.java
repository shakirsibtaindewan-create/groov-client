/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

enum PearlCatchState {
    IDLE, AIMING, HOLDING;

    private PearlCatchState() {

    }

}

