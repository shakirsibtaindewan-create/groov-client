/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.MovementPacketEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.utility.MiningTarget;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ItemListSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.world.BlockView;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.registry.Registry;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.registry.Registries;

public class Nuker
extends Module {
    private static final long n = 500L;
    private static final Direction[] o = new Direction[]{Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, Direction.DOWN};
    private static final double p = 0.499;
    private final FloatSetting range = new FloatSetting(new StringConstant("Range"), new StringConstant("Max distance to scan for blocks"), 1.0f, 6.0f, 4.5f, 0.5f);
    private final ItemListSetting blocks = new ItemListSetting(new StringConstant("Blocks"), new StringConstant("Select blocks to mine"), (Registry)Registries.ITEM, this::lambda$new$0, new ArrayList());
    private final Rotation s = new Rotation();
    private BlockPos t;
    private Direction u;
    private Vec3d v;
    private float w;
    private float x;
    private int y;
    private boolean z;
    private long A;

    public Nuker() {
        super(ModuleCategory.Utility, new StringConstant[]{new StringConstant("Nuker"), new StringConstant("Automatically mines near blocks")});
        this.registerSettings(new Setting[]{this.range, this.blocks});
    }

    @Override
    protected void onEnable() {
        this.A = 0L;
        this.s();
    }

    @Override
    protected void onDisable() {
        this.t();
        if (!this.s.e()) {
            this.s.f();
        }
        this.s();
    }

    private void s() {
        this.t = null;
        this.u = null;
        this.v = null;
        this.y = 0;
    }

    @Priority(value=300)
    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        Object object;
        MiningTarget miningTarget;
        if (Module.mc.player == null || Module.mc.world == null || Module.mc.interactionManager == null) {
            return;
        }
        long l2 = System.currentTimeMillis();
        if (Module.mc.currentScreen != null) {
            this.t();
            this.s();
            if (!this.s.e()) {
                this.s.f();
            }
            return;
        }
        if (this.t != null && l2 - this.A >= 500L) {
            this.t();
            if (!this.s.e()) {
                this.s.f();
            }
            this.s();
            return;
        }
        if (this.t != null && !this.a(this.t)) {
            this.t();
            this.s();
        }
        if (this.t == null) {
            miningTarget = this.u();
            if (miningTarget == null) {
                this.t();
                if (!this.s.e()) {
                    this.s.f();
                }
                return;
            }
            this.t = miningTarget.a;
            this.u = miningTarget.b;
            this.v = miningTarget.c;
            this.A = l2;
            object = RotationUtils.a(this.v, Module.mc.player.getEyePos());
            this.w = ((Rotation)object).a();
            this.x = MathHelper.clamp((float)((Rotation)object).b(), (float)-90.0f, (float)90.0f);
            this.y = 0;
        }
        if (!RotationManager.getInstance().e()) {
            RotationManager.getInstance().a(true);
        }
        this.s.a(this.w, this.x).g();
        RotationManager.getInstance().a(this.s, 300);
        this.A = l2;
        if (this.y < 1) {
            return;
        }
        object = Module.mc.crosshairTarget;
        if (!(object instanceof BlockHitResult) || (miningTarget_p = (BlockHitResult)object).getType() != HitResult.Type.BLOCK || !miningTarget_p.getBlockPos().equals((Object)this.t)) {
            if (this.z) {
                Module.mc.interactionManager.cancelBlockBreaking();
                this.z = false;
            }
            return;
        }
        Module.mc.interactionManager.updateBlockBreakingProgress(this.t, this.u);
        this.z = true;
        this.A = l2;
        Module.mc.player.swingHand(Hand.MAIN_HAND);
    }

    @Priority(value=300)
    private void onMovementPacketEventPost(MovementPacketEvent.Post post) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.t == null) {
            this.y = 0;
            return;
        }
        float f = Math.abs(MathHelper.wrapDegrees((float)(RotationManager.getInstance().k() - this.w)));
        float f2 = Math.abs(RotationManager.getInstance().l() - this.x);
        if (f < 0.5f && f2 < 0.5f) {
            ++this.y;
            this.A = System.currentTimeMillis();
        } else {
            this.y = 0;
            if (this.z) {
                Module.mc.interactionManager.cancelBlockBreaking();
                this.z = false;
            }
        }
    }

    private boolean a(BlockPos mc0) {
        BlockState mc1 = Module.mc.world.getBlockState(mc0);
        if (mc1.isAir()) {
            return false;
        }
        List list = this.blocks.g();
        if (!list.contains(mc1.getBlock().asItem())) {
            return false;
        }
        return Module.mc.player.canInteractWithBlockAt(mc0, 0.0);
    }

    private void t() {
        if (this.z && Module.mc.interactionManager != null) {
            Module.mc.interactionManager.cancelBlockBreaking();
        }
        this.z = false;
    }

    private MiningTarget u() {
        if (Module.mc.player == null || Module.mc.world == null) {
            return null;
        }
        List list = this.blocks.g();
        if (list.isEmpty()) {
            return null;
        }
        Vec3d VanillaChestLootTableGenerator = Module.mc.player.getEyePos();
        BlockPos mc0 = Module.mc.player.getBlockPos();
        double d2 = this.range.getValue();
        double d3 = d2 * d2;
        int n = MathHelper.ceil((double)d2);
        MiningTarget miningTarget = null;
        double d4 = Double.MAX_VALUE;
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                for (int k = -n; k <= n; ++k) {
                    double d5;
                    BlockState mc1;
                    BlockPos mc64 = mc0.add(i, j, k);
                    if (mc64.getY() < Module.mc.world.getBottomY() || mc64.getY() >= Module.mc.world.getTopYInclusive() || !Module.mc.player.canInteractWithBlockAt(mc64, 0.0) || (mc1 = Module.mc.world.getBlockState(mc64)).isAir() || mc1.getHardness((BlockView)Module.mc.world, mc64) < 0.0f || !list.contains(mc1.getBlock().asItem()) || (d5 = VanillaChestLootTableGenerator.squaredDistanceTo(Vec3d.ofCenter((Vec3i)mc64))) > d3) continue;
                    for (Direction mc63 : o) {
                        double d6;
                        Vec3d WallPlayerSkullBlock = this.a(mc64, mc63);
                        BlockHitResult mc7 = Module.mc.world.raycast(new RaycastContext(VanillaChestLootTableGenerator, WallPlayerSkullBlock, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, (Entity)Module.mc.player));
                        if (mc7.getType() != HitResult.Type.BLOCK || !mc7.getBlockPos().equals((Object)mc64) || !((d6 = VanillaChestLootTableGenerator.squaredDistanceTo(WallPlayerSkullBlock)) < d4)) continue;
                        d4 = d6;
                        miningTarget = new MiningTarget(mc64.toImmutable(), mc63, WallPlayerSkullBlock);
                    }
                }
            }
        }
        return miningTarget;
    }

    private Vec3d a(BlockPos mc0, Direction mc63) {
        return Vec3d.ofCenter((Vec3i)mc0).add(Vec3d.of((Vec3i)mc63.getVector()).multiply(0.499));
    }

    private static boolean lambda$new$0(Item mc17) {
        return mc17 instanceof BlockItem;
    }
}

