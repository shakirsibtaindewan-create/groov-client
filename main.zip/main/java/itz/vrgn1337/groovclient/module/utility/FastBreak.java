/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.event.hooks.DestroyBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.mixin.accessor.MultiPlayerGameModeInvoker;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.utility.FastBreakMode;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import net.minecraft.util.hit.BlockHitResult;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;

public class FastBreak
extends Module {
    private final ModeSetting mode = new ModeSetting(new StringConstant("Mode"), new StringConstant("FastBreak mode"), FastBreakMode.Instant);
    private final FloatSetting delay = new FloatSetting(new StringConstant("Delay"), new StringConstant("Minimum ms between finish and next start"), 250.0f, 400.0f, 275.0f, 5.0f);
    private long p = 0L;

    public FastBreak() {
        super(ModuleCategory.Utility, new StringConstant[]{new StringConstant("FastBreak"), new StringConstant("Lets you destroy blocks faster")});
        this.registerSettings(new Setting[]{this.mode, this.delay});
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.interactionManager == null) {
            return;
        }
        Object object = Module.mc.crosshairTarget;
        if (!(object instanceof BlockHitResult)) {
            return;
        }
        BlockHitResult mc7 = (BlockHitResult)object;
        object = (MultiPlayerGameModeInvoker)Module.mc.interactionManager;
        switch (((FastBreakMode)this.mode.getValue()).ordinal()) {
            case 0: {
                object.setDestroyDelay(0);
                break;
            }
            case 1: {
                if (System.currentTimeMillis() - this.p < (long)this.delay.getPercent()) break;
                object.setDestroyDelay(0);
            }
        }
    }

    private void onBreakBlockEventPre(BreakBlockEvent.Pre breakBlockEvent$Pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.mode.getValue() != FastBreakMode.Regular) {
            return;
        }
        if (System.currentTimeMillis() - this.p < (long)this.delay.getPercent()) {
            breakBlockEvent$Pre.cancel();
        }
    }

    private void onDestroyBlockEventPost(DestroyBlockEvent.Post post) {
        this.p = System.currentTimeMillis();
    }
}

