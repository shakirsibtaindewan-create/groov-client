/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.input.ItemUseUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.mixin.accessor.AbstractContainerScreenAccessor;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.HotbarSlotSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.Items;
import net.minecraft.world.World;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import itz.vrgn1337.groovclient.api.event.hooks.ClickSlotEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.ClickSlotEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;

public class AutoTotem
extends Module {
    private final BooleanSetting offhand = new BooleanSetting(new StringConstant("Offhand"), new StringConstant("Refills totem to offhand"), true);
    private final HotbarSlotSetting o = new HotbarSlotSetting(new StringConstant("Totem Slots"), new StringConstant("Hotbar slots to keep filled with totems"), new boolean[]{false, false, false, false, false, false, false, false, false});
    private final DoubleSetting offhandDelayTick = new DoubleSetting(new StringConstant("Offhand Delay Tick"), new StringConstant("Delay before offhand refill"), 0.0f, 2.0f, 0.0f, 20.0f, 1.0f, 20.0f);
    private final DoubleSetting hotbarDelayTick = new DoubleSetting(new StringConstant("Hotbar Delay Tick"), new StringConstant("Delay before hotbar refill"), 0.0f, 2.0f, 0.0f, 20.0f, 1.0f, 20.0f);
    private final BooleanSetting openInventory = new BooleanSetting(new StringConstant("Open Inventory"), new StringConstant("Automatically open inventory after pop"), false);
    private final BooleanSetting closeInventory = new BooleanSetting(new StringConstant("Close Inventory"), new StringConstant("Automatically close inventory after refill"), false);
    private final BooleanSetting hoverOnly = new BooleanSetting(new StringConstant("Hover Only"), new StringConstant("Only swap hovered totem in inventory"), false);
    private final BooleanSetting moveCursor = new BooleanSetting(new StringConstant("Move Cursor"), new StringConstant("Track cursor toward totem slot"), false);
    private final DoubleSetting sensitivity = new DoubleSetting(new StringConstant("Sensitivity"), new StringConstant("Cursor target offset jitter"), 1.0f, 10.0f, 0.0f, 10.0f, 0.1f, 10.0f);
    private final FloatSetting speed = new FloatSetting(new StringConstant("Speed"), new StringConstant("Cursor tracking speed"), 1.0f, 20.0f, 8.0f, 1.0f);
    private int x;
    private int y;
    private boolean z;
    private boolean A;
    private int B;
    private int C;
    private final Map D = new HashMap();

    public AutoTotem() {
        super(ModuleCategory.Utility, new StringConstant[]{new StringConstant("AutoTotem"), new StringConstant("Automatically refills totem")});
        this.registerSettings(new Setting[]{this.offhand, this.o, this.offhandDelayTick, this.hotbarDelayTick, this.openInventory, this.closeInventory, this.hoverOnly, this.moveCursor, this.sensitivity, this.speed});
    }

    @Override
    protected void onEnable() {
        this.x = 0;
        this.y = 0;
        this.z = false;
        this.A = false;
        this.B = 0;
        this.C = 0;
    }

    private void onClickSlotEventPre(ClickSlotEvent.Pre clickSlotEvent$Pre) {
        if (this.z && Module.mc.currentScreen instanceof InventoryScreen) {
            clickSlotEvent$Pre.cancel();
        }
    }

    private void onRenderHUDEventPre(RenderHUDEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        if (!this.moveCursor.getValue()) {
            return;
        }
        if (Module.mc.currentScreen instanceof InventoryScreen) {
            if (this.moveCursor.getValue() && this.hoverOnly.getValue()) {
                return;
            }
            ItemUseUtils.a(Items.TOTEM_OF_UNDYING, 50.0f, this.sensitivity.i(), 1200.0f - this.speed.getValue() * 500.0f / Math.max(59.0f, (float)Module.mc.getCurrentFps()));
        }
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        Screen mc29;
        if (Module.mc.player == null || Module.mc.world == null || Module.mc.interactionManager == null) {
            return;
        }
        int n = Module.mc.player.getInventory().count(Items.TOTEM_OF_UNDYING);
        this.setSuffix(new StringConstant(String.valueOf(n)));
        this.e(n == 0);
        if (this.A) {
            ++this.B;
            if (this.B > 20) {
                this.A = false;
            }
        }
        if (this.closeInventory.getValue() && this.A && Module.mc.currentScreen instanceof InventoryScreen) {
            if (this.moveCursor.getValue() && this.hoverOnly.getValue()) {
                this.closeInventory.getValue();
            }
            if ((this.moveCursor.getValue() && this.hoverOnly.getValue()) && this.sensitivity.n() < 2) {
                this.closeInventory.getValue();
            }
            if (this.sensitivity() == 0) {
                this.closeInventory.getValue();
            }
        }
        if (this.z) {
            if (this.sensitivity() > 0) {
                Module.mc.setScreen((Screen)new InventoryScreen((PlayerEntity)Module.mc.player));
            }
            this.A = true;
            this.B = 0;
            this.z = false;
        }
        if (!((mc29 = Module.mc.currentScreen) instanceof InventoryScreen)) {
            return;
        }
        InventoryScreen RealmsConnection = (InventoryScreen)mc29;
        int n2 = this.a((Screen)RealmsConnection);
        if (n2 != -1 && !this.moveCursor.getValue() && this.x >= this.a(this.offhandDelayTick)) {
            this.a(n2, 40);
            this.x = 0;
        }
        if ((n2 = this.a((Screen)RealmsConnection)) != -1) {
            for (int i = 0; i < 9; ++i) {
                if (this.c(i) || !this.o.b(i) || this.y < this.a(this.hotbarDelayTick)) continue;
                this.a(n2, i);
                this.y = 0;
                break;
            }
        }
        ++this.x;
        ++this.y;
    }

    private void onPacketReceiveEventPre(PacketReceiveEvent.Pre packetReceiveEvent$Pre) {
        EntityStatusS2CPacket mc99;
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        if (!this.openInventory.getValue()) {
            return;
        }
        Packet mc14 = packetReceiveEvent$Pre.getPacket();
        if (mc14 instanceof EntityStatusS2CPacket && (mc99 = (EntityStatusS2CPacket)mc14).getStatus() == 35 && mc99.getEntity((World)Module.mc.world) == Module.mc.player) {
            this.z = true;
        }
    }

    private void s() {
        this.A = true;
        if (Module.mc.currentScreen instanceof InventoryScreen) {
            Module.mc.player.closeHandledScreen();
        }
    }

    private boolean t() {
        for (int i = 0; i < 9; ++i) {
            if (this.c(i) || !this.o.b(i)) continue;
            return true;
        }
        return false;
    }

    private boolean u() {
        return this.offhand.getValue() && Module.mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
    }

    private boolean c(int n) {
        return Module.mc.player.getInventory().getStack(n).isOf(Items.TOTEM_OF_UNDYING);
    }

    private int v() {
        int n = 0;
        for (int i = 9; i < 36; ++i) {
            if (!Module.mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            ++n;
        }
        return n;
    }

    private int a(Screen mc29) {
        if (this.hoverOnly.getValue()) {
            if (!(mc29 instanceof HandledScreen)) {
                return -1;
            }
            HandledScreen BlockStateProviderType = (HandledScreen)mc29;
            Slot mc30 = ((AbstractContainerScreenAccessor)BlockStateProviderType).getHoveredSlot();
            if (mc30 == null) {
                return -1;
            }
            int n = mc30.id;
            if (n < 9 || n > 35) {
                return -1;
            }
            return mc30.getStack().isOf(Items.TOTEM_OF_UNDYING) ? n : -1;
        }
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (int i = 9; i < 36; ++i) {
            if (!Module.mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            arrayList.add(i);
        }
        if (arrayList.isEmpty()) {
            return -1;
        }
        Collections.shuffle(arrayList);
        return (Integer)arrayList.get(0);
    }

    private void a(int n, int n2) {
        Module.mc.interactionManager.clickSlot(Module.mc.player.currentScreenHandler.syncId, n, n2, SlotActionType.SWAP, (PlayerEntity)Module.mc.player);
    }

    private int a(DoubleSetting doubleSetting) {
        return Math.max(0, Math.round(doubleSetting.i()));
    }
}

