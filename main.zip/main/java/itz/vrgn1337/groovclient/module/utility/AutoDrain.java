/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.MovementPacketEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.WorldLineRenderer;
import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.api.util.world.RaycastHit;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.utility.DrainBox;
import itz.vrgn1337.groovclient.module.utility.DrainSource;
import itz.vrgn1337.groovclient.module.utility.EspRenderMode;
import itz.vrgn1337.groovclient.module.utility.LiquidType;
import itz.vrgn1337.groovclient.module.utility.PearlCatchState;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.util.Hand;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import itz.vrgn1337.groovclient.api.event.hooks.InteractBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;

public class AutoDrain
extends Module {
    private final ModeSetting mode = new ModeSetting(new StringConstant("Mode"), new StringConstant("Drain mode"), DrainSource.Both);
    private final ModeSetting target = new ModeSetting(new StringConstant("Target"), new StringConstant("Which liquid source blocks to target"), LiquidType.Both);
    private final FloatSetting range = new FloatSetting(new StringConstant("Range"), new StringConstant("Max scan distance in blocks"), 1.0f, 5.0f, 4.0f, 0.5f);
    private final FloatSetting delay = new FloatSetting(new StringConstant("Delay"), new StringConstant("Delay between actions in ms"), 0.0f, 1000.0f, 100.0f, 10.0f);
    private final FloatSetting hold = new FloatSetting(new StringConstant("Hold"), new StringConstant("Keep silent rotation aimed for this many ticks after action"), 0.0f, 10.0f, 2.0f, 1.0f);
    private final BooleanSetting excludeOwn = new BooleanSetting(new StringConstant("Exclude Own"), new StringConstant("Skip liquid blocks placed by you"), false);
    private final BooleanSetting previewESP = new BooleanSetting(new StringConstant("Preview ESP"), new StringConstant("Render boxes on target liquid blocks"), true);
    private final ModeSetting eSPMode = new ModeSetting(new StringConstant("ESP Mode"), new StringConstant("Fill, Outline, or Both"), EspRenderMode.Both);
    private final FloatSetting eSPAlpha = new FloatSetting(new StringConstant("ESP Alpha"), new StringConstant("Box fill transparency"), 0.0f, 255.0f, 80.0f, 1.0f);
    private final ColorSetting waterColor = new ColorSetting(new StringConstant("Water Color"), new StringConstant(""), new Color(30, 100, 255, 180));
    private final ColorSetting lavaColor = new ColorSetting(new StringConstant("Lava Color"), new StringConstant(""), new Color(255, 80, 20, 180));
    private final Rotation y = new Rotation();
    private BlockPos z;
    private boolean A;
    private BlockPos B;
    private Direction C;
    private Vec3d D;
    private int E;
    private float F;
    private float G;
    private PearlCatchState H = PearlCatchState.IDLE;
    private int I;
    private int J;
    private long K;
    private int L = -1;
    private boolean M;
    private final Set N = Collections.synchronizedSet(new HashSet());
    private final List<DrainBox> O = new ArrayList();

    public AutoDrain() {
        super(ModuleCategory.Utility, new StringConstant[]{new StringConstant("AutoDrain"), new StringConstant("Silently drains nearby liquid with a bucket or fills it with blocks")});
        this.registerSettings(new Setting[]{this.mode, this.target, this.range, this.delay, this.hold, this.excludeOwn, this.previewESP, this.eSPMode, this.eSPAlpha, this.waterColor, this.lavaColor});
    }

    @Override
    protected void onEnable() {
        this.N.clear();
        this.eSPAlpha.getValue();
        this.M = false;
        this.L = -1;
        this.K = 0L;
    }

    @Override
    protected void onDisable() {
        if (!this.y.e()) {
            this.y.f();
        }
        this.z();
        this.eSPAlpha.getValue();
        this.O.clear();
    }

    @Priority(value=250)
    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        Object object;
        Vec3d VanillaChestLootTableGenerator;
        int n;
        this.O.clear();
        if (Module.mc.player == null || Module.mc.world == null || Module.mc.interactionManager == null) {
            return;
        }
        if (Module.mc.currentScreen != null) {
            this.eSPMode.getValue();
            return;
        }
        this.waterColor();
        long l = System.currentTimeMillis();
        if (this.H == PearlCatchState.HOLDING) {
            this.excludeOwn.getValue();
            if (--this.J <= 0) {
                this.previewESP.getValue();
            }
            return;
        }
        if (this.H == PearlCatchState.AIMING) {
            if (this.z == null || !this.a(this.z)) {
                this.eSPMode.getValue();
                return;
            }
            this.excludeOwn.getValue();
            if (this.I >= 1) {
                this.a(l);
            }
            return;
        }
        if (l < this.K) {
            return;
        }
        DrainSource drainSource = (DrainSource)this.mode.getValue();
        int n2 = drainSource != DrainSource.Block ? ItemUtils.f(Items.BUCKET) : -1;
        int n3 = n = drainSource != DrainSource.Bucket ? this.y() : -1;
        if (n2 == -1 && n == -1) {
            this.z();
            return;
        }
        BlockPos mc0 = this.lavaColor();
        if (mc0 == null) {
            this.z();
            return;
        }
        boolean bl = n2 != -1;
        int n4 = bl ? n2 : n;
        BlockPos mc64 = null;
        Direction mc63 = null;
        Vec3d WallPlayerSkullBlock = null;
        if (bl) {
            VanillaChestLootTableGenerator = mc0.toCenterPos();
            mc64 = mc0;
            WallPlayerSkullBlock = mc0.toCenterPos();
        } else {
            object = RotationManager.getInstance().a(mc0, (BlockPos)null, (Direction)null);
            if (object == null) {
                this.z();
                return;
            }
            mc64 = ((RaycastHit)object).a();
            mc63 = ((RaycastHit)object).b();
            VanillaChestLootTableGenerator = WallPlayerSkullBlock = ((RaycastHit)object).c();
        }
        if (this.a(VanillaChestLootTableGenerator) > 120.0f) {
            return;
        }
        object = RotationUtils.a(VanillaChestLootTableGenerator, Module.mc.player.getEyePos());
        this.z = mc0;
        this.A = bl;
        this.B = mc64;
        this.C = mc63;
        this.D = WallPlayerSkullBlock;
        this.E = n4;
        this.F = ((Rotation)object).a();
        this.G = MathHelper.clamp((float)((Rotation)object).b(), (float)-90.0f, (float)90.0f);
        this.I = 0;
        this.H = PearlCatchState.AIMING;
        this.excludeOwn.getValue();
    }

    private void s() {
        if (!RotationManager.getInstance().e()) {
            RotationManager.getInstance().a(true);
        }
        this.y.a(this.F, this.G).g();
        RotationManager.getInstance().a(this.y, 250);
    }

    @Priority(value=250)
    private void onMovementPacketEventPost(MovementPacketEvent.Post post) {
        if (Module.mc.player == null || this.H != PearlCatchState.AIMING) {
            this.I = 0;
            return;
        }
        float f = Math.abs(MathHelper.wrapDegrees((float)(RotationManager.getInstance().k() - this.F)));
        float f2 = Math.abs(RotationManager.getInstance().l() - this.G);
        this.I = f < 1.0f && f2 < 1.0f ? ++this.I : 0;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void a(long l) {
        if (!this.M) {
            this.L = Module.mc.player.getInventory().getSelectedSlot();
            this.M = true;
        }
        if (Module.mc.player.getInventory().getSelectedSlot() != this.E) {
            Module.mc.player.getInventory().setSelectedSlot(this.E);
        }
        float f = Module.mc.player.getYaw();
        float f2 = Module.mc.player.getPitch();
        float f3 = RotationManager.getInstance().k();
        float f4 = RotationManager.getInstance().l();
        Module.mc.player.setYaw(f3);
        Module.mc.player.setPitch(f4);
        try {
            if (this.A) {
                if (Module.mc.player.getMainHandStack().getItem() == Items.BUCKET) {
                    RotationManager.getInstance().a(Hand.MAIN_HAND);
                    Module.mc.player.swingHand(Hand.MAIN_HAND);
                }
            } else if (Module.mc.player.getMainHandStack().getItem() instanceof BlockItem && this.B != null && this.C != null && this.D != null) {
                BlockHitResult mc7 = new BlockHitResult(this.D, this.C, this.B, false);
                RotationManager.getInstance().a(mc7, Hand.MAIN_HAND, true);
            }
        }
        finally {
            Module.mc.player.setYaw(f);
            Module.mc.player.setPitch(f2);
        }
        this.K = l + (long)this.delay.getValue();
        this.J = Math.max(1, (int)this.hold.getValue());
        this.I = 0;
        this.H = PearlCatchState.HOLDING;
    }

    private void t() {
        if (!this.y.e()) {
            this.y.f();
        }
        this.z = null;
        this.B = null;
        this.C = null;
        this.D = null;
        this.I = 0;
        this.J = 0;
        this.H = PearlCatchState.IDLE;
    }

    private void u() {
        this.previewESP.getValue();
        this.z();
    }

    private void v() {
        this.z = null;
        this.B = null;
        this.C = null;
        this.D = null;
        this.I = 0;
        this.J = 0;
        this.H = PearlCatchState.IDLE;
    }

    @Priority(value=250)
    private void onInteractBlockEventPost(InteractBlockEvent.Post interactBlockEvent$Post) {
        if (!this.excludeOwn.getValue() || Module.mc.player == null) {
            return;
        }
        Item mc17 = Module.mc.player.getMainHandStack().getItem();
        if (mc17 == Items.WATER_BUCKET || mc17 == Items.LAVA_BUCKET) {
            this.N.add(interactBlockEvent$Post.hitResult.getBlockPos().offset(interactBlockEvent$Post.hitResult.getSide()).toImmutable());
        }
    }

    private void onRenderWorldEventPost(RenderWorldEvent.Post renderWorldEvent$Post) {
        if (!this.previewESP.getValue() || this.O.isEmpty()) {
            return;
        }
        Camera mc22 = Module.mc.gameRenderer.getCamera();
        Vec3d VanillaChestLootTableGenerator = mc22.getCameraPos();
        MatrixStack mc13 = new MatrixStack();
        mc13.multiply((Quaternionfc)mc22.getRotation().conjugate(new Quaternionf()));
        mc13.translate(-VanillaChestLootTableGenerator.x, -VanillaChestLootTableGenerator.y, -VanillaChestLootTableGenerator.z);
        EspRenderMode espRenderMode = (EspRenderMode)this.eSPMode.getValue();
        float f = 1.5f;
        for (DrainBox drainBox : this.O) {
            WorldLineRenderer worldLineRenderer = new WorldLineRenderer(mc13).a(drainBox.a, drainBox.b, drainBox.c, drainBox.d, drainBox.e, drainBox.f).a(drainBox.g).a(false);
            switch (espRenderMode.ordinal()) {
                case 0: {
                    worldLineRenderer.b(true);
                    break;
                }
                case 1: {
                    worldLineRenderer.b(false).a(f);
                    break;
                }
                case 2: {
                    worldLineRenderer.b(true).a(drainBox.g, f);
                }
            }
            worldLineRenderer.c();
        }
    }

    private void w() {
        if (!this.previewESP.getValue() || Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        float f = this.range.getValue();
        double d = f * f;
        int n = MathHelper.ceil((float)f);
        int n2 = (int)this.eSPAlpha.getValue();
        BlockPos mc0 = Module.mc.player.getBlockPos();
        Vec3d VanillaChestLootTableGenerator = Module.mc.player.getEyePos();
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                for (int k = -n; k <= n; ++k) {
                    BlockPos mc64 = mc0.add(i, j, k);
                    if (!this.a(mc64) || VanillaChestLootTableGenerator.squaredDistanceTo(mc64.toCenterPos()) > d || this.excludeOwn.getValue() && this.N.contains(mc64)) continue;
                    Color color = this.b(mc64) ? this.waterColor.d() : this.lavaColor.d();
                    this.O.add(new DrainBox(mc64, AutoDrain.a(color, n2)));
                }
            }
        }
    }

    private BlockPos x() {
        float f = this.range.getValue();
        double d = f * f;
        int n = MathHelper.ceil((float)f);
        BlockPos mc0 = Module.mc.player.getBlockPos();
        Vec3d VanillaChestLootTableGenerator = Module.mc.player.getEyePos();
        BlockPos mc64 = null;
        double d2 = Double.MAX_VALUE;
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                for (int k = -n; k <= n; ++k) {
                    double d3;
                    BlockPos mc66 = mc0.add(i, j, k);
                    if (!this.a(mc66) || this.excludeOwn.getValue() && this.N.contains(mc66) || (d3 = VanillaChestLootTableGenerator.squaredDistanceTo(mc66.toCenterPos())) > d || !(d3 < d2)) continue;
                    d2 = d3;
                    mc64 = mc66.toImmutable();
                }
            }
        }
        return mc64;
    }

    private boolean a(BlockPos mc0) {
        if (Module.mc.world == null) {
            return false;
        }
        FluidState mc109 = Module.mc.world.getFluidState(mc0);
        if (!mc109.isStill()) {
            return false;
        }
        boolean bl = mc109.isOf((Fluid)Fluids.WATER);
        boolean bl2 = mc109.isOf((Fluid)Fluids.LAVA);
        if (!bl && !bl2) {
            return false;
        }
        return switch (((LiquidType)this.target.getValue()).ordinal()) {
            default -> throw new MatchException(null, null);
            case 1 -> bl;
            case 2 -> bl2;
            case 0 -> true;
        };
    }

    private boolean b(BlockPos mc0) {
        if (Module.mc.world == null) {
            return false;
        }
        return Module.mc.world.getFluidState(mc0).isOf((Fluid)Fluids.WATER);
    }

    private int y() {
        if (Module.mc.player == null) {
            return -1;
        }
        for (int i = 0; i < 9; ++i) {
            if (!(Module.mc.player.getInventory().getStack(i).getItem() instanceof BlockItem)) continue;
            return i;
        }
        return -1;
    }

    private float a(Vec3d VanillaChestLootTableGenerator) {
        if (Module.mc.player == null) {
            return 0.0f;
        }
        Rotation rotation = RotationUtils.a(VanillaChestLootTableGenerator, Module.mc.player.getEyePos());
        float f = Math.abs(MathHelper.wrapDegrees((float)(rotation.a() - Module.mc.player.getYaw())));
        float f2 = Math.abs(rotation.b() - Module.mc.player.getPitch());
        return (float)Math.sqrt(f * f + f2 * f2);
    }

    private void z() {
        if (this.M && this.L != -1 && Module.mc.player != null) {
            Module.mc.player.getInventory().setSelectedSlot(this.L);
        }
        this.M = false;
        this.L = -1;
    }

    private static Color a(Color color, int n) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), MathHelper.clamp((int)n, (int)0, (int)255));
    }
}

