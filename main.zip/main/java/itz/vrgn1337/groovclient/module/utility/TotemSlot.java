/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

enum TotemSlot {
    OFFHAND(40), HOTBAR_1(0), HOTBAR_2(1), HOTBAR_3(2), HOTBAR_4(3), HOTBAR_5(4), HOTBAR_6(5), HOTBAR_7(6), HOTBAR_8(7), HOTBAR_9(8);
    private final int a;

    int a() {
        return this.a;
    }

    private TotemSlot(int a) {
        this.a = a;

    }

}

