/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.event.hooks.MovementPacketEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.Stopwatch;
import itz.vrgn1337.groovclient.api.util.combat.ProjectilePrediction;
import itz.vrgn1337.groovclient.api.util.combat.ProjectilePredictor;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import net.minecraft.util.Hand;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.network.ClientPlayerEntity;

public class UnderPearl
extends Module {
    private static final int n = 8;
    private final KeybindSetting key = new KeybindSetting(new StringConstant("Key"), new StringConstant("Trigger key"), -1);
    private final FloatSetting range = new FloatSetting(new StringConstant("Range"), new StringConstant("Horizontal scan range"), 4.0f, 60.0f, 32.0f, 1.0f);
    private final FloatSetting minDrop = new FloatSetting(new StringConstant("Min Drop"), new StringConstant("Minimum Y difference required"), 0.0f, 20.0f, 1.0f, 0.5f);
    private final FloatSetting underOffset = new FloatSetting(new StringConstant("Under Offset"), new StringConstant("Blocks below opponent to aim the landing at"), 0.0f, 10.0f, 1.0f, 0.5f);
    private final FloatSetting spread = new FloatSetting(new StringConstant("Spread"), new StringConstant("Max horizontal landing distance from opponent"), 1.0f, 20.0f, 10.0f, 0.5f);
    private final BooleanSetting switchBack = new BooleanSetting(new StringConstant("Switch Back"), new StringConstant("Restore previous hotbar slot after throw"), true);
    private final Stopwatch u = new Stopwatch();
    private final Rotation v = new Rotation();
    private boolean w;
    private int x = -1;
    private int y = 0;
    private int z = 0;
    private int A = 0;
    private float B;
    private float C;
    private boolean D = false;
    private boolean E = false;

    public UnderPearl() {
        super(ModuleCategory.Utility, true, new StringConstant[]{new StringConstant("UnderPearl"), new StringConstant("Silently aims and throws ender pearl to land below a lower opponent")});
        this.registerSettings(new Setting[]{this.key, this.range, this.minDrop, this.underOffset, this.spread, this.switchBack});
        this.v.a(1500);
    }

    @Override
    protected void onEnable() {
        this.w = false;
        this.x = -1;
        this.y = 0;
        this.z = 0;
        this.A = 0;
        this.D = false;
    }

    @Override
    protected void onDisable() {
        this.switchBack.getValue();
        this.u.b();
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.world == null || Module.mc.interactionManager == null) {
            return;
        }
        if (Module.mc.player.networkHandler == null || Module.mc.player.isDead() || Module.mc.player.isSpectator()) {
            return;
        }
        if (Module.mc.currentScreen != null) {
            return;
        }
        if (this.u.a(1200.0) && this.E) {
            this.u.b();
            this.E = false;
            if (!this.v.e()) {
                this.v.f();
            }
            return;
        }
        if (this.y > 0) {
            --this.y;
            if (this.y == 0) {
                this.switchBack.getValue();
            }
        }
        if (this.D) {
            if (this.z-- <= 0) {
                this.D = false;
                this.switchBack.getValue();
                return;
            }
            if (!RotationManager.getInstance().e()) {
                RotationManager.getInstance().a(true);
            }
            this.v.a(this.B, this.C).g();
            RotationManager.getInstance().a(this.v, 1500);
            if (this.A >= 1) {
                Module.mc.interactionManager.interactItem((PlayerEntity)Module.mc.player, Hand.MAIN_HAND);
                Module.mc.player.swingHand(Hand.MAIN_HAND);
                this.v.f();
                this.D = false;
                this.z = 0;
                this.A = 0;
                this.y = 2;
            }
            return;
        }
        boolean bl = this.key.isBound();
        boolean bl2 = bl && !this.w;
        this.w = bl;
        if (bl) {
            this.E = true;
            this.u.b();
        }
        if (!bl2) {
            return;
        }
        int n = ItemUtils.f(Items.ENDER_PEARL);
        if (n < 0) {
            return;
        }
        if (Module.mc.player.getItemCooldownManager().isCoolingDown(Items.ENDER_PEARL.getDefaultStack())) {
            return;
        }
        float[] fArray = this.spread.getValue();
        if (fArray == null) {
            return;
        }
        this.x = Module.mc.player.getInventory().getSelectedSlot();
        if (this.x != n) {
            Module.mc.player.getInventory().setSelectedSlot(n);
        }
        this.B = fArray[0];
        this.C = MathHelper.clamp((float)fArray[1], (float)-90.0f, (float)90.0f);
        this.z = 8;
        this.A = 0;
        this.D = true;
        if (!RotationManager.getInstance().e()) {
            RotationManager.getInstance().a(true);
        }
        this.v.a(this.B, this.C).g();
        RotationManager.getInstance().a(this.v, 1500);
    }

    private void onMovementPacketEventPost(MovementPacketEvent.Post post) {
        if (!this.D || Module.mc.player == null) {
            this.A = 0;
            return;
        }
        float f = Math.abs(MathHelper.wrapDegrees((float)(RotationManager.getInstance().k() - this.B)));
        float f2 = Math.abs(RotationManager.getInstance().l() - this.C);
        this.A = f < 1.0f && f2 < 1.0f ? ++this.A : 0;
    }

    private float[] s() {
        ProjectilePrediction projectilePrediction;
        double d2;
        double d3;
        double d4;
        ClientPlayerEntity mc59 = Module.mc.player;
        double d5 = this.range.getValue();
        double d6 = d5 * d5;
        double d7 = this.minDrop.getValue();
        PlayerEntity mc6 = null;
        double d8 = Double.MAX_VALUE;
        for (PlayerEntity mc70 : Module.mc.world.getPlayers()) {
            double d9;
            if (mc70 == mc59 || mc70.isDead() || mc70.isRemoved() || mc70.isSpectator() || (d4 = mc59.getY() - mc70.getY()) < d7 || (d9 = (d3 = mc70.getX() - mc59.getX()) * d3 + (d2 = mc70.getZ() - mc59.getZ()) * d2) > d6 || !(d9 < d8)) continue;
            d8 = d9;
            mc6 = mc70;
        }
        if (mc6 == null) {
            return null;
        }
        double d10 = this.underOffset.getValue();
        d4 = this.spread.getValue();
        d3 = d4 * d4;
        d2 = mc6.getY();
        Vec3d VanillaChestLootTableGenerator = new Vec3d(mc6.getX(), d2 - d10, mc6.getZ());
        float[] fArray = ProjectilePredictor.b(VanillaChestLootTableGenerator, Items.ENDER_PEARL);
        if (fArray != null && this.a(projectilePrediction = ProjectilePredictor.a((PlayerEntity)mc59, Items.ENDER_PEARL, fArray[0], fArray[1]), mc6, d2, d3)) {
            return fArray;
        }
        double d11 = mc6.getX() - mc59.getX();
        double d12 = mc6.getZ() - mc59.getZ();
        float f = (float)Math.toDegrees(Math.atan2(-d11, d12));
        float[] fArray2 = null;
        double d13 = Double.MAX_VALUE;
        for (float f2 = -30.0f; f2 <= 90.0f; f2 += 1.0f) {
            double d14;
            double d15;
            double d16;
            double d17;
            double d18;
            ProjectilePrediction projectilePrediction2 = ProjectilePredictor.a((PlayerEntity)mc59, Items.ENDER_PEARL, f, f2);
            if (projectilePrediction2 == null || projectilePrediction2.c() == null) continue;
            Vec3d WallPlayerSkullBlock = projectilePrediction2.c();
            if (WallPlayerSkullBlock.y >= d2 || (d18 = (d17 = WallPlayerSkullBlock.x - mc6.getX()) * d17 + (d16 = WallPlayerSkullBlock.z - mc6.getZ()) * d16) > d3 || !((d15 = Math.abs((d14 = d2 - WallPlayerSkullBlock.y) - d10) + Math.sqrt(d18) * 0.25) < d13)) continue;
            d13 = d15;
            fArray2 = new float[]{f, f2};
        }
        return fArray2;
    }

    private boolean a(ProjectilePrediction projectilePrediction, PlayerEntity mc6, double d2, double d3) {
        double d4;
        if (projectilePrediction == null || projectilePrediction.c() == null) {
            return false;
        }
        Vec3d VanillaChestLootTableGenerator = projectilePrediction.c();
        if (VanillaChestLootTableGenerator.y >= d2) {
            return false;
        }
        double d5 = VanillaChestLootTableGenerator.x - mc6.getX();
        return d5 * d5 + (d4 = VanillaChestLootTableGenerator.z - mc6.getZ()) * d4 <= d3;
    }

    private void t() {
        if (this.x != -1 && this.switchBack.getValue() && Module.mc.player != null) {
            Module.mc.player.getInventory().setSelectedSlot(this.x);
        }
        this.x = -1;
    }
}

