/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.ItemListSetting;
import java.util.List;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registry;
import net.minecraft.registry.Registries;

public class Weapons
extends Module {
    private static Weapons n;
    private final ItemListSetting items = new ItemListSetting(new StringConstant("Items"), new StringConstant("Items considered as weapons"), (Registry)Registries.ITEM, this::lambda$new$0, List.of(Items.IRON_SWORD, Items.DIAMOND_SWORD, Items.NETHERITE_SWORD, Items.IRON_AXE, Items.DIAMOND_AXE, Items.NETHERITE_AXE, Items.IRON_SPEAR, Items.DIAMOND_SPEAR, Items.NETHERITE_SPEAR, Items.MACE));

    public Weapons() {
        super(ModuleCategory.Utility, new StringConstant[]{new StringConstant("Weapons"), new StringConstant("Configure which items count as weapons")});
        n = this;
        this.addSettings(List.of(this.items));
    }

    public static Weapons getInstance() {
        return n;
    }

    public ItemListSetting t() {
        return this.items;
    }

    public boolean u() {
        if (Module.mc.player == null) {
            return false;
        }
        ItemStack mc33 = Module.mc.player.getMainHandStack();
        if (mc33.isEmpty()) {
            return false;
        }
        return this.items.g().contains(mc33.getItem());
    }

    private static boolean lambda$new$0(Item mc17) {
        return true;
    }
}

