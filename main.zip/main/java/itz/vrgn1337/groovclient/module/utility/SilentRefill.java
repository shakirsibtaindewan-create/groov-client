/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.Stopwatch;
import itz.vrgn1337.groovclient.api.util.input.KeyBindingUtils;
import itz.vrgn1337.groovclient.api.util.input.MouseUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.mixin.accessor.MultiPlayerGameModeInvoker;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.utility.TotemSlot;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.HotbarSlotSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.ArrayList;
import java.util.Collections;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.client.option.KeyBinding;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.ItemUseEvent;
import itz.vrgn1337.groovclient.api.event.hooks.KeybindEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.ItemUseEvent;
import itz.vrgn1337.groovclient.api.event.hooks.KeybindEvent;

public class SilentRefill
extends Module {
    private final BooleanSetting offhand = new BooleanSetting(new StringConstant("Offhand"), new StringConstant("Refills totem to offhand"), true);
    private final HotbarSlotSetting o = new HotbarSlotSetting(new StringConstant("Totem Slots"), new StringConstant("Click on slots you want to refill"), new boolean[]{false, false, false, false, false, false, false, false, false});
    private final FloatSetting offhandDelay = new FloatSetting(new StringConstant("Offhand Delay"), new StringConstant("Refill delay for offhand"), 0.0f, 1000.0f, 400.0f, 50.0f);
    private final FloatSetting hotbarDelay = new FloatSetting(new StringConstant("Hotbar Delay"), new StringConstant("Refill delay for hotbar slots"), 0.0f, 1000.0f, 400.0f, 50.0f);
    private static final int r = 9;
    private static final int s = 36;
    private int t = -1;
    private boolean u;
    private TotemSlot v = null;
    private final Stopwatch w = new Stopwatch();

    public SilentRefill() {
        super(ModuleCategory.Utility, new StringConstant[]{new StringConstant("SilentRefill"), new StringConstant("Refills totem without opening inventory")});
        this.registerSettings(new Setting[]{this.offhand, this.o, this.offhandDelay, this.hotbarDelay});
    }

    @Override
    public void onDisable() {
        this.w();
        this.u = false;
        this.v = null;
        this.t = -1;
    }

    @Priority(value=1200)
    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.currentScreen != null) {
            return;
        }
        if (this.v != null && this.t != -1) {
            this.v();
            this.s();
            return;
        }
        if (this.u) {
            this.w();
            Module.mc.getNetworkHandler().sendPacket((Packet)new CloseHandledScreenC2SPacket(Module.mc.player.currentScreenHandler.syncId));
            this.u = false;
            return;
        }
        if (!this.c(40)) {
            this.t();
            return;
        }
        this.u();
    }

    @Priority(value=1200)
    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.u) {
            attackEvent$Pre.cancel();
        }
    }

    @Priority(value=1200)
    private void onItemUseEventPre(ItemUseEvent.Pre itemUseEvent$Pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.u) {
            itemUseEvent$Pre.cancel();
        }
    }

    @Priority(value=1200)
    private void onBreakBlockEventPre(BreakBlockEvent.Pre breakBlockEvent$Pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.u) {
            breakBlockEvent$Pre.cancel();
        }
    }

    @Priority(value=1200)
    private void onKeybindEventPre(KeybindEvent.Pre keybindEvent$Pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.u) {
            keybindEvent$Pre.cancel();
        }
    }

    private void s() {
        if (Module.mc.player.input.hasForwardMovement()) {
            return;
        }
        Module.mc.interactionManager.clickSlot(Module.mc.player.currentScreenHandler.syncId, this.t, this.v.a(), SlotActionType.SWAP, (PlayerEntity)Module.mc.player);
        ((MultiPlayerGameModeInvoker)Module.mc.interactionManager).ensureHasSentCarriedItem();
        this.v = null;
        this.t = -1;
    }

    private void t() {
        if (!this.offhand.getValue()) {
            return;
        }
        if (this.y()) {
            return;
        }
        if (!this.w.a((double)this.offhandDelay.getValue())) {
            return;
        }
        this.a(TotemSlot.OFFHAND);
    }

    private void u() {
        if (!this.w.a((double)this.hotbarDelay.getValue())) {
            return;
        }
        this.w.b();
        for (TotemSlot totemSlot : TotemSlot.values()) {
            if (totemSlot == TotemSlot.OFFHAND || !this.o.b(totemSlot.a()) || this.c(totemSlot.a())) continue;
            this.a(totemSlot);
            this.w.b();
            break;
        }
    }

    private void a(TotemSlot totemSlot) {
        this.t = this.x.getValue();
        if (this.t == -1) {
            return;
        }
        this.u = true;
        this.v();
        this.v = totemSlot;
    }

    private void v() {
        Module.mc.options.swapHandsKey.setPressed(false);
        Module.mc.options.dropKey.setPressed(false);
        Module.mc.options.forwardKey.setPressed(false);
        Module.mc.options.backKey.setPressed(false);
        Module.mc.options.leftKey.setPressed(false);
        Module.mc.options.rightKey.setPressed(false);
        Module.mc.options.sneakKey.setPressed(false);
        Module.mc.options.jumpKey.setPressed(false);
        Module.mc.options.attackKey.setPressed(false);
        Module.mc.options.useKey.setPressed(false);
        Module.mc.options.pickItemKey.setPressed(false);
    }

    private void w() {
        if (Module.mc.player.isDead()) {
            return;
        }
        this.a(Module.mc.options.swapHandsKey);
        this.a(Module.mc.options.dropKey);
        this.a(Module.mc.options.forwardKey);
        this.a(Module.mc.options.backKey);
        this.a(Module.mc.options.leftKey);
        this.a(Module.mc.options.rightKey);
        this.a(Module.mc.options.sneakKey);
        this.a(Module.mc.options.jumpKey);
        this.a(Module.mc.options.attackKey);
        this.a(Module.mc.options.useKey);
        this.a(Module.mc.options.pickItemKey);
    }

    private void a(KeyBinding mc32) {
        if (MouseUtils.b(KeyBindingUtils.b(mc32))) {
            mc32.setPressed(true);
        }
    }

    private int x() {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (int i = 9; i < 36; ++i) {
            if (Module.mc.player.getInventory().getStack(i).getItem() != Items.TOTEM_OF_UNDYING) continue;
            arrayList.add(i);
        }
        if (arrayList.isEmpty()) {
            return -1;
        }
        Collections.shuffle(arrayList);
        return (Integer)arrayList.getFirst();
    }

    private boolean c(int n) {
        return Module.mc.player.getInventory().getStack(n).getItem() == Items.TOTEM_OF_UNDYING;
    }

    private boolean y() {
        return Module.mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING;
    }
}

