/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.event.hooks.MouseButtonEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.ActionQueue;
import itz.vrgn1337.groovclient.api.util.WaitCondition;
import itz.vrgn1337.groovclient.api.util.input.InputUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.screen.MacroScreen;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import itz.vrgn1337.groovclient.macro.MacroInputAction;
import itz.vrgn1337.groovclient.macro.MacroProfile;
import itz.vrgn1337.groovclient.macro.MacroStep;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.utility.TimedWaitCondition;
import itz.vrgn1337.groovclient.setting.ButtonSetting;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.glfw.GLFW;

public class Macros
extends Module {
    private static final List<MacroProfile> n = new ArrayList<>();
    private final Set o = new HashSet();

    public static List<MacroProfile> s() {
        return n;
    }

    public Macros() {
        super(ModuleCategory.Utility, new StringConstant[]{new StringConstant("Macros"), new StringConstant("Block-coded macros bound to keys (swap, wait, press)")});
        this.registerSettings(new Setting[]{new ButtonSetting(new StringConstant("Editor"), new StringConstant("Open the macro editor"), new StringConstant("Open Editor..."), () -> ((Macros)this).lambda$new$0())});
    }

    @Override
    protected void onEnable() {
        this.o.clear();
    }

    @Override
    protected void onDisable() {
        ActionQueue.b(this);
        this.o.clear();
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (Module.mc.currentScreen != null) {
            return;
        }
        HashSet<Integer> hashSet = new HashSet<Integer>();
        for (MacroProfile macroProfile : n) {
            int n = macroProfile.b();
            if (n == -1 || KeybindSetting.isBound(n)) continue;
            boolean bl = this.c(n);
            if (bl) {
                hashSet.add(n);
            }
            boolean bl2 = this.o.contains(n);
            if (!bl || bl2) continue;
            this.a(macroProfile);
        }
        this.o.clear();
        this.o.addAll(hashSet);
    }

    private void onMouseButton(MouseButtonEvent mouseButtonEvent) {
        if (mouseButtonEvent.action != 1) {
            return;
        }
        if (Module.mc.currentScreen instanceof MenuGuiScreen) {
            return;
        }
        int n = KeybindSetting.getKey(mouseButtonEvent.button);
        for (MacroProfile macroProfile : Macros.n) {
            if (macroProfile.b() != n) continue;
            this.a(macroProfile);
        }
    }

    private boolean c(int n) {
        if (KeybindSetting.g(n)) {
            return false;
        }
        long l2 = Module.mc.getWindow().getHandle();
        return GLFW.glfwGetKey((long)l2, (int)n) == 1;
    }

    public void a(MacroProfile macroProfile) {
        if (Module.mc.player == null) {
            return;
        }
        if (macroProfile == null || macroProfile.c().isEmpty()) {
            return;
        }
        if (ActionQueue.a(this)) {
            return;
        }
        for (MacroStep macroStep : macroProfile.c()) {
            switch (macroStep.a()) {
                case Swap: {
                    ActionQueue.a((Object)this, ActionQueue.a(macroStep.b()));
                    break;
                }
                case Wait: {
                    ActionQueue.a((Object)this, Macros.d(macroStep.c()));
                    break;
                }
                case Press: {
                    ActionQueue.a((Object)this, ActionQueue.a(() -> ((Macros)this).lambda$run$1((MacroStep)macroStep)));
                    ActionQueue.a((Object)this, ActionQueue.b(1));
                    ActionQueue.a((Object)this, ActionQueue.a(() -> ((Macros)this).lambda$run$2((MacroStep)macroStep)));
                    break;
                }
                case Hold: {
                    MacroInputAction macroInputAction = macroStep.d();
                    ActionQueue.a((Object)this, ActionQueue.a(() -> ((Macros)this).lambda$run$3((MacroInputAction)macroInputAction)));
                    ActionQueue.a((Object)this, Macros.d(macroStep.c()));
                    ActionQueue.a((Object)this, ActionQueue.a(() -> ((Macros)this).lambda$run$4((MacroInputAction)macroInputAction)));
                }
            }
        }
    }

    private static WaitCondition d(int n) {
        return new TimedWaitCondition(n);
    }

    private void a(MacroInputAction macroInputAction, boolean bl) {
        boolean bl2;
        if (Module.mc.player == null) {
            return;
        }
        KeyBinding mc32 = switch (macroInputAction) {
            default -> throw new MatchException(null, null);
            case MacroInputAction.Attack -> Module.mc.options.attackKey;
            case MacroInputAction.Use -> Module.mc.options.useKey;
            case MacroInputAction.Jump -> Module.mc.options.jumpKey;
            case MacroInputAction.Sneak -> Module.mc.options.sneakKey;
            case MacroInputAction.Drop -> Module.mc.options.dropKey;
            case MacroInputAction.Sprint -> Module.mc.options.sprintKey;
        };
        boolean bl3 = bl2 = mc32 == Module.mc.options.attackKey || mc32 == Module.mc.options.useKey;
        if (!bl2) {
            mc32.setPressed(bl);
        }
        switch (macroInputAction) {
            case Use: {
                InputUtils.b();
                break;
            }
            case Attack: {
                InputUtils.a();
            }
        }
    }

    private void lambda$run$4(MacroInputAction macroInputAction) {
        this.a(macroInputAction, false);
    }

    private void lambda$run$3(MacroInputAction macroInputAction) {
        this.a(macroInputAction, true);
    }

    private void lambda$run$2(MacroStep macroStep) {
        this.a(macroStep.d(), false);
    }

    private void lambda$run$1(MacroStep macroStep) {
        this.a(macroStep.d(), true);
    }

    private static void lambda$new$0() {
        Main.mc.setScreen((Screen)MacroScreen.getInstance());
    }
}

