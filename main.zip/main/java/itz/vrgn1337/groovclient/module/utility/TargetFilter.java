/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import itz.vrgn1337.groovclient.social.FriendManager;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.GameMode;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import itz.vrgn1337.groovclient.api.event.hooks.EntitySpawnEvent;
import itz.vrgn1337.groovclient.api.event.hooks.EntitySpawnEvent;

public class TargetFilter
extends Module {
    private static TargetFilter n;
    private final BooleanSetting antiBot = new BooleanSetting(new StringConstant("AntiBot"), new StringConstant("Prevents targeting NPCs and bots"), true);
    private final BooleanSetting ignoreNaked = new BooleanSetting(new StringConstant("Ignore Naked"), new StringConstant("Ignores players without armor"), false);
    private final BooleanSetting ignoreInvisible = new BooleanSetting(new StringConstant("Ignore Invisible"), new StringConstant("Ignores invisible players"), false);
    private final BooleanSetting ignoreTeam = new BooleanSetting(new StringConstant("Ignore Team"), new StringConstant("Ignores same-team players"), false);
    private final BooleanSetting targetFriends = new BooleanSetting(new StringConstant("Target Friends"), new StringConstant("Allows targeting players in your friend list"), false);
    private final Set t = new HashSet();
    private static final Map<java.util.UUID, Long> u;
    private static final Map v;
    private static final Map w;
    private static final Map x;

    public TargetFilter() {
        super(ModuleCategory.Utility, new StringConstant[]{new StringConstant("TargetFilter"), new StringConstant("Defines entity type to target")});
        this.registerSettings(new Setting[]{this.antiBot, this.ignoreNaked, this.ignoreInvisible, this.ignoreTeam, this.targetFriends});
        n = this;
    }

    public static TargetFilter getInstance() {
        return n;
    }

    @Override
    protected void onEnable() {
        this.t.clear();
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        for (PlayerEntity mc6 : Module.mc.world.getPlayers()) {
            this.t.add(mc6.getUuid());
        }
    }

    private void onEntitySpawnEventPre(EntitySpawnEvent.Pre entitySpawnEvent$Pre) {
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        if (!this.antiBot.getValue()) {
            return;
        }
        Entity mc2 = entitySpawnEvent$Pre.entity;
        if (!(mc2 instanceof PlayerEntity)) {
            return;
        }
        PlayerEntity mc6 = (PlayerEntity)mc2;
        if (mc6 == Module.mc.player) {
            return;
        }
        if (this.t.contains(mc6.getUuid())) {
            entitySpawnEvent$Pre.cancel();
        }
    }

    public static boolean a(Entity mc2) {
        TargetFilter targetFilter;
        if (!TargetFilter.getInstance().e()) {
            return true;
        }
        if (mc2 == null) {
            return false;
        }
        if (mc2 == MinecraftClient.getInstance().player) {
            return false;
        }
        if (!(mc2 instanceof LivingEntity)) {
            return false;
        }
        LivingEntity mc58 = (LivingEntity)mc2;
        if (!mc2.isAlive() || mc2.isRemoved() || mc58.isDead()) {
            return false;
        }
        if (mc2 instanceof PlayerEntity && (targetFilter_p = (PlayerEntity)mc2).isSpectator()) {
            return false;
        }
        targetFilter = n;
        if (targetFilter == null || !targetFilter.e()) {
            return true;
        }
        if (targetFilter.ignoreNaked.getValue() && TargetFilter.d(mc2)) {
            return false;
        }
        if (targetFilter.ignoreInvisible.getValue() && mc2.isInvisible()) {
            return false;
        }
        if (targetFilter.ignoreTeam.getValue() && TargetFilter.e(mc2)) {
            return false;
        }
        if (!targetFilter.targetFriends.getValue() && mc2 instanceof PlayerEntity) {
            PlayerEntity mc6 = (PlayerEntity)mc2;
            if (FriendManager.getInstance().a(mc6)) {
                return false;
            }
        }
        return !TargetFilter.b(mc2);
    }

    public static boolean b(Entity mc2) {
        PlayerEntity mc6;
        if (mc2 == null) {
            return true;
        }
        MinecraftClient mc20 = MinecraftClient.getInstance();
        TargetFilter targetFilter = n;
        boolean bl = targetFilter != null && targetFilter.e() && targetFilter.antiBot.getValue();
        long l2 = TargetFilter.c(mc2);
        if (mc2 instanceof PlayerEntity && TargetFilter.a(mc6 = (PlayerEntity)mc2)) {
            return true;
        }
        if (TargetFilter.a(mc2, l2)) {
            return true;
        }
        if (TargetFilter.b(mc2, l2)) {
            return true;
        }
        if (!(mc2.isOnGround() && mc2.groundCollision || mc2.isPushable() && !mc2.hasNoGravity())) {
            return true;
        }
        if (mc2 instanceof PlayerEntity) {
            mc6 = (PlayerEntity)mc2;
            if (bl) {
                return TargetFilter.a(mc6, mc20);
            }
        }
        return false;
    }

    private static boolean a(PlayerEntity mc6) {
        if (mc6.isGliding()) {
            return false;
        }
        if (!mc6.isOnGround()) {
            u.putIfAbsent(mc6.getUuid(), System.currentTimeMillis());
            long l2 = u.getOrDefault(mc6.getUuid(), 0L);
            if (System.currentTimeMillis() - l2 > 6000L && mc6.getVelocity().y >= -0.2) {
                return true;
            }
        } else {
            u.remove(mc6.getUuid());
        }
        return false;
    }

    private static long c(Entity mc2) {
        if (mc2 == null) {
            return 0L;
        }
        UUID uUID = mc2.getUuid();
        if (mc2.isOnGround() || mc2.isRemoved()) {
            x.remove(uUID);
            return 0L;
        }
        long l2 = System.currentTimeMillis();
        x.putIfAbsent(uUID, l2);
        return l2 - x.getOrDefault(uUID, l2);
    }

    private static boolean a(Entity mc2, long l2) {
        boolean bl;
        PlayerEntity mc6;
        if (mc2 instanceof PlayerEntity && (mc6 = (PlayerEntity)mc2).isGliding()) {
            v.remove(mc2.getUuid());
            return false;
        }
        double d2 = mc2.getVelocity().y;
        if (l2 <= 5L || Math.abs(d2) > 0.08) {
            v.remove(mc2.getUuid());
            return false;
        }
        boolean bl2 = !mc2.groundCollision && !mc2.isOnGround() && Math.abs(d2) < 0.01;
        boolean bl3 = bl = mc2.hasNoGravity() || !mc2.isPushable() || bl2;
        if (bl) {
            long l3 = System.currentTimeMillis();
            v.putIfAbsent(mc2.getUuid(), l3);
            if (l3 - v.getOrDefault(mc2.getUuid(), l3) >= 6000L) {
                return true;
            }
        } else {
            v.remove(mc2.getUuid());
        }
        if (mc2.isRemoved()) {
            v.remove(mc2.getUuid());
        }
        return false;
    }

    private static boolean b(Entity mc2, long l2) {
        if (!(mc2 instanceof PlayerEntity)) {
            return false;
        }
        PlayerEntity mc6 = (PlayerEntity)mc2;
        if (mc6.isGliding() || mc6.hasNoGravity()) {
            w.remove(mc6.getUuid());
            return false;
        }
        if (l2 < 500L) {
            w.remove(mc6.getUuid());
            return false;
        }
        double d2 = mc6.getVelocity().y;
        if (Math.abs(d2) < 0.01) {
            long l3 = System.currentTimeMillis();
            w.putIfAbsent(mc6.getUuid(), l3);
            if (l3 - w.getOrDefault(mc6.getUuid(), l3) >= 9000L) {
                return true;
            }
        } else {
            w.remove(mc6.getUuid());
        }
        return false;
    }

    private static boolean a(PlayerEntity mc6, MinecraftClient mc20) {
        try {
            if (mc20.getNetworkHandler() == null) {
                return true;
            }
            PlayerListEntry ServerSamplerSource = mc20.getNetworkHandler().getPlayerListEntry(mc6.getUuid());
            if (ServerSamplerSource == null) {
                return true;
            }
            if (ServerSamplerSource.getProfile() == null) {
                return true;
            }
            GameMode mc110 = ServerSamplerSource.getGameMode();
            if (mc110 == null) {
                return true;
            }
            String string = mc6.getName().getString();
            if (string.isEmpty() || string.length() > 16 || string.length() < 3) {
                return true;
            }
            if (!string.matches("^[a-zA-Z0-9_]+$")) {
                return true;
            }
            if (mc6.getHealth() <= 0.0f) {
                return true;
            }
            if (!mc6.isPushedByFluids()) {
                return true;
            }
            if (mc6.age < 5 && !mc6.isOnGround() && Math.abs(mc6.getVelocity().y) < 0.01) {
                return true;
            }
        }
        catch (NullPointerException nullPointerException) {
            return true;
        }
        return false;
    }

    private static boolean d(Entity mc2) {
        PlayerEntity mc6;
        return mc2 instanceof PlayerEntity && (mc6 = (PlayerEntity)mc2).getArmor() == 0;
    }

    private static boolean e(Entity mc2) {
        MinecraftClient mc20 = MinecraftClient.getInstance();
        if (mc20.player == null) {
            return false;
        }
        if (!(mc2 instanceof PlayerEntity)) {
            return false;
        }
        PlayerEntity mc6 = (PlayerEntity)mc2;
        if (mc20.player.getScoreboardTeam() == null || mc6.getScoreboardTeam() == null) {
            return false;
        }
        return Objects.equals(mc20.player.getScoreboardTeam(), mc6.getScoreboardTeam());
    }

    static {
        u = new HashMap();
        v = new HashMap();
        w = new HashMap();
        x = new HashMap();
    }
}

