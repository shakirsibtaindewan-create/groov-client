/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.utility;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.ActionQueue;
import itz.vrgn1337.groovclient.api.util.WaitCondition;
import itz.vrgn1337.groovclient.api.util.math.RandomUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.Hand;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class AutoPearlCatch
extends Module {
    private final KeybindSetting actionKey = new KeybindSetting(new StringConstant("Action Key"), new StringConstant("Hold or press this key to run pearl-catch"), -1);
    private final BooleanSetting stopWalk = new BooleanSetting(new StringConstant("Stop Walk"), new StringConstant("Temporarily stop forward key while throwing"), false);
    private final DoubleSetting swapDelay = new DoubleSetting(new StringConstant("Swap Delay"), new StringConstant("Ticks to wait between slot swap and use"), 1.0f, 1.0f, 0.0f, 5.0f, 1.0f, 3.0f);
    private final DoubleSetting waitDelay = new DoubleSetting(new StringConstant("Wait Delay"), new StringConstant("Ticks between pearl use and wind slot swap"), 1.0f, 1.0f, 0.0f, 5.0f, 1.0f, 3.0f);
    private final Rotation r = new Rotation();
    private boolean s;
    private boolean t;
    private boolean u;

    public AutoPearlCatch() {
        super(ModuleCategory.Utility, true, new StringConstant[]{new StringConstant("AutoPearlCatch"), new StringConstant("Automatically throws pearl and wind charge")});
        this.registerSettings(new Setting[]{this.actionKey, this.stopWalk, this.swapDelay, this.waitDelay});
    }

    @Override
    protected void onEnable() {
        this.u = false;
        this.s = false;
    }

    @Override
    protected void onDisable() {
        ActionQueue.b(this);
        this.u();
        this.s = false;
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (!this.t()) {
            if (ActionQueue.a(this)) {
                ActionQueue.b(this);
                this.u();
            }
            return;
        }
        if (ActionQueue.a(this) || this.u) {
            if (!RotationManager.getInstance().e()) {
                RotationManager.getInstance().a(true);
            }
            RotationManager.getInstance().b(this.r, this.r.c());
            this.s = this.actionKey.isBound();
            return;
        }
        boolean bl = this.actionKey.isBound();
        boolean bl2 = bl && !this.s;
        this.s = bl;
        if (!bl2) {
            return;
        }
        if (ActionQueue.c()) {
            return;
        }
        this.s();
    }

    private void s() {
        if (Module.mc.player.getItemCooldownManager().isCoolingDown(Items.ENDER_PEARL.getDefaultStack()) || Module.mc.player.getItemCooldownManager().isCoolingDown(Items.WIND_CHARGE.getDefaultStack())) {
            return;
        }
        int n = this.a(Items.ENDER_PEARL);
        int n2 = this.a(Items.WIND_CHARGE);
        if (n < 0 || n2 < 0) {
            return;
        }
        int n3 = Module.mc.player.getInventory().getSelectedSlot();
        int n4 = Math.max(1, this.swapDelay.h());
        int n5 = Math.max(1, this.waitDelay.h());
        RotationManager.getInstance().b();
        RotationManager.getInstance().x();
        this.r.a(Module.mc.player.getYaw(), RandomUtils.a(-90.0f, -85.0f)).g();
        if (this.stopWalk.getValue() && Module.mc.options.forwardKey.isPressed()) {
            Module.mc.options.forwardKey.setPressed(false);
            this.t = true;
        }
        ArrayList<WaitCondition> arrayList = new ArrayList<WaitCondition>();
        this.u = true;
        arrayList.add(ActionQueue.a(n));
        AutoPearlCatch.a(arrayList, n4 - 1);
        arrayList.add(ActionQueue.a(Hand.MAIN_HAND));
        AutoPearlCatch.a(arrayList, n5 - 1);
        arrayList.add(ActionQueue.a(n2));
        AutoPearlCatch.a(arrayList, n4 - 1);
        arrayList.add(ActionQueue.a(Hand.MAIN_HAND));
        arrayList.add(ActionQueue.a(n3));
        arrayList.add(ActionQueue.a(() -> ((AutoPearlCatch)this).u()));
        arrayList.add(ActionQueue.a(() -> ((AutoPearlCatch)this).lambda$tryStart$0()));
        ActionQueue.a((Object)this, arrayList.toArray(new WaitCondition[0]));
    }

    private static void a(List list, int n) {
        if (n > 0) {
            list.add(ActionQueue.b(n));
        }
    }

    private boolean t() {
        return Module.mc.player != null && Module.mc.world != null && Module.mc.interactionManager != null && Module.mc.player.networkHandler != null && Module.mc.currentScreen == null && !Module.mc.player.isDead() && !Module.mc.player.isSpectator();
    }

    private int a(Item mc17) {
        for (int i = 0; i < 9; ++i) {
            ItemStack mc33 = Module.mc.player.getInventory().getStack(i);
            if (mc33.isEmpty() || !mc33.isOf(mc17)) continue;
            return i;
        }
        return -1;
    }

    private void u() {
        if (this.t) {
            Module.mc.options.forwardKey.setPressed(true);
            this.t = false;
        }
    }

    private void lambda$tryStart$0() {
        this.u = false;
    }
}

