/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;

public enum ModuleCategory {
    COMBAT(new StringConstant("Combat")), MOVEMENT(new StringConstant("Movement")), VISUAL(new StringConstant("Visual")), Utility(new StringConstant("Utility"));
    StringConstant a;

    public StringConstant a() {
        return this.$VALUES;
    }

    private ModuleCategory(StringConstant a) {
        this.$VALUES = a;

    }

    private static /* synthetic */ ModuleCategory[] b() {
        return new ModuleCategory[]{COMBAT, MOVEMENT, VISUAL, Utility};
    }

    static {
        $VALUES = ModuleCategory.$VALUES();
    }
}

