/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.MouseButtonEvent;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.AimAssist;
import itz.vrgn1337.groovclient.module.combat.AutoAnchor;
import itz.vrgn1337.groovclient.module.combat.AutoMace;
import itz.vrgn1337.groovclient.module.combat.AutoStunSlam;
import itz.vrgn1337.groovclient.module.combat.Backtrack;
import itz.vrgn1337.groovclient.module.combat.CrystalAura;
import itz.vrgn1337.groovclient.module.combat.DoubleHandTotem;
import itz.vrgn1337.groovclient.module.combat.ElytraSwap;
import itz.vrgn1337.groovclient.module.combat.FlickHit;
import itz.vrgn1337.groovclient.module.combat.HitSelect;
import itz.vrgn1337.groovclient.module.combat.MaceSwap;
import itz.vrgn1337.groovclient.module.combat.ShieldAim;
import itz.vrgn1337.groovclient.module.combat.ShieldBreaker;
import itz.vrgn1337.groovclient.module.combat.ShieldEater;
import itz.vrgn1337.groovclient.module.combat.SilentAim;
import itz.vrgn1337.groovclient.module.combat.SpearSwap;
import itz.vrgn1337.groovclient.module.combat.TotemHit;
import itz.vrgn1337.groovclient.module.combat.TriggerBot;
import itz.vrgn1337.groovclient.module.movement.FakeLag;
import itz.vrgn1337.groovclient.module.movement.JumpReset;
import itz.vrgn1337.groovclient.module.movement.KnockbackDelay;
import itz.vrgn1337.groovclient.module.movement.NoJumpDelay;
import itz.vrgn1337.groovclient.module.movement.Sprint;
import itz.vrgn1337.groovclient.module.movement.WTap;
import itz.vrgn1337.groovclient.module.utility.AutoPearlCatch;
import itz.vrgn1337.groovclient.module.utility.AutoTotem;
import itz.vrgn1337.groovclient.module.utility.FastBreak;
import itz.vrgn1337.groovclient.module.utility.FastPlace;
import itz.vrgn1337.groovclient.module.utility.KeyWindCharge;
import itz.vrgn1337.groovclient.module.utility.Macros;
import itz.vrgn1337.groovclient.module.utility.NoMiss;
import itz.vrgn1337.groovclient.module.utility.SilentRefill;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.module.utility.UnderPearl;
import itz.vrgn1337.groovclient.module.utility.Weapons;
import itz.vrgn1337.groovclient.module.visual.ESP;
import itz.vrgn1337.groovclient.module.visual.FogEditor;
import itz.vrgn1337.groovclient.module.visual.HitColor;
import itz.vrgn1337.groovclient.module.visual.Nametags;
import itz.vrgn1337.groovclient.module.visual.Outlines;
import itz.vrgn1337.groovclient.module.visual.StorageESP;
import itz.vrgn1337.groovclient.module.visual.Tracers;
import itz.vrgn1337.groovclient.module.visual.ViewModel;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ModuleManager {
    private static final ModuleManager a = new ModuleManager();
    private static volatile boolean b = false;
    private static final List<Module> c = new ArrayList<>();

    public static ModuleManager getInstance() {
        return a;
    }

    public void b() {
        if (b) {
            return;
        }
        b = true;
        Main.eventBus().register(this);
        ModuleManager.register(new AimAssist());
        ModuleManager.register(new AutoAnchor());
        ModuleManager.register(new AutoMace());
        ModuleManager.register(new AutoStunSlam());
        ModuleManager.register(new Backtrack());
        ModuleManager.register(new CrystalAura());
        ModuleManager.register(new DoubleHandTotem());
        ModuleManager.register(new ElytraSwap());
        ModuleManager.register(new FlickHit());
        ModuleManager.register(new HitSelect());
        ModuleManager.register(new MaceSwap());
        ModuleManager.register(new ShieldAim());
        ModuleManager.register(new ShieldBreaker());
        ModuleManager.register(new ShieldEater());
        ModuleManager.register(new SilentAim());
        ModuleManager.register(new SpearSwap());
        ModuleManager.register(new TotemHit());
        ModuleManager.register(new TriggerBot());
        ModuleManager.register(new FakeLag());
        ModuleManager.register(new JumpReset());
        ModuleManager.register(new KnockbackDelay());
        ModuleManager.register(new NoJumpDelay());
        ModuleManager.register(new Sprint());
        ModuleManager.register(new WTap());
        ModuleManager.register(new AutoPearlCatch());
        ModuleManager.register(new AutoTotem());
        ModuleManager.register(new FastBreak());
        ModuleManager.register(new FastPlace());
        ModuleManager.register(new KeyWindCharge());
        ModuleManager.register(new Macros());
        ModuleManager.register(new NoMiss());
        ModuleManager.register(new SilentRefill());
        ModuleManager.register(new TargetFilter());
        ModuleManager.register(new UnderPearl());
        ModuleManager.register(new Weapons());
        ModuleManager.register(new ESP());
        ModuleManager.register(new FogEditor());
        ModuleManager.register(new HitColor());
        ModuleManager.register(new Nametags());
        ModuleManager.register(new Outlines());
        ModuleManager.register(new StorageESP());
        ModuleManager.register(new Tracers());
        ModuleManager.register(new ViewModel());
    }

    public static void register(Module module) {
        Class<?> clazz = module.getClass();
        for (Module module2 : c) {
            if (module2.getClass() != clazz) continue;
            return;
        }
        c.add(module);
    }

    public static List<Module> c() {
        return c;
    }

    public static Module b(Module module) {
        for (Module module2 : c) {
            if (!module2.equals(module)) continue;
            return module2;
        }
        return null;
    }

    public static List a(ModuleCategory moduleCategory) {
        ArrayList<Module> arrayList = new ArrayList<Module>();
        for (Module module : c) {
            if (module.getCategory() != moduleCategory) continue;
            arrayList.add(module);
        }
        return arrayList;
    }

    public void a(int n, int n2) {
        this.c(n, n2);
    }

    @Priority(value=1000)
    private void onMouseButton(MouseButtonEvent mouseButtonEvent) {
        if (Main.mc.currentScreen instanceof MenuGuiScreen) {
            return;
        }
        if (mouseButtonEvent.action != 1) {
            return;
        }
        this.onMouseButton(KeybindSetting.getKey(mouseButtonEvent.button));
    }

    public boolean b(int n, int n2) {
        return this.c(n, n2) > 0;
    }

    private int c(int n, int n2) {
        HashSet<Module> hashSet = new HashSet();
        if (n != -1) {
            this.a(n, hashSet);
        }
        if (n2 >= 0) {
            this.a(KeybindSetting.reset(n2), hashSet);
        }
        int n3 = 0;
        for (Module module : hashSet) {
            module.toggleWithHud();
            ++n3;
        }
        return n3;
    }

    private int a(int n) {
        int n2 = 0;
        for (Module module : c) {
            if (module.getKeybind().d() != n) continue;
            module.toggleWithHud();
            ++n2;
        }
        return n2;
    }

    private void a(int n, Set set) {
        for (Module module : c) {
            if (module.getKeybind().d() != n) continue;
            set.add(module);
        }
    }
}

