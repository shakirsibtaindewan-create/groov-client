/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module;

import itz.vrgn1337.groovclient.api.util.SoundManager;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.b.c.HudManager;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.MinecraftClient;

public class Module {
    protected static MinecraftClient mc = MinecraftClient.getInstance();
    private final StringConstant name;
    private final StringConstant description;
    private boolean enabled;
    private boolean renderToggled;
    private boolean sendToggled;
    private StringConstant suffix;
    private volatile boolean blinking;
    private final ModuleCategory category;
    private final List settings = new ArrayList();
    private final KeybindSetting keybind;
    private final boolean hidden;
    private static volatile boolean suppressSound = false;

    public Module(ModuleCategory moduleCategory, StringConstant[] stringConstantArray) {
        this(moduleCategory, false, stringConstantArray);
    }

    public Module(ModuleCategory moduleCategory, boolean bl, StringConstant[] stringConstantArray) {
        this.category = moduleCategory;
        this.name = stringConstantArray[0];
        this.description = stringConstantArray[1];
        this.keybind = new KeybindSetting(new StringConstant("Bind"), new StringConstant("Key or mouse button to toggle this module"), -1);
        this.hidden = bl;
        if (this.hidden) {
            return;
        }
        this.addSetting(this.keybind);
    }

    public void onLoad() {
    }

    public void addSettings(List list) {
        list.forEach(arg_0 -> ((Module)this).lambda$addSettings$0(arg_0));
    }

    public void registerSettings(Setting[] settingArray) {
        this.addSettings(Arrays.stream(settingArray).toList());
    }

    private void addSetting(Setting setting) {
        if (this.settings.contains(setting)) {
            return;
        }
        this.settings.add(setting);
    }

    public List<Setting> getSettings() {
        return this.settings;
    }

    public KeybindSetting getKeybind() {
        return this.keybind;
    }

    public boolean isHidden() {
        return this.hidden;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void toggle() {
        boolean bl = this.enabled = !this.enabled;
        if (this.enabled) {
            this.onEnable();
        } else {
            this.onDisable();
        }
    }

    protected void setEnabled(boolean bl) {
        if (bl) {
            this.onEnable();
        } else {
            this.onDisable();
        }
    }

    public void setEnabledSilently(boolean bl) {
        if (this.enabled == bl) {
            return;
        }
        suppressSound = true;
        if (bl) {
            this.onEnable();
        } else {
            this.onDisable();
        }
        suppressSound = false;
    }

    protected void onEnable() {
        this.enabled = true;
        Main.eventBus().register(this);
        if (!suppressSound) {
            SoundManager.c();
        }
    }

    protected void onDisable() {
        this.enabled = false;
        Main.eventBus().unregister(this);
        if (!suppressSound) {
            SoundManager.d();
        }
    }

    protected void setRenderToggled(boolean bl) {
        this.renderToggled = bl;
    }

    protected boolean isRenderToggled() {
        return this.renderToggled;
    }

    protected void setSendToggled(boolean bl) {
        this.sendToggled = bl;
    }

    protected boolean isSendToggled() {
        return this.sendToggled;
    }

    public int getKey() {
        return this.keybind.getKey();
    }

    public void setKey(int n) {
        this.keybind.setKey(n);
    }

    @Deprecated
    public boolean isAlwaysListening() {
        return false;
    }

    public void toggleWithHud() {
        if (this.isAlwaysListening()) {
            if (this.isEnabled()) {
                this.setEnabled(false);
            }
            this.setEnabled(true);
            HudManager.getInstance().a(this, true);
            return;
        }
        this.toggle();
        HudManager.getInstance().a(this, this.enabled);
    }

    public StringConstant getName() {
        return this.name;
    }

    public StringConstant getDescription() {
        return this.description;
    }

    public ModuleCategory getCategory() {
        return this.category;
    }

    public StringConstant getSuffix() {
        return this.suffix;
    }

    protected void setSuffix(StringConstant stringConstant) {
        this.suffix = stringConstant;
    }

    public boolean isBlinking() {
        return this.blinking;
    }

    public void blink(int n) {
        this.blinking = true;
        Thread.ofVirtual().start(() -> ((Module)this).lambda$blink$1((int)n));
    }

    public void setBlinking(boolean bl) {
        this.blinking = bl;
    }

    private void lambda$blink$1(int n) {
        try {
            Thread.sleep(n);
        }
        catch (InterruptedException interruptedException) {
            // empty catch block
        }
        this.blinking = false;
    }

    private void lambda$addSettings$0(Setting setting) {
        this.addSetting(setting);
    }
}

