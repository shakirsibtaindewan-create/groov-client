/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.TweenUtil;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.AimRotationStyle;
import itz.vrgn1337.groovclient.module.combat.AimTargetSort;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.module.utility.Weapons;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.client.network.AbstractClientPlayerEntity;

public class AimAssist
extends Module {
    private final FloatSetting aimRange = new FloatSetting(new StringConstant("Aim Range"), new StringConstant("Range for selecting aim targets"), 1.0f, 8.0f, 4.5f, 0.1f);
    private final FloatSetting aimSpeed = new FloatSetting(new StringConstant("Aim Speed"), new StringConstant("Rotation speed"), 1.0f, 30.0f, 12.0f, 0.5f);
    private final BooleanSetting onlyOnWeapons = new BooleanSetting(new StringConstant("Only On Weapons"), new StringConstant("Only aims while holding a weapon"), true);
    private final ModeSetting aimPriority = new ModeSetting(new StringConstant("Aim Priority"), new StringConstant("Target prioritization mode"), AimTargetSort.CLOSEST);
    private final ModeSetting stopMode = new ModeSetting(new StringConstant("Stop Mode"), new StringConstant("When to stop active aim correction"), AimRotationStyle.Center);
    private PlayerEntity s;
    private PlayerEntity t;
    private AimTargetSort u = AimTargetSort.CLOSEST;
    private PlayerEntity v;
    private int w = 0;
    private int x = 0;
    private int y = 0;
    private int z = 0;
    private boolean A = false;
    private boolean B = false;
    private double C = 0.5;
    private double D = 0.66;
    private double E = 0.5;
    private boolean F = false;

    public AimAssist() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("AimAssist"), new StringConstant("Smoothly assists aim toward nearby players")});
        TweenUtil.getInstance();
        this.addSettings(List.of(this.aimRange, this.aimSpeed, this.onlyOnWeapons, this.aimPriority, this.stopMode));
    }

    @Override
    protected void onDisable() {
        TweenUtil.getInstance().a(this);
        RotationManager.getInstance().y();
        this.s = null;
        this.t = null;
        this.v = null;
        this.w = 0;
        this.x = 0;
        this.y = 0;
        this.z = 0;
        this.A = false;
        this.B = false;
        this.F = false;
    }

    private void onRenderWorldEventPre(RenderWorldEvent.Pre pre) {
        PlayerEntity mc6;
        if (!this.s()) {
            TweenUtil.getInstance().a(this);
            return;
        }
        if (this.onlyOnWeapons.getValue() && !Weapons.getInstance().u()) {
            TweenUtil.getInstance().a(this);
            return;
        }
        AimTargetSort aimTargetSort = (AimTargetSort)this.aimPriority.getValue();
        if (aimTargetSort != this.u) {
            this.s = null;
            this.u = aimTargetSort;
        }
        if ((mc6 = this.a(aimTargetSort)) == null) {
            TweenUtil.getInstance().a(this);
            return;
        }
        if (mc6 != this.v) {
            this.v = mc6;
            this.w = 0;
            this.x = 0;
            this.y = 0;
            this.z = 0;
            this.A = false;
            this.B = false;
            this.F = false;
        }
        if (this.b(mc6)) {
            return;
        }
        RotationManager.getInstance().a((LivingEntity)mc6, this.aimSpeed.getValue(), false);
    }

    private void onAttackEventPost(AttackEvent.Post post) {
        if (Module.mc.player == null || Module.mc.options == null) {
            return;
        }
        if (!Module.mc.options.attackKey.isPressed()) {
            return;
        }
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (!(ItemStackParticleEffect instanceof EntityHitResult)) {
            return;
        }
        EntityHitResult mc26 = (EntityHitResult)ItemStackParticleEffect;
        Entity mc2 = mc26.getEntity();
        if (mc2 instanceof PlayerEntity && (ItemStackParticleEffect_p = (PlayerEntity)mc2) != Module.mc.player) {
            this.t = ItemStackParticleEffect_p;
            this.s = ItemStackParticleEffect_p;
            return;
        }
        this.t = null;
    }

    private PlayerEntity a(AimTargetSort aimTargetSort) {
        ArrayList<AbstractClientPlayerEntity> arrayList = new ArrayList<AbstractClientPlayerEntity>();
        for (AbstractClientPlayerEntity TrackedPosition : Module.mc.world.getPlayers()) {
            if (!this.a((PlayerEntity)TrackedPosition)) continue;
            arrayList.add(TrackedPosition);
        }
        if (arrayList.isEmpty()) {
            this.s = null;
            if (!this.a(this.t)) {
                this.t = null;
            }
            return null;
        }
        if (!this.a(this.s)) {
            this.s = null;
        }
        if (!this.a(this.t)) {
            this.t = null;
        }
        return switch (aimTargetSort.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> {
                if (this.s == null) {
                    this.s = arrayList.stream().min(Comparator.comparingDouble((arg_0) -> ((AimAssist)this).lambda$selectTarget$0(arg_0))).orElse(null);
                }
                yield this.s;
            }
            case 1 -> this.t;
            case 2 -> arrayList.stream().min(Comparator.comparingDouble((arg_0) -> ((AimAssist)this).lambda$selectTarget$1(arg_0))).orElse(null);
            case 3 -> arrayList.stream().min(Comparator.comparingDouble(LivingEntity::getHealth)).orElse(null);
        };
    }

    private boolean s() {
        return Module.mc.player != null && Module.mc.world != null && Module.mc.currentScreen == null && !Module.mc.player.isDead() && !Module.mc.player.isSpectator();
    }

    private boolean a(PlayerEntity mc6) {
        if (mc6 == null) {
            return false;
        }
        if (!TargetFilter.a((Entity)mc6)) {
            return false;
        }
        if (Module.mc.player.distanceTo((Entity)mc6) > this.aimRange.getValue()) {
            return false;
        }
        return Module.mc.player.canSee((Entity)mc6);
    }

    private boolean b(PlayerEntity mc6) {
        return switch (((AimRotationStyle)this.stopMode.getValue()).ordinal()) {
            default -> throw new MatchException(null, null);
            case 1 -> {
                EntityHitResult var3_5;
                boolean var2_8;
                HitResult var4_2 = Module.mc.crosshairTarget;
                boolean v0 = var2_8 = var4_2 instanceof EntityHitResult && (var3_5 = (EntityHitResult)var4_2).getEntity() == mc6;
                if (!this.A) {
                    int v1 = this.w = var2_8 ? Math.min(8, this.w + 1) : 0;
                    if (this.w >= 3) {
                        this.A = true;
                        this.z = 0;
                    }
                } else if (var2_8) {
                    this.z = 0;
                } else {
                    this.z = Math.min(8, this.z + 1);
                    if (this.z >= 4) {
                        this.A = false;
                        this.z = 0;
                        this.w = 0;
                    }
                }
                yield this.A;
            }
            case 0 -> {
                Vec3d var2_9 = mc6.getBoundingBox().getCenter();
                Vec3d var3_6 = Module.mc.player.getEyePos();
                double var4_3 = var2_9.x - var3_6.x;
                double var6_11 = var2_9.z - var3_6.z;
                float var8_12 = (float)(Math.toDegrees(Math.atan2(var6_11, var4_3)) - 90.0);
                float var9_13 = Math.abs(MathHelper.wrapDegrees((float)(var8_12 - Module.mc.player.getYaw())));
                float var10_15 = 0.95f;
                float var11_17 = 2.8f;
                if (!this.A) {
                    int v3 = this.x = var9_13 <= 0.95f ? Math.min(8, this.x + 1) : 0;
                    if (this.x >= 3) {
                        this.A = true;
                        this.z = 0;
                    }
                } else if (var9_13 <= 2.8f) {
                    this.z = 0;
                } else {
                    this.z = Math.min(8, this.z + 1);
                    if (this.z >= 4) {
                        this.A = false;
                        this.z = 0;
                        this.x = 0;
                    }
                }
                yield this.A;
            }
            case 2 -> {
                EntityHitResult var3_7;
                HitResult var4_4;
                boolean var2_10;
                if (!this.B) {
                    this.t();
                }
                boolean v4 = var2_10 = (var4_4 = Module.mc.crosshairTarget) instanceof EntityHitResult && (var3_7 = (EntityHitResult)var4_4).getEntity() == mc6;
                if (this.F && !var2_10) {
                    this.t();
                    this.A = false;
                    this.z = 0;
                    this.y = 0;
                }
                this.F = var2_10;
                var3_7 = this.d(mc6);
                var4_4 = Module.mc.player.getEyePos();
                double var5_19 = var3_7.x - var4_4.x;
                double var7_20 = var3_7.z - var4_4.z;
                float var9_14 = (float)(Math.toDegrees(Math.atan2(var7_20, var5_19)) - 90.0);
                float var10_16 = Math.abs(MathHelper.wrapDegrees((float)(var9_14 - Module.mc.player.getYaw())));
                float var11_18 = 0.95f;
                float var12_21 = 2.7f;
                if (!this.A) {
                    int v5 = this.y = var10_16 <= 0.95f ? Math.min(8, this.y + 1) : 0;
                    if (this.y >= 3) {
                        this.A = true;
                        this.z = 0;
                    }
                } else if (var10_16 <= 2.7f) {
                    this.z = 0;
                } else {
                    this.z = Math.min(8, this.z + 1);
                    if (this.z >= 4) {
                        this.A = false;
                        this.z = 0;
                        this.y = 0;
                    }
                }
                yield this.A;
            }
        };
    }

    private Vec3d c(PlayerEntity mc6) {
        if (this.stopMode.getValue() == AimRotationStyle.Random) {
            if (!this.B) {
                this.t();
            }
            return this.d(mc6);
        }
        return mc6.getBoundingBox().getCenter();
    }

    private void t() {
        this.C = ThreadLocalRandom.current().nextDouble(0.12, 0.88);
        this.D = ThreadLocalRandom.current().nextDouble(0.46, 0.88);
        this.E = ThreadLocalRandom.current().nextDouble(0.12, 0.88);
        this.B = true;
    }

    private Vec3d d(PlayerEntity mc6) {
        Box Vec3i = mc6.getBoundingBox();
        double d = MathHelper.lerp((double)this.C, (double)Vec3i.minX, (double)Vec3i.maxX);
        double d2 = Vec3i.minY + (double)mc6.getHeight() * this.D;
        double d3 = MathHelper.lerp((double)this.E, (double)Vec3i.minZ, (double)Vec3i.maxZ);
        return new Vec3d(d, d2, d3);
    }

    private static double lambda$selectTarget$1(PlayerEntity mc6) {
        return Module.mc.player.squaredDistanceTo((Entity)mc6);
    }

    private static double lambda$selectTarget$0(PlayerEntity mc6) {
        return Module.mc.player.squaredDistanceTo((Entity)mc6);
    }
}

