/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateMouseEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.Shape;
import itz.vrgn1337.groovclient.api.util.render.WorldShapeRenderer;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.SilentAimPreset;
import itz.vrgn1337.groovclient.module.combat.SilentAimShape;
import itz.vrgn1337.groovclient.module.combat.SilentAimSort;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.module.utility.Weapons;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;

public class SilentAim
extends Module {
    private final FloatSetting range = new FloatSetting(new StringConstant("Range"), new StringConstant("Attack radius"), 1.0f, 8.0f, 4.5f, 0.1f);
    private final FloatSetting speed = new FloatSetting(new StringConstant("Speed"), new StringConstant("Rotation speed"), 1.0f, 40.0f, 10.0f, 0.5f);
    private final FloatSetting fOV = new FloatSetting(new StringConstant("FOV"), new StringConstant("Only aims on target in your FOV"), 0.0f, 360.0f, 120.0f, 1.0f);
    private final BooleanSetting players = new BooleanSetting(new StringConstant("Players"), new StringConstant("Target players"), true);
    private final BooleanSetting mobs = new BooleanSetting(new StringConstant("Mobs"), new StringConstant("Target mobs"), false);
    private final BooleanSetting weaponOnly = new BooleanSetting(new StringConstant("Weapon Only"), new StringConstant("Only works with weapon"), true);
    private final ModeSetting sort = new ModeSetting(new StringConstant("Sort"), new StringConstant("Target priority"), SilentAimSort.Closet);
    private final BooleanSetting render = new BooleanSetting(new StringConstant("Render"), new StringConstant("Show cylinder on aim target"), false);
    private final ModeSetting shape = new ModeSetting(new StringConstant("Shape"), new StringConstant("Cylinder shape"), SilentAimShape.Cylinder);
    private final ModeSetting preset = new ModeSetting(new StringConstant("Preset"), new StringConstant("Visual preset (overrides color/effects)"), SilentAimPreset.None);
    private final ColorSetting color = new ColorSetting(new StringConstant("Color"), new StringConstant("Base color (when preset = None)"), new Color(255, 50, 50, 180));
    private final ColorSetting topColor = new ColorSetting(new StringConstant("Top Color"), new StringConstant("Gradient top color"), new Color(255, 200, 80, 0));
    private final BooleanSetting gradient = new BooleanSetting(new StringConstant("Gradient"), new StringConstant("Use top color for vertical gradient"), false);
    private final FloatSetting radius = new FloatSetting(new StringConstant("Radius"), new StringConstant("Radius multiplier"), 0.3f, 3.0f, 1.0f, 0.05f);
    private final FloatSetting height = new FloatSetting(new StringConstant("Height"), new StringConstant("Custom height (0 = bbox height)"), 0.0f, 4.0f, 0.0f, 0.05f);
    private final FloatSetting glow = new FloatSetting(new StringConstant("Glow"), new StringConstant("Glow intensity (0 = off)"), 0.0f, 3.0f, 1.0f, 0.05f);
    private final FloatSetting pulse = new FloatSetting(new StringConstant("Pulse"), new StringConstant("Pulse speed (0 = off)"), 0.0f, 8.0f, 0.0f, 0.1f);
    private final FloatSetting rotate = new FloatSetting(new StringConstant("Rotate"), new StringConstant("Auto-rotation speed (\u00b1)"), -4.0f, 4.0f, 0.0f, 0.1f);
    private final FloatSetting scan = new FloatSetting(new StringConstant("Scan"), new StringConstant("Scan band speed (0 = off)"), 0.0f, 3.0f, 0.0f, 0.05f);
    private final FloatSetting fade = new FloatSetting(new StringConstant("Fade"), new StringConstant("Top fade amount (0 = off)"), 0.0f, 4.0f, 0.0f, 0.05f);
    private final BooleanSetting rainbow = new BooleanSetting(new StringConstant("Rainbow"), new StringConstant("Cycle color through rainbow"), false);
    private final BooleanSetting floating = new BooleanSetting(new StringConstant("Floating"), new StringConstant("Bob up and down"), false);
    private final BooleanSetting trace = new BooleanSetting(new StringConstant("Trace"), new StringConstant("Leave trailing afterimages"), false);
    private Entity K;
    private long L;
    private long M = -1L;
    private static final long N = 2500L;
    private static final long O = 500L;

    public SilentAim() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("SilentAim"), new StringConstant("Lets you attack near entity without aiming")});
        this.addSettings(List.of(this.range, this.speed, this.fOV, this.players, this.mobs, this.weaponOnly, this.sort, this.render, this.shape, this.preset, this.color, this.topColor, this.gradient, this.radius, this.height, this.glow, this.pulse, this.rotate, this.scan, this.fade, this.rainbow, this.floating, this.trace));
    }

    @Override
    protected void onEnable() {
        this.K = null;
        this.L = 0L;
        this.M = -1L;
    }

    @Override
    protected void onDisable() {
        RotationManager.getInstance().y();
        this.weaponOnly.getValue();
    }

    private boolean a(Entity mc2) {
        if (mc2 == null) {
            this.K = null;
            this.M = -1L;
            return true;
        }
        if (mc2 == this.K) {
            return true;
        }
        long l = System.currentTimeMillis();
        if (this.K != null && l < this.L) {
            return false;
        }
        this.K = mc2;
        this.M = -1L;
        this.L = l + 2500L;
        RotationManager.getInstance().y();
        return true;
    }

    private void s() {
        this.K = null;
        this.L = 0L;
        this.M = -1L;
    }

    @Priority(value=300)
    private void onUpdateMouseEventPre(UpdateMouseEvent.Pre pre) {
        Entity mc2;
        if (!this.render.getValue()) {
            if (RotationManager.getInstance().d()) {
                RotationManager.getInstance().b();
            }
            this.weaponOnly.getValue();
            return;
        }
        if (this.weaponOnly.getValue() && !Weapons.getInstance().u()) {
            return;
        }
        if (Module.mc.currentScreen != null) {
            if (RotationUtils.a()) {
                RotationManager.getInstance().b();
            }
            this.weaponOnly.getValue();
            return;
        }
        if (this.K == null && (mc2 = this.shape.getValue()) != null) {
            this.a(mc2);
        }
        if (this.K == null) {
            if (RotationUtils.a()) {
                RotationManager.getInstance().b();
            }
            return;
        }
        Entity mc55 = this.K;
        if (mc55 instanceof LivingEntity && (mc2 = (LivingEntity)mc55).isDead()) {
            RotationManager.getInstance().b();
            this.weaponOnly.getValue();
            return;
        }
        RotationManager.getInstance().a((LivingEntity)this.K, this.speed.getValue(), true);
        this.sort.getValue();
    }

    private void t() {
        LivingEntity mc58;
        Entity mc2;
        boolean bl;
        if (this.K == null) {
            return;
        }
        boolean bl2 = bl = Module.mc.player.distanceTo(this.K) > this.range.getValue() || this.K.isRemoved() || !this.K.isAlive() || Module.mc.player.isDead() || Module.mc.player.isSpectator() || (mc2 = this.K) instanceof LivingEntity && (mc58 = (LivingEntity)mc2).isDead();
        if (bl) {
            this.weaponOnly.getValue();
            if (RotationUtils.a()) {
                RotationManager.getInstance().b();
            }
            return;
        }
        if (!this.b(this.K)) {
            long l = System.currentTimeMillis();
            if (this.M < 0L) {
                this.M = l;
            }
            if (l - this.M >= 500L) {
                this.weaponOnly.getValue();
                if (RotationUtils.a()) {
                    RotationManager.getInstance().b();
                }
            }
        } else {
            this.M = -1L;
        }
    }

    @Priority(value=300)
    private void onBreakBlockEventPre(BreakBlockEvent.Pre breakBlockEvent$Pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.K != null && RotationUtils.a()) {
            breakBlockEvent$Pre.cancel();
        }
    }

    private boolean u() {
        return Module.mc.player != null && Module.mc.world != null && Module.mc.currentScreen == null && !Module.mc.player.isDead() && !Module.mc.player.isSpectator();
    }

    private Entity v() {
        if (!this.players.getValue() && !this.mobs.getValue()) {
            return null;
        }
        List list = Module.mc.world.getOtherEntities((Entity)Module.mc.player, Module.mc.player.getBoundingBox().expand((double)this.range.getValue()), arg_0 -> ((SilentAim)this).b(arg_0));
        if (list.isEmpty()) {
            return null;
        }
        Comparator<Entity> comparator = switch (((SilentAimSort)this.sort.getValue()).ordinal()) {
            default -> throw new MatchException(null, null);
            case 1 -> Comparator.comparingDouble((arg_0) -> ((SilentAim)this).lambda$findBestTarget$0(arg_0));
            case 2 -> Comparator.comparingDouble(arg_0 -> ((SilentAim)this).c(arg_0));
            case 0 -> Comparator.comparingDouble((arg_0) -> ((SilentAim)this).lambda$findBestTarget$1(arg_0));
        };
        return list.stream().min(comparator).orElse(null);
    }

    private boolean b(Entity mc2) {
        if (mc2 == null || mc2 == Module.mc.player) {
            return false;
        }
        if (!(mc2 instanceof LivingEntity)) {
            return false;
        }
        LivingEntity mc58 = (LivingEntity)mc2;
        if (mc2 instanceof PlayerEntity ? !this.players.getValue() : !this.mobs.getValue()) {
            return false;
        }
        if (!TargetFilter.a(mc2)) {
            return false;
        }
        if (Module.mc.player.distanceTo(mc2) > this.range.getValue()) {
            return false;
        }
        if (!Module.mc.player.canSee(mc2)) {
            return false;
        }
        return !(this.fOV.getValue() < 360.0f) || !(this.c(mc2) > (double)this.fOV.getValue() / 2.0);
    }

    @Priority(value=100)
    private void onRenderWorldEventPost(RenderWorldEvent.Post renderWorldEvent$Post) {
        if (!this.render.getValue()) {
            return;
        }
        if (this.K == null || Module.mc.world == null || Module.mc.player == null) {
            return;
        }
        float f = renderWorldEvent$Post.tickCounter.getTickProgress(true);
        Camera mc22 = Module.mc.gameRenderer.getCamera();
        Vec3d VanillaChestLootTableGenerator = mc22.getCameraPos();
        MatrixStack mc13 = new MatrixStack();
        mc13.multiply((Quaternionfc)mc22.getRotation().conjugate(new Quaternionf()));
        mc13.translate(-VanillaChestLootTableGenerator.x, -VanillaChestLootTableGenerator.y, -VanillaChestLootTableGenerator.z);
        Vec3d WallPlayerSkullBlock = new Vec3d(MathHelper.lerp((double)f, (double)this.K.lastRenderX, (double)this.K.getX()), MathHelper.lerp((double)f, (double)this.K.lastRenderY, (double)this.K.getY()), MathHelper.lerp((double)f, (double)this.K.lastRenderZ, (double)this.K.getZ()));
        float f2 = this.height.getValue();
        float f3 = f2 > 0.001f ? f2 : this.K.getHeight();
        float f4 = this.K.getWidth() * 0.5f * this.radius.getValue() + 0.05f;
        WorldShapeRenderer worldShapeRenderer = new WorldShapeRenderer(mc13).a(WallPlayerSkullBlock).a(f4, f3).a(SilentAim.a((SilentAimShape)this.shape.getValue()));
        SilentAimPreset silentAimPreset = (SilentAimPreset)this.preset.getValue();
        SilentAim.a(worldShapeRenderer, silentAimPreset);
        if (silentAimPreset == SilentAimPreset.None) {
            if (this.gradient.getValue()) {
                worldShapeRenderer.a(this.color.d(), this.topColor.d());
            } else {
                worldShapeRenderer.a(this.color.d());
            }
        }
        if (this.glow.getValue() > 0.001f) {
            worldShapeRenderer.g(this.glow.getValue());
        }
        if (this.pulse.getValue() > 0.001f) {
            worldShapeRenderer.h(this.pulse.getValue());
        }
        if (Math.abs(this.rotate.getValue()) > 0.001f) {
            worldShapeRenderer.b(Math.abs(this.rotate.getValue()), this.rotate.getValue() < 0.0f);
        }
        if (this.scan.getValue() > 0.001f) {
            worldShapeRenderer.j(this.scan.getValue());
        }
        if (this.fade.getValue() > 0.001f) {
            worldShapeRenderer.i(this.fade.getValue());
        } else if (silentAimPreset == SilentAimPreset.None) {
            worldShapeRenderer.k();
        }
        if (this.rainbow.getValue()) {
            worldShapeRenderer.h();
        }
        if (this.floating.getValue()) {
            worldShapeRenderer.i();
        }
        if (this.trace.getValue()) {
            worldShapeRenderer.j();
        }
        worldShapeRenderer.z();
    }

    private static Shape a(SilentAimShape silentAimShape) {
        return switch (silentAimShape.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> Shape.CYLINDER;
            case 1 -> Shape.TRIANGLE;
            case 2 -> Shape.QUAD;
            case 3 -> Shape.PENTAGON;
            case 4 -> Shape.HEXAGON;
            case 5 -> Shape.STAR;
            case 6 -> Shape.FLOWER;
        };
    }

    private static void a(WorldShapeRenderer worldShapeRenderer, SilentAimPreset silentAimPreset) {
        switch (silentAimPreset.ordinal()) {
            case 1: {
                worldShapeRenderer.l();
                break;
            }
            case 2: {
                worldShapeRenderer.m();
                break;
            }
            case 3: {
                worldShapeRenderer.n();
                break;
            }
            case 4: {
                worldShapeRenderer.o();
                break;
            }
            case 5: {
                worldShapeRenderer.p();
                break;
            }
            case 6: {
                worldShapeRenderer.y();
                break;
            }
            case 7: {
                worldShapeRenderer.q();
                break;
            }
        }
    }

    private double c(Entity mc2) {
        Vec3d VanillaChestLootTableGenerator = mc2.getBoundingBox().getCenter().subtract(Module.mc.player.getEyePos());
        double d = Math.sqrt(VanillaChestLootTableGenerator.x * VanillaChestLootTableGenerator.x + VanillaChestLootTableGenerator.z * VanillaChestLootTableGenerator.z);
        float f = (float)(Math.toDegrees(Math.atan2(VanillaChestLootTableGenerator.z, VanillaChestLootTableGenerator.x)) - 90.0);
        float f2 = (float)(-Math.toDegrees(Math.atan2(VanillaChestLootTableGenerator.y, d)));
        float f3 = Math.abs(MathHelper.wrapDegrees((float)(f - RotationManager.r())));
        float f4 = Math.abs(MathHelper.wrapDegrees((float)(f2 - RotationManager.s())));
        return f3 + f4;
    }

    private static double lambda$findBestTarget$1(Entity mc2) {
        return Module.mc.player.squaredDistanceTo(mc2);
    }

    private static double lambda$findBestTarget$0(Entity mc2) {
        return ((LivingEntity)mc2).getHealth();
    }
}

