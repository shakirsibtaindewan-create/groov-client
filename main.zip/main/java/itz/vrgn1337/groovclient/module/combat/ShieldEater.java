/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.BindManager;
import itz.vrgn1337.groovclient.api.util.combat.CombatUtils;
import itz.vrgn1337.groovclient.api.util.item.SlotUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.RaycastUtils;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.ShieldEaterEnchant;
import itz.vrgn1337.groovclient.module.combat.ShieldEaterMode;
import itz.vrgn1337.groovclient.module.combat.ShieldEaterState;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.registry.entry.RegistryEntry;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;

public class ShieldEater
extends Module {
    private final ModeSetting mode = new ModeSetting(new StringConstant("Mode"), new StringConstant("Legit for most situation, Blatant for aggressive playstyle"), ShieldEaterMode.LEGIT);
    private final FloatSetting hitPerTick = new FloatSetting(new StringConstant("Hit Per Tick"), new StringConstant("Attacks per tick during burst"), 1.0f, 12.0f, 3.0f, 1.0f);
    private final FloatSetting minFall = new FloatSetting(new StringConstant("Min Fall"), new StringConstant("Minimum fall distance to start burst"), 3.0f, 25.0f, 8.0f, 0.5f);
    private final FloatSetting minFallSpeed = new FloatSetting(new StringConstant("Min Fall Speed"), new StringConstant("Only works on reach selected fall speed"), 0.0f, 4.0f, 0.0f, 0.1f);
    private final ModeSetting enchant = new ModeSetting(new StringConstant("Enchant"), new StringConstant("Preferred mace enchant"), ShieldEaterEnchant.DENSITY);
    private final BooleanSetting autoSwap = new BooleanSetting(new StringConstant("Auto Swap"), new StringConstant("Auto swap to mace when conditions met"), true);
    private final BooleanSetting shieldOnly = new BooleanSetting(new StringConstant("Shield Only"), new StringConstant("Only burst when target is blocking"), true);
    private final BooleanSetting swapBack = new BooleanSetting(new StringConstant("Swap Back"), new StringConstant("Return to previous slot on landing"), true);
    private ShieldEaterState v = ShieldEaterState.IDLE;
    private PlayerEntity w;
    private int x = -1;
    private boolean y;

    public ShieldEater() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("ShieldEater"), new StringConstant("Breaks enemy shield durability with mace")});
        this.addSettings(List.of(this.mode, this.hitPerTick, this.minFall, this.minFallSpeed, this.enchant, this.autoSwap, this.shieldOnly, this.swapBack));
    }

    @Override
    protected void onEnable() {
        this.autoSwap.getValue();
    }

    @Override
    protected void onDisable() {
        this.shieldOnly.getValue();
        this.autoSwap.getValue();
    }

    private void s() {
        this.v = ShieldEaterState.IDLE;
        this.w = null;
        this.y = false;
        this.x = -1;
    }

    private void t() {
        if (this.y && this.x != -1 && Module.mc.player != null) {
            SlotUtils.c(this.x);
        }
        this.y = false;
        this.x = -1;
    }

    @Priority(value=250)
    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (!this.B()) {
            return;
        }
        if (Module.mc.currentScreen != null) {
            return;
        }
        if (Module.mc.player.isUsingItem()) {
            return;
        }
        if (Module.mc.player.isOnGround()) {
            if (this.v == ShieldEaterState.BURSTING) {
                if (this.swapBack.getValue()) {
                    this.shieldOnly.getValue();
                }
                this.autoSwap.getValue();
            }
            return;
        }
        if (Module.mc.player.getVelocity().y >= 0.0) {
            return;
        }
        switch (this.v.ordinal()) {
            case 0: {
                this.swapBack.getValue();
                break;
            }
            case 1: {
                this.v();
            }
        }
    }

    private void u() {
        if (Module.mc.player.fallDistance < (double)this.minFall.getValue()) {
            return;
        }
        float f = this.minFallSpeed.getValue();
        if (f > 0.0f && -Module.mc.player.getVelocity().y < (double)f) {
            return;
        }
        PlayerEntity mc6 = this.y();
        if (mc6 == null) {
            return;
        }
        int n = this.z();
        if (n == -1) {
            return;
        }
        this.w = mc6;
        this.v = ShieldEaterState.BURSTING;
        this.w();
    }

    private void v() {
        if (this.w == null || !this.w.isAlive() || this.w.isRemoved()) {
            this.autoSwap.getValue();
            return;
        }
        if (!CombatUtils.a((Entity)this.w)) {
            this.autoSwap.getValue();
            return;
        }
        if (this.shieldOnly.getValue() && !CombatUtils.a(this.w)) {
            if (this.swapBack.getValue()) {
                this.shieldOnly.getValue();
            }
            this.autoSwap.getValue();
            return;
        }
        this.w();
    }

    private void w() {
        int n = this.x();
        if (this.mode.getValue() == ShieldEaterMode.BLATANT) {
            BindManager.j();
        }
        try {
            for (int i = 0; i < n; ++i) {
                Module.mc.interactionManager.attackEntity((PlayerEntity)Module.mc.player, (Entity)this.w);
                Module.mc.player.swingHand(Hand.MAIN_HAND);
            }
            Main.eventBus().post(AttackEvent.ManualCalledAttack.getInstance());
        }
        finally {
            if (this.mode.getValue() == ShieldEaterMode.BLATANT) {
                BindManager.k();
            }
        }
    }

    private int x() {
        int n = (int)this.hitPerTick.getValue();
        if (n <= 1) {
            return 1;
        }
        int n2 = ThreadLocalRandom.current().nextInt(-1, 2);
        return Math.max(1, Math.min(n + n2, (int)this.hitPerTick.getMax()));
    }

    private PlayerEntity y() {
        HitResult ItemStackParticleEffect = RaycastUtils.a(3.0);
        if (!(ItemStackParticleEffect instanceof EntityHitResult)) {
            return null;
        }
        EntityHitResult mc26 = (EntityHitResult)ItemStackParticleEffect;
        Entity mc2 = mc26.getEntity();
        if (!(mc2 instanceof PlayerEntity)) {
            return null;
        }
        PlayerEntity ItemStackParticleEffect_p;
        ItemStackParticleEffect_p = (PlayerEntity)mc2;
        if (!TargetFilter.a((Entity)ItemStackParticleEffect_p)) {
            return null;
        }
        if (!Module.mc.player.canSee((Entity)ItemStackParticleEffect)) {
            return null;
        }
        if (this.shieldOnly.getValue() && !CombatUtils.a((PlayerEntity)ItemStackParticleEffect)) {
            return null;
        }
        return ItemStackParticleEffect;
    }

    private int z() {
        if (Module.mc.player.getMainHandStack().getItem() == Items.MACE) {
            return Module.mc.player.getInventory().getSelectedSlot();
        }
        if (!this.autoSwap.getValue()) {
            return -1;
        }
        int n = this.A();
        if (n == -1) {
            return -1;
        }
        if (!this.y) {
            this.x = Module.mc.player.getInventory().getSelectedSlot();
            this.y = true;
        }
        SlotUtils.c(n);
        return n;
    }

    private int A() {
        int n = -1;
        String string = switch (((ShieldEaterEnchant)this.enchant.getValue()).ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> "density";
            case 1 -> "breach";
            case 2 -> null;
        };
        for (int i = 0; i < 9; ++i) {
            ItemStack mc33 = Module.mc.player.getInventory().getStack(i);
            if (mc33.getItem() != Items.MACE) continue;
            if (string == null) {
                return i;
            }
            if (this.a(mc33, string)) {
                return i;
            }
            if (n != -1) continue;
            n = i;
        }
        return n;
    }

    private boolean a(ItemStack mc33, String string) {
        if (mc33.isEmpty()) {
            return false;
        }
        return mc33.getEnchantments().getEnchantments().stream().anyMatch(arg_0 -> Q.lambda$hasEnchant$0((String)string, arg_0));
    }

    private boolean B() {
        return Module.mc.player != null && Module.mc.world != null && Module.mc.interactionManager != null && Module.mc.currentScreen == null && !Module.mc.player.isDead() && !Module.mc.player.isSpectator();
    }

    private static boolean lambda$hasEnchant$0(String string, RegistryEntry mc96) {
        return mc96.getIdAsString().toLowerCase().contains(string);
    }
}

