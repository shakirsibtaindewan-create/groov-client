/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

enum TotemThreat {
    LOW_HEALTH, POP, CRYSTAL, ANCHOR, SWORD, MACE, PROJECTILE, MISC;

    private TotemThreat() {

    }

}

