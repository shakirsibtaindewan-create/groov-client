/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateMouseEvent;
import itz.vrgn1337.groovclient.api.util.Stopwatch;
import itz.vrgn1337.groovclient.api.util.input.InputUtils;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.item.SlotUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.world.BlockUtils;
import itz.vrgn1337.groovclient.api.util.world.RaycastHit;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.HotbarSlotSetting;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.BlockHitResult;

public class NewAutoAnchor
extends Module {
    private final KeybindSetting key = new KeybindSetting(new StringConstant("Key"), new StringConstant("Key to trigger"), KeybindSetting.getKey(1));
    private final FloatSetting placeDelay = new FloatSetting(new StringConstant("Place Delay"), new StringConstant("Wait time before place"), 0.0f, 500.0f, 100.0f, 10.0f);
    private final FloatSetting swapDelay = new FloatSetting(new StringConstant("Swap Delay"), new StringConstant("Wait time before swap"), 0.0f, 500.0f, 100.0f, 10.0f);
    private final FloatSetting explodeDelay = new FloatSetting(new StringConstant("Explode Delay"), new StringConstant("Wait time before explode charged anchor"), 0.0f, 500.0f, 100.0f, 10.0f);
    private final HotbarSlotSetting r = new HotbarSlotSetting(new StringConstant("Explode Slot"), new StringConstant("Select slot to explode anchor with"), new boolean[]{false, false, false, false, false, false, false, false, false}, true);
    private final BooleanSetting safeAnchor = new BooleanSetting(new StringConstant("Safe Anchor"), new StringConstant("Place block before explode"), false);
    private final Stopwatch t = new Stopwatch();
    private final Stopwatch u = new Stopwatch();
    private final Stopwatch v = new Stopwatch();
    private Vec3d w = Vec3d.ZERO;
    private Vec3d x = Vec3d.ZERO;
    private RaycastHit y;

    public NewAutoAnchor() {
        super(ModuleCategory.COMBAT, true, new StringConstant[]{new StringConstant("NewAutoAnchor"), new StringConstant("")});
        this.onUpdateMouseEventPre(new Setting[]{this.key, this.placeDelay, this.swapDelay, this.explodeDelay, this.r, this.safeAnchor});
    }

    @Override
    protected void onEnable() {
        this.w = this.x = Vec3d.ZERO;
        this.y = null;
        this.t.b();
        this.u.b();
        this.v.b();
    }

    private void onUpdateMouseEventPre(UpdateMouseEvent.Pre pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (!this.key.isBound()) {
            return;
        }
        boolean bl = this.safeAnchor.getValue();
        this.w();
        this.u();
        if (!bl) {
            this.v();
        } else {
            this.safeAnchor.getValue();
            this.t();
        }
    }

    private void s() {
        RotationManager.getInstance().a(this.w, 10.0f, false);
        if (this.y != null) {
            BlockHitResult mc7;
            HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
            if (ItemStackParticleEffect instanceof BlockHitResult && (mc7 = (BlockHitResult)ItemStackParticleEffect).getBlockPos().equals((Object)this.y.a()) && mc7.getSide() == this.y.b() && this.onUpdateMouseEventPre(Items.GLOWSTONE)) {
                InputUtils.b();
                this.y = null;
                this.w = this.x;
                this.x = Vec3d.ZERO;
                this.t.b();
                this.v.b();
            }
        } else if (this.onUpdateMouseEventPre(Items.GLOWSTONE)) {
            if (this.u.a((double)this.swapDelay.getValue())) {
                this.u.b();
                int n = this.r.g();
                if (n >= 0) {
                    SlotUtils.c(n);
                }
            }
        } else {
            BlockPos mc0 = this.x.getValue();
            if (mc0 != null && BlockUtils.b(mc0) && this.v.a((double)this.explodeDelay.getValue())) {
                this.v.b();
                InputUtils.b();
                this.w = Vec3d.ZERO;
            }
        }
    }

    private void t() {
        BlockPos mc0 = this.x.getValue();
        if (mc0 != null && BlockUtils.b(mc0) && this.t.a((double)this.placeDelay.getValue())) {
            RaycastHit raycastHit;
            this.t.b();
            if (!this.onUpdateMouseEventPre(Items.GLOWSTONE)) {
                int n = ItemUtils.f(Items.GLOWSTONE);
                if (n < 0) {
                    return;
                }
                SlotUtils.c(n);
            }
            if ((raycastHit = BlockUtils.a(mc0, Module.mc.player.getSteppingPos(), Direction.UP)) == null) {
                return;
            }
            this.y = raycastHit;
            this.w = BlockUtils.a(raycastHit.a(), raycastHit.b());
            this.x = mc0.toCenterPos();
            this.v.b();
        }
    }

    private void u() {
        if (this.x.getValue() != null && this.onUpdateMouseEventPre(Items.GLOWSTONE) && this.t.a((double)this.placeDelay.getValue())) {
            this.t.b();
            this.v.b();
            InputUtils.b();
        }
    }

    private void v() {
        BlockPos mc0 = this.x.getValue();
        if (mc0 == null) {
            return;
        }
        if (BlockUtils.b(mc0) && !this.onUpdateMouseEventPre(Items.GLOWSTONE) && this.v.a((double)this.explodeDelay.getValue())) {
            this.v.b();
            InputUtils.b();
        }
    }

    private void w() {
        BlockPos mc0 = this.x.getValue();
        if (mc0 == null) {
            return;
        }
        if (!BlockUtils.b(mc0)) {
            if (this.u.a((double)this.swapDelay.getValue())) {
                this.u.b();
                int n = ItemUtils.f(Items.GLOWSTONE);
                if (n < 0) {
                    return;
                }
                SlotUtils.c(n);
            }
        } else if (this.u.a((double)this.swapDelay.getValue())) {
            this.u.b();
            int n = this.r.g();
            if (n < 0) {
                return;
            }
            SlotUtils.c(n);
        }
    }

    private boolean a(Item mc17) {
        return Module.mc.player.getMainHandStack().getItem() == mc17;
    }

    private BlockPos x() {
        BlockHitResult mc7;
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (ItemStackParticleEffect instanceof BlockHitResult && Module.mc.world.getBlockState((mc7 = (BlockHitResult)ItemStackParticleEffect).getBlockPos()).getBlock() == Blocks.RESPAWN_ANCHOR) {
            return mc7.getBlockPos();
        }
        return null;
    }
}

