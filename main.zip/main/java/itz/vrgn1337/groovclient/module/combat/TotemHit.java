/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.item.SlotUtils;
import itz.vrgn1337.groovclient.api.util.math.RandomUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import net.minecraft.item.Items;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;

public class TotemHit
extends Module {
    private final FloatSetting chance = new FloatSetting(new StringConstant("Chance"), null, 0.0f, 100.0f, 100.0f, 1.0f);
    private final BooleanSetting silent = new BooleanSetting(new StringConstant("Silent"), new StringConstant("Uses silent swap"), true);
    private int p = -1;

    public TotemHit() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("TotemHit"), new StringConstant("Swaps to knockback sword when attack with totem")});
        this.registerSettings(new Setting[]{this.chance, this.silent});
    }

    @Override
    protected void onDisable() {
        this.p = -1;
    }

    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        this.s();
    }

    private void onAttackEventManualCalledAttack(AttackEvent.ManualCalledAttack attackEvent$ManualCalledAttack) {
        this.s();
    }

    private void s() {
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        if (Module.mc.player.getMainHandStack().getItem() != Items.TOTEM_OF_UNDYING) {
            return;
        }
        if (RandomUtils.a(1, 100) > this.chance.getPercent()) {
            return;
        }
        int n = ItemUtils.a();
        if (n == -1) {
            return;
        }
        int n2 = Module.mc.player.getInventory().getSelectedSlot();
        if (n == n2) {
            return;
        }
        this.p = n2;
        SlotUtils.c(n);
        if (Module.mc.player.getInventory().getSelectedSlot() != n) {
            this.p = -1;
        }
    }

    @Priority(value=-100)
    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (this.silent.getValue()) {
            return;
        }
        if (this.p == -1) {
            return;
        }
        Module.mc.player.getInventory().setSelectedSlot(this.p);
        if (Module.mc.player.getInventory().getSelectedSlot() == this.p) {
            this.p = -1;
        }
    }

    private void onUpdateEventPost(UpdateEvent.Post post) {
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        if (!this.silent.getValue()) {
            return;
        }
        if (this.p == -1) {
            return;
        }
        Module.mc.player.getInventory().setSelectedSlot(this.p);
        if (Module.mc.player.getInventory().getSelectedSlot() == this.p) {
            this.p = -1;
        }
    }
}

