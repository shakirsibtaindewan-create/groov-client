/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

public enum SlamEnchant {
    BREACH, DENSITY;

    private SlamEnchant() {

    }

}

