/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import net.minecraft.network.packet.Packet;

final class QueuedPacket {
    final Packet a;
    final long b;

    QueuedPacket(Packet mc14, long l) {
        this.a = mc14;
        this.b = l;
    }
}

