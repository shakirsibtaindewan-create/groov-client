/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

enum CrystalState {
    NONE, PLACE_OBSIDIAN, PLACE_CRYSTAL, BREAK_CRYSTAL;

    private CrystalState() {

    }

}

