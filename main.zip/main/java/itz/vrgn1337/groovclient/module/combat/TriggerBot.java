/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.combat.CombatUtils;
import itz.vrgn1337.groovclient.api.util.input.InputUtils;
import itz.vrgn1337.groovclient.api.util.network.LatencyTracker;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.RaycastUtils;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.module.utility.Weapons;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.block.Blocks;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;

public class TriggerBot
extends Module {
    private final FloatSetting cooldown = new FloatSetting(new StringConstant("Cooldown"), new StringConstant("Attack cooldown"), 50.0f, 100.0f, 80.0f, 1.0f);
    private final FloatSetting missChance = new FloatSetting(new StringConstant("Miss Chance"), new StringConstant("Miss chance"), 0.0f, 50.0f, 0.0f, 1.0f);
    private final BooleanSetting autoCrit = new BooleanSetting(new StringConstant("Auto Crit"), new StringConstant("Only attack on critical hit (prevents sweep)"), true);
    private final BooleanSetting weaponsOnly = new BooleanSetting(new StringConstant("Weapons Only"), new StringConstant("Only attack while holding a weapon"), true);
    private final BooleanSetting tPSSync = new BooleanSetting(new StringConstant("TPS Sync"), new StringConstant("Disable this if lag related module is enabled"), false);
    private final boolean s = true;
    private final int t = -5;
    private final int u = 5;
    private final Random v = new Random();
    private ItemStack w = ItemStack.EMPTY;

    public TriggerBot() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("TriggerBot"), new StringConstant("Automatically hits target entity")});
        this.addSettings(List.of(this.cooldown, this.missChance, this.autoCrit, this.weaponsOnly, this.tPSSync));
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (!this.s()) {
            return;
        }
        boolean bl = !ItemStack.areItemsAndComponentsEqual((ItemStack)this.w, (ItemStack)Module.mc.player.getMainHandStack());
        this.w = Module.mc.player.getMainHandStack().copy();
        HitResult ItemStackParticleEffect = RaycastUtils.a(3.0);
        if (!(ItemStackParticleEffect instanceof EntityHitResult)) {
            return;
        }
        EntityHitResult mc26 = (EntityHitResult)ItemStackParticleEffect;
        if (!this.a(mc26)) {
            return;
        }
        if (!TargetFilter.a(mc26.getEntity())) {
            return;
        }
        if (Module.mc.player.isOnGround() && Module.mc.options.jumpKey.isPressed()) {
            return;
        }
        if (!Module.mc.player.isOnGroungetValue() && this.autoCrit.getValue() && !this.t()) {
            return;
        }
        float f = (this.cooldown.getValue() + (float)this.u()) / 100.0f;
        if (this.tPSSync.getValue()) {
            f *= LatencyTracker.getInstance().b() / 20.0f;
        }
        f = Math.max(0.0f, Math.min(1.0f, f));
        if (Module.mc.player.getAttackCooldownProgress(0.0f) < f || bl) {
            return;
        }
        if (this.v()) {
            return;
        }
        InputUtils.a();
    }

    private boolean s() {
        return Module.mc.player != null && Module.mc.world != null && Module.mc.interactionManager != null && Module.mc.currentScreen == null && !Module.mc.player.isUsingItem() && (!this.weaponsOnly.getValue() || Weapons.getInstance().u());
    }

    private boolean t() {
        if (Module.mc.player.hasVehicle()) {
            return false;
        }
        if (Module.mc.player.isTouchingWater()) {
            return false;
        }
        if (Module.mc.player.isClimbing()) {
            return false;
        }
        if (Module.mc.player.isOnGround()) {
            return false;
        }
        if (Module.mc.player.getSteppingBlockState().getBlock() == Blocks.COBWEB) {
            return false;
        }
        if (Module.mc.player.isGliding()) {
            return true;
        }
        return Module.mc.player.fallDistance > 0.0;
    }

    private boolean a(EntityHitResult mc26) {
        Entity mc2 = mc26.getEntity();
        if (!(mc2 instanceof PlayerEntity)) {
            return false;
        }
        if (!TargetFilter.a(mc2)) {
            return false;
        }
        if (mc26.getEntity() != mc2) {
            return false;
        }
        if (!CombatUtils.a(mc2)) {
            return false;
        }
        return Module.mc.player.canSee(mc2);
    }

    private int u() {
        return -5 + this.v.nextInt(11);
    }

    private boolean v() {
        int n = (int)this.missChance.getValue();
        if (n <= 0) {
            return false;
        }
        return this.v.nextInt(100) < n;
    }
}

