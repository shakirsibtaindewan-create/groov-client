/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.Stopwatch;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.BacktrackFlushTrigger;
import itz.vrgn1337.groovclient.module.combat.BacktrackMode;
import itz.vrgn1337.groovclient.module.combat.QueuedPacket;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.module.utility.Weapons;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.common.KeepAliveS2CPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.HealthUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityPositionS2CPacket;
import net.minecraft.network.packet.s2c.play.TeamS2CPacket;
import net.minecraft.network.packet.s2c.common.CommonPingS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;

public class Backtrack
extends Module {
    private final ModeSetting mode = new ModeSetting(new StringConstant("Mode"), new StringConstant("Lag - pause network thread. Delay - high ping style packet delay"), BacktrackMode.LAG);
    private final DoubleSetting delay = new DoubleSetting(new StringConstant("Delay"), new StringConstant("Packet hold time in ms (random per packet between min and max)"), 150.0f, 350.0f, 0.0f, 2000.0f, 10.0f, 2000.0f);
    private final BooleanSetting dynamicDelay = new BooleanSetting(new StringConstant("Dynamic Delay"), new StringConstant("Scale delay by target distance: closer = max, farther = min"), false);
    private final FloatSetting lagCooldown = new FloatSetting(new StringConstant("Lag Cooldown"), new StringConstant("Lag mode rest duration after each trigger"), 500.0f, 5000.0f, 1000.0f, 50.0f);
    private final FloatSetting maxRange = new FloatSetting(new StringConstant("Max Range"), new StringConstant("Maximum backtrack range"), 3.0f, 10.0f, 4.5f, 0.1f);
    private final FloatSetting flushRange = new FloatSetting(new StringConstant("Flush Range"), new StringConstant("Release packets when target enters this range"), 0.0f, 3.0f, 1.5f, 0.1f);
    private final BooleanSetting onlyPlayers = new BooleanSetting(new StringConstant("Only Players"), new StringConstant("Only backtrack player entities"), true);
    private final BooleanSetting weaponOnly = new BooleanSetting(new StringConstant("Weapon Only"), new StringConstant("Only delay packets while holding a weapon"), true);
    private final BooleanSetting delayUntilHit = new BooleanSetting(new StringConstant("Delay Until Hit"), new StringConstant("On velocity, hold packets until you sprint attack (reduces knockback)"), false);
    private final FloatSetting delayUntilHitTimeout = new FloatSetting(new StringConstant("Delay Until Hit Timeout"), new StringConstant("Maximum time to hold packets while waiting for a sprint attack"), 250.0f, 5000.0f, 2000.0f, 50.0f);
    private final BooleanSetting instantKeepAlive = new BooleanSetting(new StringConstant("Instant KeepAlive"), new StringConstant("Pass KeepAlive packets through instantly so tab ping looks normal"), true);
    private final BooleanSetting instantHealth = new BooleanSetting(new StringConstant("Instant Health"), new StringConstant("Pass health/food updates through instantly"), true);
    private final ModeSetting flushOn = new ModeSetting(new StringConstant("Flush On"), new StringConstant("Events that release queued packets instantly"), BacktrackFlushTrigger.VELOCITY, true);
    private final Object A = new Object();
    private volatile boolean B = false;
    private final Stopwatch C = new Stopwatch();
    private volatile boolean D;
    private volatile long E;
    private final ConcurrentLinkedQueue F = new ConcurrentLinkedQueue();
    private volatile long G = 0L;
    private volatile boolean H = false;
    private volatile long I = 0L;

    public Backtrack() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("Backtrack"), new StringConstant("Delays enemy position updates for extended reach")});
        this.registerSettings(new Setting[]{this.mode, this.delay, this.dynamicDelay, this.lagCooldown, this.maxRange, this.flushRange, this.onlyPlayers, this.weaponOnly, this.delayUntilHit, this.delayUntilHitTimeout, this.instantKeepAlive, this.instantHealth, this.flushOn});
    }

    @Override
    protected void onDisable() {
        this.onlyPlayers.getValue();
        this.weaponOnly.getValue();
        this.D = false;
        this.E = 0L;
        this.G = 0L;
        this.H = false;
        this.I = 0L;
        this.C.b();
    }

    public void a() {
        this.setSuffix(new StringConstant(this.mode.getValueName() + " " + this.delay.j() + "ms"));
        if (this.D || !this.F.isEmpty()) {
            this.b(this.delay.h());
        }
    }

    @Priority(value=50)
    private void onPacketReceiveEventPre(PacketReceiveEvent.Pre packetReceiveEvent$Pre) {
        long l;
        double d;
        EntityVelocityUpdateS2CPacket mc97;
        boolean bl;
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        Packet mc14 = packetReceiveEvent$Pre.getPacket();
        if (this.H && System.currentTimeMillis() - this.I > (long)this.delayUntilHitTimeout.getValue()) {
            this.H = false;
            this.I = 0L;
            this.flushRange.getValue();
        }
        boolean bl2 = bl = mc14 instanceof EntityVelocityUpdateS2CPacket && (mc97 = (EntityVelocityUpdateS2CPacket)mc14).getEntityId() == Module.mc.player.getId() || mc14 instanceof ExplosionS2CPacket;
        if (bl && this.delayUntilHit.getValue() && this.mode.getValue() == BacktrackMode.DELAY) {
            this.H = true;
            this.I = System.currentTimeMillis();
        }
        if (mc14 instanceof EntityPositionS2CPacket && this.a(BacktrackFlushTrigger.TELEPORT)) {
            this.flushRange.getValue();
            return;
        }
        if (mc14 instanceof ExplosionS2CPacket && this.a(BacktrackFlushTrigger.VELOCITY) && !this.H) {
            this.flushRange.getValue();
            return;
        }
        if (mc14 instanceof EntityVelocityUpdateS2CPacket && (mc97 = (EntityVelocityUpdateS2CPacket)mc14).getEntityId() == Module.mc.player.getId() && this.a(BacktrackFlushTrigger.VELOCITY) && !this.H) {
            this.flushRange.getValue();
            return;
        }
        if (mc14 instanceof EntityDamageS2CPacket && (mc97_p = (EntityDamageS2CPacket)mc14).entityId() == Module.mc.player.getId() && this.a(BacktrackFlushTrigger.DAMAGED)) {
            this.flushRange.getValue();
            return;
        }
        if (this.mode.getValue() == BacktrackMode.DELAY && this.b(mc14)) {
            return;
        }
        if (this.weaponOnly.getValue() && !Weapons.getInstance().u()) {
            return;
        }
        mc97 = this.delayUntilHit.getValue();
        if (mc97 == null && !this.H) {
            return;
        }
        double d2 = d = mc97 != null ? (double)Module.mc.player.distanceTo((Entity)mc97) : Double.MAX_VALUE;
        if (!this.H) {
            if (this.flushRange.getValue() > 0.0f && d <= (double)this.flushRange.getValue()) {
                if (this.mode.getValue() == BacktrackMode.DELAY) {
                    this.weaponOnly.getValue();
                }
                return;
            }
            if (d > (double)this.maxRange.getValue()) {
                return;
            }
        }
        if ((l = this.a(d)) <= 0L) {
            return;
        }
        if (this.mode.getValue() == BacktrackMode.LAG) {
            if (System.currentTimeMillis() < this.E) {
                return;
            }
            this.a(l);
            this.E = System.currentTimeMillis() + (long)this.lagCooldown.getValue();
        } else {
            packetReceiveEvent$Pre.cancel();
            long l2 = System.currentTimeMillis();
            long l3 = this.H ? this.I + (long)this.delayUntilHitTimeout.getValue() : Math.max(l2 + l, this.G + 1L);
            this.G = l3;
            this.F.add(new QueuedPacket(mc14, l3));
        }
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        QueuedPacket queuedPacket;
        if (this.F.isEmpty()) {
            return;
        }
        long l = System.currentTimeMillis();
        while ((queuedPacket = (QueuedPacket)this.F.peek()) != null && queuedPacket.b <= l) {
            this.F.poll();
            this.a(queuedPacket.a);
        }
        if (this.F.isEmpty()) {
            this.G = 0L;
        }
    }

    private long a(double d) {
        float f = Math.min(this.delay.d(), this.delay.f());
        float f2 = Math.max(this.delay.d(), this.delay.f());
        if (f2 - f < 1.0f) {
            return (long)f2;
        }
        if (this.dynamicDelay.getValue() && d != Double.MAX_VALUE) {
            float f3 = Math.max(0.001f, this.maxRange.getValue() - this.flushRange.getValue());
            float f4 = (float)((d - (double)this.flushRange.getValue()) / (double)f3);
            f4 = Math.max(0.0f, Math.min(1.0f, f4));
            float f5 = f2 - (f2 - f) * f4;
            return (long)f5;
        }
        return (long)ThreadLocalRandom.current().nextDouble(f, f2);
    }

    private void onAttackEventManualCalledAttack(AttackEvent.ManualCalledAttack attackEvent$ManualCalledAttack) {
        if (Module.mc.player != null && Module.mc.player.isSprinting() && this.H) {
            this.H = false;
            this.I = 0L;
            this.flushRange.getValue();
            return;
        }
        if (this.a(BacktrackFlushTrigger.ATTACK)) {
            this.flushRange.getValue();
        }
    }

    private void onAttackEventPost(AttackEvent.Post post) {
        if (Module.mc.player != null && Module.mc.player.isSprinting() && this.H) {
            this.H = false;
            this.I = 0L;
            this.flushRange.getValue();
            return;
        }
        if (this.a(BacktrackFlushTrigger.ATTACK)) {
            this.flushRange.getValue();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void a(long l) {
        Object object = this.A;
        synchronized (object) {
            long l2;
            this.B = false;
            long l3 = System.currentTimeMillis() + l;
            while (!this.B && (l2 = l3 - System.currentTimeMillis()) > 0L) {
                try {
                    if (this.C.a((double)l)) {
                        this.D = true;
                        this.A.wait(l2);
                    }
                    this.C.b();
                }
                catch (InterruptedException interruptedException) {
                    break;
                }
                finally {
                    this.D = false;
                }
            }
        }
    }

    private void s() {
        this.onlyPlayers.getValue();
        this.weaponOnly.getValue();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void t() {
        Object object = this.A;
        synchronized (object) {
            this.B = true;
            this.A.notifyAll();
        }
    }

    private void u() {
        QueuedPacket queuedPacket;
        while ((queuedPacket = (QueuedPacket)this.F.poll()) != null) {
            this.a(queuedPacket.a);
        }
        this.G = 0L;
    }

    private void a(Packet mc14) {
        if (Module.mc.player == null || Module.mc.player.networkHandler == null) {
            return;
        }
        try {
            Packet mc98 = mc14;
            mc98.apply((PacketListener)Module.mc.player.networkHandler);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private boolean a(BacktrackFlushTrigger backtrackFlushTrigger) {
        return this.flushOn.getSelectedSet().contains((Object)backtrackFlushTrigger);
    }

    private boolean b(Packet mc14) {
        EntityStatusS2CPacket mc99;
        Entity mc2;
        if (mc14 instanceof DisconnectS2CPacket) {
            return true;
        }
        if (mc14 instanceof KeepAliveS2CPacket && this.instantKeepAlive.getValue()) {
            return true;
        }
        if (mc14 instanceof CommonPingS2CPacket) {
            return true;
        }
        if (mc14 instanceof GameJoinS2CPacket) {
            return true;
        }
        if (mc14 instanceof PlayerRespawnS2CPacket) {
            return true;
        }
        if (mc14 instanceof PlayerPositionLookS2CPacket) {
            return true;
        }
        if (mc14 instanceof WorldTimeUpdateS2CPacket) {
            return true;
        }
        if (mc14 instanceof EntityStatusS2CPacket && (mc2 = (mc99 = (EntityStatusS2CPacket)mc14).getEntity((World)Module.mc.world)) != null && !(mc2 instanceof LivingEntity)) {
            return true;
        }
        if (mc14 instanceof HealthUpdateS2CPacket && this.instantHealth.getValue()) {
            return true;
        }
        if (mc14 instanceof PlaySoundS2CPacket) {
            return true;
        }
        return mc14 instanceof TeamS2CPacket;
    }

    private LivingEntity v() {
        if (Module.mc.player == null || Module.mc.world == null) {
            return null;
        }
        LivingEntity mc58 = null;
        double d = this.maxRange.getValue();
        for (Entity mc2 : Module.mc.world.getEntities()) {
            double d2;
            if (!this.a(mc2) || !((d2 = (double)Module.mc.player.distanceTo(mc2)) <= d)) continue;
            d = d2;
            mc58 = (LivingEntity)mc2;
        }
        return mc58;
    }

    private boolean a(Entity mc2) {
        if (mc2 == null || mc2 == Module.mc.player) {
            return false;
        }
        if (!(mc2 instanceof LivingEntity)) {
            return false;
        }
        if (this.onlyPlayers.getValue() && !(mc2 instanceof PlayerEntity)) {
            return false;
        }
        if (mc2 instanceof PlayerEntity) {
            PlayerEntity mc6 = (PlayerEntity)mc2;
            return TargetFilter.a((Entity)mc6);
        }
        return true;
    }
}

