/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.util.ActionQueue;
import itz.vrgn1337.groovclient.api.util.WaitCondition;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.RaycastUtils;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.MaceEnchant;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.registry.entry.RegistryEntry;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;

public class MaceSwap
extends Module {
    private final ModeSetting enchant = new ModeSetting(new StringConstant("Enchant"), new StringConstant("Preferred mace enchant"), MaceEnchant.BREACH);
    private final FloatSetting switchBack = new FloatSetting(new StringConstant("Switch Back"), new StringConstant("Delay in ms before swapping back"), 50.0f, 500.0f, 200.0f, 50.0f);
    private final BooleanSetting fallCheck = new BooleanSetting(new StringConstant("Fall Check"), new StringConstant("Only swap when falling down"), false);

    public MaceSwap() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("MaceSwap"), new StringConstant("Swaps to mace when attacking")});
        this.onAttackEventManualCalledAttack(List.of(this.enchant, this.switchBack, this.fallCheck));
    }

    public boolean s() {
        return this.e() && ActionQueue.a(this);
    }

    @Override
    protected void onDisable() {
        ActionQueue.b(this);
    }

    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        this.t();
    }

    private void onAttackEventManualCalledAttack(AttackEvent.ManualCalledAttack attackEvent$ManualCalledAttack) {
        this.t();
    }

    private void t() {
        if (Module.mc.player == null || Module.mc.world == null || Module.mc.currentScreen != null) {
            return;
        }
        if (ActionQueue.c()) {
            return;
        }
        Item mc17 = Module.mc.player.getMainHandStack().getItem();
        if (!ItemUtils.c(mc17) && !ItemUtils.d(mc17)) {
            return;
        }
        if (this.fallCheck.getValue() && (Module.mc.player.isOnGround() || Module.mc.player.getVelocity().y >= 0.0)) {
            return;
        }
        HitResult ItemStackParticleEffect = RaycastUtils.a(3.0);
        if (!(ItemStackParticleEffect instanceof EntityHitResult)) {
            return;
        }
        EntityHitResult mc26 = (EntityHitResult)ItemStackParticleEffect;
        Entity mc2 = mc26.getEntity();
        if (!(mc2 instanceof PlayerEntity)) {
            return;
        }
        PlayerEntity ItemStackParticleEffect_p;
        ItemStackParticleEffect_p = (PlayerEntity)mc2;
        if (!TargetFilter.a((Entity)ItemStackParticleEffect_p)) {
            return;
        }
        int n = this.u();
        if (n == -1) {
            return;
        }
        int n2 = Module.mc.player.getInventory().getSelectedSlot();
        int n3 = Math.max(1, Math.round(this.switchBack.getValue() / 50.0f));
        ActionQueue.a((Object)this, new WaitCondition[]{ActionQueue.a(n), ActionQueue.a((Entity)ItemStackParticleEffect), ActionQueue.b(n3), ActionQueue.a(n2)});
    }

    private int u() {
        int n = -1;
        String string = switch (((MaceEnchant)this.enchant.getValue()).ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> "breach";
            case 1 -> "density";
            case 2 -> null;
        };
        for (int i = 0; i < 9; ++i) {
            ItemStack mc33 = Module.mc.player.getInventory().getStack(i);
            if (mc33.getItem() != Items.MACE) continue;
            if (string == null) {
                return i;
            }
            if (this.a(mc33, string)) {
                return i;
            }
            if (n != -1) continue;
            n = i;
        }
        return n;
    }

    private boolean a(ItemStack mc33, String string) {
        if (mc33.isEmpty()) {
            return false;
        }
        return mc33.getEnchantments().getEnchantments().stream().anyMatch(arg_0 -> M.lambda$hasEnchant$0((String)string, arg_0));
    }

    private static boolean lambda$hasEnchant$0(String string, RegistryEntry mc96) {
        return mc96.getIdAsString().toLowerCase().contains(string);
    }
}

