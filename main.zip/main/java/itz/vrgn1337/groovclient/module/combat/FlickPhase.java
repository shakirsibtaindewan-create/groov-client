/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

enum FlickPhase {
    IDLE, FLICK_TO, FLICK_BACK;

    private FlickPhase() {

    }

}

