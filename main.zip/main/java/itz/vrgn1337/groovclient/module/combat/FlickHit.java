/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.RayTraceTarget;
import itz.vrgn1337.groovclient.api.util.rotation.RaycastUtils;
import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.FlickMode;
import itz.vrgn1337.groovclient.module.combat.FlickPhase;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.HotbarSlotSetting;
import itz.vrgn1337.groovclient.setting.ItemListSetting;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.Comparator;
import java.util.List;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registry;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.registry.Registries;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;

public class FlickHit
extends Module {
    private final ModeSetting mode = new ModeSetting(new StringConstant("Mode"), new StringConstant("Flick works with key, Snap works automatically on attack"), FlickMode.FLICK);
    private final FloatSetting speed = new FloatSetting(new StringConstant("Speed"), new StringConstant("Rotation speed"), 1.0f, 50.0f, 50.0f, 1.0f);
    private final BooleanSetting silent = new BooleanSetting(new StringConstant("Silent"), new StringConstant("Use silent flick rotation"), false);
    private final KeybindSetting flickKey = new KeybindSetting(new StringConstant("Flick Key"), new StringConstant("Key to activate FlickHit (not used in SnapHit mode)"), -1);
    private final DoubleSetting range = new DoubleSetting(new StringConstant("Range"), new StringConstant("Only activates with target in range"), 0.5f, 3.0f, 0.0f, 8.0f, 0.1f, 8.0f);
    private final FloatSetting fOV = new FloatSetting(new StringConstant("FOV"), new StringConstant("Only activates on target in your FOV"), 0.0f, 360.0f, 360.0f, 1.0f);
    private final BooleanSetting useWhitelist = new BooleanSetting(new StringConstant("Use Whitelist"), new StringConstant("Only activate with whitelisted items"), false);
    private final ItemListSetting u = new ItemListSetting(new StringConstant("Items"), new StringConstant("Items to activate FlickHit with"), (Registry)Registries.ITEM, this::lambda$new$0, List.of(Items.NETHERITE_AXE, Items.DIAMOND_AXE, Items.IRON_AXE, Items.GOLDEN_AXE, Items.STONE_AXE, Items.WOODEN_AXE, Items.NETHERITE_SWORD, Items.DIAMOND_SWORD, Items.IRON_SWORD, Items.GOLDEN_SWORD, Items.STONE_SWORD, Items.WOODEN_SWORD, Items.MACE));
    private final HotbarSlotSetting v = new HotbarSlotSetting(new StringConstant("Slots"), new StringConstant("Only activates on selected hotbar slots"), new boolean[]{true, true, true, true, true, true, true, true, true});
    private static final int w = 20;
    private FlickPhase x = FlickPhase.IDLE;
    private Entity y;
    private Vec2f z;
    private boolean A;
    private int B;
    private final Rotation C = new Rotation();

    public FlickHit() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("FlickHit"), new StringConstant("Flicks to target and attacks on key press, or snaps on every attack")});
        this.registerSettings(new Setting[]{this.mode, this.speed, this.silent, this.flickKey, this.range, this.fOV, this.useWhitelist, this.u, this.v});
    }

    @Override
    protected void onEnable() {
        this.x.getValue();
        this.A = false;
    }

    @Override
    protected void onDisable() {
        this.x.getValue();
        this.A = false;
    }

    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        if (this.mode.getValue() != FlickMode.SNAP) {
            return;
        }
        if (Module.mc.player == null || Module.mc.world == null || Module.mc.currentScreen != null) {
            return;
        }
        if (this.x != FlickPhase.IDLE) {
            return;
        }
        if (!this.v()) {
            return;
        }
        if (!this.w()) {
            return;
        }
        Entity mc2 = this.u();
        if (mc2 == null) {
            return;
        }
        attackEvent$Pre.cancel();
        this.y = mc2;
        this.z = this.silent.getValue() ? new Vec2f(RotationManager.r(), RotationManager.s()) : new Vec2f(Module.mc.player.getYaw(), Module.mc.player.getPitch());
        this.x = FlickPhase.FLICK_TO;
        this.B = 0;
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.world == null || Module.mc.interactionManager == null || Module.mc.currentScreen != null) {
            this.x.getValue();
            this.A = false;
            return;
        }
        boolean bl = this.flickKey.isBound();
        boolean bl2 = bl && !this.A;
        this.A = bl;
        switch (this.x.ordinal()) {
            case 0: {
                if (this.mode.getValue() != FlickMode.FLICK) break;
                this.f(bl2);
                break;
            }
            case 1: {
                this.fOV.getValue();
                break;
            }
            case 2: {
                this.useWhitelist.getValue();
            }
        }
    }

    private void f(boolean bl) {
        if (!bl) {
            return;
        }
        if (!this.v()) {
            return;
        }
        if (!this.w()) {
            return;
        }
        Entity mc2 = this.u();
        if (mc2 == null) {
            return;
        }
        this.y = mc2;
        this.z = this.silent.getValue() ? new Vec2f(RotationManager.r(), RotationManager.s()) : new Vec2f(Module.mc.player.getYaw(), Module.mc.player.getPitch());
        this.x = FlickPhase.FLICK_TO;
        this.B = 0;
    }

    private void s() {
        EntityHitResult mc26;
        HitResult ItemStackParticleEffect;
        ++this.B;
        if (!this.a(this.y)) {
            this.y = null;
            this.x = FlickPhase.FLICK_BACK;
            this.B = 0;
            return;
        }
        Rotation rotation = RotationUtils.a(this.y.getBoundingBox().getCenter(), Module.mc.player.getEyePos());
        this.a(rotation);
        HitResult KelpBlock = ItemStackParticleEffect = this.silent.getValue() ? RaycastUtils.b(Module.mc.player.getEntityInteractionRange(), RayTraceTarget.ALL) : RaycastUtils.a(Module.mc.player.getEntityInteractionRange());
        if (ItemStackParticleEffect instanceof EntityHitResult && (mc26 = (EntityHitResult)ItemStackParticleEffect).getEntity() == this.y && Module.mc.player.getAttackCooldownProgress(0.0f) >= 0.92f) {
            Module.mc.interactionManager.attackEntity((PlayerEntity)Module.mc.player, this.y);
            Main.eventBus().post(AttackEvent.ManualCalledAttack.getInstance());
            Module.mc.player.swingHand(Hand.MAIN_HAND);
            this.x = FlickPhase.FLICK_BACK;
            this.B = 0;
            return;
        }
        if (this.B >= 20) {
            this.x = FlickPhase.FLICK_BACK;
            this.B = 0;
        }
    }

    private void t() {
        ++this.B;
        if (this.z == null) {
            this.x.getValue();
            return;
        }
        Rotation rotation = new Rotation(this.z.x, this.z.y);
        this.a(rotation);
        float f = this.silent.getValue() ? RotationManager.r() : Module.mc.player.getYaw();
        float f2 = this.silent.getValue() ? RotationManager.s() : Module.mc.player.getPitch();
        float f3 = Math.abs(MathHelper.wrapDegrees((float)(f - this.z.x)));
        float f4 = Math.abs(f2 - this.z.y);
        if (f3 < 1.0f && f4 < 1.0f || this.B >= 20) {
            this.x.getValue();
        }
    }

    private void a(Rotation rotation) {
        float f = MathHelper.clamp((float)(this.speed.getValue() / 10.0f), (float)0.05f, (float)1.0f);
        if (this.silent.getValue()) {
            float f2 = RotationManager.r();
            float f3 = RotationManager.s();
            float f4 = MathHelper.lerpAngleDegrees((float)f, (float)f2, (float)rotation.a());
            float f5 = MathHelper.clamp((float)(f3 + (rotation.b() - f3) * f), (float)-90.0f, (float)90.0f);
            if (!RotationManager.getInstance().e()) {
                RotationManager.getInstance().a(true);
            }
            this.C.a(f4, f5).g();
            RotationManager.getInstance().b(this.C, 1500);
        } else {
            float f6 = Module.mc.player.getYaw();
            float f7 = Module.mc.player.getPitch();
            float f8 = MathHelper.lerpAngleDegrees((float)f, (float)f6, (float)rotation.a());
            float f9 = MathHelper.clamp((float)(f7 + (rotation.b() - f7) * f), (float)-90.0f, (float)90.0f);
            Module.mc.player.setYaw(f8);
            Module.mc.player.setPitch(f9);
        }
    }

    private boolean a(Entity mc2) {
        if (mc2 == null || mc2 == Module.mc.player) {
            return false;
        }
        if (!mc2.isAlive() || mc2.isRemoved()) {
            return false;
        }
        if (!this.c(mc2)) {
            return false;
        }
        return this.d(mc2);
    }

    private Entity u() {
        return Module.mc.world.getOtherEntities((Entity)Module.mc.player, Module.mc.player.getBoundingBox().expand((double)this.range.f()), arg_0 -> ((FlickHit)this).c(arg_0)).stream().filter(arg_0 -> ((FlickHit)this).b(arg_0)).min(Comparator.comparingDouble((arg_0) -> ((FlickHit)this).lambda$findValidTarget$1(arg_0))).orElse(null);
    }

    private boolean b(Entity mc2) {
        if (!this.a(mc2)) {
            return false;
        }
        if (mc2 instanceof LivingEntity && !TargetFilter.a(mc2)) {
            return false;
        }
        if (this.fOV.getValue() < 360.0f) {
            Rotation rotation = RotationUtils.a(mc2.getBoundingBox().getCenter(), Module.mc.player.getEyePos());
            float f = this.silent.getValue() ? RotationManager.r() : Module.mc.player.getYaw();
            float f2 = Math.abs(MathHelper.wrapDegrees((float)(f - rotation.a())));
            if (f2 > this.fOV.getValue() / 2.0f) {
                return false;
            }
        }
        return true;
    }

    private boolean c(Entity mc2) {
        return mc2 instanceof LivingEntity || mc2 instanceof EndCrystalEntity;
    }

    private boolean d(Entity mc2) {
        float f = mc2.distanceTo((Entity)Module.mc.player);
        return f < this.range.f() && f > this.range.d();
    }

    private boolean v() {
        if (!this.useWhitelist.getValue()) {
            return true;
        }
        return this.u.g().contains(Module.mc.player.getMainHandStack().getItem());
    }

    private boolean w() {
        return this.v.b(Module.mc.player.getInventory().getSelectedSlot());
    }

    private void x() {
        this.x = FlickPhase.IDLE;
        this.y = null;
        this.z = null;
        this.B = 0;
        if (!this.C.e()) {
            this.C.f();
        }
    }

    private static double lambda$findValidTarget$1(Entity mc2) {
        return Module.mc.player.squaredDistanceTo(mc2);
    }

    private static boolean lambda$new$0(Item mc17) {
        return true;
    }
}

