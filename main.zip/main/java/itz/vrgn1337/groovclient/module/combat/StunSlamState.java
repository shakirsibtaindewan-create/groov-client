/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

enum StunSlamState {
    IDLE, SWAP, ATTACK, DONE;

    private StunSlamState() {

    }

}

