/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.MovementPacketEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.TickCounter;
import itz.vrgn1337.groovclient.api.util.item.SlotUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.api.util.world.RaycastHit;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.CrystalState;
import itz.vrgn1337.groovclient.module.combat.CrystalTargetMode;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ItemListSetting;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.List;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.registry.Registry;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.registry.Registries;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;

public class CrystalAura
extends Module {
    private static final Direction[] n = new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, Direction.UP};
    private static final int o = 12;
    private static final double p = 5.5;
    private static final float q = 3.0f;
    private static final float r = 1.4f;
    private static final float s = 8.0f;
    private static final float t = 1.5f;
    private static final float u = 1.5f;
    private static final float v = 1.7f;
    private final BooleanSetting autoPlace = new BooleanSetting(new StringConstant("Auto Place"), new StringConstant("Automatically places end crystals"), true);
    private final BooleanSetting autoBreak = new BooleanSetting(new StringConstant("Auto Break"), new StringConstant("Automatically breaks end crystals"), true);
    private final BooleanSetting autoObsidian = new BooleanSetting(new StringConstant("Auto Obsidian"), new StringConstant("Places obsidian around target before crystal"), false);
    private final ModeSetting targetMode = new ModeSetting(new StringConstant("Target Mode"), new StringConstant("How to pick the target player"), CrystalTargetMode.NEAREST);
    private final FloatSetting targetRange = new FloatSetting(new StringConstant("Target Range"), new StringConstant("Max distance to search for target player"), 1.0f, 12.0f, 6.0f, 0.5f);
    private final FloatSetting targetFOV = new FloatSetting(new StringConstant("Target FOV"), new StringConstant("FOV cone for FOV target mode"), 10.0f, 180.0f, 180.0f, 1.0f);
    private final FloatSetting scanRadius = new FloatSetting(new StringConstant("Scan Radius"), new StringConstant("Horizontal radius to scan around target"), 1.0f, 4.0f, 3.0f, 1.0f);
    private final FloatSetting placeDelay = new FloatSetting(new StringConstant("Place Delay"), new StringConstant("Delay between crystal placements in ticks"), 0.0f, 10.0f, 1.0f, 1.0f);
    private final FloatSetting breakDelay = new FloatSetting(new StringConstant("Break Delay"), new StringConstant("Delay between crystal breaks in ticks"), 0.0f, 10.0f, 1.0f, 1.0f);
    private final FloatSetting switchDelay = new FloatSetting(new StringConstant("Switch Delay"), new StringConstant("Delay between item switches in ticks"), 0.0f, 10.0f, 2.0f, 1.0f);
    private final BooleanSetting switchBack = new BooleanSetting(new StringConstant("Switch Back"), new StringConstant("Switches back to previous slot on release"), true);
    private final ItemListSetting triggerItems = new ItemListSetting(new StringConstant("Trigger Items"), new StringConstant("Items that activate CrystalAura on right-click (non-crystal triggers auto-swap)"), (Registry)Registries.ITEM, this::lambda$new$0, List.of(Items.END_CRYSTAL, Items.TOTEM_OF_UNDYING, Items.NETHERITE_SWORD, Items.DIAMOND_SWORD));
    private final KeybindSetting key = new KeybindSetting(new StringConstant("Key"), new StringConstant("Key to activate auto crystal"), KeybindSetting.getKey(1));
    private final TickCounter J = new TickCounter();
    private final TickCounter K = new TickCounter();
    private final TickCounter L = new TickCounter();
    private final Rotation M = new Rotation();
    private CrystalState N = CrystalState.NONE;
    private RaycastHit O;
    private BlockPos P;
    private BlockPos Q;
    private EndCrystalEntity R;
    private boolean S;
    private int T;
    private boolean U;
    private int V = -1;
    private boolean W = false;
    private float X = Float.NaN;
    private float Y = Float.NaN;
    private float Z = Float.NaN;
    private boolean aa;

    public CrystalAura() {
        super(ModuleCategory.COMBAT, true, new StringConstant[]{new StringConstant("CrystalAura"), new StringConstant("Automatically places and breaks end crystals")});
        this.registerSettings(new Setting[]{this.autoPlace, this.autoBreak, this.autoObsidian, this.targetMode, this.targetRange, this.targetFOV, this.scanRadius, this.placeDelay, this.breakDelay, this.switchDelay, this.switchBack, this.triggerItems, this.key});
        this.M.a(1000);
    }

    @Override
    protected void onEnable() {
        this.J.b();
        this.K.b();
        this.L.b();
        this.V = -1;
        this.W = false;
        this.U = false;
        this.X = Float.NaN;
        this.Y = Float.NaN;
        this.Z = Float.NaN;
        this.t();
    }

    @Override
    protected void onDisable() {
        if (Module.mc.player != null && this.V != -1) {
            SlotUtils.c(this.V);
        }
        this.V = -1;
        this.W = false;
        this.U = false;
        this.t();
        Rotation rotation = RotationManager.getInstance().o();
        if (rotation == this.M && !this.M.e()) {
            this.M.f();
        }
    }

    private boolean s() {
        if (Module.mc.player == null) {
            return false;
        }
        return this.triggerItems.g().contains(Module.mc.player.getMainHandStack().getItem());
    }

    private void t() {
        this.N = CrystalState.NONE;
        this.O = null;
        this.P = null;
        this.Q = null;
        this.R = null;
        this.S = false;
        this.T = 0;
        this.Y = Float.NaN;
        this.Z = Float.NaN;
    }

    @Priority(value=700)
    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.S && this.N != CrystalState.NONE) {
            attackEvent$Pre.cancel();
        }
    }

    @Priority(value=700)
    private void onBreakBlockEventPre(BreakBlockEvent.Pre breakBlockEvent$Pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.S && this.N != CrystalState.NONE) {
            breakBlockEvent$Pre.cancel();
        }
    }

    @Priority(value=700)
    private void onRenderWorldEventPre(RenderWorldEvent.Pre pre) {
        boolean bl;
        if (Module.mc.player == null || Module.mc.currentScreen != null) {
            return;
        }
        boolean bl2 = bl = this.key.isBound() && (this.s() || this.N == CrystalState.PLACE_OBSIDIAN);
        if (this.W && !bl) {
            this.U = true;
            this.t();
        }
        this.W = bl;
        if (this.U) {
            this.U = false;
            this.triggerItems();
        }
        if (!bl && this.N != CrystalState.NONE) {
            this.t();
        }
        if (this.N != CrystalState.NONE) {
            this.targetMode.getValue();
        }
    }

    @Priority(value=700)
    private void onMovementPacketEventPre(MovementPacketEvent.Pre pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.N != CrystalState.NONE) {
            this.S = true;
        }
        this.X = RotationManager.getInstance().k();
    }

    @Priority(value=700)
    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        boolean bl;
        if (Module.mc.player == null || Module.mc.currentScreen != null) {
            return;
        }
        this.aa = false;
        if (this.N != CrystalState.NONE) {
            this.targetRange.getValue();
        }
        this.scanRadius.getValue();
        if (this.N != CrystalState.NONE) {
            return;
        }
        boolean bl2 = bl = this.key.isBound() && this.s();
        if (bl) {
            this.v();
        }
    }

    private float u() {
        if (Float.isNaN(this.X)) {
            return 0.0f;
        }
        float f = RotationManager.getInstance().k();
        return Math.abs(MathHelper.wrapDegrees((float)(f - this.X)));
    }

    private void v() {
        if (Module.mc.player.isSneaking() || Module.mc.player.isUsingItem()) {
            return;
        }
        if (this.autoBreak.getValue() && this.autoPlace.getValue()) {
            return;
        }
        if (this.autoPlace.getValue()) {
            if (this.autoBreak.getValue()) {
                return;
            }
            if (this.autoObsidian.getValue()) {
                this.autoObsidian.getValue();
            }
        }
    }

    private boolean w() {
        if (!this.L.a(this.breakDelay.getPercent())) {
            return false;
        }
        EndCrystalEntity mc100 = this.key();
        if (mc100 == null) {
            return false;
        }
        this.a(mc100);
        this.N = CrystalState.BREAK_CRYSTAL;
        this.R = mc100;
        this.T = 0;
        this.S = false;
        return true;
    }

    private boolean x() {
        if (!this.K.a(this.placeDelay.getPercent())) {
            return false;
        }
        BlockPos mc0 = this.J();
        if (mc0 == null) {
            return false;
        }
        if (!this.M()) {
            if (this.aa) {
                return false;
            }
            if (!this.J.a(this.switchDelay.getPercent())) {
                return false;
            }
            if (this.V == -1) {
                this.V = Module.mc.player.getInventory().getSelectedSlot();
            }
            this.J.b();
            SlotUtils.b(Items.END_CRYSTAL);
        }
        if (!this.M()) {
            return false;
        }
        this.a(mc0);
        this.N = CrystalState.PLACE_CRYSTAL;
        this.Q = mc0.toImmutable();
        this.T = 0;
        this.S = false;
        return true;
    }

    private boolean y() {
        BlockPos mc0 = this.K.getValue();
        if (mc0 == null) {
            return false;
        }
        RaycastHit raycastHit = this.d(mc0);
        if (raycastHit == null) {
            return false;
        }
        if (!this.N()) {
            if (this.aa) {
                return false;
            }
            if (!this.J.a(this.switchDelay.getPercent())) {
                return false;
            }
            if (this.V == -1) {
                this.V = Module.mc.player.getInventory().getSelectedSlot();
            }
            this.J.b();
            SlotUtils.b(Items.OBSIDIAN);
        }
        if (!this.N()) {
            return false;
        }
        this.a(raycastHit);
        this.N = CrystalState.PLACE_OBSIDIAN;
        this.O = raycastHit;
        this.P = mc0.toImmutable();
        this.T = 0;
        this.S = false;
        return true;
    }

    private void z() {
        switch (this.N.ordinal()) {
            case 1: {
                if (this.O == null) break;
                this.a(this.O);
                break;
            }
            case 2: {
                if (this.Q == null) break;
                this.a(this.Q);
                break;
            }
            case 3: {
                if (this.R == null || !this.R.isAlive()) break;
                this.a(this.R);
                break;
            }
        }
    }

    private void a(RaycastHit raycastHit) {
        Rotation rotation = RotationUtils.a(raycastHit.c(), Module.mc.player.getEyePos());
        this.a(rotation.a(), rotation.b());
    }

    private void a(BlockPos mc0) {
        double d = (Math.random() - 0.5) * 0.4;
        double d2 = (Math.random() - 0.5) * 0.4;
        double d3 = 1.0 + Math.random() * 0.06;
        Vec3d VanillaChestLootTableGenerator = new Vec3d((double)mc0.getX() + 0.5 + d, (double)mc0.getY() + d3, (double)mc0.getZ() + 0.5 + d2);
        Rotation rotation = RotationUtils.a(VanillaChestLootTableGenerator, Module.mc.player.getEyePos());
        this.a(rotation.a(), rotation.b());
    }

    private void a(EndCrystalEntity mc100) {
        double d = (Math.random() - 0.5) * 0.4;
        double d2 = (Math.random() - 0.5) * 0.4;
        double d3 = (double)mc100.getHeight() * (0.3 + Math.random() * 0.4);
        Vec3d VanillaChestLootTableGenerator = mc100.getEntityPos().add(d, d3, d2);
        Rotation rotation = RotationUtils.a(VanillaChestLootTableGenerator, Module.mc.player.getEyePos());
        this.a(rotation.a(), rotation.b());
    }

    private void a(float f, float f2) {
        this.Y = f;
        this.Z = MathHelper.clamp((float)f2, (float)-90.0f, (float)90.0f);
    }

    private void A() {
        if (Float.isNaN(this.Y) || Float.isNaN(this.Z)) {
            return;
        }
        RotationManager rotationManager = RotationManager.getInstance();
        float f = rotationManager.k();
        float f2 = rotationManager.l();
        float f3 = MathHelper.wrapDegrees((float)(this.Y - f));
        float f4 = this.Z - f2;
        float f5 = Math.abs(f3);
        float f6 = Math.abs(f4);
        float f7 = f5 > 3.0f ? 8.0f : 1.4f;
        float f8 = f6 > 3.0f ? 8.0f : 1.4f;
        float f9 = MathHelper.clamp((float)f3, (float)(-f7), (float)f7);
        float f10 = MathHelper.clamp((float)f4, (float)(-f8), (float)f8);
        if (f5 <= 3.0f) {
            f9 += (float)((Math.random() - 0.5) * 0.3);
            f9 = MathHelper.clamp((float)f9, (float)-1.7f, (float)1.7f);
        }
        if (f6 <= 3.0f) {
            f10 += (float)((Math.random() - 0.5) * 0.2);
            f10 = MathHelper.clamp((float)f10, (float)-1.7f, (float)1.7f);
        }
        float f11 = f + f9;
        float f12 = MathHelper.clamp((float)(f2 + f10), (float)-90.0f, (float)90.0f);
        if (!rotationManager.e()) {
            rotationManager.a(true);
        }
        this.M.a(f11, f12).g();
        rotationManager.b(this.M, 1000);
    }

    private boolean B() {
        if (Float.isNaN(this.Y) || Float.isNaN(this.Z)) {
            return false;
        }
        RotationManager rotationManager = RotationManager.getInstance();
        float f = Math.abs(MathHelper.wrapDegrees((float)(this.Y - rotationManager.k())));
        float f2 = Math.abs(this.Z - rotationManager.l());
        return f < 1.5f && f2 < 1.5f && this.u() < 1.7f;
    }

    private void C() {
        boolean bl;
        if (!this.S || this.N == CrystalState.NONE) {
            return;
        }
        ++this.T;
        switch (this.N.ordinal()) {
            case 1: {
                boolean bl2 = this.placeDelay.getValue();
                break;
            }
            case 2: {
                boolean bl2 = this.breakDelay.getValue();
                break;
            }
            case 3: {
                boolean bl2 = this.switchDelay.getValue();
                break;
            }
            default: {
                boolean bl2 = bl = true;
            }
        }
        if (bl || this.T >= 12) {
            this.t();
        } else {
            this.S = false;
        }
    }

    private boolean D() {
        if (this.O == null || this.P == null) {
            return true;
        }
        if (!this.N()) {
            return true;
        }
        if (!Module.mc.player.canInteractWithBlockAt(this.O.a(), 0.0)) {
            return true;
        }
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (ItemStackParticleEffect instanceof BlockHitResult) {
            BlockHitResult mc7 = (BlockHitResult)ItemStackParticleEffect;
            if (!mc7.getBlockPos().equals((Object)this.O.a())) {
                return false;
            }
            if (mc7.getSide() != this.O.b()) {
                return false;
            }
            if (!this.targetFOV.getValue()) {
                return false;
            }
            this.K.b();
            Module.mc.interactionManager.interactBlock(Module.mc.player, Hand.MAIN_HAND, mc7);
            Module.mc.player.swingHand(Hand.MAIN_HAND);
            this.aa = true;
            this.switchBack.getValue();
            return true;
        }
        return false;
    }

    private boolean E() {
        if (this.Q == null) {
            return true;
        }
        if (!this.M()) {
            return true;
        }
        if (!Module.mc.player.canInteractWithBlockAt(this.Q, 0.0)) {
            return true;
        }
        if (!this.b(this.Q)) {
            return true;
        }
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (ItemStackParticleEffect instanceof BlockHitResult) {
            BlockHitResult mc7 = (BlockHitResult)ItemStackParticleEffect;
            if (!mc7.getBlockPos().equals((Object)this.Q)) {
                return false;
            }
            if (mc7.getSide() != Direction.UP) {
                return false;
            }
            if (!this.targetFOV.getValue()) {
                return false;
            }
            this.K.b();
            Module.mc.interactionManager.interactBlock(Module.mc.player, Hand.MAIN_HAND, mc7);
            Module.mc.player.swingHand(Hand.MAIN_HAND);
            this.aa = true;
            this.switchBack.getValue();
            return true;
        }
        return false;
    }

    private boolean F() {
        EntityHitResult mc26;
        if (this.R == null || !this.R.isAlive()) {
            return true;
        }
        if ((double)Module.mc.player.distanceTo((Entity)this.R) > 5.5) {
            return true;
        }
        if (Module.mc.interactionManager == null) {
            return true;
        }
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (ItemStackParticleEffect instanceof EntityHitResult && (mc26 = (EntityHitResult)ItemStackParticleEffect).getEntity() == this.R) {
            this.L.b();
            Module.mc.interactionManager.attackEntity((PlayerEntity)Module.mc.player, (Entity)this.R);
            Main.eventBus().post(AttackEvent.ManualCalledAttack.getInstance());
            Module.mc.player.swingHand(Hand.MAIN_HAND);
            this.aa = true;
            return true;
        }
        return false;
    }

    private void G() {
        if (this.key.isBound() && Module.mc.options.useKey.isPressed()) {
            Module.mc.options.useKey.setPressed(false);
        }
        if (this.key.isBound() && Module.mc.options.attackKey.isPressed()) {
            Module.mc.options.attackKey.setPressed(false);
        }
    }

    private void H() {
        if (this.switchBack.getValue() && this.J.a(this.switchDelay.getPercent())) {
            if (this.V != -1 && Module.mc.player != null) {
                SlotUtils.c(this.V);
            }
            this.V = -1;
        } else {
            this.V = -1;
        }
    }

    private EndCrystalEntity I() {
        if (Module.mc.world == null) {
            return null;
        }
        Box Vec3i = Module.mc.player.getBoundingBox().expand(5.5);
        EndCrystalEntity mc100 = null;
        double d = Double.MAX_VALUE;
        for (Entity mc2 : Module.mc.world.getOtherEntities((Entity)Module.mc.player, Vec3i)) {
            double d2;
            EndCrystalEntity mc101;
            if (!(mc2 instanceof EndCrystalEntity) || !(mc101 = (EndCrystalEntity)mc2).isAlive() || (d2 = (double)Module.mc.player.distanceTo((Entity)mc101)) > 5.5 || !(d2 < d)) continue;
            d = d2;
            mc100 = mc101;
        }
        return mc100;
    }

    private BlockPos J() {
        PlayerEntity mc6 = this.L();
        if (mc6 == null || Module.mc.world == null) {
            return null;
        }
        BlockPos mc0 = mc6.getBlockPos();
        Vec3d VanillaChestLootTableGenerator = mc6.getEntityPos().add(0.0, (double)mc6.getHeight() * 0.5, 0.0);
        int n = this.scanRadius.getPercent();
        BlockPos mc64 = null;
        double d = Double.MAX_VALUE;
        for (int i = -2; i <= 1; ++i) {
            for (int j = -n; j <= n; ++j) {
                for (int k = -n; k <= n; ++k) {
                    double d2;
                    BlockPos mc66 = mc0.add(j, i, k);
                    if (mc66.getY() > mc0.getY() || !this.b(mc66) || !Module.mc.player.canInteractWithBlockAt(mc66, 0.0) || !((d2 = Vec3d.ofCenter((Vec3i)mc66).squaredDistanceTo(VanillaChestLootTableGenerator)) < d)) continue;
                    d = d2;
                    mc64 = mc66.toImmutable();
                }
            }
        }
        return mc64;
    }

    private boolean b(BlockPos mc0) {
        if (Module.mc.world == null) {
            return false;
        }
        BlockState mc1 = Module.mc.world.getBlockState(mc0);
        Block mc62 = mc1.getBlock();
        if (mc62 != Blocks.OBSIDIAN && mc62 != Blocks.BEDROCK) {
            return false;
        }
        BlockState mc102 = Module.mc.world.getBlockState(mc0.up());
        if (!mc102.isAir() && !mc102.isReplaceable()) {
            return false;
        }
        return Module.mc.world.getNonSpectatingEntities(EndCrystalEntity.class, new Box(mc0.up()).expand(0.1)).isEmpty();
    }

    private BlockPos K() {
        PlayerEntity mc6 = this.L();
        if (mc6 == null || Module.mc.world == null) {
            return null;
        }
        BlockPos mc0 = mc6.getBlockPos();
        Vec3d VanillaChestLootTableGenerator = mc6.getEntityPos().add(0.0, (double)mc6.getHeight() * 0.5, 0.0);
        int n = this.scanRadius.getPercent();
        RotationManager rotationManager = RotationManager.getInstance();
        BlockPos mc64 = null;
        double d = Double.MAX_VALUE;
        for (int i = -2; i <= 1; ++i) {
            for (int j = -n; j <= n; ++j) {
                for (int k = -n; k <= n; ++k) {
                    double d2;
                    BlockState mc1;
                    BlockPos mc66 = mc0.add(j, i, k);
                    if (mc66.getY() > mc0.getY() || new Box(mc66).expand(-0.05).intersects(mc6.getBoundingBox()) || !(mc1 = Module.mc.world.getBlockState(mc66.up())).isAir() && !mc1.isReplaceable() || !Module.mc.world.getNonSpectatingEntities(EndCrystalEntity.class, new Box(mc66.up()).expand(0.1)).isEmpty() || !rotationManager.b(mc66) || !this.c(mc66) || !((d2 = Vec3d.ofCenter((Vec3i)mc66).squaredDistanceTo(VanillaChestLootTableGenerator)) < d)) continue;
                    d = d2;
                    mc64 = mc66.toImmutable();
                }
            }
        }
        return mc64;
    }

    private PlayerEntity L() {
        if (Module.mc.player == null || Module.mc.world == null) {
            return null;
        }
        Vec3d VanillaChestLootTableGenerator = Module.mc.player.getEyePos();
        Vec3d WallPlayerSkullBlock = Module.mc.player.getRotationVector();
        float f = this.targetRange.getValue();
        float f2 = this.targetFOV.getValue();
        boolean bl = this.targetMode.getValue() == CrystalTargetMode.FOV;
        PlayerEntity mc6 = null;
        double d = Double.MAX_VALUE;
        for (PlayerEntity mc70 : Module.mc.world.getPlayers()) {
            double d2;
            if (mc70 == Module.mc.player || mc70.isSpectator() || mc70.isDead() || (d2 = (double)Module.mc.player.distanceTo((Entity)mc70)) > (double)f) continue;
            double d3 = d2;
            if (bl) {
                double d4;
                double d5;
                Vec3d VanillaEntityLootTableGenerator = mc70.getEyePos().subtract(VanillaChestLootTableGenerator);
                double d6 = VanillaEntityLootTableGenerator.length();
                if (d6 < 1.0E-4 || (d5 = Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, d4 = VanillaEntityLootTableGenerator.multiply(1.0 / d6).dotProduct(WallPlayerSkullBlock)))))) > (double)f2) continue;
                d3 = d5 + d2 * 0.5;
            }
            if (!(d3 < d)) continue;
            d = d3;
            mc6 = mc70;
        }
        return mc6;
    }

    private boolean c(BlockPos mc0) {
        RotationManager rotationManager = RotationManager.getInstance();
        for (Direction mc63 : Direction.values()) {
            BlockPos mc64 = mc0.offset(mc63);
            if (Module.mc.world.isAir(mc64) || rotationManager.a(mc64) || !Module.mc.player.canInteractWithBlockAt(mc64, 0.0)) continue;
            return true;
        }
        return false;
    }

    private RaycastHit d(BlockPos mc0) {
        RaycastHit raycastHit = null;
        double d = Double.MAX_VALUE;
        boolean bl = RotationManager.getInstance().a(mc0);
        for (Direction mc63 : n) {
            BlockPos mc64 = mc0.offset(mc63.getOpposite());
            if (!Module.mc.player.canInteractWithBlockAt(mc64, 0.0) || Module.mc.world.isAir(mc64) || RotationManager.getInstance().a(mc64)) continue;
            Vec3d VanillaChestLootTableGenerator = RotationManager.a(mc64, mc63);
            if (!bl && !this.a(mc64, mc63, VanillaChestLootTableGenerator)) continue;
            Rotation rotation = RotationUtils.a(VanillaChestLootTableGenerator, Module.mc.player.getEyePos());
            float f = Math.abs(MathHelper.wrapDegrees((float)(Module.mc.player.getYaw() - rotation.a())));
            float f2 = MathHelper.clamp((float)rotation.b(), (float)-90.0f, (float)90.0f);
            float f3 = Math.abs(Module.mc.player.getPitch() - f2);
            double d2 = (double)f + (double)f3 * 0.6 + Module.mc.player.getEyePos().squaredDistanceTo(VanillaChestLootTableGenerator) * 0.12;
            if (!(d2 < d)) continue;
            d = d2;
            raycastHit = new RaycastHit(mc64, mc63, VanillaChestLootTableGenerator);
        }
        return raycastHit;
    }

    private boolean a(BlockPos mc0, Direction mc63, Vec3d VanillaChestLootTableGenerator) {
        BlockHitResult mc7 = Module.mc.world.raycast(new RaycastContext(Module.mc.player.getEyePos(), VanillaChestLootTableGenerator, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, (Entity)Module.mc.player));
        return mc7.getType() == HitResult.Type.BLOCK && mc7.getBlockPos().equals((Object)mc0) && mc7.getSide() == mc63;
    }

    private boolean M() {
        return Module.mc.player.getMainHandStack().isOf(Items.END_CRYSTAL);
    }

    private boolean N() {
        return Module.mc.player.getMainHandStack().isOf(Items.OBSIDIAN);
    }

    private static boolean lambda$new$0(Item mc17) {
        return true;
    }
}

