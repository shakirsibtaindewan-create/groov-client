/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateMouseEvent;
import itz.vrgn1337.groovclient.api.util.input.InputUtils;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.MaceWeaponType;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.registry.entry.RegistryEntry;

public class AutoMace
extends Module {
    private final ModeSetting weapon = new ModeSetting(new StringConstant("Weapon"), new StringConstant("Which weapon type to auto-attack with"), MaceWeaponType.DENSITY, true);
    private final DoubleSetting delay = new DoubleSetting(new StringConstant("Delay"), new StringConstant("Attack delay range in ms"), 250.0f, 750.0f, 50.0f, 1000.0f, 50.0f, 750.0f);
    private final BooleanSetting cooldownCheck = new BooleanSetting(new StringConstant("Cooldown Check"), new StringConstant("Wait for attack cooldown before hitting"), true);
    private final BooleanSetting silentAim = new BooleanSetting(new StringConstant("Silent Aim"), new StringConstant("Aims on target silently"), true);
    private long r = 0L;
    private long s = 0L;
    private PlayerEntity t;

    public AutoMace() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("AutoMace"), new StringConstant("Auto attacks when aiming at a player")});
        this.addSettings(List.of(this.weapon, this.delay, this.cooldownCheck, this.silentAim));
    }

    @Override
    protected void onEnable() {
        this.r = System.currentTimeMillis();
        this.s = (long)this.delay.i();
        this.t = null;
    }

    @Override
    protected void onDisable() {
        this.r = 0L;
        this.s = 0L;
    }

    private void onUpdateMouseEventPre(UpdateMouseEvent.Pre pre) {
        if (!this.s()) {
            return;
        }
        if (!this.t()) {
            return;
        }
        if (this.silentAim.getValue() && this.t != null && Module.mc.player.distanceTo((Entity)this.t) < 16.0f && this.t.getY() + 1.0 < Module.mc.player.getY()) {
            if (!RotationManager.getInstance().e()) {
                RotationManager.getInstance().a(true);
            }
            RotationManager.getInstance().a((LivingEntity)this.t, 260.0f, true);
        }
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (!this.s()) {
            return;
        }
        if (!this.t()) {
            return;
        }
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (!(ItemStackParticleEffect instanceof EntityHitResult)) {
            return;
        }
        EntityHitResult mc26 = (EntityHitResult)ItemStackParticleEffect;
        Entity mc2 = mc26.getEntity();
        if (!(mc2 instanceof PlayerEntity)) {
            return;
        }
        PlayerEntity ItemStackParticleEffect_p;
        ItemStackParticleEffect_p = (PlayerEntity)mc2;
        if (!TargetFilter.a((Entity)ItemStackParticleEffect_p)) {
            return;
        }
        if (!Module.mc.player.canSee((Entity)ItemStackParticleEffect)) {
            return;
        }
        this.t = ItemStackParticleEffect;
        long l = System.currentTimeMillis();
        if (l - this.r < this.s) {
            return;
        }
        if (this.cooldownCheck.getValue() && Module.mc.player.getAttackCooldownProgress(0.0f) < 0.9f) {
            return;
        }
        InputUtils.a();
        this.r = l;
        this.s = (long)this.delay.i();
    }

    private boolean s() {
        return Module.mc.player != null && Module.mc.world != null && Module.mc.interactionManager != null && Module.mc.currentScreen == null && !Module.mc.player.isDead() && !Module.mc.player.isSpectator();
    }

    private boolean t() {
        ItemStack mc33 = Module.mc.player.getMainHandStack();
        Item mc17 = mc33.getItem();
        if (this.weapon.isSelected(MaceWeaponType.DENSITY.ordinal()) && mc17 == Items.MACE && this.a(mc33, "density")) {
            return true;
        }
        if (this.weapon.isSelected(MaceWeaponType.BREACH.ordinal()) && mc17 == Items.MACE && this.a(mc33, "breach")) {
            return true;
        }
        if (this.weapon.isSelected(MaceWeaponType.SWORDS.ordinal()) && ItemUtils.c(mc17)) {
            return true;
        }
        if (this.weapon.isSelected(MaceWeaponType.AXES.ordinal()) && ItemUtils.d(mc17)) {
            return true;
        }
        return this.weapon.isSelected(MaceWeaponType.SPEARS.ordinal()) && ItemUtils.e(mc17);
    }

    private boolean a(ItemStack mc33, String string) {
        if (mc33.isEmpty()) {
            return false;
        }
        return mc33.getEnchantments().getEnchantments().stream().anyMatch(arg_0 -> E.lambda$hasEnchant$0((String)string, arg_0));
    }

    private static boolean lambda$hasEnchant$0(String string, RegistryEntry mc96) {
        return mc96.getIdAsString().toLowerCase().contains(string);
    }
}

