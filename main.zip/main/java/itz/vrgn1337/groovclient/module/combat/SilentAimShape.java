/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

public enum SilentAimShape {
    Cylinder, Triangle, Quad, Pentagon, Hexagon, Star, Flower;

    private SilentAimShape() {

    }

}

