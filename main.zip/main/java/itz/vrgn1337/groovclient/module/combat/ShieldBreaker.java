/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.combat.CombatUtils;
import itz.vrgn1337.groovclient.api.util.input.InputUtils;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.item.SlotUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;

public class ShieldBreaker
extends Module {
    private final BooleanSetting swapBack = new BooleanSetting(new StringConstant("Swap Back"), new StringConstant("Returns to original slot"), true);
    private int o = -1;
    private boolean p;
    private boolean q;

    public ShieldBreaker() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("ShieldBreaker"), new StringConstant("Disables enemy shield with axe")});
        this.registerSettings(new Setting[]{this.swapBack});
    }

    @Override
    protected void onDisable() {
        this.o = -1;
        this.q = false;
        this.p = false;
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        EntityHitResult mc26;
        if (Module.mc.player == null) {
            return;
        }
        if (this.q) {
            this.q = false;
            if (this.o != -1 && this.swapBack.getValue()) {
                SlotUtils.c(this.o);
            }
            this.o = -1;
            return;
        }
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (ItemStackParticleEffect instanceof EntityHitResult && (mc26 = (EntityHitResult) ItemStackParticleEffect).getEntity() instanceof PlayerEntity) {
            PlayerEntity mc6 = (PlayerEntity)ItemStackParticleEffect;
            if (!(TargetFilter.a((Entity)mc6) && CombatUtils.a((Entity)mc6) && CombatUtils.a(mc6))) {
                return;
            }
            if (this.p) {
                InputUtils.a();
                this.q = true;
                this.p = false;
                return;
            }
            int n = ItemUtils.b();
            if (n == -1) {
                return;
            }
            this.o = Module.mc.player.getInventory().getSelectedSlot();
            SlotUtils.c(n);
            this.p = true;
        }
    }
}

