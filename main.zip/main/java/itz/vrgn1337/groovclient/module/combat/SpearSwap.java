/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.item.SlotUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.RaycastUtils;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.SpearEnchant;
import itz.vrgn1337.groovclient.module.combat.SpearSwapState;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import java.util.List;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.registry.entry.RegistryEntry;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;

public class SpearSwap
extends Module {
    private final ModeSetting swapTo = new ModeSetting(new StringConstant("Swap To"), new StringConstant("What to swap spear to on attack"), SpearEnchant.SWORD);
    private final FloatSetting switchBack = new FloatSetting(new StringConstant("Switch Back"), new StringConstant("Delay in ms before swapping back"), 50.0f, 500.0f, 400.0f, 50.0f);
    private final BooleanSetting fallCheck = new BooleanSetting(new StringConstant("Fall Check"), new StringConstant("Only swap when falling down"), false);
    private SpearSwapState q = SpearSwapState.IDLE;
    private PlayerEntity r;
    private int s = -1;
    private long t = 0L;

    public SpearSwap() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("SpearSwap"), new StringConstant("Swaps spear to sword or mace when attacking")});
        this.addSettings(List.of(this.swapTo, this.switchBack, this.fallCheck));
    }

    public boolean s() {
        return this.e() && this.q != SpearSwapState.IDLE;
    }

    @Override
    protected void onDisable() {
        if (this.s != -1 && Module.mc.player != null) {
            SlotUtils.c(this.s);
        }
        this.t();
        super.onDisable();
    }

    private void t() {
        this.q = SpearSwapState.IDLE;
        this.r = null;
        this.s = -1;
        this.t = 0L;
    }

    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        this.u();
    }

    private void onAttackEventManualCalledAttack(AttackEvent.ManualCalledAttack attackEvent$ManualCalledAttack) {
        this.u();
    }

    private void u() {
        if (Module.mc.player == null || Module.mc.world == null || Module.mc.currentScreen != null) {
            return;
        }
        if (this.q != SpearSwapState.IDLE) {
            return;
        }
        if (!ItemUtils.e(Module.mc.player.getMainHandStack().getItem())) {
            return;
        }
        if (this.fallCheck.getValue() && (Module.mc.player.isOnGround() || Module.mc.player.getVelocity().y >= 0.0)) {
            return;
        }
        HitResult ItemStackParticleEffect = RaycastUtils.a(4.5);
        if (!(ItemStackParticleEffect instanceof EntityHitResult)) {
            return;
        }
        EntityHitResult mc26 = (EntityHitResult)ItemStackParticleEffect;
        Entity mc2 = mc26.getEntity();
        if (!(mc2 instanceof PlayerEntity)) {
            return;
        }
        PlayerEntity ItemStackParticleEffect_p;
        ItemStackParticleEffect_p = (PlayerEntity)mc2;
        if (!TargetFilter.a((Entity)ItemStackParticleEffect_p)) {
            return;
        }
        int n = this.v();
        if (n == -1) {
            return;
        }
        this.r = ItemStackParticleEffect;
        this.q = SpearSwapState.SWAP;
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        switch (this.q.ordinal()) {
            case 1: {
                if (this.r == null || !this.r.isAlive()) {
                    this.t();
                    return;
                }
                int n = this.v();
                if (n == -1) {
                    this.t();
                    return;
                }
                this.s = Module.mc.player.getInventory().getSelectedSlot();
                SlotUtils.c(n);
                this.q = SpearSwapState.ATTACK;
                break;
            }
            case 2: {
                if (this.r == null || !this.r.isAlive()) {
                    this.t();
                    return;
                }
                Module.mc.interactionManager.attackEntity((PlayerEntity)Module.mc.player, (Entity)this.r);
                Main.eventBus().post(AttackEvent.ManualCalledAttack.getInstance());
                Module.mc.player.swingHand(Hand.MAIN_HAND);
                this.t = System.currentTimeMillis();
                this.r = null;
                this.q = SpearSwapState.COOLDOWN;
                break;
            }
            case 3: {
                if (System.currentTimeMillis() - this.t < (long)this.switchBack.getValue()) break;
                if (this.s != -1) {
                    SlotUtils.c(this.s);
                }
                this.t();
                break;
            }
        }
    }

    private int v() {
        return switch (((SpearEnchant)this.swapTo.getValue()).ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> ItemUtils.a();
            case 1 -> this.a("breach");
            case 2 -> this.a("density");
        };
    }

    private int a(String string) {
        int n = -1;
        for (int i = 0; i < 9; ++i) {
            ItemStack mc33 = Module.mc.player.getInventory().getStack(i);
            if (mc33.getItem() != Items.MACE) continue;
            if (this.a(mc33, string)) {
                return i;
            }
            if (n != -1) continue;
            n = i;
        }
        return n;
    }

    private boolean a(ItemStack mc33, String string) {
        if (mc33.isEmpty()) {
            return false;
        }
        return mc33.getEnchantments().getEnchantments().stream().anyMatch(arg_0 -> S.lambda$hasEnchant$0((String)string, arg_0));
    }

    private static boolean lambda$hasEnchant$0(String string, RegistryEntry mc96) {
        return mc96.getIdAsString().toLowerCase().contains(string);
    }
}

