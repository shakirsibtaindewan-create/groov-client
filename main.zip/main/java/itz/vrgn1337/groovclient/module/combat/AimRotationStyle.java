/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

public enum AimRotationStyle {
    Center, Look, Random;

    private AimRotationStyle() {

    }

}

