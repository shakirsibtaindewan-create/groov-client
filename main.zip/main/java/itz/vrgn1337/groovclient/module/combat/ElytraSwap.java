/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.ActionQueue;
import itz.vrgn1337.groovclient.api.util.WaitCondition;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.List;
import net.minecraft.util.Hand;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;

public class ElytraSwap
extends Module {
    private final KeybindSetting key = new KeybindSetting(new StringConstant("Key"), new StringConstant("Key to trigger swap"), 0);
    private final BooleanSetting swapBack = new BooleanSetting(new StringConstant("SwapBack"), new StringConstant("Swap back to your original slot after use"), true);
    private static final List p = List.of(Items.LEATHER_CHESTPLATE, Items.CHAINMAIL_CHESTPLATE, Items.COPPER_CHESTPLATE, Items.GOLDEN_CHESTPLATE, Items.IRON_CHESTPLATE, Items.DIAMOND_CHESTPLATE, Items.NETHERITE_CHESTPLATE);
    private boolean q;

    public ElytraSwap() {
        super(ModuleCategory.COMBAT, true, new StringConstant[]{new StringConstant("ElytraSwap"), new StringConstant("Elytra swapping macro")});
        this.registerSettings(new Setting[]{this.key, this.swapBack});
    }

    @Override
    public void onEnable() {
        this.q = false;
    }

    @Override
    protected void onDisable() {
        ActionQueue.b(this);
        this.q = false;
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.currentScreen != null) {
            this.q = false;
            return;
        }
        boolean bl = this.key.isBound();
        boolean bl2 = bl && !this.q;
        this.q = bl;
        if (!bl2) {
            return;
        }
        if (ActionQueue.c()) {
            return;
        }
        int n = this.s();
        if (n < 0) {
            return;
        }
        int n2 = Module.mc.player.getInventory().getSelectedSlot();
        if (this.swapBack.getValue() && n2 != n) {
            ActionQueue.a((Object)this, new WaitCondition[]{ActionQueue.a(n), ActionQueue.a(Hand.MAIN_HAND), ActionQueue.b(3), ActionQueue.a(n2)});
        } else {
            ActionQueue.a((Object)this, new WaitCondition[]{ActionQueue.a(n), ActionQueue.a(Hand.MAIN_HAND)});
        }
    }

    private int s() {
        block3: {
            boolean bl;
            block2: {
                boolean bl2 = Module.mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem() == Items.ELYTRA;
                bl = p.contains(Module.mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem());
                if (!bl2) break block2;
                for (int i = 0; i < 9; ++i) {
                    if (!p.contains(Module.mc.player.getInventory().getStack(i).getItem())) continue;
                    return i;
                }
                break block3;
            }
            if (!bl) break block3;
            for (int i = 0; i < 9; ++i) {
                if (!Module.mc.player.getInventory().getStack(i).isOf(Items.ELYTRA)) continue;
                return i;
            }
        }
        return -1;
    }
}

