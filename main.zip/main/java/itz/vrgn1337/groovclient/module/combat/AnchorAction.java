/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

enum AnchorAction {
    NONE, CHARGE, EXPLODE, PLACE_SAFE;

    private AnchorAction() {

    }

}

