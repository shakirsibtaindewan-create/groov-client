/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.Stopwatch;
import itz.vrgn1337.groovclient.api.util.combat.CombatUtils;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.math.RandomUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.RaycastUtils;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.HitSelectMode;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;

public class HitSelect
extends Module {
    private final ModeSetting mode = new ModeSetting(new StringConstant("Mode"), new StringConstant("HitSelect mode"), HitSelectMode.AGGRESSIVE);
    private final BooleanSetting waitForFall = new BooleanSetting(new StringConstant("Wait For Fall"), new StringConstant("Only allow hits while falling in critical window"), true);
    private final FloatSetting minFallSpeed = new FloatSetting(new StringConstant("Min Fall Speed"), new StringConstant("Highest allowed downward velocity"), -0.5f, 0.0f, -0.08f, 0.01f);
    private final FloatSetting maxFallSpeed = new FloatSetting(new StringConstant("Max Fall Speed"), new StringConstant("Lowest allowed downward velocity"), -1.0f, 0.0f, -0.4f, 0.01f);
    private final BooleanSetting groundCheck = new BooleanSetting(new StringConstant("Ground Check"), new StringConstant("Block attacks while on ground"), true);
    private final BooleanSetting counterMode = new BooleanSetting(new StringConstant("Counter Mode"), new StringConstant("Only counter after being hurt"), false);
    private final FloatSetting hurtWindow = new FloatSetting(new StringConstant("Hurt Window"), new StringConstant("Minimum hurtTime to start counter window"), 0.0f, 10.0f, 7.0f, 1.0f);
    private final DoubleSetting counterDelay = new DoubleSetting(new StringConstant("Counter Delay"), new StringConstant("Random counter delay in milliseconds"), 0.0f, 50.0f, 0.0f, 200.0f, 1.0f, 200.0f);
    private final BooleanSetting predictLanding = new BooleanSetting(new StringConstant("Predict Landing"), new StringConstant("Only hit when landing race is favorable"), false);
    private final FloatSetting landingAdvantage = new FloatSetting(new StringConstant("Landing Advantage"), new StringConstant("Required landing-time advantage in ticks"), 0.0f, 10.0f, 2.0f, 0.5f);
    private final BooleanSetting allowDuringKb = new BooleanSetting(new StringConstant("Allow During Kb"), new StringConstant("Allow attacks while taking knockback"), true);
    private final BooleanSetting prioritizeKb = new BooleanSetting(new StringConstant("Prioritize Kb"), new StringConstant("Prioritize attack while taking knockback"), false);
    private final DoubleSetting cancelChance = new DoubleSetting(new StringConstant("Cancel Chance"), new StringConstant("Attack cancel chance"), 80.0f, 100.0f, 0.0f, 100.0f, 1.0f, 100.0f);
    private final Stopwatch A = new Stopwatch();
    private double B;
    private int C;
    private boolean D;
    private boolean E;
    private long F;
    private int G;
    private int H;
    private String I = "";

    public HitSelect() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("HitSelect"), new StringConstant("Select hits to reduce taking knockback and increase crit hit chance")});
        this.registerSettings(new Setting[]{this.mode, this.waitForFall, this.minFallSpeed, this.maxFallSpeed, this.groundCheck, this.counterMode, this.hurtWindow, this.counterDelay, this.predictLanding, this.landingAdvantage, this.allowDuringKb, this.prioritizeKb, this.cancelChance});
    }

    @Override
    protected void onEnable() {
        this.counterMode.getValue();
    }

    @Override
    protected void onDisable() {
        this.counterMode.getValue();
    }

    public void a() {
        this.setSuffix(new StringConstant(this.mode.getValueName()));
        this.e(this.r());
    }

    private void s() {
        this.B = 0.0;
        this.C = 0;
        this.D = false;
        this.E = false;
        this.F = 0L;
        this.G = 0;
        this.H = 0;
        this.I = "";
        this.A.b();
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        if (!ItemUtils.c(Module.mc.player.getMainHandStack().getItem())) {
            return;
        }
        this.hurtWindow.getValue();
        this.counterDelay();
        this.C = Module.mc.player.hurtTime;
        this.B = Module.mc.player.getVelocity().y;
    }

    private void t() {
        double d = Module.mc.player.getVelocity().y;
        if (d > 0.1 && this.B <= 0.05 && Module.mc.player.hurtTime > 0) {
            this.D = true;
        }
        if (Module.mc.player.isOnGround()) {
            this.D = false;
        }
    }

    private void u() {
        int n = Module.mc.player.hurtTime;
        if (n > this.C && n >= Math.round(this.hurtWindow.getValue())) {
            this.E = true;
            this.F = System.currentTimeMillis();
            this.A.b();
        }
        if (this.E && System.currentTimeMillis() - this.F > 500L) {
            this.E = false;
        }
    }

    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        if (!ItemUtils.c(Module.mc.player.getMainHandStack().getItem())) {
            return;
        }
        if (!this.predictLanding.getValue()) {
            attackEvent$Pre.cancel();
        }
    }

    private boolean v() {
        EntityHitResult mc26;
        if (Module.mc.player == null || Module.mc.world == null) {
            return true;
        }
        PlayerEntity mc6 = null;
        HitResult ItemStackParticleEffect = RaycastUtils.a(3.0);
        if (ItemStackParticleEffect instanceof EntityHitResult && (mc26 = (EntityHitResult) ItemStackParticleEffect).getEntity() instanceof PlayerEntity) {
            PlayerEntity mc70;
            mc6 = mc70 = (PlayerEntity)mc26.getEntity();
        }
        if (mc6 == null) {
            return true;
        }
        if (!CombatUtils.a(mc6)) {
            return true;
        }
        if (!TargetFilter.a(mc6)) {
            return true;
        }
        return switch (((HitSelectMode)this.mode.getValue()).ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> this.landingAdvantage.getValue();
            case 1 -> this.allowDuringKb.getValue();
            case 2 -> this.a((LivingEntity)mc6);
            case 3 -> this.b((LivingEntity)mc6);
        };
    }

    private boolean w() {
        if (this.D && this.allowDuringKb.getValue() && this.prioritizeKb.getValue()) {
            return this.a("KB reduction");
        }
        if (!this.prioritizeKb.getValue()) {
            return this.b("Waiting for crit timing");
        }
        return this.a("Crit timing OK");
    }

    private boolean x() {
        if (this.D && this.allowDuringKb.getValue()) {
            if (this.prioritizeKb.getValue()) {
                return this.a("KB counter");
            }
            if (this.prioritizeKb.getValue()) {
                return this.a("KB + Crit");
            }
        }
        if (this.counterMode.getValue()) {
            if (!this.E) {
                return this.b("Waiting for hit");
            }
            if (!this.A.a((double)this.counterDelay.i())) {
                return this.b("Counter delay");
            }
        }
        if (this.waitForFall.getValue() && !this.prioritizeKb.getValue()) {
            return this.b("Waiting for crit after hit");
        }
        return this.a("Counter attack");
    }

    private boolean a(LivingEntity mc58) {
        if (this.D && this.allowDuringKb.getValue() && this.prioritizeKb.getValue()) {
            return this.a("KB attack");
        }
        if (this.predictLanding.getValue() && !this.c(mc58)) {
            return this.b("Target lands first");
        }
        if (this.waitForFall.getValue() && !this.prioritizeKb.getValue()) {
            return this.b("Waiting for fall");
        }
        return this.a("Aggressive OK");
    }

    private boolean b(LivingEntity mc58) {
        if (this.D && this.allowDuringKb.getValue()) {
            if (this.prioritizeKb.getValue()) {
                return this.a("Hybrid KB counter");
            }
            if (this.prioritizeKb.getValue()) {
                return this.a("Hybrid KB priority");
            }
        }
        if (this.E && this.A.a((double)this.counterDelay.i()) && this.prioritizeKb.getValue()) {
            return this.a("Hybrid counter crit");
        }
        if (this.predictLanding.getValue() && mc58 != null && !this.c(mc58)) {
            return this.b("Hybrid: target lands first");
        }
        if (this.waitForFall.getValue() && !this.prioritizeKb.getValue()) {
            return this.b("Hybrid: waiting for crit");
        }
        return this.a("Hybrid OK");
    }

    private boolean y() {
        if (this.groundCheck.getValue() && Module.mc.player.isOnGround()) {
            return false;
        }
        if (!this.waitForFall.getValue()) {
            return true;
        }
        double d = Module.mc.player.getVelocity().y;
        double d2 = this.minFallSpeed.getValue();
        double d3 = this.maxFallSpeed.getValue();
        return d <= d2 && d >= d3;
    }

    private boolean c(LivingEntity mc58) {
        if (mc58 == null) {
            return true;
        }
        double d = this.d((LivingEntity)Module.mc.player);
        double d2 = this.d(mc58);
        return d + (double)this.landingAdvantage.getValue() < d2;
    }

    private double d(LivingEntity mc58) {
        double d;
        if (mc58.isOnGround()) {
            return 0.0;
        }
        double d2 = mc58.getY();
        double d3 = mc58.getVelocity().y;
        double d4 = d2;
        for (d = 0.0; d < 100.0; d += 1.0) {
            d3 -= 0.08;
            d2 += (d3 *= 0.98);
            if (!(d3 < 0.0) || !(d2 <= d4 - 0.5)) continue;
            break;
        }
        return d;
    }

    private boolean a(String string) {
        ++this.H;
        this.I = "";
        return true;
    }

    private boolean b(String string) {
        int n = Math.round(this.cancelChance.i());
        if (RandomUtils.a(1, 100) > n) {
            ++this.H;
            return true;
        }
        ++this.G;
        this.I = string;
        return false;
    }

    public boolean z() {
        return this.D;
    }

    public boolean A() {
        return this.E;
    }

    public boolean B() {
        return this.prioritizeKb.getValue();
    }

    public String C() {
        return this.I;
    }

    public int D() {
        return this.G;
    }

    public int E() {
        return this.H;
    }
}

