/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.MovementPacketEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.TickCounter;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.item.SlotUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.api.util.world.BlockUtils;
import itz.vrgn1337.groovclient.api.util.world.RaycastHit;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.AnchorAction;
import itz.vrgn1337.groovclient.module.combat.AnchorBlock;
import itz.vrgn1337.groovclient.module.combat.AnchorSafeTime;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.HotbarSlotSetting;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.util.Hand;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.hit.BlockHitResult;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;

public class AutoAnchor
extends Module {
    private static final int n = 2;
    private static final long o = 1750L;
    private static final int p = 6;
    private final BooleanSetting autoCharge = new BooleanSetting(new StringConstant("Auto Charge"), new StringConstant("Automatically charges anchor with glowstone"), true);
    private final BooleanSetting autoExplode = new BooleanSetting(new StringConstant("Auto Explode"), new StringConstant("Automatically explodes charged anchor"), true);
    private final BooleanSetting safeAnchor = new BooleanSetting(new StringConstant("Safe Anchor"), new StringConstant("Places a block between you and anchor before interaction"), false);
    private final ModeSetting safeTime = new ModeSetting(new StringConstant("Safe time"), new StringConstant("Select safe anchor place timing before charge or after charge"), AnchorSafeTime.BEFORE);
    private final ModeSetting safeBlock = new ModeSetting(new StringConstant("Safe Block"), new StringConstant("Block to use for safe anchor"), AnchorBlock.OBSIDIAN);
    private final FloatSetting switchDelay = new FloatSetting(new StringConstant("Switch Delay"), new StringConstant("Delay between item switches in ticks"), 0.0f, 10.0f, 2.0f, 1.0f);
    private final FloatSetting interactDelay = new FloatSetting(new StringConstant("Interact Delay"), new StringConstant("Delay between anchor interactions in ticks"), 0.0f, 10.0f, 2.0f, 1.0f);
    private final HotbarSlotSetting x = new HotbarSlotSetting(new StringConstant("Explode Slot"), new StringConstant("Hotbar slot to switch to before exploding"), new boolean[]{false, false, false, false, false, false, false, false, false}, true);
    private final BooleanSetting switchBack = new BooleanSetting(new StringConstant("Switch Back"), new StringConstant("Switches back to previous slot after action"), true);
    private final KeybindSetting key = new KeybindSetting(new StringConstant("Key"), new StringConstant("Key to activate auto anchor"), KeybindSetting.getKey(1));
    private final TickCounter A = new TickCounter();
    private final TickCounter B = new TickCounter();
    private final Rotation C = new Rotation();
    private final Map D = new HashMap();
    private final Map E = new HashMap();
    private static final long F = 500L;
    private BlockPos G;
    private BlockPos H;
    private BlockPos I;
    private boolean J;
    private int K = -1;
    private AnchorAction L = AnchorAction.NONE;
    private BlockPos M;
    private RaycastHit N;
    private BlockPos O;
    private BlockPos P;
    private Item Q;
    private boolean R = false;
    private int S = 0;
    private final Set T = new HashSet();
    private final Map U = new HashMap();
    private boolean V = false;
    private boolean W;

    public AutoAnchor() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("AutoAnchor"), new StringConstant("Automatically charges and explodes respawn anchors")});
        this.registerSettings(new Setting[]{this.autoCharge, this.autoExplode, this.safeAnchor, this.safeTime, this.safeBlock, this.switchDelay, this.interactDelay, this.x, this.switchBack, this.key});
        this.C.a(1000);
    }

    @Override
    protected void onEnable() {
        this.A.b();
        this.B.b();
        this.K = -1;
        this.H = null;
        this.I = null;
        this.G = null;
        this.D.clear();
        this.E.clear();
        this.T.clear();
        this.U.clear();
        this.V = false;
        this.safeAnchor.getValue();
    }

    @Override
    protected void onDisable() {
        boolean bl;
        this.G = null;
        this.D.clear();
        this.E.clear();
        this.T.clear();
        this.U.clear();
        this.V = false;
        this.safeAnchor.getValue();
        Rotation rotation = RotationManager.getInstance().o();
        boolean bl2 = bl = rotation == this.C;
        if (bl && !this.C.e()) {
            this.C.f();
        }
    }

    private void s() {
        this.L = AnchorAction.NONE;
        this.M = null;
        this.N = null;
        this.O = null;
        this.P = null;
        this.Q = null;
        this.R = false;
        this.S = 0;
    }

    @Priority(value=700)
    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.R && this.L != AnchorAction.NONE) {
            attackEvent$Pre.cancel();
        }
    }

    @Priority(value=700)
    private void onBreakBlockEventPre(BreakBlockEvent.Pre breakBlockEvent$Pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.R && this.L != AnchorAction.NONE) {
            breakBlockEvent$Pre.cancel();
        }
    }

    @Priority(value=700)
    private void onRenderWorldEventPre(RenderWorldEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.currentScreen != null) {
            return;
        }
        if (this.J) {
            this.J = false;
            this.E();
        }
        this.safeBlock.getValue();
        if (!this.key.isBound() && this.L != AnchorAction.NONE) {
            this.safeAnchor.getValue();
        }
        if (this.L != AnchorAction.NONE && !this.R) {
            this.switchDelay.getValue();
        }
    }

    @Priority(value=700)
    private void onMovementPacketEventPre(MovementPacketEvent.Pre pre) {
        if (Module.mc.player == null) {
            return;
        }
        if (this.L != AnchorAction.NONE) {
            this.R = true;
        }
    }

    @Priority(value=700)
    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.currentScreen != null) {
            return;
        }
        this.safeTime.getValue();
        this.W = false;
        this.key();
        if (this.L != AnchorAction.NONE) {
            return;
        }
        if (!this.key.isBound()) {
            return;
        }
        this.interactDelay.getValue();
        if (this.J()) {
            for (int i = 0; i < 4; ++i) {
                if (this.L == AnchorAction.NONE) {
                    this.interactDelay.getValue();
                    if (this.L == AnchorAction.NONE) break;
                }
                this.R = true;
                this.key();
                if (this.L != AnchorAction.NONE) break;
            }
        }
    }

    private void t() {
        if (Module.mc.world == null) {
            return;
        }
        boolean bl = this.key.isBound();
        if (bl && !this.V) {
            this.T.clear();
            this.U.clear();
            this.a(this.T);
        } else if (!bl && this.V) {
            this.T.clear();
            this.U.clear();
        } else if (bl) {
            HashSet<BlockPos> hashSet = new HashSet();
            this.a(hashSet);
            long l = System.currentTimeMillis();
            for (BlockPos mc0 : hashSet) {
                if (this.T.contains(mc0) || this.U.containsKey(mc0)) continue;
                this.U.put(mc0, l);
            }
            this.U.entrySet().removeIf(arg_0 -> D.lambda$updateAnchorTracking$0((long)l, arg_0));
            this.T.removeIf(this::lambda$updateAnchorTracking$1);
        }
        this.V = bl;
    }

    private void a(Set set) {
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        BlockPos mc0 = Module.mc.player.getBlockPos();
        for (int i = -6; i <= 6; ++i) {
            for (int j = -6; j <= 6; ++j) {
                for (int k = -6; k <= 6; ++k) {
                    BlockPos mc64 = mc0.add(j, i, k);
                    if (Module.mc.world.getBlockState(mc64).getBlock() != Blocks.RESPAWN_ANCHOR) continue;
                    set.add(mc64.toImmutable());
                }
            }
        }
    }

    private void u() {
        if (this.H != null && Module.mc.world.getBlockState(this.H).getBlock() != Blocks.RESPAWN_ANCHOR) {
            this.H = null;
        }
        if (this.I != null && Module.mc.world.getBlockState(this.I).getBlock() != Blocks.RESPAWN_ANCHOR) {
            this.I = null;
        }
        this.D.entrySet().removeIf(arg_0 -> ((AutoAnchor)this).lambda$cleanupState$2(arg_0));
        if (this.G != null && Module.mc.world.getBlockState(this.G).getBlock() != Blocks.RESPAWN_ANCHOR) {
            this.G = null;
        }
    }

    private void v() {
        switch (this.L.ordinal()) {
            case 1: 
            case 2: {
                if (this.M == null) break;
                this.b(this.M);
                break;
            }
            case 3: {
                if (this.N == null) break;
                this.a(this.N);
            }
        }
    }

    private void w() {
        if (!this.key.isBound() || Module.mc.player.isSneaking() || Module.mc.player.isUsingItem()) {
            return;
        }
        if (this.autoCharge.getValue() && this.x.getValue()) {
            return;
        }
        if (this.autoExplode.getValue()) {
            this.switchBack.getValue();
        }
    }

    private boolean x() {
        BlockPos mc0 = this.O();
        if (mc0 == null) {
            return false;
        }
        if (BlockUtils.b(mc0)) {
            return false;
        }
        if (mc0.equals((Object)this.H)) {
            return false;
        }
        if (this.safeAnchor.getValue() && !this.U.containsKey(mc0)) {
            return false;
        }
        if (this.H() && !this.c(mc0)) {
            return this.a(mc0);
        }
        if (!this.F()) {
            if (this.W && !this.J()) {
                return false;
            }
            if (!this.A.a(this.K())) {
                return false;
            }
            if (this.K == -1) {
                this.K = Module.mc.player.getInventory().getSelectedSlot();
            }
            this.A.b();
            SlotUtils.a(Items.GLOWSTONE, 55L);
        }
        if (!this.B.a(this.L()) || !this.F()) {
            return false;
        }
        this.b(mc0);
        this.L = AnchorAction.CHARGE;
        this.M = mc0;
        this.S = 0;
        return true;
    }

    private boolean y() {
        BlockPos mc0 = this.O();
        if (mc0 == null) {
            return false;
        }
        if (!BlockUtils.b(mc0)) {
            return false;
        }
        if (mc0.equals((Object)this.I)) {
            return false;
        }
        if (this.safeAnchor.getValue() && !this.U.containsKey(mc0)) {
            return false;
        }
        if (this.I() && !this.c(mc0)) {
            return this.a(mc0);
        }
        if (this.F()) {
            int n;
            if (this.W && !this.J()) {
                return false;
            }
            if (!this.A.a(this.K())) {
                return false;
            }
            if (this.K == -1) {
                this.K = Module.mc.player.getInventory().getSelectedSlot();
            }
            if ((n = this.x.g()) != -1) {
                SlotUtils.c(n);
            } else {
                this.G();
            }
            this.A.b();
        }
        if (!this.B.a(this.L()) || this.F()) {
            return false;
        }
        this.b(mc0);
        this.L = AnchorAction.EXPLODE;
        this.M = mc0;
        this.S = 0;
        return true;
    }

    private boolean a(BlockPos mc0) {
        if (Module.mc.player == null || Module.mc.world == null || Module.mc.interactionManager == null) {
            return false;
        }
        Direction mc63 = this.d(mc0);
        BlockPos mc64 = this.a(mc0, mc63);
        if (mc64 == null) {
            return false;
        }
        RaycastHit raycastHit = BlockUtils.a(mc64, mc0, mc63);
        if (raycastHit == null) {
            return false;
        }
        if (raycastHit.a().equals((Object)mc0)) {
            return false;
        }
        Item mc17 = this.M();
        if (mc17 == null) {
            return false;
        }
        int n = ItemUtils.f(mc17);
        if (n == -1) {
            return false;
        }
        if (Module.mc.player.getInventory().getSelectedSlot() != n) {
            if (this.W && !this.J()) {
                return false;
            }
            if (this.K == -1) {
                this.K = Module.mc.player.getInventory().getSelectedSlot();
            }
            SlotUtils.c(n);
        }
        this.a(raycastHit);
        this.L = AnchorAction.PLACE_SAFE;
        this.N = raycastHit;
        this.O = mc0;
        this.P = mc64;
        this.Q = mc17;
        this.S = 0;
        return true;
    }

    private void b(BlockPos mc0) {
        double d = (Math.random() - 0.5) * 0.4;
        double d2 = (Math.random() - 0.5) * 0.4;
        double d3 = this.c(mc0) ? (double)mc0.getY() + 1.0 + Math.random() * 0.06 : (double)mc0.getY() + 0.94;
        Vec3d VanillaChestLootTableGenerator = new Vec3d((double)mc0.getX() + 0.5 + d, d3, (double)mc0.getZ() + 0.5 + d2);
        Rotation rotation = RotationUtils.a(VanillaChestLootTableGenerator, Module.mc.player.getEyePos());
        float f = 0.6f + (float)(Math.random() * 0.35);
        float f2 = MathHelper.lerpAngleDegrees((float)f, (float)RotationManager.getInstance().k(), (float)rotation.a());
        float f3 = MathHelper.clamp((float)rotation.b(), (float)-90.0f, (float)90.0f);
        if (!RotationManager.getInstance().e()) {
            RotationManager.getInstance().a(true);
        }
        this.C.a(f2, f3).g();
        RotationManager.getInstance().b(this.C, 1000);
    }

    private void a(RaycastHit raycastHit) {
        Rotation rotation = RotationUtils.a(raycastHit.c(), Module.mc.player.getEyePos());
        float f = 0.6f + (float)(Math.random() * 0.35);
        float f2 = MathHelper.lerpAngleDegrees((float)f, (float)RotationManager.getInstance().k(), (float)rotation.a());
        float f3 = MathHelper.clamp((float)rotation.b(), (float)-90.0f, (float)90.0f);
        if (!RotationManager.getInstance().e()) {
            RotationManager.getInstance().a(true);
        }
        this.C.a(f2, f3).g();
        RotationManager.getInstance().b(this.C, 1000);
    }

    private void z() {
        boolean bl;
        if (!this.R || this.L == AnchorAction.NONE) {
            return;
        }
        ++this.S;
        switch (this.L.ordinal()) {
            case 1: {
                boolean bl2 = this.A();
                break;
            }
            case 2: {
                boolean bl2 = this.B();
                break;
            }
            case 3: {
                boolean bl2 = this.C();
                break;
            }
            default: {
                boolean bl2 = bl = true;
            }
        }
        if (bl || this.S >= 2) {
            this.safeAnchor.getValue();
        } else {
            this.R = false;
        }
    }

    private boolean A() {
        if (this.M == null) {
            return true;
        }
        if (Module.mc.world.getBlockState(this.M).getBlock() != Blocks.RESPAWN_ANCHOR) {
            return true;
        }
        if (BlockUtils.b(this.M)) {
            return true;
        }
        if (!this.F()) {
            return true;
        }
        if (!Module.mc.player.canInteractWithBlockAt(this.M, 0.0)) {
            return true;
        }
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (ItemStackParticleEffect instanceof BlockHitResult) {
            BlockHitResult mc7 = (BlockHitResult)ItemStackParticleEffect;
            if (!mc7.getBlockPos().equals((Object)this.M)) {
                return false;
            }
            this.B.b();
            Module.mc.interactionManager.interactBlock(Module.mc.player, Hand.MAIN_HAND, mc7);
            Module.mc.player.swingHand(Hand.MAIN_HAND);
            this.W = true;
            this.H = this.M;
            this.D();
            if (!this.autoExplode.getValue()) {
                this.J = true;
            }
            return true;
        }
        return false;
    }

    private boolean B() {
        if (this.M == null) {
            return true;
        }
        if (Module.mc.world.getBlockState(this.M).getBlock() != Blocks.RESPAWN_ANCHOR) {
            return true;
        }
        if (!BlockUtils.b(this.M)) {
            return true;
        }
        if (this.F()) {
            return true;
        }
        if (!Module.mc.player.canInteractWithBlockAt(this.M, 0.0)) {
            return true;
        }
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (ItemStackParticleEffect instanceof BlockHitResult) {
            BlockHitResult mc7 = (BlockHitResult)ItemStackParticleEffect;
            if (!mc7.getBlockPos().equals((Object)this.M)) {
                return false;
            }
            this.B.b();
            Module.mc.interactionManager.interactBlock(Module.mc.player, Hand.MAIN_HAND, mc7);
            Module.mc.player.swingHand(Hand.MAIN_HAND);
            this.W = true;
            this.I = this.M;
            this.D();
            this.J = true;
            return true;
        }
        return false;
    }

    private boolean C() {
        if (this.N == null || this.Q == null || this.P == null) {
            return true;
        }
        if (!Module.mc.player.canInteractWithBlockAt(this.N.a(), 0.0) && !Module.mc.player.canInteractWithBlockAt(this.P, 0.0)) {
            return true;
        }
        if (!Module.mc.player.getMainHandStack().isOf(this.Q)) {
            return true;
        }
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (ItemStackParticleEffect instanceof BlockHitResult) {
            boolean bl;
            BlockHitResult mc7 = (BlockHitResult)ItemStackParticleEffect;
            boolean bl2 = mc7.getBlockPos().equals((Object)this.N.a()) && mc7.getSide() == this.N.b();
            boolean bl3 = bl = mc7.getBlockPos().equals((Object)this.P) && !Module.mc.world.isAir(this.P) && RotationManager.getInstance().a(this.P);
            if (!bl2 && !bl) {
                return false;
            }
            Module.mc.interactionManager.interactBlock(Module.mc.player, Hand.MAIN_HAND, mc7);
            Module.mc.player.swingHand(Hand.MAIN_HAND);
            this.W = true;
            this.D.put(this.O, this.P);
            this.E.put(this.O, System.currentTimeMillis());
            this.G = this.O;
            return true;
        }
        return false;
    }

    private void D() {
        if (this.key.isBound() && Module.mc.options.useKey.isPressed()) {
            Module.mc.options.useKey.setPressed(false);
        }
    }

    private void E() {
        if (this.switchBack.getValue() && this.A.a(this.K())) {
            if (this.K != -1 && Module.mc.player != null) {
                SlotUtils.c(this.K);
            }
            this.K = -1;
        } else {
            this.K = -1;
        }
    }

    private boolean F() {
        return Module.mc.player.getMainHandStack().isOf(Items.GLOWSTONE);
    }

    private void G() {
        if (this.K != -1 && !Module.mc.player.getInventory().getStack(this.K).isOf(Items.GLOWSTONE)) {
            SlotUtils.c(this.K);
            return;
        }
        for (int i = 0; i < 9; ++i) {
            if (Module.mc.player.getInventory().getStack(i).isOf(Items.GLOWSTONE)) continue;
            SlotUtils.c(i);
            return;
        }
    }

    private boolean H() {
        if (!this.safeAnchor.getValue()) {
            return false;
        }
        AnchorSafeTime anchorSafeTime = (AnchorSafeTime)this.safeTime.getValue();
        return anchorSafeTime == AnchorSafeTime.BEFORE || anchorSafeTime == AnchorSafeTime.INSTANT;
    }

    private boolean I() {
        return this.safeAnchor.getValue() && this.safeTime.getValue() == AnchorSafeTime.CHARGE;
    }

    private boolean J() {
        return this.safeAnchor.getValue() && this.safeTime.getValue() == AnchorSafeTime.INSTANT;
    }

    private int K() {
        return this.J() ? 0 : this.switchDelay.getPercent();
    }

    private int L() {
        return this.J() ? 0 : this.interactDelay.getPercent();
    }

    private boolean c(BlockPos mc0) {
        BlockPos mc64 = (BlockPos)this.D.get(mc0);
        if (mc64 == null) {
            return false;
        }
        Long l = (Long)this.E.get(mc0);
        if (l != null && System.currentTimeMillis() - l < 500L) {
            return true;
        }
        return !Module.mc.world.getBlockState(mc64).isReplaceable();
    }

    private Item M() {
        Item mc17;
        Item mc94 = this.safeBlock.getValue() == AnchorBlock.OBSIDIAN ? Items.OBSIDIAN : Items.GLOWSTONE;
        Item mc95 = mc17 = mc94 == Items.OBSIDIAN ? Items.GLOWSTONE : Items.OBSIDIAN;
        if (ItemUtils.g(mc94)) {
            return mc94;
        }
        if (ItemUtils.g(mc17)) {
            return mc17;
        }
        return null;
    }

    private BlockPos N() {
        BlockHitResult mc7;
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (ItemStackParticleEffect instanceof BlockHitResult && Module.mc.world.getBlockState((mc7 = (BlockHitResult)ItemStackParticleEffect).getBlockPos()).getBlock() == Blocks.RESPAWN_ANCHOR) {
            return mc7.getBlockPos();
        }
        return null;
    }

    private BlockPos O() {
        BlockPos mc0 = this.N();
        if (mc0 != null) {
            this.G = mc0;
            return mc0;
        }
        if (this.G == null) {
            return null;
        }
        if (Module.mc.world.getBlockState(this.G).getBlock() != Blocks.RESPAWN_ANCHOR) {
            return null;
        }
        if (!Module.mc.player.canInteractWithBlockAt(this.G, 0.0)) {
            return null;
        }
        return this.G;
    }

    private Direction d(BlockPos mc0) {
        double d = Module.mc.player.getX() - ((double)mc0.getX() + 0.5);
        double d2 = Module.mc.player.getZ() - ((double)mc0.getZ() + 0.5);
        if (Math.abs(d) > Math.abs(d2)) {
            return d > 0.0 ? Direction.EAST : Direction.WEST;
        }
        return d2 > 0.0 ? Direction.SOUTH : Direction.NORTH;
    }

    private BlockPos a(BlockPos mc0, Direction mc63) {
        BlockPos mc64 = mc0.offset(mc63);
        if (!this.e(mc64)) {
            return null;
        }
        RaycastHit raycastHit = BlockUtils.a(mc64, mc0, mc63);
        if (raycastHit == null || raycastHit.a().equals((Object)mc0)) {
            return null;
        }
        return mc64;
    }

    private boolean e(BlockPos mc0) {
        return !Module.mc.player.getBoundingBox().intersects(new Box(mc0)) && Module.mc.player.canInteractWithBlockAt(mc0, 0.0);
    }

    private boolean lambda$cleanupState$2(Map.Entry entry) {
        boolean bl;
        boolean bl2 = bl = Module.mc.world.getBlockState((BlockPos)entry.getKey()).getBlock() != Blocks.RESPAWN_ANCHOR;
        if (bl) {
            this.E.remove(entry.getKey());
        }
        return bl;
    }

    private static boolean lambda$updateAnchorTracking$1(BlockPos mc0) {
        return Module.mc.world.getBlockState(mc0).getBlock() != Blocks.RESPAWN_ANCHOR;
    }

    private static boolean lambda$updateAnchorTracking$0(long l, Map.Entry entry) {
        return l - (Long)entry.getValue() > 1750L || Module.mc.world.getBlockState((BlockPos)entry.getKey()).getBlock() != Blocks.RESPAWN_ANCHOR;
    }
}

