/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

enum ShieldEaterState {
    IDLE, BURSTING;

    private ShieldEaterState() {

    }

}

