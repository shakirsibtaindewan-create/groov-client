/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.combat.CombatUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.Rotation;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.ShieldAimSort;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;

public class ShieldAim
extends Module {
    private final FloatSetting range = new FloatSetting(new StringConstant("Range"), new StringConstant("Max distance to consider attackers"), 1.0f, 32.0f, 6.0f, 0.5f);
    private final FloatSetting speed = new FloatSetting(new StringConstant("Speed"), new StringConstant("Max yaw degrees per tick"), 1.0f, 22.0f, 10.0f, 0.5f);
    private final FloatSetting fOV = new FloatSetting(new StringConstant("FOV"), new StringConstant("Only align to targets within this yaw arc"), 30.0f, 360.0f, 360.0f, 1.0f);
    private final BooleanSetting players = new BooleanSetting(new StringConstant("Players"), new StringConstant("Align to nearby players"), true);
    private final BooleanSetting mobs = new BooleanSetting(new StringConstant("Mobs"), new StringConstant("Align to nearby hostile mobs"), false);
    private final BooleanSetting predict = new BooleanSetting(new StringConstant("Predict"), new StringConstant("Lead target using its velocity"), true);
    private final ModeSetting sort = new ModeSetting(new StringConstant("Sort"), new StringConstant("Target priority"), ShieldAimSort.Closest);
    private final Rotation u = new Rotation();

    public ShieldAim() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("ShieldAim"), new StringConstant("Silently faces the nearest enemy while shield blocking")});
        this.addSettings(List.of(this.range, this.speed, this.fOV, this.players, this.mobs, this.predict, this.sort));
    }

    @Priority(value=150)
    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        if (Module.mc.player.isDead() || Module.mc.player.isSpectator()) {
            return;
        }
        if (Module.mc.currentScreen != null) {
            return;
        }
        if (!CombatUtils.a((PlayerEntity)Module.mc.player)) {
            return;
        }
        LivingEntity mc58 = this.predict.getValue();
        if (mc58 == null) {
            return;
        }
        Vec3d VanillaChestLootTableGenerator = Module.mc.player.getEyePos();
        Vec3d WallPlayerSkullBlock = mc58.getEyePos();
        if (this.predict.getValue()) {
            Vec3d VanillaEntityLootTableGenerator = mc58.getVelocity();
            WallPlayerSkullBlock = WallPlayerSkullBlock.add(VanillaEntityLootTableGenerator.x * 0.5, 0.0, VanillaEntityLootTableGenerator.z * 0.5);
        }
        double d = WallPlayerSkullBlock.x - VanillaChestLootTableGenerator.x;
        double d2 = WallPlayerSkullBlock.z - VanillaChestLootTableGenerator.z;
        float f = (float)Math.toDegrees(Math.atan2(d2, d)) - 90.0f;
        float f2 = RotationManager.r();
        float f3 = RotationManager.s();
        float f4 = MathHelper.wrapDegrees((float)(f - f2));
        float f5 = this.speed.getValue();
        float f6 = MathHelper.clamp((float)f4, (float)(-f5), (float)f5);
        float f7 = f2 + f6;
        this.u.a(f7, f3).g();
        RotationManager.getInstance().a(this.u, 100);
    }

    private LivingEntity s() {
        if (!this.players.getValue() && !this.mobs.getValue()) {
            return null;
        }
        double d = this.range.getValue();
        Vec3d VanillaChestLootTableGenerator = Module.mc.player.getEyePos();
        float f = RotationManager.r();
        float f2 = this.fOV.getValue() * 0.5f;
        boolean bl = this.fOV.getValue() < 360.0f;
        List<LivingEntity> list = Module.mc.world.getEntitiesByClass(LivingEntity.class, Module.mc.player.getBoundingBox().expand(d), arg_0 -> ((ShieldAim)this).a(arg_0));
        if (list.isEmpty()) {
            return null;
        }
        LivingEntity mc58 = null;
        double d2 = Double.MAX_VALUE;
        ShieldAimSort shieldAimSort = (ShieldAimSort)this.sort.getValue();
        for (LivingEntity mc71 : list) {
            double d3;
            if ((double)Module.mc.player.distanceTo((Entity)mc71) > d) continue;
            double d4 = -1.0;
            if (bl || shieldAimSort == ShieldAimSort.FOV) {
                Vec3d WallPlayerSkullBlock = mc71.getEyePos();
                float f3 = (float)Math.toDegrees(Math.atan2(WallPlayerSkullBlock.z - VanillaChestLootTableGenerator.z, WallPlayerSkullBlock.x - VanillaChestLootTableGenerator.x)) - 90.0f;
                d4 = Math.abs(MathHelper.wrapDegrees((float)(f3 - f)));
                if (bl && d4 > (double)f2) continue;
            }
            if (!((d3 = (switch (shieldAimSort.ordinal()) {
                default -> throw new MatchException(null, null);
                case 0 -> Module.mc.player.squaredDistanceTo((Entity)mc71);
                case 1 -> mc71.getHealth();
                case 2 -> d4;
            })) < d2)) continue;
            d2 = d3;
            mc58 = mc71;
        }
        return mc58;
    }

    private boolean a(LivingEntity mc58) {
        if (mc58 == null || mc58 == Module.mc.player) {
            return false;
        }
        if (!mc58.isAlive()) {
            return false;
        }
        if (mc58 instanceof PlayerEntity) {
            PlayerEntity mc6 = (PlayerEntity)mc58;
            if (!this.players.getValue()) {
                return false;
            }
            if (mc6.isSpectator() || mc6.isInvisible()) {
                return false;
            }
            return TargetFilter.a((Entity)mc6);
        }
        if (!this.mobs.getValue()) {
            return false;
        }
        return mc58 instanceof MobEntity;
    }
}

