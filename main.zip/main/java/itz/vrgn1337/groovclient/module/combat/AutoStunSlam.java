/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.BindManager;
import itz.vrgn1337.groovclient.api.util.Stopwatch;
import itz.vrgn1337.groovclient.api.util.combat.CombatUtils;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.item.SlotUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.rotation.RaycastUtils;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.SlamEnchant;
import itz.vrgn1337.groovclient.module.combat.SlamMode;
import itz.vrgn1337.groovclient.module.combat.StunSlamState;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.registry.entry.RegistryEntry;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;

public class AutoStunSlam
extends Module {
    private final ModeSetting mode = new ModeSetting(new StringConstant("Mode"), new StringConstant("Legit based on CPS, Blatant uses silent swap"), SlamMode.LEGIT);
    private final ModeSetting enchant = new ModeSetting(new StringConstant("Enchant"), new StringConstant("Preferred mace enchant for slam"), SlamEnchant.DENSITY);
    private final DoubleSetting cPS = new DoubleSetting(new StringConstant("CPS"), new StringConstant("Clicks per second for legit slam attack"), 16.0f, 20.0f, 1.0f, 25.0f, 1.0f, 12.0f);
    private final BooleanSetting onlyFalling = new BooleanSetting(new StringConstant("Only Falling"), new StringConstant("Only activate when falling"), true);
    private final FloatSetting maxFallSpeed = new FloatSetting(new StringConstant("Max Fall Speed"), new StringConstant("Do not trigger on fall speed. 0 will disable this setting"), 0.0f, 4.0f, 0.0f, 0.1f);
    private final FloatSetting chance = new FloatSetting(new StringConstant("Chance"), new StringConstant("Chance to trigger stun slam"), 0.0f, 100.0f, 80.0f, 1.0f);
    private StunSlamState t = StunSlamState.IDLE;
    private PlayerEntity u;
    private long v = 0L;
    private long w = 0L;
    private long x = 0L;
    private final Stopwatch y = new Stopwatch();

    public AutoStunSlam() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("AutoStunSlam"), new StringConstant("Swaps to mace after axe hit while falling")});
        this.addSettings(List.of(this.mode, this.enchant, this.cPS, this.onlyFalling, this.maxFallSpeed, this.chance));
    }

    public void a() {
        this.cPS.a(this.mode.getValue() == SlamMode.LEGIT);
    }

    @Override
    protected void onDisable() {
        this.chance.getValue();
        this.y.b();
    }

    private void s() {
        this.t = StunSlamState.IDLE;
        this.u = null;
        this.v = 0L;
        this.w = 0L;
        this.x = 0L;
    }

    private boolean t() {
        if (Module.mc.player == null || Module.mc.world == null || Module.mc.currentScreen != null) {
            return false;
        }
        if (Module.mc.player.isUsingItem()) {
            return false;
        }
        if (this.mode.getValue() == SlamMode.LEGIT && !ItemUtils.d(Module.mc.player.getMainHandStack().getItem())) {
            return false;
        }
        if (this.onlyFalling.getValue() && (Module.mc.player.isOnGround() || Module.mc.player.getVelocity().y >= 0.0)) {
            return false;
        }
        float f = this.maxFallSpeed.getValue();
        if (f > 0.0f && -Module.mc.player.getVelocity().y >= (double)f) {
            return false;
        }
        return ThreadLocalRandom.current().nextInt(99) <= (int)this.chance.getValue();
    }

    @Priority(value=500)
    private void onAttackEventManualCalledAttack(AttackEvent.ManualCalledAttack manualCalledAttack) {
        if (this.mode.getValue() == SlamMode.LEGIT) {
            this.v();
        } else {
            Module.mc.execute(() -> ((AutoStunSlam)this).u());
        }
    }

    @Priority(value=500)
    private void onAttackEventPre(AttackEvent.Pre attackEvent$Pre) {
        if (this.mode.getValue() == SlamMode.LEGIT) {
            this.v();
        } else {
            Module.mc.execute(() -> ((AutoStunSlam)this).u());
        }
    }

    private void u() {
        if (this.mode.getValue() != SlamMode.BLATANT) {
            return;
        }
        if (!this.t()) {
            return;
        }
        HitResult ItemStackParticleEffect = RaycastUtils.a(3.0);
        if (!(ItemStackParticleEffect instanceof EntityHitResult)) {
            return;
        }
        EntityHitResult mc26 = (EntityHitResult)ItemStackParticleEffect;
        Entity mc2 = mc26.getEntity();
        if (!(mc2 instanceof PlayerEntity)) {
            return;
        }
        PlayerEntity ItemStackParticleEffect_p;
        ItemStackParticleEffect_p = (PlayerEntity)mc2;
        if (!TargetFilter.a((Entity)ItemStackParticleEffect_p)) {
            return;
        }
        if (!CombatUtils.a((PlayerEntity)ItemStackParticleEffect)) {
            return;
        }
        int n = this.y();
        if (n == -1) {
            return;
        }
        int n2 = ItemUtils.b();
        if (n2 == -1) {
            return;
        }
        int n3 = Module.mc.player.getInventory().getSelectedSlot();
        BindManager.j();
        Module.mc.player.getInventory().setSelectedSlot(n2);
        Module.mc.interactionManager.attackEntity((PlayerEntity)Module.mc.player, (Entity)ItemStackParticleEffect);
        Module.mc.player.swingHand(Hand.MAIN_HAND);
        Module.mc.player.getInventory().setSelectedSlot(n);
        Module.mc.interactionManager.attackEntity((PlayerEntity)Module.mc.player, (Entity)ItemStackParticleEffect);
        Module.mc.player.swingHand(Hand.MAIN_HAND);
        Module.mc.player.getInventory().setSelectedSlot(n3);
        BindManager.k();
    }

    private void v() {
        if (!this.t()) {
            return;
        }
        if (Module.mc.currentScreen != null) {
            return;
        }
        if (this.t != StunSlamState.IDLE) {
            return;
        }
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (!(ItemStackParticleEffect instanceof EntityHitResult)) {
            return;
        }
        EntityHitResult mc26 = (EntityHitResult)ItemStackParticleEffect;
        Entity mc2 = mc26.getEntity();
        if (!(mc2 instanceof PlayerEntity)) {
            return;
        }
        PlayerEntity ItemStackParticleEffect_p;
        ItemStackParticleEffect_p = (PlayerEntity)mc2;
        if (!TargetFilter.a((Entity)ItemStackParticleEffect_p)) {
            return;
        }
        if (!CombatUtils.a((PlayerEntity)ItemStackParticleEffect_p)) {
            return;
        }
        int n = this.y();
        if (n == -1) {
            return;
        }
        this.u = ItemStackParticleEffect_p;
        this.t = StunSlamState.SWAP;
    }

    private void onUpdateEventPost(UpdateEvent.Post post) {
        EntityHitResult mc26;
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        this.setSuffix(new StringConstant(this.cPS.e() + "-" + this.cPS.g() + "cps"));
        if (Module.mc.currentScreen != null) {
            return;
        }
        if (this.mode.getValue() != SlamMode.LEGIT) {
            return;
        }
        if (this.t != StunSlamState.SWAP) {
            return;
        }
        int n = this.y();
        if (n == -1) {
            return;
        }
        HitResult ItemStackParticleEffect = Module.mc.crosshairTarget;
        if (ItemStackParticleEffect instanceof EntityHitResult && (mc26 = (EntityHitResult)ItemStackParticleEffect).getEntity() == this.u && SlotUtils.c(n)) {
            Module.mc.player.attack((Entity)this.u);
            Module.mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    @Priority(value=300)
    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        PlayerEntity mc6;
        EntityHitResult mc26;
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        if (this.mode.getValue() != SlamMode.LEGIT) {
            return;
        }
        if (this.y.a(1000.0)) {
            mc26 = Module.mc.world.getPlayers().iterator();
            while (mc26.hasNext()) {
                mc6 = (PlayerEntity)mc26.next();
                if (mc6 == Module.mc.player || !TargetFilter.a((Entity)mc6) || Module.mc.player.distanceTo((Entity)mc6) > 16.0f || mc6.getY() >= Module.mc.player.getY() || !CombatUtils.a(mc6) || ItemUtils.d(Module.mc.player.getMainHandStack().getItem())) continue;
                int n = ItemUtils.b();
                if (n != -1) {
                    SlotUtils.c(n);
                    this.y.b();
                }
                return;
            }
        }
        if (this.u != null && this.t != StunSlamState.IDLE && !CombatUtils.a(this.u)) {
            int n = this.y();
            if (n > -1) {
                SlotUtils.c(n);
                this.chance.getValue();
            }
            return;
        }
        if (this.t == StunSlamState.DONE) {
            if (System.currentTimeMillis() - this.x >= 300L) {
                this.chance.getValue();
            }
            return;
        }
        if (this.t == StunSlamState.ATTACK) {
            if (this.u == null || !this.u.isAlive()) {
                this.chance.getValue();
                return;
            }
            mc6 = RaycastUtils.a(3.0);
            if (!(mc6 instanceof EntityHitResult) || (mc26 = (EntityHitResult)mc6).getEntity() != this.u) {
                this.chance.getValue();
                return;
            }
            if (!this.w()) {
                return;
            }
            Module.mc.interactionManager.attackEntity((PlayerEntity)Module.mc.player, (Entity)this.u);
            Main.eventBus().post(AttackEvent.ManualCalledAttack.getInstance());
            Module.mc.player.swingHand(Hand.MAIN_HAND);
            this.v = System.currentTimeMillis();
            this.w = this.x();
            this.x = System.currentTimeMillis();
            this.t = StunSlamState.DONE;
        }
    }

    private boolean w() {
        return System.currentTimeMillis() - this.v >= this.w;
    }

    private long x() {
        float f = this.cPS.d();
        float f2 = this.cPS.f();
        double d = (double)f + Math.random() * (double)(f2 - f);
        if (d < 1.0) {
            d = 1.0;
        }
        double d2 = 1000.0 / d;
        double d3 = d2 * ThreadLocalRandom.current().nextDouble(-0.15, 0.15);
        return Math.max(50L, (long)(d2 + d3));
    }

    private int y() {
        int n = -1;
        String string = this.enchant.getValue() == SlamEnchant.BREACH ? "breach" : "density";
        for (int i = 0; i < 9; ++i) {
            ItemStack mc33 = Module.mc.player.getInventory().getStack(i);
            if (mc33.getItem() != Items.MACE) continue;
            if (this.a(mc33, string)) {
                return i;
            }
            if (n != -1) continue;
            n = i;
        }
        return n;
    }

    private boolean a(ItemStack mc33, String string) {
        if (mc33.isEmpty()) {
            return false;
        }
        return mc33.getEnchantments().getEnchantments().stream().anyMatch(arg_0 -> F.lambda$hasEnchant$0((String)string, arg_0));
    }

    private static boolean lambda$hasEnchant$0(String string, RegistryEntry mc96) {
        return mc96.getIdAsString().toLowerCase().contains(string);
    }
}

