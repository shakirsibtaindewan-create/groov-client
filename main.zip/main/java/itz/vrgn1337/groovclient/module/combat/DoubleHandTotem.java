/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.combat;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.item.ItemUtils;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.combat.TotemThreat;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.HotbarSlotSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.world.World;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.state.property.Property;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.block.RespawnAnchorBlock;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;

public class DoubleHandTotem
extends Module {
    private final BooleanSetting onPop = new BooleanSetting(new StringConstant("On Pop"), new StringConstant("Switches to totem right after your pop"), true);
    private final BooleanSetting inInventory = new BooleanSetting(new StringConstant("In Inventory"), new StringConstant("Switches to totem while inventory is open"), false);
    private final HotbarSlotSetting p = new HotbarSlotSetting(new StringConstant("Slot"), new StringConstant("Preferred hotbar slot when inventory is open"), new boolean[]{false, false, false, false, false, false, false, false, false}, true);
    private final FloatSetting range = new FloatSetting(new StringConstant("Range"), new StringConstant("Threat detection range"), 0.0f, 10.0f, 5.0f, 0.5f);
    private final BooleanSetting detectCrystal = new BooleanSetting(new StringConstant("Detect Crystal"), new StringConstant("Detects crystal danger"), true);
    private final BooleanSetting detectAnchor = new BooleanSetting(new StringConstant("Detect Anchor"), new StringConstant("Detects respawn anchor danger"), true);
    private final BooleanSetting lowHealth = new BooleanSetting(new StringConstant("Low Health"), new StringConstant("Double hand when your health is low"), true);
    private final FloatSetting health = new FloatSetting(new StringConstant("Health"), new StringConstant("Health threshold for totem switch"), 0.0f, 20.0f, 6.0f, 1.0f);
    private final BooleanSetting swordPop = new BooleanSetting(new StringConstant("Sword Pop"), new StringConstant("Predicts sword burst damage"), false);
    private final BooleanSetting mace = new BooleanSetting(new StringConstant("Mace"), new StringConstant("Predicts mace burst damage"), false);
    private final BooleanSetting projectile = new BooleanSetting(new StringConstant("Projectile"), new StringConstant("Detects incoming projectiles"), true);
    private final FloatSetting projRange = new FloatSetting(new StringConstant("Proj Range"), new StringConstant("Projectile detection range"), 5.0f, 30.0f, 15.0f, 0.5f);
    private final FloatSetting predictTicks = new FloatSetting(new StringConstant("Predict Ticks"), new StringConstant("How many ticks to predict projectile path"), 10.0f, 80.0f, 40.0f, 1.0f);
    private final FloatSetting cooldown = new FloatSetting(new StringConstant("Cooldown"), new StringConstant("Minimum delay between automatic double hand"), 0.0f, 1000.0f, 500.0f, 50.0f);
    private long B;
    private TotemThreat C;

    public DoubleHandTotem() {
        super(ModuleCategory.COMBAT, new StringConstant[]{new StringConstant("DoubleHandTotem"), new StringConstant("Predicts danger and switches to totem")});
        this.registerSettings(new Setting[]{this.onPop, this.inInventory, this.p, this.range, this.detectCrystal, this.detectAnchor, this.lowHealth, this.health, this.swordPop, this.mace, this.projectile, this.projRange, this.predictTicks, this.cooldown});
    }

    public void a() {
        this.p.a(this.inInventory.getValue());
    }

    @Override
    protected void onEnable() {
        this.B = 0L;
        this.C = null;
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        this.lowHealth.getValue();
        this.health.getValue();
        this.swordPop.getValue();
        this.detectAnchor.getValue();
    }

    private void onPacketReceiveEventPre(PacketReceiveEvent.Pre packetReceiveEvent$Pre) {
        EntityStatusS2CPacket mc99;
        if (Module.mc.player == null || Module.mc.world == null) {
            return;
        }
        if (!this.onPop.getValue()) {
            return;
        }
        Packet mc14 = packetReceiveEvent$Pre.getPacket();
        if (mc14 instanceof EntityStatusS2CPacket && (mc99 = (EntityStatusS2CPacket)mc14).getStatus() == 35 && mc99.getEntity((World)Module.mc.world) == Module.mc.player) {
            this.a(TotemThreat.POP);
        }
    }

    private void s() {
        if (!this.inInventory.getValue()) {
            return;
        }
        if (!(Module.mc.currentScreen instanceof InventoryScreen)) {
            return;
        }
        int n = this.p.g();
        if (n >= 0 && Module.mc.player.getInventory().getStack(n).isOf(Items.TOTEM_OF_UNDYING)) {
            Module.mc.player.getInventory().setSelectedSlot(n);
            return;
        }
        if (ItemUtils.g(Items.TOTEM_OF_UNDYING)) {
            this.a(TotemThreat.MISC);
        }
    }

    private void t() {
        double d = this.range.getValue();
        double d2 = d * d;
        for (PlayerEntity mc6 : Module.mc.world.getPlayers()) {
            if (mc6 == Module.mc.player || !TargetFilter.a((Entity)mc6) || mc6.isCreative() || mc6.isSpectator() || Module.mc.player.squaredDistanceTo((Entity)mc6) > d2) continue;
            if (this.swordPop.getValue() && this.a(mc6)) {
                return;
            }
            if (this.mace.getValue() && this.b(mc6)) {
                return;
            }
            if (this.detectAnchor.getValue() && this.c(mc6)) {
                return;
            }
            if (!this.detectCrystal.getValue() || !this.d(mc6)) continue;
            return;
        }
    }

    private void u() {
        if (!this.projectile.getValue()) {
            return;
        }
        double d = this.projRange.getValue();
        Box HorizontalFacingBlock = Module.mc.player.getBoundingBox().expand(d);
        for (Entity mc2 : Module.mc.world.getOtherEntities((Entity)Module.mc.player, HorizontalFacingBlock, (arg_0) -> ((DoubleHandTotem)this).lambda$handleProjectileThreats$0(arg_0))) {
            ProjectileEntity mc103;
            if (!(mc2 instanceof ProjectileEntity) || !this.a(mc103 = (ProjectileEntity)mc2) || mc103.getOwner() == Module.mc.player || !this.b(mc103)) continue;
            this.a(TotemThreat.PROJECTILE);
            return;
        }
    }

    private boolean a(ProjectileEntity mc103) {
        EntityType mc104 = mc103.getType();
        return mc104 == EntityType.ARROW || mc104 == EntityType.TRIDENT || mc104 == EntityType.ENDER_PEARL || mc104 == EntityType.SPLASH_POTION || mc104 == EntityType.LINGERING_POTION;
    }

    private boolean b(ProjectileEntity mc103) {
        Vec3d VanillaChestLootTableGenerator = mc103.getEntityPos();
        Vec3d WallPlayerSkullBlock = mc103.getVelocity();
        if (WallPlayerSkullBlock.lengthSquared() < 0.01) {
            return false;
        }
        Vec3d VanillaEntityLootTableGenerator = Module.mc.player.getEntityPos().add(0.0, (double)Module.mc.player.getHeight() * 0.5, 0.0);
        Vec3d PlayerSkullBlock = VanillaEntityLootTableGenerator.subtract(VanillaChestLootTableGenerator);
        if (PlayerSkullBlock.lengthSquared() < 0.01) {
            return true;
        }
        double d = WallPlayerSkullBlock.normalize().dotProduct(PlayerSkullBlock.normalize());
        if (d < 0.3) {
            return false;
        }
        int n = this.predictTicks.getPercent();
        Box HorizontalFacingBlock = Module.mc.player.getBoundingBox().expand(0.6);
        Vec3d RedstoneBlock = VanillaChestLootTableGenerator;
        Vec3d VanillaFishingLootTableGenerator = WallPlayerSkullBlock;
        double d2 = this.c(mc103);
        double d3 = this.d(mc103);
        for (int i = 1; i <= n; ++i) {
            RedstoneBlock = RedstoneBlock.add(VanillaFishingLootTableGenerator);
            VanillaFishingLootTableGenerator = VanillaFishingLootTableGenerator.multiply(d3).subtract(0.0, d2, 0.0);
            if (HorizontalFacingBlock.contains(RedstoneBlock)) {
                return true;
            }
            if (this.a(RedstoneBlock, HorizontalFacingBlock) < 0.5) {
                return true;
            }
            Vec3d LootTableProvider = VanillaEntityLootTableGenerator.subtract(RedstoneBlock);
            if (LootTableProvider.lengthSquared() > PlayerSkullBlock.lengthSquared() * 4.0) break;
        }
        return false;
    }

    private double c(ProjectileEntity mc103) {
        EntityType mc104 = mc103.getType();
        if (mc104 == EntityType.ENDER_PEARL) {
            return 0.03;
        }
        if (mc104 == EntityType.ARROW || mc104 == EntityType.TRIDENT) {
            return 0.05;
        }
        if (mc104 == EntityType.SPLASH_POTION || mc104 == EntityType.LINGERING_POTION) {
            return 0.05;
        }
        return 0.03;
    }

    private double d(ProjectileEntity mc103) {
        EntityType mc104 = mc103.getType();
        if (mc104 == EntityType.ENDER_PEARL) {
            return 0.99;
        }
        if (mc104 == EntityType.SPLASH_POTION || mc104 == EntityType.LINGERING_POTION) {
            return 0.99;
        }
        return 0.99;
    }

    private double a(Vec3d VanillaChestLootTableGenerator, Box HorizontalFacingBlock) {
        double d = Math.max(HorizontalFacingBlock.minX - VanillaChestLootTableGenerator.x, Math.max(0.0, VanillaChestLootTableGenerator.x - HorizontalFacingBlock.maxX));
        double d2 = Math.max(HorizontalFacingBlock.minY - VanillaChestLootTableGenerator.y, Math.max(0.0, VanillaChestLootTableGenerator.y - HorizontalFacingBlock.maxY));
        double d3 = Math.max(HorizontalFacingBlock.minZ - VanillaChestLootTableGenerator.z, Math.max(0.0, VanillaChestLootTableGenerator.z - HorizontalFacingBlock.maxZ));
        return d * d + d2 * d2 + d3 * d3;
    }

    private boolean a(PlayerEntity mc6) {
        if (!this.a(mc6, 3.2, 0.92)) {
            return false;
        }
        if (!ItemUtils.c(mc6.getMainHandStack().getItem())) {
            return false;
        }
        if (this.a(7.0f)) {
            this.a(TotemThreat.SWORD);
            return true;
        }
        return false;
    }

    private boolean b(PlayerEntity mc6) {
        Item mc17 = mc6.getMainHandStack().getItem();
        if (mc17 != Items.MACE) {
            return false;
        }
        if (!this.a(mc6, 4.0, 0.88)) {
            return false;
        }
        if (this.a(10.5f)) {
            this.a(TotemThreat.MACE);
            return true;
        }
        return false;
    }

    private boolean c(PlayerEntity mc6) {
        if (mc6.distanceTo((Entity)Module.mc.player) > 4.5f) {
            return false;
        }
        if (!mc6.getMainHandStack().isOf(Items.GLOWSTONE) && !mc6.getOffHandStack().isOf(Items.GLOWSTONE)) {
            return false;
        }
        BlockPos mc0 = mc6.getBlockPos();
        for (BlockPos mc64 : BlockPos.iterate((BlockPos)mc0.add(-3, -2, -3), (BlockPos)mc0.add(3, 2, 3))) {
            Integer n;
            if (!Module.mc.world.getBlockState(mc64).isOf(Blocks.RESPAWN_ANCHOR) || (n = Module.mc.world.getBlockState(mc64).getOrEmpty((Property)RespawnAnchorBlock.CHARGES).orElse(0)) <= 0 || !(Module.mc.player.squaredDistanceTo(Vec3d.ofCenter((Vec3i)mc64)) <= 36.0)) continue;
            this.a(TotemThreat.ANCHOR);
            return true;
        }
        return false;
    }

    private boolean d(PlayerEntity mc6) {
        if (mc6.distanceTo((Entity)Module.mc.player) > 4.0f) {
            return false;
        }
        Box HorizontalFacingBlock = Module.mc.player.getBoundingBox().expand(6.0);
        for (Entity mc2 : Module.mc.world.getOtherEntities((Entity)Module.mc.player, HorizontalFacingBlock, (arg_0) -> ((DoubleHandTotem)this).lambda$handleCrystalThreat$1(arg_0))) {
            EndCrystalEntity mc100 = (EndCrystalEntity)mc2;
            if (!(mc100.getY() <= Module.mc.player.getY()) || !(Module.mc.player.getY() - mc100.getY() <= 8.0)) continue;
            this.a(TotemThreat.CRYSTAL);
            return true;
        }
        return false;
    }

    private boolean a(PlayerEntity mc6, double d, double d2) {
        if ((double)mc6.distanceTo((Entity)Module.mc.player) > d) {
            return false;
        }
        Vec3d VanillaChestLootTableGenerator = mc6.getEyePos();
        Vec3d WallPlayerSkullBlock = Module.mc.player.getBoundingBox().getCenter().subtract(VanillaChestLootTableGenerator);
        if (WallPlayerSkullBlock.lengthSquared() < 1.0E-4) {
            return true;
        }
        Vec3d VanillaEntityLootTableGenerator = mc6.getRotationVec(1.0f);
        return VanillaEntityLootTableGenerator.normalize().dotProduct(WallPlayerSkullBlock.normalize()) >= d2;
    }

    private boolean a(float f) {
        float f2 = 2.0f;
        float f3 = Module.mc.player.getHealth() + Module.mc.player.getAbsorptionAmount();
        return f + f2 >= f3;
    }

    private void v() {
        if (!this.lowHealth.getValue()) {
            return;
        }
        float f = Module.mc.player.getHealth() + Module.mc.player.getAbsorptionAmount();
        if (f <= this.health.getValue()) {
            this.a(TotemThreat.LOW_HEALTH);
        }
    }

    private void a(TotemThreat totemThreat) {
        if (totemThreat != TotemThreat.POP) {
            long l = System.currentTimeMillis();
            if (l - this.B < (long)this.cooldown.getValue()) {
                return;
            }
            if (this.C == totemThreat) {
                return;
            }
            this.B = l;
        }
        this.C = totemThreat;
        ItemUtils.h(Items.TOTEM_OF_UNDYING);
    }

    private static boolean lambda$handleCrystalThreat$1(Entity mc2) {
        return mc2 instanceof EndCrystalEntity;
    }

    private static boolean lambda$handleProjectileThreats$0(Entity mc2) {
        return mc2 instanceof ProjectileEntity;
    }
}

