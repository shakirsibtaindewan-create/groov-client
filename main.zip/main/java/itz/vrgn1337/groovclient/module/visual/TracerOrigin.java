/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

public enum TracerOrigin {
    Top, Middle, Bottom, Crosshair;

    private TracerOrigin() {

    }

}

