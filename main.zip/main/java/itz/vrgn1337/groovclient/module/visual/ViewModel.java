/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.bridge.ViewModelBridge;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.visual.ViewModelPreset;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;

public class ViewModel
extends Module {
    private static final float[][] n = new float[][]{{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f}, {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f}, {0.08f, -0.08f, 0.0f, -10.0f, 4.0f, 4.0f, 0.88f, -0.05f, -0.05f, 0.0f, -6.0f, -2.0f, -3.0f, 0.92f}, {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f}};
    private final ModeSetting preset = new ModeSetting(new StringConstant("Preset"), new StringConstant("Select a preset or use custom sliders"), ViewModelPreset.CUSTOM);
    private final BooleanSetting oldBlockSwing = new BooleanSetting(new StringConstant("Old Block Swing"), new StringConstant("Replace hit swing to block break swing"), false);
    private final FloatSetting mainX = new FloatSetting(new StringConstant("MainX"), new StringConstant("Main hand X offset"), -1.0f, 1.0f, 0.0f, 0.01f);
    private final FloatSetting mainY = new FloatSetting(new StringConstant("MainY"), new StringConstant("Main hand Y offset"), -1.0f, 1.0f, 0.0f, 0.01f);
    private final FloatSetting mainZ = new FloatSetting(new StringConstant("MainZ"), new StringConstant("Main hand Z offset"), -1.0f, 1.0f, 0.0f, 0.01f);
    private final FloatSetting mainRotX = new FloatSetting(new StringConstant("MainRotX"), new StringConstant("Main hand X rotation"), -45.0f, 45.0f, 0.0f, 0.5f);
    private final FloatSetting mainRotY = new FloatSetting(new StringConstant("MainRotY"), new StringConstant("Main hand Y rotation"), -45.0f, 45.0f, 0.0f, 0.5f);
    private final FloatSetting mainRotZ = new FloatSetting(new StringConstant("MainRotZ"), new StringConstant("Main hand Z rotation"), -45.0f, 45.0f, 0.0f, 0.5f);
    private final FloatSetting mainScale = new FloatSetting(new StringConstant("MainScale"), new StringConstant("Main hand scale"), 0.1f, 2.0f, 1.0f, 0.01f);
    private final FloatSetting offX = new FloatSetting(new StringConstant("OffX"), new StringConstant("Off hand X offset"), -1.0f, 1.0f, 0.0f, 0.01f);
    private final FloatSetting offY = new FloatSetting(new StringConstant("OffY"), new StringConstant("Off hand Y offset"), -1.0f, 1.0f, 0.0f, 0.01f);
    private final FloatSetting offZ = new FloatSetting(new StringConstant("OffZ"), new StringConstant("Off hand Z offset"), -1.0f, 1.0f, 0.0f, 0.01f);
    private final FloatSetting offRotX = new FloatSetting(new StringConstant("OffRotX"), new StringConstant("Off hand X rotation"), -45.0f, 45.0f, 0.0f, 0.5f);
    private final FloatSetting offRotY = new FloatSetting(new StringConstant("OffRotY"), new StringConstant("Off hand Y rotation"), -45.0f, 45.0f, 0.0f, 0.5f);
    private final FloatSetting offRotZ = new FloatSetting(new StringConstant("OffRotZ"), new StringConstant("Off hand Z rotation"), -45.0f, 45.0f, 0.0f, 0.5f);
    private final FloatSetting offScale = new FloatSetting(new StringConstant("OffScale"), new StringConstant("Off hand scale"), 0.1f, 2.0f, 1.0f, 0.01f);

    public ViewModel() {
        super(ModuleCategory.VISUAL, new StringConstant[]{new StringConstant("ViewModel"), new StringConstant("Customises first-person hand position, rotation, and scale")});
        this.registerSettings(new Setting[]{this.preset, this.oldBlockSwing, this.mainX, this.mainY, this.mainZ, this.mainRotX, this.mainRotY, this.mainRotZ, this.mainScale, this.offX, this.offY, this.offZ, this.offRotX, this.offRotY, this.offRotZ, this.offScale});
    }

    @Override
    protected void onEnable() {
        this.mainZ.getValue();
    }

    @Override
    protected void onDisable() {
        ViewModelBridge.enabled = false;
        ViewModelBridge.oldBlockSwing = false;
        ViewModelBridge.swordBlock = false;
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        this.mainZ.getValue();
    }

    private void s() {
        ViewModelBridge.enabled = true;
        ViewModelPreset viewModelPreset = (ViewModelPreset)this.preset.getValue();
        ViewModelBridge.oldBlockSwing = this.oldBlockSwing.getValue();
        boolean bl = ViewModelBridge.swordBlock = viewModelPreset == ViewModelPreset.BlockHit;
        if (viewModelPreset == ViewModelPreset.CUSTOM) {
            ViewModelBridge.mainX = this.mainX.getValue();
            ViewModelBridge.mainY = this.mainY.getValue();
            ViewModelBridge.mainZ = this.mainZ.getValue();
            ViewModelBridge.mainRotX = this.mainRotX.getValue();
            ViewModelBridge.mainRotY = this.mainRotY.getValue();
            ViewModelBridge.mainRotZ = this.mainRotZ.getValue();
            ViewModelBridge.mainScale = this.mainScale.getValue();
            ViewModelBridge.offX = this.offX.getValue();
            ViewModelBridge.offY = this.offY.getValue();
            ViewModelBridge.offZ = this.offZ.getValue();
            ViewModelBridge.offRotX = this.offRotX.getValue();
            ViewModelBridge.offRotY = this.offRotY.getValue();
            ViewModelBridge.offRotZ = this.offRotZ.getValue();
            ViewModelBridge.offScale = this.offScale.getValue();
        } else {
            float[] fArray = n[viewModelPreset.ordinal()];
            ViewModelBridge.mainX = fArray[0];
            ViewModelBridge.mainY = fArray[1];
            ViewModelBridge.mainZ = fArray[2];
            ViewModelBridge.mainRotX = fArray[3];
            ViewModelBridge.mainRotY = fArray[4];
            ViewModelBridge.mainRotZ = fArray[5];
            ViewModelBridge.mainScale = fArray[6];
            ViewModelBridge.offX = fArray[7];
            ViewModelBridge.offY = fArray[8];
            ViewModelBridge.offZ = fArray[9];
            ViewModelBridge.offRotX = fArray[10];
            ViewModelBridge.offRotY = fArray[11];
            ViewModelBridge.offRotZ = fArray[12];
            ViewModelBridge.offScale = fArray[13];
        }
    }
}

