/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

public enum EntityShaderMode {
    SOLID, CHROMA, GLASS, STARFIELD, LENS, AURA;

    private EntityShaderMode() {

    }

}

