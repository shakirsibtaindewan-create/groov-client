/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

public enum GlassPreset {
    CUSTOM, LIGHT, DARK, VIBRANT;

    private GlassPreset() {

    }

}

