/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

import itz.vrgn1337.groovclient.api.event.hooks.RenderSkyEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.visual.PatternStyle;
import itz.vrgn1337.groovclient.module.visual.SkyPattern;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.awt.Color;

public class FogEditor
extends Module {
    private final ModeSetting skyMode = new ModeSetting(new StringConstant("Sky Mode"), new StringConstant("Sky shader type"), SkyPattern.Galaxy);
    private final ColorSetting color1 = new ColorSetting(new StringConstant("Color1"), new StringConstant("Primary color"), new Color(8, 4, 28, 255));
    private final ColorSetting color2 = new ColorSetting(new StringConstant("Color2"), new StringConstant("Secondary color"), new Color(120, 40, 160, 255));
    private final ColorSetting color3 = new ColorSetting(new StringConstant("Color3"), new StringConstant("Accent color"), new Color(30, 80, 180, 255));
    private final ColorSetting color4 = new ColorSetting(new StringConstant("Color4"), new StringConstant("Highlight color"), new Color(255, 240, 200, 255));
    private final FloatSetting opacity = new FloatSetting(new StringConstant("Opacity"), new StringConstant("Sky shader opacity"), 0.0f, 1.0f, 0.9f, 0.01f);
    private final FloatSetting speed = new FloatSetting(new StringConstant("Speed"), new StringConstant("Animation speed"), 0.0f, 5.0f, 0.3f, 0.1f);
    private final FloatSetting scale = new FloatSetting(new StringConstant("Scale"), new StringConstant("Noise scale"), 0.5f, 10.0f, 3.0f, 0.1f);
    private final FloatSetting warp = new FloatSetting(new StringConstant("Warp"), new StringConstant("Warp distortion strength"), 0.0f, 10.0f, 4.0f, 0.1f);
    private final FloatSetting camoShimmer = new FloatSetting(new StringConstant("Camo Shimmer"), new StringConstant("Camo shimmer intensity"), 0.0f, 1.0f, 0.12f, 0.01f);
    private final FloatSetting octaves = new FloatSetting(new StringConstant("Octaves"), new StringConstant("Noise detail level"), 1.0f, 8.0f, 5.0f, 1.0f);
    private final ModeSetting pattern = new ModeSetting(new StringConstant("Pattern"), new StringConstant("Camouflage pattern type"), PatternStyle.Organic);
    private final FloatSetting camoDensity = new FloatSetting(new StringConstant("Camo Density"), new StringConstant("Geometric pattern density"), 1.0f, 20.0f, 6.0f, 0.5f);
    private final FloatSetting softness = new FloatSetting(new StringConstant("Softness"), new StringConstant("Geometric edge softness"), 0.01f, 0.5f, 0.08f, 0.01f);
    private final FloatSetting jitter = new FloatSetting(new StringConstant("Jitter"), new StringConstant("Geometric position jitter"), 0.0f, 1.0f, 0.22f, 0.01f);
    private final FloatSetting starDensity = new FloatSetting(new StringConstant("Star Density"), new StringConstant("Star density"), 5.0f, 30.0f, 15.0f, 0.5f);
    private final FloatSetting nebulaScale = new FloatSetting(new StringConstant("Nebula Scale"), new StringConstant("Nebula size"), 0.5f, 3.0f, 1.5f, 0.1f);
    private final FloatSetting twirl = new FloatSetting(new StringConstant("Twirl"), new StringConstant("Galaxy swirl intensity"), 0.0f, 2.0f, 0.8f, 0.1f);
    private final FloatSetting galaxyShimmer = new FloatSetting(new StringConstant("Galaxy Shimmer"), new StringConstant("Star shimmer"), 0.0f, 1.0f, 0.7f, 0.01f);
    private final BooleanSetting noFog = new BooleanSetting(new StringConstant("NoFog"), new StringConstant("Disables vanilla fog rendering"), false);

    public FogEditor() {
        super(ModuleCategory.VISUAL, new StringConstant[]{new StringConstant("FogEditor"), new StringConstant("Modifies fog and applies sky shaders")});
        this.onRenderSky(new Setting[]{this.skyMode, this.color1, this.color2, this.color3, this.color4, this.opacity, this.speed, this.scale, this.warp, this.camoShimmer, this.octaves, this.pattern, this.camoDensity, this.softness, this.jitter, this.starDensity, this.nebulaScale, this.twirl, this.galaxyShimmer, this.noFog});
    }

    public boolean s() {
        return this.e() && this.noFog.getValue();
    }

    private void onRenderSky(RenderSkyEvent renderSkyEvent) {
        if (Module.mc.world == null) {
            return;
        }
        float f = this.opacity.getValue();
        if (f <= 0.001f) {
            return;
        }
        Color color = FogEditor.a(this.color1.d(), f);
        Color color2 = FogEditor.a(this.color2.d(), f);
        Color color3 = FogEditor.a(this.color3.d(), f);
        Color color4 = FogEditor.a(this.color4.d(), f);
        if (this.skyMode.getValue() == SkyPattern.Galaxy) {
            GuiRenderer.a(this.speed.getValue(), this.starDensity.getValue(), this.nebulaScale.getValue(), this.twirl.getValue(), this.galaxyShimmer.getValue(), color, color2, color3, color4);
        } else {
            int n = this.pattern.getValue() == PatternStyle.Geometric ? 1 : 0;
            GuiRenderer.a(this.speed.getValue(), this.scale.getValue(), this.warp.getValue(), this.camoShimmer.getValue(), this.octaves.getPercent(), n, this.camoDensity.getValue(), this.softness.getValue(), this.jitter.getValue(), color, color2, color3, color4);
        }
    }

    private static Color a(Color color, float f) {
        int n = Math.max(0, Math.min(255, (int)((float)color.getAlpha() * f)));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), n);
    }
}

