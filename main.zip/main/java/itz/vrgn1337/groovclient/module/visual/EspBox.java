/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

import java.awt.Color;

final class EspBox {
    final float a;
    final float b;
    final float c;
    final float d;
    final float e;
    final float f;
    final Color g;

    EspBox(float f, float f2, float f3, float f4, float f5, float f6, Color color) {
        this.a = f;
        this.b = f2;
        this.c = f3;
        this.d = f4;
        this.e = f5;
        this.f = f6;
        this.g = color;
    }

    float a() {
        return (this.a + this.d) * 0.5f;
    }

    float b() {
        return (this.b + this.e) * 0.5f;
    }

    float c() {
        return (this.c + this.f) * 0.5f;
    }
}

