/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

import itz.vrgn1337.groovclient.api.util.bridge.GameRendererMixinBridge;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.visual.TracerOrigin;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.awt.Color;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix3x2fStack;
import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;

public class Tracers
extends Module {
    private final ModeSetting origin = new ModeSetting(new StringConstant("Origin"), new StringConstant("Where tracer lines start from on screen"), TracerOrigin.Bottom);
    private final FloatSetting range = new FloatSetting(new StringConstant("Range"), new StringConstant("Max distance to draw tracers"), 16.0f, 256.0f, 96.0f, 1.0f);
    private final FloatSetting thickness = new FloatSetting(new StringConstant("Thickness"), new StringConstant("Tracer line thickness"), 0.3f, 3.0f, 0.8f, 0.1f);
    private final FloatSetting glowSize = new FloatSetting(new StringConstant("Glow Size"), new StringConstant("Soft halo radius around the line"), 0.0f, 6.0f, 2.5f, 0.1f);
    private final BooleanSetting self = new BooleanSetting(new StringConstant("Self"), new StringConstant("Draws tracer to self in third person"), false);
    private final BooleanSetting healthTint = new BooleanSetting(new StringConstant("Health Tint"), new StringConstant("Tints line by target HP (green to red)"), false);
    private final BooleanSetting distanceFade = new BooleanSetting(new StringConstant("Distance Fade"), new StringConstant("Fades line alpha with distance"), true);
    private final BooleanSetting glow = new BooleanSetting(new StringConstant("Glow"), new StringConstant("Soft additive halo around the line"), true);
    private final BooleanSetting gradient = new BooleanSetting(new StringConstant("Gradient"), new StringConstant("Fades line from origin to target"), true);
    private final ColorSetting enemyColor = new ColorSetting(new StringConstant("Enemy Color"), new StringConstant("Tracer color for other players"), new Color(255, 95, 95, 220));
    private final ColorSetting selfColor = new ColorSetting(new StringConstant("Self Color"), new StringConstant("Tracer color for self"), new Color(100, 170, 255, 220));
    private static final Color y = new Color(95, 230, 120, 220);
    private static final Color z = new Color(240, 210, 90, 220);
    private static final Color A = new Color(240, 95, 95, 220);
    private static final float B = 4.0f;

    public Tracers() {
        super(ModuleCategory.VISUAL, new StringConstant[]{new StringConstant("Tracers"), new StringConstant("Draws lines from the screen to nearby players")});
        this.registerSettings(new Setting[]{this.origin, this.range, this.thickness, this.glowSize, this.self, this.healthTint, this.distanceFade, this.glow, this.gradient, this.enemyColor, this.selfColor});
    }

    private void onRenderHUDEventPost(RenderHUDEvent.Post renderHUDEvent$Post) {
        if (Module.mc.world == null || Module.mc.player == null) {
            return;
        }
        if (!GameRendererMixinBridge.isReady()) {
            return;
        }
        float f = renderHUDEvent$Post.tickCounter.getTickProgress(true);
        DrawContext mc15 = renderHUDEvent$Post.context;
        float f2 = Module.mc.getWindow().getScaledWidth();
        float f3 = Module.mc.getWindow().getScaledHeight();
        TracerOrigin tracerOrigin = (TracerOrigin)this.origin.getValue();
        float f4 = f2 * 0.5f;
        float f5 = switch (tracerOrigin.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> 0.0f;
            case 1 -> f3 * 0.5f;
            case 2 -> f3;
            case 3 -> f3 * 0.5f;
        };
        float f6 = this.thickness.getValue();
        float f7 = this.glowSize.getValue();
        float f8 = this.range.getValue();
        float f9 = f8 * f8;
        boolean bl = this.distanceFade.getValue();
        boolean bl2 = this.healthTint.getValue();
        boolean bl3 = this.glow.getValue() && f7 > 0.01f;
        boolean bl4 = this.gradient.getValue();
        double d2 = Module.mc.player.getX();
        double d3 = Module.mc.player.getY();
        double d4 = Module.mc.player.getZ();
        for (PlayerEntity mc6 : Module.mc.world.getPlayers()) {
            Vec3d VanillaChestLootTableGenerator;
            float[] fArray;
            double d5;
            double d6;
            double d7;
            double d8;
            if (!this.c(mc6) || (d8 = (d7 = mc6.getX() - d2) * d7 + (d6 = mc6.getY() - d3) * d6 + (d5 = mc6.getZ() - d4) * d5) > (double)f9 || (fArray = GameRendererMixinBridge.worldToScreen(VanillaChestLootTableGenerator = new Vec3d(MathHelper.lerp((double)f, (double)mc6.lastRenderX, (double)mc6.getX()), MathHelper.lerp((double)f, (double)mc6.lastRenderY, (double)mc6.getY()) + (double)mc6.getHeight() * 0.5, MathHelper.lerp((double)f, (double)mc6.lastRenderZ, (double)mc6.getZ()))))[2] <= 0.0f) continue;
            Color color = this.b(mc6);
            if (bl2 && mc6 != Module.mc.player) {
                color = Tracers.a(color, Tracers.c(mc6));
            }
            int n = color.getAlpha();
            if (bl) {
                float f10 = 1.0f - MathHelper.clamp((float)((float)Math.sqrt(d8) / f8), (float)0.0f, (float)1.0f);
                n = Math.round((float)n * MathHelper.clamp((float)(0.25f + 0.75f * f10), (float)0.05f, (float)1.0f));
            }
            Color color2 = Tracers.a(color, n);
            Tracers.a(mc15, f4, f5, fArray[0], fArray[1], f6, f7, color2, bl3, bl4);
        }
    }

    private boolean a(PlayerEntity mc6) {
        if (mc6 == null || !mc6.isAlive() || mc6.isSpectator() || mc6.isInvisible()) {
            return false;
        }
        if (mc6 == Module.mc.player) {
            if (!this.self.getValue()) {
                return false;
            }
            return Module.mc.gameRenderer.getCamera().isThirdPerson();
        }
        return true;
    }

    private Color b(PlayerEntity mc6) {
        return mc6 == Module.mc.player ? this.selfColor.d() : this.enemyColor.d();
    }

    private static Color c(PlayerEntity mc6) {
        float f = MathHelper.clamp((float)(mc6.getHealth() / Math.max(1.0f, mc6.getMaxHealth())), (float)0.0f, (float)1.0f);
        return f > 0.66f ? y : (f > 0.33f ? z : A);
    }

    private static Color a(Color color, Color color2) {
        return new Color((color.getRed() + color2.getRed()) / 2, (color.getGreen() + color2.getGreen()) / 2, (color.getBlue() + color2.getBlue()) / 2, Math.max(color.getAlpha(), color2.getAlpha()));
    }

    private static Color a(Color color, int n) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.max(0, Math.min(255, n)));
    }

    private static void a(DrawContext mc15, float f, float f2, float f3, float f4, float f5, float f6, Color color, boolean bl, boolean bl2) {
        int n;
        float f7 = f3 - f;
        float f8 = f4 - f2;
        float f9 = (float)Math.sqrt(f7 * f7 + f8 * f8);
        if (f9 < 0.5f) {
            return;
        }
        float f10 = (float)Math.atan2(f8, f7);
        int n2 = Math.max(1, Math.round(f9 * 4.0f));
        float f11 = Math.max(0.4f, f5 * 0.5f) * 4.0f;
        int n3 = Math.round(-f11);
        if (n3 == (n = Math.round(f11))) {
            n = n3 + 1;
        }
        int n4 = bl2 ? MathHelper.clamp((int)Math.round(f9 / 6.0f), (int)8, (int)64) : 1;
        int n5 = color.getRed();
        int n6 = color.getGreen();
        int n7 = color.getBlue();
        int n8 = color.getAlpha();
        Matrix3x2fStack matrix3x2fStack = mc15.getMatrices();
        matrix3x2fStack.pushMatrix();
        matrix3x2fStack.translate(f, f2);
        matrix3x2fStack.rotate(f10);
        matrix3x2fStack.scale(0.25f, 0.25f);
        if (bl) {
            int n9 = 3;
            for (int i = 0; i < n9; ++i) {
                float f12 = ((float)i + 1.0f) / (float)n9;
                float f13 = f11 + f6 * 4.0f * f12;
                int n10 = Math.round(-f13);
                int n11 = Math.round(f13);
                float f14 = (1.0f - f12) * 0.35f + 0.05f;
                Tracers.a(mc15, n2, n10, n11, n4, n5, n6, n7, n8, f14, bl2);
            }
        }
        Tracers.a(mc15, n2, n3, n, n4, n5, n6, n7, n8, 1.0f, bl2);
        matrix3x2fStack.popMatrix();
    }

    private static void a(DrawContext mc15, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, float f, boolean bl) {
        if (n4 <= 1) {
            int n9 = Math.round((float)n8 * f);
            if (n9 <= 0) {
                return;
            }
            mc15.fill(0, n2, n, n3, Tracers.c(n9) << 24 | n5 << 16 | n6 << 8 | n7);
            return;
        }
        float f2 = (float)n / (float)n4;
        for (int i = 0; i < n4; ++i) {
            int n10 = Math.round((float)i * f2);
            int n11 = i == n4 - 1 ? n : Math.round((float)(i + 1) * f2);
            float f3 = ((float)i + 0.5f) / (float)n4;
            float f4 = bl ? MathHelper.clamp((float)(0.05f + 0.95f * f3), (float)0.0f, (float)1.0f) : 1.0f;
            int n12 = Math.round((float)n8 * f * f4);
            if (n12 <= 0) continue;
            int n13 = Tracers.c(n12) << 24 | n5 << 16 | n6 << 8 | n7;
            mc15.fill(n10, n2, n11, n3, n13);
        }
    }

    private static int c(int n) {
        return n < 0 ? 0 : (n > 255 ? 255 : n);
    }
}

