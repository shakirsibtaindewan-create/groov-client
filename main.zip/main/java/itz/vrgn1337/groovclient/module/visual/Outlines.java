/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

import itz.vrgn1337.groovclient.api.util.bridge.EntityShaderBridge;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.visual.BlendMode;
import itz.vrgn1337.groovclient.module.visual.EntityShaderMode;
import itz.vrgn1337.groovclient.module.visual.EntityTargetFilter;
import itz.vrgn1337.groovclient.module.visual.GlassPreset;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.awt.Color;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import itz.vrgn1337.groovclient.api.util.bridge.EntityShaderBridge;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;

public class Outlines
extends Module {
    private final ModeSetting mode = new ModeSetting(new StringConstant("Mode"), new StringConstant("Color mode"), EntityShaderMode.SOLID);
    private final ModeSetting target = new ModeSetting(new StringConstant("Target"), new StringConstant("Which entities to shade"), EntityTargetFilter.PLAYERS);
    private final ModeSetting blendMode = new ModeSetting(new StringConstant("Blend Mode"), new StringConstant("How the outline composites onto the world"), EntityShaderBridge.BlendMode.ALPHA);
    private final BooleanSetting self = new BooleanSetting(new StringConstant("Self"), new StringConstant("Apply to your own player"), false);
    private final ColorSetting outlineColor = new ColorSetting(new StringConstant("Outline Color"), new StringConstant("Outline color"), new Color(255, 255, 255, 255));
    private final FloatSetting outlineWidth = new FloatSetting(new StringConstant("Outline Width"), new StringConstant("Outline thickness"), 0.5f, 10.0f, 7.0f, 0.5f);
    private final BooleanSetting gradient = new BooleanSetting(new StringConstant("Gradient"), new StringConstant("4-color gradient for outline"), false);
    private final ColorSetting gradientColor2 = new ColorSetting(new StringConstant("Gradient Color2"), new StringConstant("Top-right color"), new Color(255, 0, 0, 255));
    private final ColorSetting gradientColor3 = new ColorSetting(new StringConstant("Gradient Color3"), new StringConstant("Bottom-left color"), new Color(0, 255, 0, 255));
    private final ColorSetting gradientColor4 = new ColorSetting(new StringConstant("Gradient Color4"), new StringConstant("Bottom-right color"), new Color(0, 0, 255, 255));
    private final BooleanSetting fill = new BooleanSetting(new StringConstant("Fill"), new StringConstant("Fill inside outline"), true);
    private final ColorSetting fillColor = new ColorSetting(new StringConstant("Fill Color"), new StringConstant("Fill color"), new Color(255, 255, 255, 128));
    private final FloatSetting fillAlpha = new FloatSetting(new StringConstant("Fill Alpha"), new StringConstant("Fill opacity"), 0.0f, 1.0f, 0.3f, 0.05f);
    private final FloatSetting chromaSpeed = new FloatSetting(new StringConstant("Chroma Speed"), new StringConstant("Rainbow cycle speed"), 0.1f, 5.0f, 1.0f, 0.1f);
    private final FloatSetting chromaScale = new FloatSetting(new StringConstant("Chroma Scale"), new StringConstant("Rainbow spread"), 0.1f, 3.0f, 0.5f, 0.05f);
    private final ModeSetting glassPreset = new ModeSetting(new StringConstant("Glass Preset"), new StringConstant("Quick Liquid-Glass look presets"), GlassPreset.CUSTOM);
    private final FloatSetting glassBlur = new FloatSetting(new StringConstant("Glass Blur"), new StringConstant("Frosted blur radius"), 0.0f, 40.0f, 14.0f, 0.5f);
    private final FloatSetting glassRefraction = new FloatSetting(new StringConstant("Glass Refraction"), new StringConstant("Edge refraction strength"), 0.0f, 40.0f, 18.0f, 0.5f);
    private final FloatSetting glassChroma = new FloatSetting(new StringConstant("Glass Chroma"), new StringConstant("Chromatic aberration at edges"), 0.0f, 20.0f, 8.0f, 0.5f);
    private final FloatSetting glassSaturation = new FloatSetting(new StringConstant("Glass Saturation"), new StringConstant("Background saturation boost"), 0.5f, 2.5f, 1.55f, 0.05f);
    private final FloatSetting glassBrightness = new FloatSetting(new StringConstant("Glass Brightness"), new StringConstant("Background brightness"), 0.5f, 1.5f, 1.08f, 0.02f);
    private final FloatSetting glassRimThickness = new FloatSetting(new StringConstant("Glass RimThickness"), new StringConstant("Inner rim thickness"), 0.0f, 8.0f, 1.6f, 0.1f);
    private final FloatSetting glassSpecular = new FloatSetting(new StringConstant("Glass Specular"), new StringConstant("Edge specular bloom"), 0.0f, 1.0f, 0.22f, 0.02f);
    private final FloatSetting glassSheen = new FloatSetting(new StringConstant("Glass Sheen"), new StringConstant("Top-facing sheen"), 0.0f, 0.5f, 0.08f, 0.01f);
    private final FloatSetting glassShadow = new FloatSetting(new StringConstant("Glass Shadow"), new StringConstant("Bottom-facing shadow"), 0.0f, 1.0f, 0.3f, 0.02f);
    private final FloatSetting glassFrost = new FloatSetting(new StringConstant("Glass Frost"), new StringConstant("Micro-speckle frost jitter"), 0.0f, 2.0f, 0.35f, 0.05f);
    private final FloatSetting starCellSize = new FloatSetting(new StringConstant("Star Cell Size"), new StringConstant("Spacing between stars (px)"), 12.0f, 160.0f, 54.0f, 1.0f);
    private final FloatSetting starSize = new FloatSetting(new StringConstant("Star Size"), new StringConstant("Star/moon radius (px)"), 1.0f, 48.0f, 16.0f, 0.5f);
    private final FloatSetting starSpeed = new FloatSetting(new StringConstant("Star Speed"), new StringConstant("Drift speed"), 0.0f, 3.0f, 0.6f, 0.05f);
    private final ColorSetting starColor = new ColorSetting(new StringConstant("Star Color"), new StringConstant("Star/moon color"), new Color(255, 240, 200, 230));
    private final FloatSetting moonRatio = new FloatSetting(new StringConstant("Moon Ratio"), new StringConstant("0=all stars, 1=all crescents"), 0.0f, 1.0f, 0.35f, 0.05f);
    private final FloatSetting starGlow = new FloatSetting(new StringConstant("Star Glow"), new StringConstant("Glow falloff around stars"), 0.0f, 40.0f, 14.0f, 0.5f);
    private final FloatSetting lensStrength = new FloatSetting(new StringConstant("Lens Strength"), new StringConstant("Rim refraction (px)"), 0.0f, 120.0f, 40.0f, 0.5f);
    private final FloatSetting lensMagnify = new FloatSetting(new StringConstant("Lens Magnify"), new StringConstant("Radial zoom (<0 concave, >0 convex)"), -2.5f, 6.0f, 2.2f, 0.05f);
    private final FloatSetting lensChroma = new FloatSetting(new StringConstant("Lens Chroma"), new StringConstant("Chromatic aberration at rim"), 0.0f, 30.0f, 8.0f, 0.5f);
    private final FloatSetting lensSpecular = new FloatSetting(new StringConstant("Lens Specular"), new StringConstant("Top-left highlight"), 0.0f, 1.0f, 0.35f, 0.02f);
    private final FloatSetting lensRim = new FloatSetting(new StringConstant("Lens Rim"), new StringConstant("Inner rim highlight thickness"), 0.0f, 6.0f, 1.2f, 0.1f);
    private final FloatSetting auraRadius = new FloatSetting(new StringConstant("Aura Radius"), new StringConstant("Flame extent outside silhouette (px)"), 2.0f, 96.0f, 66.0f, 0.5f);
    private final FloatSetting auraSpeed = new FloatSetting(new StringConstant("Aura Speed"), new StringConstant("Upward flow speed"), 0.0f, 4.0f, 1.2f, 0.05f);
    private final FloatSetting auraTurbulence = new FloatSetting(new StringConstant("Aura Turbulence"), new StringConstant("Noise frequency"), 0.3f, 4.0f, 1.5f, 0.05f);
    private final FloatSetting auraIntensity = new FloatSetting(new StringConstant("Aura Intensity"), new StringConstant("Overall alpha multiplier"), 0.0f, 2.0f, 1.1f, 0.05f);
    private final ColorSetting auraInner = new ColorSetting(new StringConstant("Aura Inner"), new StringConstant("Hot inner color"), new Color(255, 210, 90, 255));
    private final ColorSetting auraOuter = new ColorSetting(new StringConstant("Aura Outer"), new StringConstant("Cool outer tip color"), new Color(255, 70, 20, 0));
    private final FloatSetting outerGlow = new FloatSetting(new StringConstant("Outer Glow"), new StringConstant("Outer glow width"), 0.0f, 30.0f, 0.0f, 0.5f);
    private final FloatSetting innerGlow = new FloatSetting(new StringConstant("Inner Glow"), new StringConstant("Inner glow width"), 0.0f, 30.0f, 0.0f, 0.5f);
    private final BooleanSetting glowSparkle = new BooleanSetting(new StringConstant("Glow Sparkle"), new StringConstant("Animated sparkle on glow"), false);
    private final BooleanSetting itemEntities = new BooleanSetting(new StringConstant("Item Entities"), new StringConstant("Apply to dropped items"), false);
    private final BooleanSetting heldItems = new BooleanSetting(new StringConstant("Held Items"), new StringConstant("Apply to first-person held items"), false);
    private final BooleanSetting nonLiving = new BooleanSetting(new StringConstant("Non Living"), new StringConstant("Apply to non-living entities"), false);

    public Outlines() {
        super(ModuleCategory.VISUAL, new StringConstant[]{new StringConstant("Outlines"), new StringConstant("Draws outlines")});
        this.onRenderWorldEventPost(new Setting[]{this.mode, this.target, this.blendMode, this.self, this.outlineColor, this.outlineWidth, this.gradient, this.gradientColor2, this.gradientColor3, this.gradientColor4, this.fill, this.fillColor, this.fillAlpha, this.chromaSpeed, this.chromaScale, this.glassPreset, this.glassBlur, this.glassRefraction, this.glassChroma, this.glassSaturation, this.glassBrightness, this.glassRimThickness, this.glassSpecular, this.glassSheen, this.glassShadow, this.glassFrost, this.starCellSize, this.starSize, this.starSpeed, this.starColor, this.moonRatio, this.starGlow, this.lensStrength, this.lensMagnify, this.lensChroma, this.lensSpecular, this.lensRim, this.auraRadius, this.auraSpeed, this.auraTurbulence, this.auraIntensity, this.auraInner, this.auraOuter, this.outerGlow, this.innerGlow, this.glowSparkle, this.itemEntities, this.heldItems, this.nonLiving});
    }

    @Override
    protected void onEnable() {
        EntityShaderBridge.setFilter(arg_0 -> ((Outlines)this).a(arg_0));
        this.outlineWidth.getValue();
    }

    @Override
    protected void onDisable() {
        EntityShaderBridge.setFilter(null);
        EntityShaderBridge.clearPending();
    }

    private boolean a(LivingEntityRenderState mc10) {
        if (Module.mc.world == null || Module.mc.player == null) {
            return false;
        }
        boolean bl = mc10 instanceof PlayerEntityRenderState;
        if (bl && !this.self.getValue() && mc10.squaredDistanceToCamera < 0.5) {
            return false;
        }
        EntityTargetFilter entityTargetFilter = (EntityTargetFilter)this.target.getValue();
        if (entityTargetFilter == EntityTargetFilter.PLAYERS && !bl) {
            return false;
        }
        return entityTargetFilter != EntityTargetFilter.MOBS || !bl;
    }

    private void s() {
        EntityShaderBridge.ShaderMode entityShaderBridge$ShaderMode = switch (((EntityShaderMode)this.mode.getValue()).ordinal()) {
            case 1 -> EntityShaderBridge.ShaderMode.CHROMA;
            case 2 -> EntityShaderBridge.ShaderMode.LIQUID_GLASS;
            case 3 -> EntityShaderBridge.ShaderMode.STARFIELD;
            case 4 -> EntityShaderBridge.ShaderMode.LENS;
            case 5 -> EntityShaderBridge.ShaderMode.AURA;
            default -> EntityShaderBridge.ShaderMode.SOLID;
        };
        EntityShaderBridge.setMode(entityShaderBridge$ShaderMode);
        EntityShaderBridge.setOutlineColor(this.outlineColor.d());
        EntityShaderBridge.setOutlineWidth(this.outlineWidth.getValue());
        EntityShaderBridge.setBlendMode(this.blendMode.getValue() == EntityShaderBridge.BlendMode.ADDITIVE ? EntityShaderBridge.BlendMode.ADDITIVE : EntityShaderBridge.BlendMode.ALPHA);
        EntityShaderBridge.setGradient(this.gradient.getValue(), this.gradientColor2.d(), this.gradientColor3.d(), this.gradientColor4.d());
        EntityShaderBridge.setFill(this.fill.getValue(), this.fillColor.d(), this.fillAlpha.getValue());
        EntityShaderBridge.setChromaParams(this.chromaSpeed.getValue(), this.chromaScale.getValue());
        EntityShaderBridge.setGlow(this.outerGlow.getValue(), this.innerGlow.getValue(), this.glowSparkle.getValue());
        EntityShaderBridge.setShadeItemEntities(this.itemEntities.getValue());
        EntityShaderBridge.setShadeHeldItems(this.heldItems.getValue());
        EntityShaderBridge.setShadeNonLiving(this.nonLiving.getValue());
        this.gradient.getValue();
        EntityShaderBridge.setStarfieldParams(this.starCellSize.getValue(), this.starSize.getValue(), this.starSpeed.getValue(), this.starColor.d(), this.moonRatio.getValue(), this.starGlow.getValue());
        EntityShaderBridge.setLensParams(this.lensStrength.getValue(), this.lensMagnify.getValue(), this.lensChroma.getValue(), this.lensSpecular.getValue(), this.lensRim.getValue());
        EntityShaderBridge.setAuraParams(this.auraRadius.getValue(), this.auraSpeed.getValue(), this.auraTurbulence.getValue(), this.auraIntensity.getValue(), this.auraInner.d(), this.auraOuter.d());
    }

    private void t() {
        float f = this.glassBlur.getValue();
        float f2 = this.glassRefraction.getValue();
        float f3 = this.glassChroma.getValue();
        float f4 = this.glassSaturation.getValue();
        float f5 = this.glassBrightness.getValue();
        float f6 = this.glassRimThickness.getValue();
        float f7 = this.glassSpecular.getValue();
        float f8 = this.glassSheen.getValue();
        float f9 = this.glassShadow.getValue();
        float f10 = this.glassFrost.getValue();
        switch (((GlassPreset)this.glassPreset.getValue()).ordinal()) {
            case 1: {
                f4 = 1.45f;
                f5 = 1.06f;
                f6 = 1.3f;
                f7 = 0.22f;
                f8 = 0.08f;
                f9 = 0.35f;
                f = 16.0f;
                f2 = 18.0f;
                f3 = 7.0f;
                f10 = 0.35f;
                break;
            }
            case 2: {
                f4 = 1.2f;
                f5 = 0.95f;
                f6 = 1.4f;
                f7 = 0.14f;
                f8 = 0.05f;
                f9 = 0.55f;
                f = 20.0f;
                f2 = 20.0f;
                f3 = 5.0f;
                f10 = 0.3f;
                break;
            }
            case 3: {
                f4 = 1.85f;
                f5 = 1.12f;
                f6 = 1.6f;
                f7 = 0.28f;
                f8 = 0.1f;
                f9 = 0.28f;
                f = 14.0f;
                f2 = 22.0f;
                f3 = 10.0f;
                f10 = 0.4f;
                break;
            }
        }
        EntityShaderBridge.setLiquidGlassParams(f, f2, f3, f10);
        EntityShaderBridge.setLiquidGlassLook(f4, f5, f6, f7, f8, f9);
    }

    private void onRenderWorldEventPost(RenderWorldEvent.Post renderWorldEvent$Post) {
        this.outlineWidth.getValue();
        EntityShaderBridge.drawAllPending();
    }
}

