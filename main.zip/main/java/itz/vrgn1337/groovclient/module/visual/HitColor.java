/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.mixin.accessor.OverlayTextureAccessor;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.awt.Color;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.util.math.ColorHelper;

public class HitColor
extends Module {
    private static final int n = -1291911168;
    private final ColorSetting color = new ColorSetting(new StringConstant("Color"), new StringConstant("Hit flash color"), new Color(255, 255, 255, 160));
    private int p = 0;
    private boolean q = false;

    public HitColor() {
        super(ModuleCategory.VISUAL, new StringConstant[]{new StringConstant("HitColor"), new StringConstant("Recolors entity damage flash")});
        this.registerSettings(new Setting[]{this.color});
    }

    @Override
    protected void onEnable() {
        this.c(HitColor.onUpdateEventPre(this.color.d()));
    }

    @Override
    protected void onDisable() {
        this.c(-1291911168);
        this.q = false;
    }

    private void onUpdateEventPre(UpdateEvent.Pre pre) {
        int n = HitColor.onUpdateEventPre(this.color.d());
        if (!this.q || n != this.p) {
            this.c(n);
        }
    }

    private void c(int n) {
        if (Module.mc == null || Module.mc.gameRenderer == null) {
            return;
        }
        OverlayTexture mc111 = Module.mc.gameRenderer.getOverlayTexture();
        if (mc111 == null) {
            return;
        }
        NativeImageBackedTexture BundleSelectedItemModel = ((OverlayTextureAccessor)mc111).getTexture();
        if (BundleSelectedItemModel == null) {
            return;
        }
        NativeImage LootTableData = BundleSelectedItemModel.getImage();
        if (LootTableData == null) {
            return;
        }
        for (int i = 0; i < 16; ++i) {
            for (int j = 0; j < 16; ++j) {
                if (i < 8) {
                    LootTableData.setColorArgb(j, i, n);
                    continue;
                }
                int n2 = (int)((1.0f - (float)j / 15.0f * 0.75f) * 255.0f);
                LootTableData.setColorArgb(j, i, ColorHelper.whiteWithAlpha((int)n2));
            }
        }
        BundleSelectedItemModel.upload();
        this.p = n;
        this.q = true;
    }

    public Color s() {
        return this.color.d();
    }

    private static int a(Color color) {
        return color.getAlpha() << 24 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
    }
}

