/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

public enum EspGeometry {
    Box2D, Box3D;

    private EspGeometry() {

    }

}

