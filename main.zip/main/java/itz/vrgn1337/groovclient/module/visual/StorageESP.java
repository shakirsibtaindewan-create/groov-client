/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

import itz.vrgn1337.groovclient.api.util.bridge.GameRendererMixinBridge;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.WorldLineRenderer;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.visual.EspBox;
import itz.vrgn1337.groovclient.module.visual.StorageEspMode;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.ChestMinecartEntity;
import net.minecraft.entity.vehicle.HopperMinecartEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnchantingTableBlockEntity;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.vehicle.ChestBoatEntity;
import org.joml.Matrix3x2fStack;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;

public class StorageESP
extends Module {
    private final ModeSetting mode = new ModeSetting(new StringConstant("Mode"), new StringConstant("ESP mode"), StorageEspMode.Glass);
    private final FloatSetting range = new FloatSetting(new StringConstant("Range"), new StringConstant("Max distance"), 8.0f, 128.0f, 48.0f, 1.0f);
    private final FloatSetting alpha = new FloatSetting(new StringConstant("Alpha"), new StringConstant("Box fill transparency"), 0.0f, 255.0f, 80.0f, 1.0f);
    private final BooleanSetting tracers = new BooleanSetting(new StringConstant("Tracers"), new StringConstant("Draw tracer lines to storages"), false);
    private final FloatSetting tracerAlpha = new FloatSetting(new StringConstant("Tracer Alpha"), new StringConstant("Tracer line transparency"), 0.0f, 255.0f, 180.0f, 1.0f);
    private final FloatSetting lineWidth = new FloatSetting(new StringConstant("Line Width"), new StringConstant("Outline and tracer thickness"), 0.5f, 5.0f, 1.0f, 0.5f);
    private final ColorSetting chest = new ColorSetting(new StringConstant("Chest"), new StringConstant(""), new Color(219, 145, 26, 200));
    private final ColorSetting enderChest = new ColorSetting(new StringConstant("Ender Chest"), new StringConstant(""), new Color(109, 12, 184, 200));
    private final ColorSetting barrel = new ColorSetting(new StringConstant("Barrel"), new StringConstant(""), new Color(117, 86, 42, 200));
    private final ColorSetting shulker = new ColorSetting(new StringConstant("Shulker"), new StringConstant(""), new Color(121, 69, 188, 255));
    private final ColorSetting hopper = new ColorSetting(new StringConstant("Hopper"), new StringConstant(""), new Color(198, 198, 198, 200));
    private final ColorSetting furnace = new ColorSetting(new StringConstant("Furnace"), new StringConstant(""), new Color(126, 126, 126, 200));
    private final ColorSetting dispenser = new ColorSetting(new StringConstant("Dispenser"), new StringConstant(""), new Color(57, 57, 57, 200));
    private final ColorSetting enchantTable = new ColorSetting(new StringConstant("Enchant Table"), new StringConstant(""), new Color(0, 220, 220, 200));
    private final ColorSetting spawner = new ColorSetting(new StringConstant("Spawner"), new StringConstant(""), new Color(0, 160, 0, 200));
    private final List<EspBox> C = new ArrayList();

    public StorageESP() {
        super(ModuleCategory.VISUAL, new StringConstant[]{new StringConstant("StorageESP"), new StringConstant("Renders boxes on nearby storage blocks and entities")});
        this.addSettings(List.of(this.mode, this.range, this.alpha, this.tracers, this.tracerAlpha, this.lineWidth, this.chest, this.enderChest, this.barrel, this.shulker, this.hopper, this.furnace, this.dispenser, this.enchantTable, this.spawner));
    }

    private void onRenderWorldEventPost(RenderWorldEvent.Post renderWorldEvent$Post) {
        this.C.clear();
        if (Module.mc.world == null || Module.mc.player == null) {
            return;
        }
        double d2 = this.range.getValue();
        double d3 = d2 * d2;
        int n = (int)this.alpha.getValue();
        double d4 = Module.mc.player.getX();
        double d5 = Module.mc.player.getY();
        double d6 = Module.mc.player.getZ();
        this.a(d4, d5, d6, d3, n);
        this.b(d4, d5, d6, d3, n);
        if (this.C.isEmpty()) {
            return;
        }
        Camera mc22 = Module.mc.gameRenderer.getCamera();
        Vec3d VanillaChestLootTableGenerator = mc22.getCameraPos();
        MatrixStack mc13 = new MatrixStack();
        mc13.multiply((Quaternionfc)mc22.getRotation().conjugate(new Quaternionf()));
        mc13.translate(-VanillaChestLootTableGenerator.x, -VanillaChestLootTableGenerator.y, -VanillaChestLootTableGenerator.z);
        StorageEspMode storageEspMode = (StorageEspMode)this.mode.getValue();
        float f = this.lineWidth.getValue();
        for (EspBox espBox : this.C) {
            WorldLineRenderer worldLineRenderer = new WorldLineRenderer(mc13).a(espBox.a, espBox.b, espBox.c, espBox.d, espBox.e, espBox.f).a(espBox.g).a(false);
            switch (storageEspMode.ordinal()) {
                case 0: {
                    worldLineRenderer.b(true);
                    break;
                }
                case 1: {
                    worldLineRenderer.b(false).a(f);
                    break;
                }
                case 2: {
                    worldLineRenderer.b();
                }
            }
            worldLineRenderer.c();
        }
    }

    private void onRenderHUDEventPost(RenderHUDEvent.Post renderHUDEvent$Post) {
        if (!this.tracers.getValue()) {
            return;
        }
        if (this.C.isEmpty()) {
            return;
        }
        if (!GameRendererMixinBridge.isReady()) {
            return;
        }
        int n = (int)this.tracerAlpha.getValue();
        float f = Math.max(1.0f, this.lineWidth.getValue());
        float f2 = (float)Module.mc.getWindow().getScaledWidth() / 2.0f;
        float f3 = (float)Module.mc.getWindow().getScaledHeight() / 2.0f;
        DrawContext mc15 = renderHUDEvent$Post.context;
        for (EspBox espBox : this.C) {
            float[] fArray = GameRendererMixinBridge.worldToScreen(new Vec3d((double)espBox.a(), (double)espBox.b(), (double)espBox.c()));
            Color color = StorageESP.a(espBox.g, n);
            StorageESP.a(mc15, f2, f3, fArray[0], fArray[1], f, color);
        }
    }

    private static void a(DrawContext mc15, float f, float f2, float f3, float f4, float f5, Color color) {
        float f6 = f3 - f;
        float f7 = f4 - f2;
        float f8 = (float)Math.sqrt(f6 * f6 + f7 * f7);
        if (f8 < 1.0E-4f) {
            return;
        }
        float f9 = (float)Math.atan2(f7, f6);
        float f10 = f5 * 0.5f;
        int n = color.getAlpha() << 24 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
        Matrix3x2fStack matrix3x2fStack = mc15.getMatrices();
        matrix3x2fStack.pushMatrix();
        matrix3x2fStack.translate(f, f2);
        matrix3x2fStack.rotate(f9);
        mc15.fill(0, Math.round(-f10), Math.round(f8), Math.round(f10), n);
        matrix3x2fStack.popMatrix();
    }

    private void a(double d2, double d3, double d4, double d5, int n) {
        if (Module.mc.world == null || Module.mc.player == null) {
            return;
        }
        int n2 = Math.min((Integer)Module.mc.options.getViewDistance().getValue(), 8);
        BlockPos mc0 = Module.mc.player.getBlockPos();
        int n3 = mc0.getX() >> 4;
        int n4 = mc0.getZ() >> 4;
        for (int i = n3 - n2; i <= n3 + n2; ++i) {
            for (int j = n4 - n2; j <= n4 + n2; ++j) {
                WorldChunk mc113;
                if (!Module.mc.world.isChunkLoaded(i, j)) continue;
                try {
                    mc113 = Module.mc.world.getChunk(i, j);
                }
                catch (Exception exception) {
                    continue;
                }
                for (BlockEntity mc114 : mc113.getBlockEntities().values()) {
                    double d6;
                    double d7;
                    BlockPos mc64;
                    double d8;
                    Color color = this.a(mc114);
                    if (color == null || (d8 = (double)(mc64 = mc114.getPos()).getX() + 0.5 - d2) * d8 + (d7 = (double)mc64.getY() + 0.5 - d3) * d7 + (d6 = (double)mc64.getZ() + 0.5 - d4) * d6 > d5) continue;
                    this.C.add(new EspBox(mc64.getX(), mc64.getY(), mc64.getZ(), (float)mc64.getX() + 1.0f, (float)mc64.getY() + 1.0f, (float)mc64.getZ() + 1.0f, StorageESP.a(color, n)));
                }
            }
        }
    }

    private void b(double d2, double d3, double d4, double d5, int n) {
        if (Module.mc.world == null) {
            return;
        }
        for (Entity mc2 : Module.mc.world.getEntities()) {
            double d6;
            double d7;
            double d8;
            Color color = this.a(mc2);
            if (color == null || (d8 = mc2.getX() - d2) * d8 + (d7 = mc2.getY() - d3) * d7 + (d6 = mc2.getZ() - d4) * d6 > d5) continue;
            float f = mc2.getWidth() / 2.0f;
            this.C.add(new EspBox((float)(mc2.getX() - (double)f), (float)mc2.getY(), (float)(mc2.getZ() - (double)f), (float)(mc2.getX() + (double)f), (float)(mc2.getY() + (double)mc2.getHeight()), (float)(mc2.getZ() + (double)f), StorageESP.a(color, n)));
        }
    }

    private Color a(BlockEntity mc114) {
        if (mc114 instanceof ChestBlockEntity || mc114 instanceof TrappedChestBlockEntity) {
            return this.chest.d();
        }
        if (mc114 instanceof EnderChestBlockEntity) {
            return this.enderChest.d();
        }
        if (mc114 instanceof BarrelBlockEntity) {
            return this.barrel.d();
        }
        if (mc114 instanceof ShulkerBoxBlockEntity) {
            return this.shulker.d();
        }
        if (mc114 instanceof HopperBlockEntity) {
            return this.hopper.d();
        }
        if (mc114 instanceof AbstractFurnaceBlockEntity) {
            return this.furnace.d();
        }
        if (mc114 instanceof DispenserBlockEntity) {
            return this.dispenser.d();
        }
        if (mc114 instanceof EnchantingTableBlockEntity) {
            return this.enchantTable.d();
        }
        if (mc114 instanceof MobSpawnerBlockEntity) {
            return this.spawner.d();
        }
        return null;
    }

    private Color a(Entity mc2) {
        if (mc2 instanceof ChestBoatEntity) {
            return this.chest.d();
        }
        if (mc2 instanceof ChestMinecartEntity) {
            return this.chest.d();
        }
        if (mc2 instanceof HopperMinecartEntity) {
            return this.hopper.d();
        }
        return null;
    }

    private static Color a(Color color, int n) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.max(0, Math.min(255, n)));
    }
}

