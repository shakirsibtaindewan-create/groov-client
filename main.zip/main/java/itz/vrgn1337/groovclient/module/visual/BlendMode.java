/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

public enum BlendMode {
    ALPHA, ADDITIVE;

    private BlendMode() {

    }

}

