/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

import itz.vrgn1337.groovclient.api.util.bridge.GameRendererMixinBridge;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.WorldLineRenderer;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.ModuleManager;
import itz.vrgn1337.groovclient.module.visual.EspGeometry;
import itz.vrgn1337.groovclient.module.visual.HitColor;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;

public class ESP
extends Module {
    private static final Color n = new Color(0, 0, 0, 145);
    private static final Color o = new Color(95, 255, 120, 240);
    private static final Color p = new Color(255, 220, 90, 240);
    private static final Color q = new Color(255, 95, 95, 240);
    private static final Color r = new Color(10, 10, 10, 170);
    private final ModeSetting mode = new ModeSetting(new StringConstant("Mode"), new StringConstant("ESP mode"), EspGeometry.Box2D);
    private final ColorSetting enemyColor = new ColorSetting(new StringConstant("Enemy Color"), new StringConstant("ESP box color for enemies"), new Color(255, 95, 95, 10));
    private final ColorSetting selfColor = new ColorSetting(new StringConstant("Self Color"), new StringConstant("ESP box color for self"), new Color(100, 170, 255, 220));
    private final BooleanSetting self = new BooleanSetting(new StringConstant("Self"), new StringConstant("Renders self in third person"), false);
    private final BooleanSetting shadow = new BooleanSetting(new StringConstant("Shadow"), new StringConstant("Blurs shadow behind box"), true);
    private final BooleanSetting healthBar = new BooleanSetting(new StringConstant("Health Bar"), new StringConstant("Renders health bar"), true);
    private final FloatSetting lineWidth = new FloatSetting(new StringConstant("Line Width"), new StringConstant("ESP border thickness"), 1.0f, 4.0f, 2.0f, 0.1f);
    private final FloatSetting radius = new FloatSetting(new StringConstant("Radius"), new StringConstant("Box corner radius"), 0.0f, 6.0f, 1.5f, 0.1f);
    private final FloatSetting shadowSize = new FloatSetting(new StringConstant("Shadow Size"), new StringConstant("Blur shadow size"), 2.0f, 10.0f, 4.0f, 0.1f);
    private final double[][] B = new double[8][3];
    private final Map C = new HashMap();
    private int D;

    public ESP() {
        super(ModuleCategory.VISUAL, new StringConstant[]{new StringConstant("ESP"), new StringConstant("Draws ESP on players")});
        this.addSettings(List.of(this.mode, this.enemyColor, this.selfColor, this.self, this.shadow, this.healthBar, this.lineWidth, this.radius, this.shadowSize));
    }

    private void onRenderHUDEventPost(RenderHUDEvent.Post renderHUDEvent$Post) {
        if (this.mode.getValue() == EspGeometry.Box3D) {
            return;
        }
        if (Module.mc.world == null) {
            return;
        }
        float f = renderHUDEvent$Post.tickCounter.getTickProgress(true);
        MatrixStack mc13 = new MatrixStack();
        if (++this.D >= 200) {
            this.D = 0;
            Iterator<Object> iterator = this.C.keySet().iterator();
            while (iterator.hasNext()) {
                Object object = (UUID)iterator.next();
                boolean bl = false;
                for (PlayerEntity mc6 : Module.mc.world.getPlayers()) {
                    if (!mc6.getUuid().equals(object)) continue;
                    bl = true;
                    break;
                }
                if (bl) continue;
                iterator.remove();
            }
        }
        for (Object object : Module.mc.world.getPlayers()) {
            if (!this.a((PlayerEntity)object)) continue;
            this.a((PlayerEntity)object, mc13, f);
        }
    }

    private boolean a(PlayerEntity mc6) {
        if (mc6 == null || !mc6.isAlive() || mc6.isSpectator()) {
            return false;
        }
        if (mc6 == Module.mc.player) {
            if (!this.self.getValue()) {
                return false;
            }
            return Module.mc.gameRenderer.getCamera().isThirdPerson();
        }
        return !mc6.isInvisible();
    }

    private void a(PlayerEntity mc6, MatrixStack mc13, float f) {
        Vec3d VanillaChestLootTableGenerator = new Vec3d(MathHelper.lerp((double)f, (double)mc6.lastRenderX, (double)mc6.getX()), MathHelper.lerp((double)f, (double)mc6.lastRenderY, (double)mc6.getY()), MathHelper.lerp((double)f, (double)mc6.lastRenderZ, (double)mc6.getZ()));
        float f2 = mc6.getWidth() * 0.5f;
        float f3 = mc6.getHeight();
        this.a(VanillaChestLootTableGenerator, f2, f3);
        float f4 = Float.MAX_VALUE;
        float f5 = Float.MAX_VALUE;
        float f6 = -3.4028235E38f;
        float f7 = -3.4028235E38f;
        boolean bl = false;
        for (int i = 0; i < 8; ++i) {
            float[] fArray = this.a(this.B[i][0], this.B[i][1], this.B[i][2]);
            if (fArray[2] <= 0.0f) continue;
            bl = true;
            f4 = Math.min(f4, fArray[0]);
            f5 = Math.min(f5, fArray[1]);
            f6 = Math.max(f6, fArray[0]);
            f7 = Math.max(f7, fArray[1]);
        }
        if (!bl) {
            return;
        }
        float f8 = f6 - f4;
        float f9 = f7 - f5;
        if (f8 < 8.0f || f9 < 8.0f) {
            return;
        }
        float f10 = this.lineWidth.getValue();
        float f11 = this.radius.getValue();
        Color color = mc6 == Module.mc.player ? this.selfColor.d() : this.enemyColor.d();
        Color color2 = this.a(mc6, color);
        this.a(mc13, f4, f5, f8, f9, f10, f11, color2);
        if (this.healthBar.getValue()) {
            this.a(mc13, mc6, f4, f5, f9, f11, f);
        }
    }

    private void a(MatrixStack mc13, float f, float f2, float f3, float f4, float f5, float f6, Color color) {
        float f7;
        if (this.shadow.getValue()) {
            f7 = this.shadowSize.getValue();
            new PanelRenderer(mc13, f - f7 * 0.5f, f2 - f7 * 0.5f, f3 + f7, f4 + f7).a(f6 + f7 * 0.5f).a(new Color(0, 0, 0, 55)).a(10.0f + f7 * 0.2f, 1.0f).j();
        }
        new PanelRenderer(mc13, f, f2, f3, f4).a(f6 + 0.6f).a(n).j();
        f7 = f + f5;
        float f8 = f2 + f5;
        float f9 = f3 - f5 * 2.0f;
        float f10 = f4 - f5 * 2.0f;
        if (f9 > 0.0f && f10 > 0.0f) {
            new PanelRenderer(mc13, f7, f8, f9, f10).a(Math.max(0.0f, f6 - f5)).a(new Color(0, 0, 0, 0)).j();
        }
        new PanelRenderer(mc13, f, f2, f3, f4).a(f6).a(color).j();
        if (f9 > 0.0f && f10 > 0.0f) {
            new PanelRenderer(mc13, f7, f8, f9, f10).a(Math.max(0.0f, f6 - f5)).a(new Color(0, 0, 0, 0)).j();
        }
    }

    private void a(MatrixStack mc13, PlayerEntity mc6, float f, float f2, float f3, float f4, float f5) {
        float f6;
        float f7 = Math.max(1.0f, mc6.getMaxHealth());
        float f8 = MathHelper.clamp((float)(mc6.getHealth() / f7), (float)0.0f, (float)1.0f);
        UUID uUID = mc6.getUuid();
        float f9 = this.C.getOrDefault(uUID, Float.valueOf(f8)).floatValue();
        float f10 = f9 + (f8 - f9) * (f6 = MathHelper.clamp((float)(0.18f + f5 * 0.3f), (float)0.0f, (float)1.0f));
        if (Math.abs(f10 - f8) < 0.001f) {
            f10 = f8;
        }
        this.C.put(uUID, Float.valueOf(f10));
        float f11 = 3.0f;
        float f12 = f - f11 - 2.5f;
        new PanelRenderer(mc13, f12, f2, f11, f3).a(Math.min(f4, 2.0f)).a(r).j();
        float f13 = f3 * f10;
        float f14 = f2 + f3 - f13;
        Color color = f10 > 0.66f ? o : (f10 > 0.33f ? p : q);
        new PanelRenderer(mc13, f12, f14, f11, f13).a(Math.min(f4, 2.0f)).a(color).j();
    }

    private void onRenderWorldEventPost(RenderWorldEvent.Post renderWorldEvent$Post) {
        if (this.mode.getValue() != EspGeometry.Box3D) {
            return;
        }
        if (Module.mc.world == null) {
            return;
        }
        float f = renderWorldEvent$Post.tickCounter.getTickProgress(true);
        Camera mc22 = Module.mc.gameRenderer.getCamera();
        Vec3d VanillaChestLootTableGenerator = mc22.getCameraPos();
        MatrixStack mc13 = new MatrixStack();
        mc13.multiply((Quaternionfc)mc22.getRotation().conjugate(new Quaternionf()));
        mc13.translate(-VanillaChestLootTableGenerator.x, -VanillaChestLootTableGenerator.y, -VanillaChestLootTableGenerator.z);
        float f2 = this.lineWidth.getValue();
        for (PlayerEntity mc6 : Module.mc.world.getPlayers()) {
            if (!this.a(mc6)) continue;
            Vec3d WallPlayerSkullBlock = new Vec3d(MathHelper.lerp((double)f, (double)mc6.lastRenderX, (double)mc6.getX()), MathHelper.lerp((double)f, (double)mc6.lastRenderY, (double)mc6.getY()), MathHelper.lerp((double)f, (double)mc6.lastRenderZ, (double)mc6.getZ()));
            float f3 = mc6.getWidth() * 0.5f;
            float f4 = mc6.getHeight();
            Color color = mc6 == Module.mc.player ? this.selfColor.d() : this.enemyColor.d();
            Color color2 = this.a(mc6, color);
            new WorldLineRenderer(mc13).a((float)(WallPlayerSkullBlock.x - (double)f3), (float)WallPlayerSkullBlock.y, (float)(WallPlayerSkullBlock.z - (double)f3), (float)(WallPlayerSkullBlock.x + (double)f3), (float)(WallPlayerSkullBlock.y + (double)f4), (float)(WallPlayerSkullBlock.z + (double)f3)).a(color2).b(true).a(n, f2).b().c();
        }
    }

    private Color a(PlayerEntity mc6, Color color) {
        if (mc6.hurtTime <= 0) {
            return color;
        }
        HitColor hitColor = null;
        for (Module module : ModuleManager.c()) {
            HitColor hitColor2;
            if (!(module instanceof HitColor)) continue;
            hitColor = hitColor2 = (HitColor)module;
            break;
        }
        if (hitColor == null || !hitColor.e()) {
            return color;
        }
        Color color2 = hitColor.s();
        float f = (float)mc6.hurtTime / 10.0f;
        int n = Math.round((float)color.getRed() + (float)(color2.getRed() - color.getRed()) * f);
        int n2 = Math.round((float)color.getGreen() + (float)(color2.getGreen() - color.getGreen()) * f);
        int n3 = Math.round((float)color.getBlue() + (float)(color2.getBlue() - color.getBlue()) * f);
        int n4 = Math.round((float)color.getAlpha() + (float)(color2.getAlpha() - color.getAlpha()) * f);
        return new Color(Math.max(0, Math.min(255, n)), Math.max(0, Math.min(255, n2)), Math.max(0, Math.min(255, n3)), Math.max(0, Math.min(255, n4)));
    }

    private void a(Vec3d VanillaChestLootTableGenerator, float f, float f2) {
        double d2 = VanillaChestLootTableGenerator.x - (double)f;
        double d3 = VanillaChestLootTableGenerator.x + (double)f;
        double d4 = VanillaChestLootTableGenerator.y;
        double d5 = VanillaChestLootTableGenerator.y + (double)f2;
        double d6 = VanillaChestLootTableGenerator.z - (double)f;
        double d7 = VanillaChestLootTableGenerator.z + (double)f;
        this.B[0][0] = d2;
        this.B[0][1] = d4;
        this.B[0][2] = d6;
        this.B[1][0] = d2;
        this.B[1][1] = d4;
        this.B[1][2] = d7;
        this.B[2][0] = d2;
        this.B[2][1] = d5;
        this.B[2][2] = d6;
        this.B[3][0] = d2;
        this.B[3][1] = d5;
        this.B[3][2] = d7;
        this.B[4][0] = d3;
        this.B[4][1] = d4;
        this.B[4][2] = d6;
        this.B[5][0] = d3;
        this.B[5][1] = d4;
        this.B[5][2] = d7;
        this.B[6][0] = d3;
        this.B[6][1] = d5;
        this.B[6][2] = d6;
        this.B[7][0] = d3;
        this.B[7][1] = d5;
        this.B[7][2] = d7;
    }

    private float[] a(double d2, double d3, double d4) {
        return GameRendererMixinBridge.worldToScreen(new Vec3d(d2, d3, d4));
    }
}

