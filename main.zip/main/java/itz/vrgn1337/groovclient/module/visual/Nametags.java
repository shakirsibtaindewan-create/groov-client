/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.module.visual;

import itz.vrgn1337.groovclient.api.util.bridge.GameRendererMixinBridge;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.font.MsdfFont;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.entry.RegistryEntry;
import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;

public class Nametags
extends Module {
    private final BooleanSetting self = new BooleanSetting(new StringConstant("Self"), new StringConstant("Renders self in third person"), true);
    private final BooleanSetting healthBar = new BooleanSetting(new StringConstant("HealthBar"), new StringConstant("Shows a health bar"), true);
    private final BooleanSetting distance = new BooleanSetting(new StringConstant("Distance"), new StringConstant("Shows distance"), true);
    private final BooleanSetting ping = new BooleanSetting(new StringConstant("Ping"), new StringConstant("Shows ping"), false);
    private final BooleanSetting armor = new BooleanSetting(new StringConstant("Armor"), new StringConstant("Shows armor pieces"), true);
    private final BooleanSetting items = new BooleanSetting(new StringConstant("Items"), new StringConstant("Shows main and off hand items"), true);
    private final BooleanSetting enchants = new BooleanSetting(new StringConstant("Enchants"), new StringConstant("Shows enchants below items"), true);
    private final BooleanSetting durability = new BooleanSetting(new StringConstant("Durability"), new StringConstant("Shows durability bars on items"), true);
    private final BooleanSetting potions = new BooleanSetting(new StringConstant("Potions"), new StringConstant("Shows active potion effects"), true);
    private final ColorSetting bgColor = new ColorSetting(new StringConstant("BgColor"), new StringConstant("Background color"), new Color(12, 12, 14, 180));
    private final ColorSetting textColor = new ColorSetting(new StringConstant("TextColor"), new StringConstant("Name text color"), Color.WHITE);
    private final ColorSetting enchantColor = new ColorSetting(new StringConstant("EnchantColor"), new StringConstant("Enchant text color"), new Color(180, 210, 255, 230));
    private static final Color z = new Color(0, 0, 0, 160);
    private static final Color A = new Color(95, 230, 120, 235);
    private static final Color B = new Color(240, 210, 90, 235);
    private static final Color C = new Color(240, 95, 95, 235);
    private static final Color D = new Color(255, 200, 60, 230);
    private static Nametags E;

    public Nametags() {
        super(ModuleCategory.VISUAL, new StringConstant[]{new StringConstant("Nametags"), new StringConstant("Shows custom nametags")});
        E = this;
        this.addSettings(List.of(this.self, this.healthBar, this.distance, this.ping, this.armor, this.items, this.enchants, this.durability, this.potions, this.bgColor, this.textColor, this.enchantColor));
    }

    public static boolean a(PlayerEntity mc6) {
        Nametags nametags = Nametags.getInstance();
        if (nametags == null || !nametags.e()) {
            return false;
        }
        return mc6 != Module.mc.player || nametags.self.getValue();
    }

    private static Nametags getInstance() {
        return E;
    }

    private void onRenderHUDEventPost(RenderHUDEvent.Post renderHUDEvent$Post) {
        if (Module.mc.world == null || Module.mc.player == null) {
            return;
        }
        float f = renderHUDEvent$Post.tickCounter.getTickProgress(true);
        MatrixStack mc13 = new MatrixStack();
        for (PlayerEntity mc6 : Module.mc.world.getPlayers()) {
            if (!this.b(mc6)) continue;
            this.a(mc6, mc13, renderHUDEvent$Post.context, f);
        }
    }

    private boolean b(PlayerEntity mc6) {
        if (mc6 == null || !mc6.isAlive() || mc6.isSpectator() || mc6.isInvisible()) {
            return false;
        }
        if (mc6 == Module.mc.player) {
            if (!this.self.getValue()) {
                return false;
            }
            return Module.mc.gameRenderer.getCamera().isThirdPerson();
        }
        return true;
    }

    private void a(PlayerEntity mc6, MatrixStack mc13, DrawContext mc15, float f) {
        String string;
        Vec3d VanillaChestLootTableGenerator = new Vec3d(MathHelper.lerp((double)f, (double)mc6.lastRenderX, (double)mc6.getX()), MathHelper.lerp((double)f, (double)mc6.lastRenderY, (double)mc6.getY()) + (double)mc6.getHeight() + 0.35, MathHelper.lerp((double)f, (double)mc6.lastRenderZ, (double)mc6.getZ()));
        float[] fArray = GameRendererMixinBridge.worldToScreen(VanillaChestLootTableGenerator);
        if (fArray[2] <= 0.0f) {
            return;
        }
        float f2 = fArray[0];
        float f3 = fArray[1];
        float f4 = Math.max(0.5f, MenuGuiScreen.d());
        float f5 = Module.mc.player.distanceTo((Entity)mc6);
        float f6 = MathHelper.clamp((float)(8.0f / Math.max(f5, 0.001f)), (float)0.55f, (float)1.35f);
        float f7 = f4 * f6;
        float f8 = 7.0f * f7;
        float f9 = 5.0f * f7;
        float f10 = 3.5f * f7;
        float f11 = 2.0f * f7;
        float f12 = 1.6f * f7;
        float f13 = 2.0f * f7;
        MsdfFont msdfFont = FontManager.a();
        StringBuilder stringBuilder = new StringBuilder();
        float f14 = mc6.getAbsorptionAmount();
        if (f14 > 0.0f) {
            stringBuilder.append("  +").append(String.format("%.0f", Float.valueOf(f14)));
        }
        if (this.distance.getValue()) {
            stringBuilder.append("  ").append(String.format("%.1fm", Float.valueOf(f5)));
        }
        if (this.ping.getValue() && Module.mc.getNetworkHandler() != null && (string = Module.mc.getNetworkHandler().getPlayerListEntry(mc6.getUuid())) != null) {
            stringBuilder.append("  ").append(string.getLatency()).append("ms");
        }
        string = mc6.getName().getString();
        StringConstant stringConstant = new StringConstant(string + stringBuilder.toString());
        float f15 = msdfFont.a(stringConstant, f8);
        float f16 = msdfFont.b(f8);
        float f17 = f15 + f10 * 2.0f;
        float f18 = f16 + f11 * 2.0f;
        if (this.healthBar.getValue()) {
            f18 += f13 + f12;
        }
        float f19 = f2 - f17 / 2.0f;
        float f20 = f3 - f18;
        new PanelRenderer(mc13, f19, f20, f17, f18).a(2.5f * f7).a(this.bgColor.d()).j();
        msdfFont.a(mc13, stringConstant, f19 + f10, f20 + f11, f8, this.textColor.d());
        if (this.healthBar.getValue()) {
            float f21;
            float f22 = Math.max(1.0f, mc6.getMaxHealth());
            float f23 = mc6.getHealth();
            float f24 = mc6.getAbsorptionAmount();
            float f25 = MathHelper.clamp((float)(f23 / f22), (float)0.0f, (float)1.0f);
            float f26 = MathHelper.clamp((float)(f24 / f22), (float)0.0f, (float)1.0f);
            float f27 = f19 + f10;
            float f28 = f20 + f11 + f16 + f13;
            float f29 = f17 - f10 * 2.0f;
            new PanelRenderer(mc13, f27, f28, f29, f12).a(f12 * 0.5f).a(z).j();
            float f30 = f29 * f25;
            if (f30 > 0.3f) {
                Color color = f25 > 0.66f ? A : (f25 > 0.33f ? B : C);
                new PanelRenderer(mc13, f27, f28, f30, f12).a(f12 * 0.5f).a(color).j();
            }
            if (f24 > 0.0f && (f21 = Math.min(f29 * f26, f29 - f30)) > 0.3f) {
                new PanelRenderer(mc13, f27 + f30, f28, f21, f12).a(f12 * 0.5f).a(D).j();
            }
        }
        this.a(mc6, mc13, mc15, f2, f20, f7, f9);
        if (this.potions.getValue()) {
            this.a(mc6, mc13, f2, f20 + f18 + 1.5f * f7, f7);
        }
    }

    private void a(PlayerEntity mc6, MatrixStack mc13, DrawContext mc15, float f, float f2, float f3, float f4) {
        Object object;
        Object object2;
        if (!this.armor.getValue() && !this.items.getValue()) {
            return;
        }
        ArrayList<Object> arrayList = new ArrayList<Object>();
        if (this.items.getValue() && !(object2 = mc6.getOffHandStack()).isEmpty()) {
            arrayList.add(object2);
        }
        if (this.armor.getValue()) {
            object2 = mc6.getEquippedStack(EquipmentSlot.FEET);
            ItemStack mc33 = mc6.getEquippedStack(EquipmentSlot.LEGS);
            ItemStack mc68 = mc6.getEquippedStack(EquipmentSlot.CHEST);
            object = mc6.getEquippedStack(EquipmentSlot.HEAD);
            if (!object2.isEmpty()) {
                arrayList.add(object2);
            }
            if (!mc33.isEmpty()) {
                arrayList.add(mc33);
            }
            if (!mc68.isEmpty()) {
                arrayList.add(mc68);
            }
            if (!object.isEmpty()) {
                arrayList.add(object);
            }
        }
        if (this.items.getValue() && !(object2 = mc6.getMainHandStack()).isEmpty()) {
            arrayList.add(object2);
        }
        if (arrayList.isEmpty()) {
            return;
        }
        object2 = FontManager.a();
        float f5 = 10.0f * f3;
        float f6 = 1.5f * f3;
        float[] fArray = new float[arrayList.size()];
        String[] stringArray = new String[arrayList.size()];
        float f7 = 0.0f;
        for (int i = 0; i < arrayList.size(); ++i) {
            String string;
            stringArray[i] = string = this.enchants.getValue() ? this.a((ItemStack)arrayList.get(i)) : "";
            float f8 = string.isEmpty() ? 0.0f : ((MsdfFont)object2).a(new StringConstant(string), f4);
            fArray[i] = Math.max(f5, f8);
            f7 += fArray[i];
            if (i >= arrayList.size() - 1) continue;
            f7 += f6;
        }
        float f9 = f - f7 / 2.0f;
        float f10 = ((MsdfFont)object2).b(f4);
        boolean bl = false;
        for (String string : stringArray) {
            if (string.isEmpty()) continue;
            bl = true;
            break;
        }
        float f11 = bl ? f10 + 1.0f * f3 : 0.0f;
        float f12 = f2 - f5 - f11 - 1.5f * f3;
        float f13 = RenderScale.h();
        float f14 = f5 / 16.0f;
        float f15 = f9;
        for (int i = 0; i < arrayList.size(); ++i) {
            float f16;
            float f17;
            ItemStack mc112 = (ItemStack)arrayList.get(i);
            float f18 = f15 + (fArray[i] - f5) * 0.5f;
            mc15.getMatrices().pushMatrix();
            mc15.getMatrices().translate(f18 * f13, f12 * f13);
            mc15.getMatrices().scale(f14 * f13, f14 * f13);
            mc15.drawItem(mc112, 0, 0);
            mc15.getMatrices().popMatrix();
            if (this.durability.getValue() && mc112.isDamaged()) {
                float f19 = 1.0f - (float)mc112.getDamage() / (float)mc112.getMaxDamage();
                Color color = f19 > 0.5f ? new Color(80, 220, 100, 230) : (f19 > 0.25f ? new Color(220, 200, 60, 230) : new Color(220, 60, 60, 230));
                f17 = Math.max(0.8f, 1.0f * f3);
                f16 = f12 + f5 - f17;
                new PanelRenderer(mc13, f18, f16, f5, f17).a(new Color(0, 0, 0, 180)).j();
                new PanelRenderer(mc13, f18, f16, f5 * f19, f17).a(color).j();
            }
            if (!stringArray[i].isEmpty()) {
                StringConstant stringConstant = new StringConstant(stringArray[i]);
                float f20 = ((MsdfFont)object2).a(stringConstant, f4);
                f17 = f15 + (fArray[i] - f20) * 0.5f;
                f16 = f12 + f5 + 1.0f * f3;
                ((MsdfFont)object2).a(mc13, stringConstant, f17, f16, f4, this.enchantColor.d());
            }
            f15 += fArray[i] + f6;
        }
    }

    private void a(PlayerEntity mc6, MatrixStack mc13, float f, float f2, float f3) {
        Object object;
        int n;
        Object object22;
        Collection<StatusEffect> collection = mc6.getStatusEffects();
        if (collection.isEmpty()) {
            return;
        }
        MsdfFont msdfFont = FontManager.a();
        float f4 = 5.0f * f3;
        float f5 = 2.0f * f3;
        float f6 = 1.2f * f3;
        float f7 = msdfFont.b(f4) + f6 * 2.0f;
        float f8 = 1.5f * f3;
ArrayList<String> arrayList = new ArrayList<String>();
        ArrayList<Color> arrayList2 = new ArrayList<Color>();
        for (StatusEffect object22 : collection) {
            String string = ((StatusEffect)object22.getEffectType().value()).getTranslationKey();
            n = object22.getAmplifier();
            arrayList.add(string + String.valueOf(n > 0 ? Integer.valueOf(n + 1) : "") + " " + this.c(object22.getDuration()));
            int n2 = ((StatusEffect)object22.getEffectType().value()).getColor();
            arrayList2.add(new Color(n2 >> 16 & 0xFF, n2 >> 8 & 0xFF, n2 & 0xFF, 210));
        }
        float f9 = 0.0f;
        float[] object22 = new float[arrayList.size()];
        for (int i = 0; i < arrayList.size(); ++i) {
            object22[i] = (float)(msdfFont.a(new StringConstant(arrayList.get(i)), f4) + f8 * 2.0f);
            f9 += object22[i];
            if (i >= arrayList.size() - 1) continue;
            f9 += f8;
        }
        float f10 = f - f9 / 2.0f;
        for (n = 0; n < arrayList.size(); ++n) {
            Color object = arrayList2.get(n);
            Color color = new Color(Math.max(0, object.getRed() / 4), Math.max(0, object.getGreen() / 4), Math.max(0, object.getBlue() / 4), 210);
            new PanelRenderer(mc13, f10, f2, object22[n], f7).a(1.5f * f3).a(color).j();
            msdfFont.a(mc13, new StringConstant(arrayList.get(n)), f10 + f5, f2 + f6, f4, object);
            f10 += object22[n] + f8;
        }
    }

    private String a(ItemStack mc33) {
        if (mc33.isEmpty() || mc33.getEnchantments().isEmpty()) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        for (RegistryEntry mc96 : mc33.getEnchantments().getEnchantments()) {
            int n2 = mc33.getEnchantments().getLevel(mc96);
            String string = mc96.getIdAsString();
            int n3 = string.indexOf(58);
            String string2 = n3 >= 0 ? string.substring(n3 + 1) : string;
            String string3 = this.a(string2);
            if (n > 0) {
                stringBuilder.append(' ');
            }
            stringBuilder.append(string3).append(n2);
            if (++n < 4) continue;
            break;
        }
        return stringBuilder.toString();
    }

    private String a(String string) {
        int n = string.lastIndexOf(46);
        String string2 = n >= 0 ? string.substring(n + 1) : string;
        String[] stringArray = string2.split("[_\s]+");
        StringBuilder stringBuilder = new StringBuilder();
        for (String string3 : stringArray) {
            if (string3.isEmpty()) continue;
            stringBuilder.append(Character.toUpperCase(string3.charAt(0)));
        }
        if (stringBuilder.length() == 0 && !string2.isEmpty()) {
            stringBuilder.append(Character.toUpperCase(string2.charAt(0)));
        }
        return stringBuilder.toString();
    }

    private String c(int n) {
        if (n < 0) {
            return "**";
        }
        int n2 = n / 20;
        int n3 = n2 / 60;
        return String.format("%d:%02d", n3, n2 %= 60);
    }
}

