/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.screen;

import itz.vrgn1337.groovclient.api.backend.AuthState;
import itz.vrgn1337.groovclient.module.ModuleCategory;

class ModuleCategorySwitchMap {
    static final int[] a;
    static final int[] b;

    static {
        b = new int[ModuleCategory.values().length];
        try {
            ModuleCategorySwitchMap.b[ModuleCategory.COMBAT.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ModuleCategorySwitchMap.b[ModuleCategory.MOVEMENT.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ModuleCategorySwitchMap.b[ModuleCategory.VISUAL.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ModuleCategorySwitchMap.b[ModuleCategory.Utility.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        a = new int[AuthState.values().length];
        try {
            ModuleCategorySwitchMap.a[AuthState.AUTHENTICATED.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ModuleCategorySwitchMap.a[AuthState.CONNECTING.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

