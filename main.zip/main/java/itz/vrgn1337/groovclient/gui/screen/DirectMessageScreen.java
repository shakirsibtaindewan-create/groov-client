/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.screen;

import itz.vrgn1337.groovclient.api.backend.BackendClient;
import itz.vrgn1337.groovclient.api.backend.DirectMessage;
import itz.vrgn1337.groovclient.api.backend.FriendEntry;
import itz.vrgn1337.groovclient.api.backend.SocialService;
import itz.vrgn1337.groovclient.api.util.SoundManager;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.screen.FriendsScreen;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;

public class DirectMessageScreen
extends Screen {
    private static final DirectMessageScreen a = new DirectMessageScreen();
    private static final String b = "dm.screen.open";
    private static final Color c = new Color(0, 0, 0, 80);
    private boolean d = false;
    private final List e = new ArrayList();
    private final List f = new ArrayList();
    private String g = null;
    private final StringBuilder h = new StringBuilder();
    private final StringBuilder i = new StringBuilder();
    private boolean j = true;
    private boolean k = false;
    private float l = 0.0f;
    private float m = 0.0f;
    private float n = 0.0f;
    private float o = 0.0f;
    private final Consumer p = arg_0 -> ((DirectMessageScreen)this).a(arg_0);

    public static DirectMessageScreen getInstance() {
        return a;
    }

    protected DirectMessageScreen() {
        super((Text)Text.empty());
    }

    public void init() {
        this.d = false;
        GuiRenderer.b(b, 0.0f);
        SocialService.getInstance().a(this.p);
        this.d();
    }

    public void removed() {
        SocialService.getInstance().b(this.p);
    }

    public boolean keyPressed(KeyInput mc27) {
        String string;
        if (mc27.key() == 256) {
            this.d = true;
            return true;
        }
        if (mc27.key() == 257) {
            if (this.k) {
                this.c();
            } else {
                this.b();
            }
            return true;
        }
        if (mc27.key() == 259) {
            StringBuilder stringBuilder;
            StringBuilder stringBuilder2 = stringBuilder = this.k ? this.i : this.h;
            if (stringBuilder.length() > 0) {
                stringBuilder.deleteCharAt(stringBuilder.length() - 1);
            }
            return true;
        }
        String string2 = string = mc27.key() == 32 ? " " : GLFW.glfwGetKeyName((int)mc27.key(), (int)mc27.scancode());
        if (string != null && !string.isEmpty()) {
            int n2;
            StringBuilder stringBuilder = this.k ? this.i : this.h;
            int n3 = n2 = this.k ? 16 : 240;
            if (stringBuilder.length() < n2) {
                stringBuilder.append(string);
            }
            return true;
        }
        return super.keyPressed(mc27);
    }

    public boolean mouseScrolled(double d2, double d3, double d4, double d5) {
        float f2 = RenderScale.c();
        float f3 = RenderScale.d();
        float f4 = 560.0f;
        float f5 = Math.min(420.0f, f3 * 0.82f);
        float f6 = (f2 - f4) * 0.5f;
        float f7 = (f3 - f5) * 0.5f;
        float f8 = 40.0f;
        float f9 = 12.0f;
        float f10 = 170.0f;
        float f11 = f7 + f8 + 8.0f;
        float f12 = f5 - f8 - 16.0f;
        float f13 = f6 + f9 + f10 + f9;
        float f14 = f4 - f10 - f9 * 3.0f;
        float f15 = f12 - 34.0f;
        if (RenderScale.a(f6 + f9, f11, f10, f12)) {
            this.m += (float)d5 * 10.0f;
            return true;
        }
        if (RenderScale.a(f13, f11, f14, f15)) {
            this.o += (float)d5 * 11.0f;
            return true;
        }
        return super.mouseScrolled(d2, d3, d4, d5);
    }

    protected void applyBlur(DrawContext mc15) {
    }

    public void render(DrawContext mc15, int n2, int n3, float f2) {
        MatrixStack mc13 = new MatrixStack();
        float f3 = GuiRenderer.a(b, this.d ? 0.0f : 1.0f, 0.06f);
        if (this.d && f3 <= 0.01f) {
            this.d = false;
            GuiRenderer.b(b);
            Main.mc.setScreen((Screen)FriendsScreen.getInstance());
            return;
        }
        float f4 = RenderScale.c();
        float f5 = RenderScale.d();
        new PanelRenderer(mc13, 0.0f, 0.0f, f4, f5).a(GuiRenderer.a(c, (int)((float)c.getAlpha() * f3))).j();
        float f6 = 560.0f;
        float f7 = Math.min(420.0f, f5 * 0.82f);
        float f8 = (f4 - f6) * 0.5f;
        float f9 = (f5 - f7) * 0.5f;
        float f10 = GuiRenderer.g(f3);
        float f11 = 0.85f + 0.15f * f10;
        float f12 = f8 + f6 * 0.5f;
        float f13 = f9 + f7 * 0.5f;
        mc13.push();
        mc13.translate(f12, f13, 0.0f);
        mc13.scale(f11, f11, 1.0f);
        mc13.translate(-f12, -f13, 0.0f);
        new PanelRenderer(mc13, f8, f9, f6, f7).a(GuiRenderer.a(new Color(12, 12, 16), (int)(240.0f * f3))).a(16.0f, 1.0f).a(12.0f).j();
        Color color = MenuGuiScreen.c();
        int n4 = (int)(255.0f * f3);
        float f14 = 40.0f;
        GuiRenderer.a(mc13, "write", f8 + 14.0f, f9 + (f14 - 14.0f) * 0.5f, 14.0f, 14.0f, GuiRenderer.a(color, n4));
        FontManager.a().a(mc13, new StringConstant("Direct Messages"), f8 + 36.0f, f9 + f14 * 0.28f, 10.0f, GuiRenderer.a(Color.WHITE, n4));
        new PanelRenderer(mc13, f8 + 12.0f, f9 + f14 - 1.0f, f6 - 24.0f, 1.0f).a(GuiRenderer.a(new Color(255, 255, 255), (int)(20.0f * f3))).j();
        float f15 = 12.0f;
        float f16 = 170.0f;
        float f17 = f9 + f14 + 8.0f;
        float f18 = f7 - f14 - 16.0f;
        float f19 = f8 + f15;
        float f20 = f19 + f16 + f15;
        float f21 = f6 - f16 - f15 * 3.0f;
        this.getInstance(mc13, f19, f17, f16, f18, f3, color);
        this.b(mc13, f20, f17, f21, f18, f3, color);
        mc13.pop();
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, Color color) {
        new PanelRenderer(mc13, f2, f3, f4, f5).a(new Color(18, 18, 24, (int)(210.0f * f6))).a(8.0f).j();
        float f7 = 20.0f;
        float f8 = f3 + 6.0f;
        float f9 = f4 - 36.0f;
        new PanelRenderer(mc13, f2 + 6.0f, f8, f9, f7).a(new Color(10, 10, 14, (int)(220.0f * f6))).a(6.0f).j().a(0, () -> ((DirectMessageScreen)this).lambda$drawFriendPane$0());
        GuiRenderer.a(mc13, f2 + 6.0f, f8, f9, f7, 1.0f, 6.0f, new Color(38, 38, 52, (int)(200.0f * f6)));
        String string = this.i.isEmpty() ? "Search user" : this.i.toString();
        FontManager.a().a(mc13, new StringConstant(string), f2 + 12.0f, f8 + 6.0f, 6.4f, this.i.isEmpty() ? new Color(100, 100, 100) : Color.WHITE);
        float f10 = f2 + f4 - 24.0f;
        this.a(mc13, f10, f8, 18.0f, f7, "search", f6, new Color(60, 88, 150), () -> ((DirectMessageScreen)this).c());
        float f11 = f3 + f7 + 12.0f;
        float f12 = f5 - f7 - 16.0f;
        float f13 = 28.0f;
        float f14 = 3.0f;
        this.l += this.m;
        this.m *= 0.84f;
        float f15 = Math.max(0.0f, (float)this.e.size() * (f13 + f14) - f12 + 4.0f);
        this.l = GuiRenderer.b(this.l, -f15, 0.0f);
        GuiRenderer.a(f2, f11, f4, f12);
        for (int j = 0; j < this.e.size(); ++j) {
            FriendEntry friendEntry = (FriendEntry)this.e.get(j);
            float f16 = f11 + this.l + (float)j * (f13 + f14);
            if (f16 + f13 < f11 || f16 > f11 + f12) continue;
            boolean bl = friendEntry.a.equalsIgnoreCase(this.g);
            Color color2 = bl ? new Color(44, 52, 72, (int)(220.0f * f6)) : new Color(26, 26, 34, (int)(220.0f * f6));
            new PanelRenderer(mc13, f2 + 4.0f, f16, f4 - 8.0f, f13).a(color2).a(6.0f).j().a(0, () -> ((DirectMessageScreen)this).lambda$drawFriendPane$1((FriendEntry)friendEntry));
            Color color3 = friendEntry.c ? GuiRenderer.a(new Color(80, 220, 120), (int)(235.0f * f6)) : GuiRenderer.a(new Color(120, 120, 120), (int)(235.0f * f6));
            new PanelRenderer(mc13, f2 + 10.0f, f16 + 11.0f, 6.0f, 6.0f).a(color3).a(3.0f).j();
            FontManager.a().a(mc13, new StringConstant(friendEntry.a), f2 + 20.0f, f16 + 8.0f, 6.8f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)));
        }
        GuiRenderer.b();
    }

    private void b(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, Color color) {
        Object object;
        float f7;
        new PanelRenderer(mc13, f2, f3, f4, f5).a(new Color(18, 18, 24, (int)(210.0f * f6))).a(8.0f).j();
        float f8 = 24.0f;
        float f9 = f5 - f8 - 8.0f;
        new PanelRenderer(mc13, f2 + 6.0f, f3 + 6.0f, f4 - 12.0f, f9 - 10.0f).a(new Color(14, 14, 20, (int)(220.0f * f6))).a(6.0f).j();
        this.n += this.o;
        this.o *= 0.84f;
        float f10 = 22.0f;
        float f11 = Math.max(0.0f, (float)this.f.size() * f10 - (f9 - 16.0f));
        this.n = GuiRenderer.b(this.n, -f11, 0.0f);
        String string = BackendClient.getInstance().h() != null ? BackendClient.getInstance().h().a() : "";
        GuiRenderer.a(f2 + 8.0f, f3 + 8.0f, f4 - 16.0f, f9 - 14.0f);
        for (int j = 0; j < this.f.size(); ++j) {
            float f12;
            DirectMessage directMessage = (DirectMessage)this.f.get(j);
            f7 = f3 + 10.0f + this.n + (float)j * f10;
            boolean bl = directMessage.b.equalsIgnoreCase(string);
            object = directMessage.d;
            float f13 = f4 - 32.0f;
            float f14 = Math.min(FontManager.a().a(new StringConstant((String)object), 6.4f), f13 - 14.0f);
            float f15 = f14 + 16.0f;
            float f16 = 15.0f;
            float f17 = f7 + (f10 - f16) * 0.5f;
            if (bl) {
                f12 = f2 + f4 - 12.0f - f15;
                new PanelRenderer(mc13, f12, f17, f15, f16).a(new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(80.0f * f6))).a(6.0f).j();
                FontManager.a().a(mc13, new StringConstant((String)object), f12 + 8.0f, f17 + 4.0f, 6.4f, GuiRenderer.a(Color.WHITE, (int)(235.0f * f6)));
                continue;
            }
            f12 = f2 + 12.0f;
            new PanelRenderer(mc13, f12, f17, f15, f16).a(new Color(30, 30, 42, (int)(220.0f * f6))).a(6.0f).j();
            FontManager.a().a(mc13, new StringConstant((String)object), f12 + 8.0f, f17 + 4.0f, 6.4f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        }
        if (this.f.isEmpty() && this.g != null) {
            String string2 = "No messages yet. Say hello!";
            float f18 = FontManager.a().a(new StringConstant(string2), 6.4f);
            FontManager.a().a(mc13, new StringConstant(string2), f2 + (f4 - f18) * 0.5f, f3 + f9 * 0.5f - 3.0f, 6.4f, new Color(65, 65, 82, (int)(200.0f * f6)));
        } else if (this.g == null) {
            String string3 = "Select a conversation";
            float f19 = FontManager.a().a(new StringConstant(string3), 6.4f);
            FontManager.a().a(mc13, new StringConstant(string3), f2 + (f4 - f19) * 0.5f, f3 + f9 * 0.5f - 3.0f, 6.4f, new Color(65, 65, 82, (int)(200.0f * f6)));
        }
        GuiRenderer.b();
        float f20 = f3 + f5 - f8 - 4.0f;
        new PanelRenderer(mc13, f2 + 6.0f, f20, f4 - 64.0f, f8).a(new Color(11, 11, 16, (int)(230.0f * f6))).a(6.0f).j().a(0, () -> ((DirectMessageScreen)this).lambda$drawMessagePane$2());
        GuiRenderer.a(mc13, f2 + 6.0f, f20, f4 - 64.0f, f8, 1.0f, 6.0f, new Color(38, 38, 52, (int)(200.0f * f6)));
        String string4 = this.h.isEmpty() ? "Type message..." : this.h.toString();
        FontManager.a().a(mc13, new StringConstant(string4), f2 + 12.0f, f20 + 7.0f, 6.4f, this.h.isEmpty() ? new Color(100, 100, 100, (int)(220.0f * f6)) : GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)));
        f7 = f2 + f4 - 54.0f;
        float f21 = GuiRenderer.a("dm.send." + f2, RenderScale.a(f7, f20, 48.0f, f8) ? 1.0f : 0.0f, 0.12f);
        object = GuiRenderer.a(new Color(52, 110, 70), new Color(66, 138, 88), f21);
        new PanelRenderer(mc13, f7, f20, 48.0f, f8).a(GuiRenderer.a((Color)object, (int)(220.0f * f6))).a(6.0f).j().a(0, () -> ((DirectMessageScreen)this).b());
        GuiRenderer.a(mc13, "check", f7 + 7.0f, f20 + 7.0f, 10.0f, 10.0f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)));
        FontManager.a().a(mc13, new StringConstant("Send"), f7 + 19.0f, f20 + 8.0f, 6.0f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)));
        if (this.g != null) {
            FontManager.a().a(mc13, new StringConstant("@ " + this.g), f2 + 8.0f, f3 - 11.0f, 6.5f, GuiRenderer.a(color, (int)(220.0f * f6)));
        }
    }

    private void b() {
        if (this.g == null || this.h.isEmpty()) {
            return;
        }
        String string = this.h.toString().trim();
        if (string.isEmpty()) {
            return;
        }
        SocialService.getInstance().b(this.g, string, arg_0 -> ((DirectMessageScreen)this).lambda$sendCurrentDm$3(arg_0), this::lambda$sendCurrentDm$4);
        this.h.setLength(0);
    }

    private void c() {
        String string = this.i.toString().trim();
        if (string.isEmpty()) {
            return;
        }
        SocialService.getInstance().mouseScrolled(string, string, arg_0 -> ((DirectMessageScreen)this).lambda$addFriendFromSearch$5(arg_0), this::lambda$addFriendFromSearch$6);
    }

    private void d() {
        SocialService.getInstance().getInstance(arg_0 -> ((DirectMessageScreen)this).lambda$refreshFriends$7(arg_0), this::lambda$refreshFriends$8);
    }

    private void e() {
        if (this.g == null) {
            this.f.clear();
            return;
        }
        SocialService.getInstance().mouseScrolled(this.g, 80, arg_0 -> ((DirectMessageScreen)this).lambda$loadHistoryForSelected$9(arg_0), this::lambda$loadHistoryForSelected$10);
    }

    private void a(DirectMessage directMessage) {
        if (directMessage == null || directMessage.b == null) {
            return;
        }
        if (this.g != null && directMessage.b.equalsIgnoreCase(this.g)) {
            this.f.add(directMessage);
            this.n = -Math.max(0.0f, (float)this.f.size() * 22.0f - 220.0f);
        }
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, float f5, String string, float f6, Color color, Runnable runnable) {
        float f7 = GuiRenderer.a("dm.icon." + string + "." + f2 + "." + f3, RenderScale.a(f2, f3, f4, f5) ? 1.0f : 0.0f, 0.12f);
        Color color2 = GuiRenderer.a(color, GuiRenderer.b(color, 1.2f), f7);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(color2, (int)(210.0f * f6))).a(6.0f).j().a(0, runnable);
        GuiRenderer.a(mc13, string, f2 + (f4 - 10.0f) * 0.5f, f3 + (f5 - 10.0f) * 0.5f, 10.0f, 10.0f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)));
    }

    public boolean shouldPause() {
        return false;
    }

    public void close() {
        if (!this.d) {
            this.d = true;
        }
    }

    private static void lambda$loadHistoryForSelected$10(String string) {
    }

    private void lambda$loadHistoryForSelected$9(List list) {
        this.f.clear();
        this.f.addAll(list);
        this.n = -Math.max(0.0f, (float)this.f.size() * 22.0f - 220.0f);
    }

    private static void lambda$refreshFriends$8(String string) {
    }

    private void lambda$refreshFriends$7(List list) {
        this.e.clear();
        this.e.addAll(list);
        if (this.g == null && !this.e.isEmpty()) {
            this.g = ((FriendEntry)this.e.get((int)0)).a;
            this.e();
        }
    }

    private static void lambda$addFriendFromSearch$6(String string) {
    }

    private void lambda$addFriendFromSearch$5(String string) {
        SoundManager.b();
        this.i.setLength(0);
        this.d();
    }

    private static void lambda$sendCurrentDm$4(String string) {
    }

    private void lambda$sendCurrentDm$3(String string) {
        SoundManager.b();
        this.e();
    }

    private void lambda$drawMessagePane$2() {
        this.j = true;
        this.k = false;
    }

    private void lambda$drawFriendPane$1(FriendEntry friendEntry) {
        if (!friendEntry.a.equalsIgnoreCase(this.g)) {
            this.g = friendEntry.a;
            this.e();
            SoundManager.b();
        }
    }

    private void lambda$drawFriendPane$0() {
        this.k = true;
        this.j = false;
    }
}

