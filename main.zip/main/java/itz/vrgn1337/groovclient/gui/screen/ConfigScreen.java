/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.screen;

import itz.vrgn1337.groovclient.api.util.SoundManager;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.config.ClientSettings;
import itz.vrgn1337.groovclient.config.ConfigEntry;
import itz.vrgn1337.groovclient.config.ConfigManager;
import itz.vrgn1337.groovclient.config.ConfigScreenMode;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import java.awt.Color;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;

public class ConfigScreen
extends Screen {
    private static final ConfigScreen a = new ConfigScreen();
    private static final String b = "config.screen.open";
    private static final Color c = new Color(0, 0, 0, 80);
    private static final Color d = new Color(18, 18, 22, 230);
    private static final Color e = new Color(30, 30, 38, 230);
    private static final Color f = new Color(80, 220, 100);
    private boolean g = false;
    private ConfigScreenMode h = ConfigScreenMode.NONE;
    private ConfigEntry i = null;
    private float j;
    private float k;
    private final StringBuilder l = new StringBuilder();
    private final StringBuilder m = new StringBuilder();
    private int n = 0;
    private boolean o = false;
    private boolean p = false;
    private float q = 0.0f;
    private float r = 0.0f;
    private float s;
    private float t;
    private float u;
    private float v;

    public static ConfigScreen getInstance() {
        return a;
    }

    protected ConfigScreen() {
        super((Text)Text.empty());
    }

    public void init() {
        this.g = false;
        this.h = ConfigScreenMode.NONE;
        this.i = null;
        GuiRenderer.b(b, 0.0f);
    }

    public boolean keyPressed(KeyInput mc27) {
        if (mc27.key() == 256) {
            if (this.h != ConfigScreenMode.NONE) {
                this.d();
                return true;
            }
            this.g = true;
            return true;
        }
        if (this.h == ConfigScreenMode.CREATE || this.h == ConfigScreenMode.EDIT) {
            if (mc27.key() == 258) {
                this.n = (this.n + 1) % 2;
                return true;
            }
            if (mc27.key() == 257) {
                this.b();
                return true;
            }
            if (mc27.key() == 259) {
                StringBuilder stringBuilder;
                StringBuilder stringBuilder2 = stringBuilder = this.n == 0 ? this.l : this.m;
                if (stringBuilder.length() > 0) {
                    stringBuilder.deleteCharAt(stringBuilder.length() - 1);
                }
                return true;
            }
            String string = GLFW.glfwGetKeyName((int)mc27.key(), (int)mc27.scancode());
            if (string != null && !string.isEmpty()) {
                StringBuilder stringBuilder = this.n == 0 ? this.l : this.m;
                if (stringBuilder.length() < (this.n == 0 ? 24 : 48)) {
                    stringBuilder.append(string);
                }
                return true;
            }
            return true;
        }
        if (this.h == ConfigScreenMode.IMPORT) {
            if (mc27.key() == 257) {
                this.c();
                return true;
            }
            if (mc27.key() == 259) {
                if (this.l.length() > 0) {
                    this.l.deleteCharAt(this.l.length() - 1);
                }
                return true;
            }
            if (mc27.key() == 86 && (GLFW.glfwGetKey((long)Main.mc.getWindow().getHandle(), (int)341) == 1 || GLFW.glfwGetKey((long)Main.mc.getWindow().getHandle(), (int)345) == 1)) {
                String string = GLFW.glfwGetClipboardString((long)Main.mc.getWindow().getHandle());
                if (string != null) {
                    String string2 = string.trim();
                    if (this.l.length() + string2.length() <= 64) {
                        this.l.append(string2);
                    }
                }
                return true;
            }
            String string = GLFW.glfwGetKeyName((int)mc27.key(), (int)mc27.scancode());
            if (string != null && !string.isEmpty() && this.l.length() < 64) {
                this.l.append(string);
                return true;
            }
            return true;
        }
        return super.keyPressed(mc27);
    }

    public boolean mouseScrolled(double d2, double d3, double d4, double d5) {
        this.r += (float)d5 * 12.0f;
        return true;
    }

    protected void applyBlur(DrawContext mc15) {
    }

    public void render(DrawContext mc15, int n2, int n3, float f2) {
        MatrixStack mc13 = new MatrixStack();
        float f3 = GuiRenderer.a(b, this.g ? 0.0f : 1.0f, 0.06f);
        if (this.g && f3 <= 0.01f) {
            this.g = false;
            GuiRenderer.b(b);
            Main.mc.setScreen(null);
            return;
        }
        float f4 = RenderScale.c();
        float f5 = RenderScale.d();
        new PanelRenderer(mc13, 0.0f, 0.0f, f4, f5).a(GuiRenderer.a(c, (int)((float)c.getAlpha() * f3))).j();
        float f6 = 320.0f;
        float f7 = f5 * 0.7f;
        float f8 = (f4 - f6) * 0.5f;
        float f9 = (f5 - f7) * 0.5f;
        float f10 = GuiRenderer.g(f3);
        float f11 = 0.85f + 0.15f * f10;
        float f12 = f8 + f6 * 0.5f;
        float f13 = f9 + f7 * 0.5f;
        mc13.push();
        mc13.translate(f12, f13, 0.0f);
        mc13.scale(f11, f11, 1.0f);
        mc13.translate(-f12, -f13, 0.0f);
        new PanelRenderer(mc13, f8, f9, f6, f7).a(GuiRenderer.a(new Color(12, 12, 16), (int)(240.0f * f3))).a(16.0f, 1.0f).a(12.0f).j();
        float f14 = 40.0f;
        Color color = MenuGuiScreen.c();
        float f15 = 14.0f;
        float f16 = f8 + 14.0f;
        float f17 = f9 + (f14 - f15) * 0.5f;
        GuiRenderer.a(mc13, "folder", f16, f17, f15, f15, GuiRenderer.a(color, (int)(255.0f * f3)));
        FontManager.a().a(mc13, new StringConstant("Configs"), f16 + f15 + 8.0f, f9 + f14 * 0.28f, 10.0f, GuiRenderer.a(Color.WHITE, (int)(255.0f * f3)));
        StringConstant stringConstant = new StringConstant("Import");
        float f18 = FontManager.a().a(stringConstant, 7.0f);
        float f19 = 10.0f;
        float f20 = 8.0f;
        float f21 = f19 + 5.0f + f18 + f20 * 2.0f;
        float f22 = 20.0f;
        float f23 = f8 + f6 - f21 - 10.0f;
        float f24 = f9 + (f14 - f22) * 0.5f;
        float f25 = (float)RenderScale.j();
        float f26 = (float)RenderScale.k();
        boolean bl = f25 >= f23 && f25 <= f23 + f21 && f26 >= f24 && f26 <= f24 + f22;
        float f27 = GuiRenderer.a("config.header.import.hover", bl ? 1.0f : 0.0f, 0.12f);
        new PanelRenderer(mc13, f23, f24, f21, f22).a(GuiRenderer.a(GuiRenderer.a(new Color(40, 40, 48), new Color(60, 60, 72), f27), (int)(200.0f * f3))).a(5.0f).j();
        GuiRenderer.a(mc13, "users", f23 + f20, f24 + (f22 - f19) * 0.5f, f19, f19, GuiRenderer.a(color, (int)(255.0f * f3)));
        FontManager.a().a(mc13, stringConstant, f23 + f20 + f19 + 5.0f, f24 + f22 * 0.28f, 7.0f, GuiRenderer.a(Color.WHITE, (int)(255.0f * f3)));
        this.s = f23;
        this.t = f24;
        this.u = f21;
        this.v = f22;
        new PanelRenderer(mc13, f8 + 12.0f, f9 + f14 - 1.0f, f6 - 24.0f, 1.0f).a(GuiRenderer.a(new Color(255, 255, 255), (int)(20.0f * f3))).j();
        float f28 = f9 + f14 + 6.0f;
        float f29 = f7 - f14 - 12.0f;
        float f30 = f8 + 10.0f;
        float f31 = f6 - 20.0f;
        this.q += this.r;
        this.r *= 0.85f;
        if (Math.abs(this.r) < 0.01f) {
            this.r = 0.0f;
        }
        float f32 = 52.0f;
        float f33 = 6.0f;
        float f34 = (float)ConfigManager.getInstance().b().size() * (f32 + f33);
        float f35 = Math.max(0.0f, f34 - f29);
        this.q = GuiRenderer.b(this.q, -f35, 0.0f);
        GuiRenderer.a(f30, f28, f31, f29);
        float f36 = (float)RenderScale.j();
        float f37 = (float)RenderScale.k();
        this.a(f36, f37, f30, f28, f31, f29, f32, f33);
        List list = ConfigManager.getInstance().b();
        for (int j = 0; j < list.size(); ++j) {
            float f38;
            float f39;
            ConfigEntry configEntry = (ConfigEntry)list.get(j);
            float f40 = f28 + this.q + (float)j * (f32 + f33);
            if (f40 + f32 < f28 || f40 > f28 + f29) continue;
            boolean bl2 = configEntry == ConfigManager.getInstance().c();
            boolean bl3 = f36 >= f30 && f36 <= f30 + f31 && f37 >= Math.max(f40, f28) && f37 <= Math.min(f40 + f32, f28 + f29) && f37 >= f28 && f37 <= f28 + f29;
            float f41 = GuiRenderer.a("config.card." + j, bl3 ? 1.0f : 0.0f, 0.12f);
            Color color2 = GuiRenderer.a(d, e, f41);
            int n4 = (int)((float)color2.getAlpha() * f3);
            new PanelRenderer(mc13, f30, f40, f31, f32).a(GuiRenderer.a(color2, n4)).a(12.0f, 1.0f).a(8.0f).j();
            if (bl2) {
                new PanelRenderer(mc13, f30, f40, 3.0f, f32).a(GuiRenderer.a(color, (int)(220.0f * f3))).a(3.0f, 0.0f, 3.0f, 0.0f).j();
            }
            float f42 = f30 + 12.0f;
            int n5 = (int)(255.0f * f3);
            FontManager.a().a(mc13, new StringConstant(configEntry.c()), f42, f40 + 10.0f, 8.0f, GuiRenderer.a(bl2 ? color : Color.WHITE, n5));
            if (configEntry.d() != null && !configEntry.d().isEmpty()) {
                FontManager.a().a(mc13, new StringConstant(configEntry.d()), f42, f40 + 24.0f, 6.5f, GuiRenderer.a(new Color(150, 150, 150), n5));
            }
            if (bl2) {
                StringConstant stringConstant2 = new StringConstant("Active");
                f39 = FontManager.a().a(stringConstant2, 5.5f) + 8.0f;
                f38 = 14.0f;
                float f43 = f30 + f31 - f39 - 8.0f;
                float f44 = f40 + (f32 - f38) * 0.5f;
                new PanelRenderer(mc13, f43, f44, f39, f38).a(GuiRenderer.a(f, (int)(40.0f * f3))).a(4.0f).j();
                FontManager.a().a(mc13, stringConstant2, f43 + 4.0f, f44 + f38 * 0.2f, 5.5f, GuiRenderer.a(f, n5));
            }
            if (!configEntry.h()) continue;
            float f45 = 10.0f;
            f39 = f30 + f31 - f45 - 8.0f - (bl2 ? 52.0f : 0.0f);
            f38 = f40 + (f32 - f45) * 0.5f;
            GuiRenderer.a(mc13, "users", f39, f38, f45, f45, GuiRenderer.a(new Color(150, 180, 255), (int)(180.0f * f3)));
        }
        if (list.isEmpty()) {
            StringConstant stringConstant3 = new StringConstant("Right-click to create a config");
            float f46 = FontManager.a().a(stringConstant3, 7.0f);
            FontManager.a().a(mc13, stringConstant3, f30 + (f31 - f46) * 0.5f, f28 + f29 * 0.4f, 7.0f, GuiRenderer.a(new Color(100, 100, 100), (int)(200.0f * f3)));
        }
        GuiRenderer.b();
        mc13.pop();
        this.a(new MatrixStack(), f3);
    }

    private void a(float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9) {
        boolean bl;
        long l2 = Main.mc.getWindow().getHandle();
        boolean bl2 = GLFW.glfwGetMouseButton((long)l2, (int)0) == 1;
        boolean bl3 = GLFW.glfwGetMouseButton((long)l2, (int)1) == 1;
        boolean bl4 = bl2 && !this.o;
        boolean bl5 = bl3 && !this.p;
        this.o = bl2;
        this.p = bl3;
        if (this.h != ConfigScreenMode.NONE) {
            return;
        }
        boolean bl6 = bl = this.u > 0.0f && f2 >= this.s && f2 <= this.s + this.u && f3 >= this.t && f3 <= this.t + this.v;
        if (bl4 && bl) {
            this.j = this.s + this.u * 0.5f;
            this.k = this.t + this.v;
            this.h = ConfigScreenMode.IMPORT;
            this.l.setLength(0);
            this.m.setLength(0);
            this.n = 0;
            GuiRenderer.b("config.popup", 0.0f);
            SoundManager.b();
            return;
        }
        boolean bl7 = f2 >= f4 && f2 <= f4 + f6 && f3 >= f5 && f3 <= f5 + f7;
        List list = ConfigManager.getInstance().b();
        ConfigEntry configEntry = null;
        if (bl7) {
            for (int j = 0; j < list.size(); ++j) {
                float f10 = f5 + this.q + (float)j * (f8 + f9);
                if (!(f3 >= Math.max(f10, f5)) || !(f3 <= Math.min(f10 + f8, f5 + f7))) continue;
                configEntry = (ConfigEntry)list.get(j);
                break;
            }
        }
        if (bl4 && configEntry != null) {
            this.i = configEntry;
            this.j = f2;
            this.k = f3;
            this.h = ConfigScreenMode.CONFIRM_LOAD;
            GuiRenderer.b("config.popup", 0.0f);
            SoundManager.b();
        }
        if (bl5 && bl7) {
            this.j = f2;
            this.k = f3;
            if (configEntry != null) {
                this.i = configEntry;
                this.h = ConfigScreenMode.EDIT;
            } else {
                this.i = null;
                this.h = ConfigScreenMode.CREATE;
                this.l.setLength(0);
                this.m.setLength(0);
                this.n = 0;
            }
            GuiRenderer.b("config.popup", 0.0f);
            SoundManager.b();
        }
    }

    private void a(MatrixStack mc13, float f2) {
        if (this.h == ConfigScreenMode.NONE) {
            return;
        }
        float f3 = GuiRenderer.a("config.popup", this.h != ConfigScreenMode.NONE ? 1.0f : 0.0f, 0.06f);
        float f4 = GuiRenderer.g(f3);
        if (f3 < 0.01f) {
            this.h = ConfigScreenMode.NONE;
            this.i = null;
            return;
        }
        switch (this.h.ordinal()) {
            case 1: {
                this.getInstance(mc13, f2, f3, f4);
                break;
            }
            case 2: {
                this.b(mc13, f2, f3, f4);
                break;
            }
            case 3: {
                this.d(mc13, f2, f3, f4);
                break;
            }
            case 4: {
                this.c(mc13, f2, f3, f4);
            }
        }
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4) {
        if (this.i == null) {
            return;
        }
        float f5 = f4;
        float f6 = 180.0f;
        float f7 = 90.0f;
        float f8 = 10.0f;
        float f9 = 10.0f;
        float f10 = this.getInstance(this.j, f6 * f5);
        float f11 = this.b(this.k, f7 * f5);
        float f12 = f6 * f5;
        float f13 = f7 * f5;
        int n2 = (int)(240.0f * f3 * f2);
        Color color = MenuGuiScreen.c();
        this.a(mc13, n2);
        new PanelRenderer(mc13, f10, f11, f12, f13).a(GuiRenderer.a(new Color(18, 18, 22), n2)).a(16.0f, 1.0f).a(f8 * f5).j();
        if (f3 < 0.4f) {
            return;
        }
        float f14 = GuiRenderer.b((f3 - 0.3f) / 0.7f, 0.0f, 1.0f) * f2;
        int n3 = (int)(f14 * 255.0f);
        float f15 = 10.0f * f5;
        float f16 = f10 + f9 * f5;
        float f17 = f11 + (f9 + 1.0f) * f5;
        GuiRenderer.a(mc13, "folder", f16, f17, f15, f15, GuiRenderer.a(color, n3));
        FontManager.a().a(mc13, new StringConstant("Load Config?"), f16 + f15 + 4.0f * f5, f11 + f9 * f5, 8.0f * f5, GuiRenderer.a(Color.WHITE, n3));
        FontManager.a().a(mc13, new StringConstant(this.i.c()), f10 + f9 * f5, f11 + (f9 + 18.0f) * f5, 7.0f * f5, GuiRenderer.a(color, n3));
        float f18 = (f6 - f9 * 3.0f) * 0.5f;
        float f19 = 22.0f;
        float f20 = f11 + (f7 - f19 - f9) * f5;
        float f21 = f10 + f9 * f5;
        float f22 = f18 * f5;
        float f23 = f19 * f5;
        float f24 = GuiRenderer.a("config.popup.load.hover", this.a(f21, f20, f22, f23) ? 1.0f : 0.0f, 0.12f);
        new PanelRenderer(mc13, f21, f20, f22, f23).a(GuiRenderer.a(GuiRenderer.a(color, GuiRenderer.b(color, 1.3f), f24), (int)(200.0f * f14))).a(6.0f * f5).j().a(0, () -> ((ConfigScreen)this).lambda$drawConfirmLoadPopup$0());
        FontManager.a().a(mc13, new StringConstant("Load"), f21 + f22 * 0.3f, f20 + f23 * 0.25f, 7.0f * f5, GuiRenderer.a(Color.WHITE, n3));
        float f25 = f10 + (f9 * 2.0f + f18) * f5;
        float f26 = f18 * f5;
        float f27 = GuiRenderer.a("config.popup.cancel.hover", this.a(f25, f20, f26, f23) ? 1.0f : 0.0f, 0.12f);
        new PanelRenderer(mc13, f25, f20, f26, f23).a(GuiRenderer.a(GuiRenderer.a(new Color(50, 50, 55), new Color(70, 70, 75), f27), (int)(200.0f * f14))).a(6.0f * f5).j().a(0, () -> ((ConfigScreen)this).lambda$drawConfirmLoadPopup$1());
        FontManager.a().a(mc13, new StringConstant("Cancel"), f25 + f26 * 0.22f, f20 + f23 * 0.25f, 7.0f * f5, GuiRenderer.a(Color.WHITE, n3));
    }

    private void b(MatrixStack mc13, float f2, float f3, float f4) {
        this.a(mc13, f2, f3, f4, "New Config", "Create", null);
    }

    private void c(MatrixStack mc13, float f2, float f3, float f4) {
        float f5 = f4;
        float f6 = 240.0f;
        float f7 = 110.0f;
        float f8 = 10.0f;
        float f9 = 10.0f;
        float f10 = this.getInstance(this.j, f6 * f5);
        float f11 = this.b(this.k, f7 * f5);
        float f12 = f6 * f5;
        float f13 = f7 * f5;
        int n2 = (int)(240.0f * f3 * f2);
        Color color = MenuGuiScreen.c();
        this.a(mc13, n2);
        new PanelRenderer(mc13, f10, f11, f12, f13).a(GuiRenderer.a(new Color(18, 18, 22), n2)).a(16.0f, 1.0f).a(f8 * f5).j();
        if (f3 < 0.4f) {
            return;
        }
        float f14 = GuiRenderer.b((f3 - 0.3f) / 0.7f, 0.0f, 1.0f) * f2;
        int n3 = (int)(f14 * 255.0f);
        float f15 = 10.0f * f5;
        float f16 = f10 + f9 * f5;
        float f17 = f11 + (f9 + 1.0f) * f5;
        GuiRenderer.a(mc13, "users", f16, f17, f15, f15, GuiRenderer.a(color, n3));
        FontManager.a().a(mc13, new StringConstant("Import by ID"), f16 + f15 + 4.0f * f5, f11 + f9 * f5, 8.0f * f5, GuiRenderer.a(Color.WHITE, n3));
        float f18 = f10 + f9 * f5;
        float f19 = (f6 - f9 * 2.0f) * f5;
        float f20 = 20.0f * f5;
        float f21 = f11 + (f9 + 20.0f) * f5;
        this.a(mc13, f18, f21, f19, f20, f5, this.l.toString(), "Paste config ID", true, f14, color);
        float f22 = 22.0f;
        float f23 = f9;
        float f24 = (f6 - f9 * 3.0f) * 0.5f;
        float f25 = f11 + (f7 - f22 - f9) * f5;
        float f26 = f22 * f5;
        float f27 = f18;
        float f28 = f24 * f5;
        float f29 = GuiRenderer.a("config.popup.import.hover", this.a(f27, f25, f28, f26) ? 1.0f : 0.0f, 0.12f);
        new PanelRenderer(mc13, f27, f25, f28, f26).a(GuiRenderer.a(GuiRenderer.a(color, GuiRenderer.b(color, 1.3f), f29), (int)(200.0f * f14))).a(6.0f * f5).j().a(0, () -> ((ConfigScreen)this).lambda$drawImportPopup$2());
        float f30 = 8.0f * f5;
        float f31 = f27 + 6.0f * f5;
        float f32 = f25 + (f26 - f30) * 0.5f;
        GuiRenderer.a(mc13, "users", f31, f32, f30, f30, GuiRenderer.a(Color.WHITE, n3));
        FontManager.a().a(mc13, new StringConstant("Import"), f31 + f30 + 3.0f * f5, f25 + f26 * 0.25f, 7.0f * f5, GuiRenderer.a(Color.WHITE, n3));
        float f33 = f27 + (f24 + f23) * f5;
        float f34 = f24 * f5;
        float f35 = GuiRenderer.a("config.popup.import.cancel.hover", this.a(f33, f25, f34, f26) ? 1.0f : 0.0f, 0.12f);
        new PanelRenderer(mc13, f33, f25, f34, f26).a(GuiRenderer.a(GuiRenderer.a(new Color(50, 50, 55), new Color(70, 70, 75), f35), (int)(200.0f * f14))).a(6.0f * f5).j().a(0, () -> ((ConfigScreen)this).lambda$drawImportPopup$3());
        FontManager.a().a(mc13, new StringConstant("Cancel"), f33 + f34 * 0.22f, f25 + f26 * 0.25f, 7.0f * f5, GuiRenderer.a(Color.WHITE, n3));
    }

    private void d(MatrixStack mc13, float f2, float f3, float f4) {
        if (this.i == null) {
            return;
        }
        if (this.l.length() == 0 && this.m.length() == 0) {
            this.l.append(this.i.c());
            if (this.i.d() != null) {
                this.m.append(this.i.d());
            }
            this.n = 0;
        }
        this.a(mc13, f2, f3, f4, "Edit Config", "Save", this.i);
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, String string, String string2, ConfigEntry configEntry) {
        boolean bl;
        float f5 = f4;
        float f6 = 220.0f;
        float f7 = configEntry != null ? 180.0f : 140.0f;
        float f8 = 10.0f;
        float f9 = 10.0f;
        float f10 = this.getInstance(this.j, f6 * f5);
        float f11 = this.b(this.k, f7 * f5);
        float f12 = f6 * f5;
        float f13 = f7 * f5;
        int n2 = (int)(240.0f * f3 * f2);
        Color color = MenuGuiScreen.c();
        this.a(mc13, n2);
        new PanelRenderer(mc13, f10, f11, f12, f13).a(GuiRenderer.a(new Color(18, 18, 22), n2)).a(16.0f, 1.0f).a(f8 * f5).j();
        if (f3 < 0.4f) {
            return;
        }
        float f14 = GuiRenderer.b((f3 - 0.3f) / 0.7f, 0.0f, 1.0f) * f2;
        int n3 = (int)(f14 * 255.0f);
        float f15 = 10.0f * f5;
        float f16 = f10 + f9 * f5;
        float f17 = f11 + (f9 + 1.0f) * f5;
        String string3 = configEntry != null ? "write" : "folder";
        GuiRenderer.a(mc13, string3, f16, f17, f15, f15, GuiRenderer.a(color, n3));
        FontManager.a().a(mc13, new StringConstant(string), f16 + f15 + 4.0f * f5, f11 + f9 * f5, 8.0f * f5, GuiRenderer.a(Color.WHITE, n3));
        float f18 = f10 + f9 * f5;
        float f19 = (f6 - f9 * 2.0f) * f5;
        float f20 = 20.0f * f5;
        float f21 = f11 + (f9 + 20.0f) * f5;
        this.a(mc13, f18, f21, f19, f20, f5, this.l.toString(), "Name", this.n == 0, f14, color);
        float f22 = f11 + (f9 + 46.0f) * f5;
        this.a(mc13, f18, f22, f19, f20, f5, this.m.toString(), "Description", this.n == 1, f14, color);
        float f23 = 22.0f;
        float f24 = f9;
        boolean bl2 = bl = configEntry != null;
        if (bl) {
            float f25 = (f6 - f9 * 3.0f) * 0.5f;
            float f26 = f11 + (f7 - f23 * 2.0f - f24 - f9) * f5;
            float f27 = f26 + (f23 + f24) * f5;
            float f28 = f18;
            float f29 = f25 * f5;
            float f30 = f23 * f5;
            float f31 = GuiRenderer.a("config.popup.confirm.hover", this.a(f28, f26, f29, f30) ? 1.0f : 0.0f, 0.12f);
            new PanelRenderer(mc13, f28, f26, f29, f30).a(GuiRenderer.a(GuiRenderer.a(color, GuiRenderer.b(color, 1.3f), f31), (int)(200.0f * f14))).a(6.0f * f5).j().a(0, () -> ((ConfigScreen)this).lambda$drawInputPopup$4());
            float f32 = 8.0f * f5;
            float f33 = f28 + 6.0f * f5;
            float f34 = f26 + (f30 - f32) * 0.5f;
            GuiRenderer.a(mc13, "write", f33, f34, f32, f32, GuiRenderer.a(Color.WHITE, n3));
            FontManager.a().a(mc13, new StringConstant(string2), f33 + f32 + 3.0f * f5, f26 + f30 * 0.25f, 7.0f * f5, GuiRenderer.a(Color.WHITE, n3));
            float f35 = f28 + (f25 + f24) * f5;
            float f36 = GuiRenderer.a("config.popup.share.hover", this.a(f35, f26, f29, f30) ? 1.0f : 0.0f, 0.12f);
            new PanelRenderer(mc13, f35, f26, f29, f30).a(GuiRenderer.a(GuiRenderer.a(new Color(60, 80, 140), new Color(80, 100, 170), f36), (int)(200.0f * f14))).a(6.0f * f5).j().a(0, () -> this.lambda$drawInputPopup$5((ConfigEntry)configEntry));
            float f37 = 8.0f * f5;
            float f38 = f35 + 6.0f * f5;
            float f39 = f26 + (f30 - f37) * 0.5f;
            GuiRenderer.a(mc13, "share", f38, f39, f37, f37, GuiRenderer.a(Color.WHITE, n3));
            FontManager.a().a(mc13, new StringConstant("Share"), f38 + f37 + 3.0f * f5, f26 + f30 * 0.25f, 7.0f * f5, GuiRenderer.a(Color.WHITE, n3));
            float f40 = f18;
            boolean bl3 = configEntry.b() && configEntry.a().equals(ClientSettings.getInstance().j());
            Color color2 = bl3 ? new Color(50, 120, 70) : new Color(60, 60, 80);
            Color color3 = bl3 ? new Color(60, 140, 80) : new Color(80, 80, 100);
            float f41 = GuiRenderer.a("config.popup.default.hover", this.a(f40, f27, f29, f30) ? 1.0f : 0.0f, 0.12f);
            new PanelRenderer(mc13, f40, f27, f29, f30).a(GuiRenderer.a(GuiRenderer.a(color2, color3, f41), (int)(200.0f * f14))).a(6.0f * f5).j().a(0, () -> this.lambda$drawInputPopup$6((ConfigEntry)configEntry));
            float f42 = 8.0f * f5;
            float f43 = f40 + 6.0f * f5;
            float f44 = f27 + (f30 - f42) * 0.5f;
            GuiRenderer.a(mc13, "folder", f43, f44, f42, f42, GuiRenderer.a(Color.WHITE, n3));
            FontManager.a().a(mc13, new StringConstant(bl3 ? "Default" : "Set default"), f43 + f42 + 3.0f * f5, f27 + f30 * 0.25f, 7.0f * f5, GuiRenderer.a(Color.WHITE, n3));
            float f45 = f40 + (f25 + f24) * f5;
            float f46 = GuiRenderer.a("config.popup.del.hover", this.a(f45, f27, f29, f30) ? 1.0f : 0.0f, 0.12f);
            new PanelRenderer(mc13, f45, f27, f29, f30).a(GuiRenderer.a(GuiRenderer.a(new Color(140, 50, 50), new Color(170, 60, 60), f46), (int)(200.0f * f14))).a(6.0f * f5).j().a(0, () -> ((ConfigScreen)this).lambda$drawInputPopup$7((ConfigEntry)configEntry));
            float f47 = 8.0f * f5;
            float f48 = f45 + 6.0f * f5;
            float f49 = f27 + (f30 - f47) * 0.5f;
            GuiRenderer.a(mc13, "remove", f48, f49, f47, f47, GuiRenderer.a(Color.WHITE, n3));
            FontManager.a().a(mc13, new StringConstant("Delete"), f48 + f47 + 3.0f * f5, f27 + f30 * 0.25f, 7.0f * f5, GuiRenderer.a(Color.WHITE, n3));
        } else {
            float f50 = f18;
            float f51 = f11 + (f7 - f23 - f9) * f5;
            float f52 = 2.0f;
            float f53 = (f6 - f9 * (f52 + 1.0f)) / f52;
            float f54 = f53 * f5;
            float f55 = f23 * f5;
            float f56 = GuiRenderer.a("config.popup.confirm.hover", this.a(f50, f51, f54, f55) ? 1.0f : 0.0f, 0.12f);
            new PanelRenderer(mc13, f50, f51, f54, f55).a(GuiRenderer.a(GuiRenderer.a(color, GuiRenderer.b(color, 1.3f), f56), (int)(200.0f * f14))).a(6.0f * f5).j().a(0, () -> ((ConfigScreen)this).lambda$drawInputPopup$8());
            FontManager.a().a(mc13, new StringConstant(string2), f50 + f54 * 0.2f, f51 + f55 * 0.25f, 7.0f * f5, GuiRenderer.a(Color.WHITE, n3));
            float f57 = f18 + (f53 + f24) * f5;
            float f58 = f53 * f5;
            float f59 = GuiRenderer.a("config.popup.del.hover", this.a(f57, f51, f58, f55) ? 1.0f : 0.0f, 0.12f);
            new PanelRenderer(mc13, f57, f51, f58, f55).a(GuiRenderer.a(GuiRenderer.a(new Color(50, 50, 55), new Color(70, 70, 75), f59), (int)(200.0f * f14))).a(6.0f * f5).j().a(0, () -> ((ConfigScreen)this).lambda$drawInputPopup$9());
            FontManager.a().a(mc13, new StringConstant("Cancel"), f57 + f58 * 0.15f, f51 + f55 * 0.25f, 7.0f * f5, GuiRenderer.a(Color.WHITE, n3));
        }
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, String string, String string2, boolean bl, float f7, Color color) {
        int n2 = (int)(f7 * 255.0f);
        float f8 = GuiRenderer.a("config.input." + string2, bl ? 1.0f : 0.0f, 0.12f);
        Color color2 = GuiRenderer.a(new Color(50, 50, 55), color, f8);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(10, 10, 14), (int)(200.0f * f7))).a(5.0f * f6).j();
        GuiRenderer.a(mc13, f2, f3, f4, f5, 1.0f * f6, 5.0f * f6, GuiRenderer.a(color2, (int)(120.0f * f7)));
        String string3 = string.isEmpty() ? string2 : string;
        Color color3 = string.isEmpty() ? GuiRenderer.a(new Color(80, 80, 80), n2) : GuiRenderer.a(Color.WHITE, n2);
        FontManager.a().a(mc13, new StringConstant(string3), f2 + 6.0f * f6, f3 + f5 * 0.22f, 6.5f * f6, color3);
        if (bl && System.currentTimeMillis() / 500L % 2L == 0L) {
            float f9 = f2 + 6.0f * f6 + FontManager.a().a(new StringConstant(string), 6.5f * f6);
            new PanelRenderer(mc13, f9, f3 + 4.0f * f6, 1.0f * f6, f5 - 8.0f * f6).a(GuiRenderer.a(Color.WHITE, n2)).j();
        }
    }

    private void a(MatrixStack mc13, int n2) {
        float f2 = 5.0f;
        new PanelRenderer(mc13, this.j - f2 * 0.5f, this.k - f2 * 0.5f, f2, f2).a(GuiRenderer.a(new Color(18, 18, 22), n2)).a(2.0f).j();
    }

    private void b() {
        String string = this.l.toString().trim();
        if (string.isEmpty()) {
            return;
        }
        String string2 = this.m.toString().trim();
        if (this.h == ConfigScreenMode.CREATE) {
            ConfigEntry configEntry = new ConfigEntry(string, string2);
            this.d();
            ConfigManager.getInstance().a(configEntry, null, ConfigScreen.e());
        } else if (this.h == ConfigScreenMode.EDIT && this.i != null) {
            this.i.b(string);
            this.i.c(string2);
            ConfigEntry configEntry = this.i;
            this.d();
            ConfigManager.getInstance().a(configEntry, null, ConfigScreen.e());
        } else {
            this.d();
        }
    }

    private void c() {
        String string = this.l.toString().trim();
        if (string.isEmpty()) {
            return;
        }
        this.d();
        ConfigManager.getInstance().a(string, null, ConfigScreen.e());
    }

    private void d() {
        this.h = ConfigScreenMode.NONE;
        this.i = null;
        this.l.setLength(0);
        this.m.setLength(0);
        this.n = 0;
    }

    private static Consumer e() {
        return this::lambda$onErr$10;
    }

    private boolean a(float f2, float f3, float f4, float f5) {
        double d2 = RenderScale.j();
        double d3 = RenderScale.k();
        return d2 >= (double)f2 && d2 <= (double)(f2 + f4) && d3 >= (double)f3 && d3 <= (double)(f3 + f5);
    }

    private float a(float f2, float f3) {
        if (f2 + f3 > RenderScale.c()) {
            return RenderScale.c() - f3 - 4.0f;
        }
        return f2;
    }

    private float b(float f2, float f3) {
        if (f2 + f3 > RenderScale.d()) {
            return RenderScale.d() - f3 - 4.0f;
        }
        return f2;
    }

    public boolean shouldPause() {
        return false;
    }

    public void close() {
        if (!this.g) {
            this.g = true;
        }
    }

    private static void lambda$onErr$10(String string) {
    }

    private void lambda$drawInputPopup$9() {
        this.d();
        SoundManager.b();
    }

    private void lambda$drawInputPopup$8() {
        this.b();
        SoundManager.b();
    }

    private void lambda$drawInputPopup$7(ConfigEntry configEntry) {
        ConfigEntry configEntry2 = configEntry;
        this.d();
        SoundManager.b();
        ConfigManager.getInstance().c(configEntry2, null, ConfigScreen.e());
    }

    private static void lambda$drawInputPopup$6(ConfigEntry configEntry) {
        SoundManager.b();
        if (configEntry.b()) {
            ClientSettings.getInstance().b(configEntry.a());
        }
    }

    private static void lambda$drawInputPopup$5(ConfigEntry configEntry) {
        SoundManager.b();
        ConfigManager.getInstance().a(configEntry, null, ConfigScreen.e());
    }

    private void lambda$drawInputPopup$4() {
        this.b();
        SoundManager.b();
    }

    private void lambda$drawImportPopup$3() {
        this.d();
        SoundManager.b();
    }

    private void lambda$drawImportPopup$2() {
        this.c();
        SoundManager.b();
    }

    private void lambda$drawConfirmLoadPopup$1() {
        this.d();
        SoundManager.b();
    }

    private void lambda$drawConfirmLoadPopup$0() {
        ConfigEntry configEntry = this.i;
        this.d();
        SoundManager.b();
        if (configEntry != null) {
            ConfigManager.getInstance().b(configEntry, null, ConfigScreen.e());
        }
    }
}

