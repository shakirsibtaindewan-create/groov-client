/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.screen;

import itz.vrgn1337.groovclient.api.backend.FriendEntry;
import itz.vrgn1337.groovclient.api.backend.SocialService;
import itz.vrgn1337.groovclient.api.util.SoundManager;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.config.ClientSettings;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.screen.DirectMessageScreen;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import itz.vrgn1337.groovclient.gui.screen.SettingsScreen;
import itz.vrgn1337.groovclient.module.utility.TargetFilter;
import itz.vrgn1337.groovclient.social.Friend;
import itz.vrgn1337.groovclient.social.FriendManager;
import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;
import net.minecraft.client.input.KeyInput;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.entity.player.SkinTextures;
import org.lwjgl.glfw.GLFW;

public class FriendsScreen
extends Screen {
    private static final FriendsScreen a = new FriendsScreen();
    private static final String b = "friends.screen.open";
    private static final Color c = new Color(0, 0, 0, 80);
    private boolean d = false;
    private final StringBuilder e = new StringBuilder();
    private boolean f = false;
    private boolean g = false;
    private float h;
    private float i;
    private float j;
    private float k;
    private static final Pattern l = Pattern.compile("^[A-Za-z0-9_]{3,16}$");
    private float m = 0.0f;
    private float n = 0.0f;
    private float o = 0.0f;
    private float p = 0.0f;

    public static FriendsScreen getInstance() {
        return a;
    }

    protected FriendsScreen() {
        super((Text)Text.empty());
    }

    public void init() {
        this.d = false;
        GuiRenderer.b(b, 0.0f);
    }

    public boolean keyPressed(KeyInput mc27) {
        String string;
        if (mc27.key() == 256) {
            this.d = true;
            return true;
        }
        if (mc27.key() == 258) {
            this.f = !this.f;
            return true;
        }
        if (mc27.key() == 257) {
            this.c();
            return true;
        }
        if (mc27.key() == 259) {
            if (this.e.length() > 0) {
                this.e.deleteCharAt(this.e.length() - 1);
            }
            return true;
        }
        if (this.f && (string = GLFW.glfwGetKeyName((int)mc27.key(), (int)mc27.scancode())) != null && !string.isEmpty()) {
            if (this.e.length() < 40) {
                this.e.append(string);
            }
            return true;
        }
        return super.keyPressed(mc27);
    }

    public boolean mouseScrolled(double d2, double d3, double d4, double d5) {
        float f2 = (float)RenderScale.j();
        float f3 = (float)RenderScale.k();
        float f4 = RenderScale.c();
        float f5 = RenderScale.d();
        float f6 = 500.0f;
        float f7 = Math.min(420.0f, f5 * 0.82f);
        float f8 = (f4 - f6) * 0.5f;
        float f9 = (f5 - f7) * 0.5f;
        float f10 = 40.0f;
        float f11 = 12.0f;
        float f12 = f9 + f10 + 70.0f;
        float f13 = f7 - f10 - 80.0f;
        float f14 = (f6 - f11 * 3.0f) * 0.5f;
        float f15 = f8 + f11;
        float f16 = f15 + f14 + f11;
        if (RenderScale.a(f15, f12, f14, f13)) {
            this.n += (float)d5 * 11.0f;
            return true;
        }
        if (RenderScale.a(f16, f12, f14, f13)) {
            this.p += (float)d5 * 11.0f;
            return true;
        }
        return RenderScale.a(f8, f9, f6, f7) || super.mouseScrolled(d2, d3, d4, d5);
    }

    protected void applyBlur(DrawContext mc15) {
    }

    public void render(DrawContext mc15, int n2, int n3, float f2) {
        MatrixStack mc13 = new MatrixStack();
        float f3 = GuiRenderer.a(b, this.d ? 0.0f : 1.0f, 0.06f);
        if (this.d && f3 <= 0.01f) {
            this.d = false;
            GuiRenderer.b(b);
            Main.mc.setScreen((Screen)SettingsScreen.getInstance());
            return;
        }
        float f4 = RenderScale.c();
        float f5 = RenderScale.d();
        new PanelRenderer(mc13, 0.0f, 0.0f, f4, f5).a(GuiRenderer.a(c, (int)((float)c.getAlpha() * f3))).j();
        float f6 = 500.0f;
        float f7 = Math.min(420.0f, f5 * 0.82f);
        float f8 = (f4 - f6) * 0.5f;
        float f9 = (f5 - f7) * 0.5f;
        float f10 = GuiRenderer.g(f3);
        float f11 = 0.85f + 0.15f * f10;
        float f12 = f8 + f6 * 0.5f;
        float f13 = f9 + f7 * 0.5f;
        mc13.push();
        mc13.translate(f12, f13, 0.0f);
        mc13.scale(f11, f11, 1.0f);
        mc13.translate(-f12, -f13, 0.0f);
        new PanelRenderer(mc13, f8, f9, f6, f7).a(GuiRenderer.a(new Color(12, 12, 16), (int)(240.0f * f3))).a(16.0f, 1.0f).a(12.0f).j();
        Color color = MenuGuiScreen.c();
        int n4 = (int)(255.0f * f3);
        float f14 = 40.0f;
        float f15 = 14.0f;
        float f16 = f8 + 14.0f;
        float f17 = f9 + (f14 - f15) * 0.5f;
        GuiRenderer.a(mc13, "users", f16, f17, f15, f15, GuiRenderer.a(color, n4));
        FontManager.a().a(mc13, new StringConstant("Friends"), f16 + f15 + 8.0f, f9 + f14 * 0.28f, 10.0f, GuiRenderer.a(Color.WHITE, n4));
        new PanelRenderer(mc13, f8 + 12.0f, f9 + f14 - 1.0f, f6 - 24.0f, 1.0f).a(GuiRenderer.a(new Color(255, 255, 255), (int)(20.0f * f3))).j();
        float f18 = 12.0f;
        float f19 = f9 + f14 + 10.0f;
        float f20 = 20.0f;
        float f21 = 230.0f;
        float f22 = 24.0f;
        float f23 = 8.0f;
        float f24 = f8 + f18;
        this.a(mc13, f24, f19 + 3.0f, f21, f20, "Nickname / UUID", this.e.toString(), this.f, f3, color);
        float f25 = f24 + f21 + f23;
        this.b(mc13, f25, f19 + 3.0f, f22, f20, "check", f3, new Color(55, 120, 72), () -> ((FriendsScreen)this).c());
        float f26 = 80.0f;
        float f27 = f8 + f6 - f26 - f18;
        this.b(mc13, f27, f19 + 3.0f, f26, f20, "Clear", f3, new Color(140, 55, 55), () -> ((FriendsScreen)this).lambda$render$0());
        this.j = 72.0f;
        this.k = f20;
        this.h = f27 - this.j - 8.0f;
        this.i = f19 + 3.0f;
        this.b(mc13, this.h, this.i, this.j, this.k, "Privacy", f3, new Color(70, 70, 88), () -> ((FriendsScreen)this).lambda$render$1());
        float f28 = 24.0f;
        float f29 = this.h - f28 - 8.0f;
        this.b(mc13, f29, f19 + 3.0f, f28, f20, "write", f3, new Color(60, 88, 150), () -> ((FriendsScreen)this).lambda$render$2());
        float f30 = f9 + f14 + 70.0f;
        float f31 = f7 - f14 - 80.0f;
        float f32 = (f6 - f18 * 3.0f) * 0.5f;
        float f33 = f8 + f18;
        float f34 = f33 + f32 + f18;
        int n5 = FriendManager.getInstance().b().stream().filter(arg_0 -> ((FriendsScreen)this).lambda$render$3(arg_0)).toList().size();
        int n6 = this.b().size();
        this.a(mc13, f33, f30 - 12.0f, "Friends", n5, f3, color);
        this.a(mc13, f34, f30 - 12.0f, "Same Server", n6, f3, color);
        this.getInstance(mc15, mc13, f33, f30, f32, f31, f3, color);
        this.b(mc15, mc13, f34, f30, f32, f31, f3, color);
        this.a(mc13, color);
        mc13.pop();
    }

    private void a(DrawContext mc15, MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, Color color) {
        List<a> list = FriendManager.getInstance().b().stream().filter(arg_0 -> ((FriendsScreen)this).lambda$drawFriendsList$4(arg_0)).toList();
        float f7 = 32.0f;
        float f8 = 4.0f;
        this.m += this.n;
        this.n *= 0.84f;
        if (Math.abs(this.n) < 0.01f) {
            this.n = 0.0f;
        }
        float f9 = Math.max(0.0f, (float)list.size() * (f7 + f8) - f5);
        this.m = GuiRenderer.b(this.m, -f9, 0.0f);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(new Color(18, 18, 24, (int)(210.0f * f6))).a(8.0f).j();
        GuiRenderer.a(f2, f3, f4, f5);
        for (int j = 0; j < list.size(); ++j) {
            boolean bl;
            Friend friend = (Friend)list.get(j);
            float f10 = f3 + this.m + (float)j * (f7 + f8);
            if (f10 + f7 < f3 || f10 > f3 + f5) continue;
            float f11 = GuiRenderer.a("friends.list.hover." + j, RenderScale.a(f2, f10, f4, f7) ? 1.0f : 0.0f, 0.12f);
            Color color2 = GuiRenderer.a(new Color(26, 26, 33), new Color(36, 36, 45), f11);
            new PanelRenderer(mc13, f2 + 4.0f, f10, f4 - 8.0f, f7).a(GuiRenderer.a(color2, (int)(220.0f * f6))).a(6.0f).j();
            float f12 = 20.0f;
            float f13 = f2 + 9.0f;
            float f14 = f10 + (f7 - f12) * 0.5f;
            if (f14 >= f3 && f14 + f12 <= f3 + f5) {
                this.getInstance(mc15, mc13, this.b(friend), f13, f14, f12, f6, color);
            }
            Color color3 = (bl = this.getInstance(friend)) ? new Color(72, 210, 110) : new Color(60, 60, 75);
            new PanelRenderer(mc13, f13 + f12 - 4.0f, f14 + f12 - 4.0f, 7.0f, 7.0f).a(GuiRenderer.a(new Color(18, 18, 24), (int)(240.0f * f6))).a(3.5f).j();
            new PanelRenderer(mc13, f13 + f12 - 3.0f, f14 + f12 - 3.0f, 5.0f, 5.0f).a(GuiRenderer.a(color3, (int)(230.0f * f6))).a(2.5f).j();
            String string = friend.b() == null ? "-" : friend.b().toString().substring(0, 8);
            FontManager.a().a(mc13, new StringConstant(friend.a().isBlank() ? "Unknown" : friend.a()), f2 + 34.0f, f10 + 8.0f, 7.0f, bl ? GuiRenderer.a(Color.WHITE, (int)(255.0f * f6)) : GuiRenderer.a(new Color(180, 180, 190), (int)(210.0f * f6)));
            FontManager.a().a(mc13, new StringConstant(bl ? "online" : string), f2 + 34.0f, f10 + 19.0f, 6.0f, bl ? new Color(72, 210, 110, (int)(180.0f * f6)) : new Color(100, 100, 110, (int)(180.0f * f6)));
            float f15 = 24.0f;
            float f16 = f2 + f4 - f15 - 10.0f;
            float f17 = f10 + 6.0f;
            new PanelRenderer(mc13, f16, f17, f15, 18.0f).a(GuiRenderer.a(new Color(135, 55, 55), (int)(220.0f * f6))).a(5.0f).j().a(0, () -> this.lambda$drawFriendsList$7((Friend)friend));
            GuiRenderer.a(mc13, "cross", f16 + 7.0f, f17 + 4.0f, 10.0f, 10.0f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)));
        }
        GuiRenderer.b();
        if (list.isEmpty()) {
            String string = "No friends added yet";
            float f18 = FontManager.a().a(new StringConstant(string), 6.5f);
            FontManager.a().a(mc13, new StringConstant(string), f2 + (f4 - f18) * 0.5f, f3 + f5 * 0.5f - 4.0f, 6.5f, new Color(65, 65, 80, (int)(200.0f * f6)));
        }
    }

    private void b(DrawContext mc15, MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, Color color) {
        List list = this.b();
        float f7 = 32.0f;
        float f8 = 4.0f;
        this.o += this.p;
        this.p *= 0.84f;
        if (Math.abs(this.p) < 0.01f) {
            this.p = 0.0f;
        }
        float f9 = Math.max(0.0f, (float)list.size() * (f7 + f8) - f5);
        this.o = GuiRenderer.b(this.o, -f9, 0.0f);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(new Color(18, 18, 24, (int)(210.0f * f6))).a(8.0f).j();
        GuiRenderer.a(f2, f3, f4, f5);
        for (int j = 0; j < list.size(); ++j) {
            PlayerEntity mc6 = (PlayerEntity)list.get(j);
            float f10 = f3 + this.o + (float)j * (f7 + f8);
            if (f10 + f7 < f3 || f10 > f3 + f5) continue;
            boolean bl = FriendManager.getInstance().a(mc6);
            float f11 = GuiRenderer.a("friends.nearby.hover." + j, RenderScale.a(f2, f10, f4, f7) ? 1.0f : 0.0f, 0.12f);
            Color color2 = GuiRenderer.a(new Color(26, 26, 33), new Color(36, 36, 45), f11);
            new PanelRenderer(mc13, f2 + 4.0f, f10, f4 - 8.0f, f7).a(GuiRenderer.a(color2, (int)(220.0f * f6))).a(6.0f).j();
            float f12 = 20.0f;
            float f13 = f2 + 9.0f;
            float f14 = f10 + (f7 - f12) * 0.5f;
            if (f14 >= f3 && f14 + f12 <= f3 + f5) {
                this.a(mc15, mc13, mc6, f13, f14, f12, f6, color);
            }
            double d2 = Main.mc.player == null ? 0.0 : Math.sqrt(mc6.squaredDistanceTo((Entity)Main.mc.player));
            FontManager.a().a(mc13, new StringConstant(mc6.getName().getString()), f2 + 34.0f, f10 + 8.0f, 7.0f, bl ? color : Color.WHITE);
            FontManager.a().a(mc13, new StringConstant(String.format("%.1fm", d2)), f2 + 34.0f, f10 + 19.0f, 6.0f, new Color(150, 150, 150));
            float f15 = 24.0f;
            float f16 = f2 + f4 - f15 - 10.0f;
            float f17 = f10 + 6.0f;
            Color color3 = bl ? new Color(135, 55, 55) : new Color(55, 120, 72);
            String string = bl ? "cross" : "check";
            new PanelRenderer(mc13, f16, f17, f15, 18.0f).a(GuiRenderer.a(color3, (int)(220.0f * f6))).a(5.0f).j().a(0, () -> this.lambda$drawNearbyList$8((boolean)bl, (PlayerEntity)mc6));
            GuiRenderer.a(mc13, string, f16 + 7.0f, f17 + 4.0f, 10.0f, 10.0f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)));
        }
        GuiRenderer.b();
        if (list.isEmpty()) {
            String string = "No players nearby";
            float f18 = FontManager.a().a(new StringConstant(string), 6.5f);
            FontManager.a().a(mc13, new StringConstant(string), f2 + (f4 - f18) * 0.5f, f3 + f5 * 0.5f - 4.0f, 6.5f, new Color(65, 65, 80, (int)(200.0f * f6)));
        }
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, float f5, String string, String string2, boolean bl, float f6, Color color) {
        float f7 = GuiRenderer.a("friends.input.focus." + string, bl ? 1.0f : 0.0f, 0.12f);
        Color color2 = GuiRenderer.a(new Color(50, 50, 55), color, f7);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(new Color(10, 10, 14, (int)(220.0f * f6))).a(6.0f).j().a(0, () -> ((FriendsScreen)this).lambda$drawInputField$9());
        GuiRenderer.a(mc13, f2, f3, f4, f5, 1.0f, 6.0f, GuiRenderer.a(color2, (int)(130.0f * f6)));
        String string3 = string2.isBlank() ? string : string2;
        Color color3 = string2.isBlank() ? new Color(90, 90, 90) : Color.WHITE;
        FontManager.a().a(mc13, new StringConstant(string3), f2 + 6.0f, f3 + 6.0f, 6.5f, color3);
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, float f5, String string, float f6, Color color, Runnable runnable) {
        float f7 = GuiRenderer.a("friends.btn." + string + "." + f2 + "." + f3, RenderScale.a(f2, f3, f4, f5) ? 1.0f : 0.0f, 0.12f);
        Color color2 = GuiRenderer.a(color, GuiRenderer.b(color, 1.2f), f7);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(color2, (int)(200.0f * f6))).a(6.0f).j().a(0, runnable);
        float f8 = FontManager.a().a(new StringConstant(string), 6.5f);
        FontManager.a().a(mc13, new StringConstant(string), f2 + (f4 - f8) * 0.5f, f3 + 6.0f, 6.5f, Color.WHITE);
    }

    private void b(MatrixStack mc13, float f2, float f3, float f4, float f5, String string, float f6, Color color, Runnable runnable) {
        float f7 = GuiRenderer.a("friends.icon.btn." + string + "." + f2 + "." + f3, RenderScale.a(f2, f3, f4, f5) ? 1.0f : 0.0f, 0.12f);
        Color color2 = GuiRenderer.a(color, GuiRenderer.b(color, 1.2f), f7);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(color2, (int)(200.0f * f6))).a(6.0f).j().a(0, runnable);
        GuiRenderer.a(mc13, string, f2 + (f4 - 10.0f) * 0.5f, f3 + (f5 - 10.0f) * 0.5f, 10.0f, 10.0f, Color.WHITE);
    }

    private void a(MatrixStack mc13, float f2, float f3, String string, int n2, float f4, Color color) {
        FontManager.a().a(mc13, new StringConstant(string), f2 + 2.0f, f3, 7.0f, GuiRenderer.a(Color.WHITE, (int)(220.0f * f4)));
        if (n2 >= 0) {
            String string2 = String.valueOf(n2);
            float f5 = FontManager.a().a(new StringConstant(string), 7.0f);
            float f6 = FontManager.a().a(new StringConstant(string2), 5.5f) + 7.0f;
            float f7 = f2 + 2.0f + f5 + 5.0f;
            new PanelRenderer(mc13, f7, f3 + 0.5f, f6, 8.5f).a(GuiRenderer.a(color, (int)(70.0f * f4))).a(4.0f).j();
            FontManager.a().a(mc13, new StringConstant(string2), f7 + 3.5f, f3 + 1.0f, 5.5f, GuiRenderer.a(color, (int)(200.0f * f4)));
        }
    }

    private boolean a(Friend friend) {
        String string = friend.a();
        if (string == null || string.isBlank()) {
            return false;
        }
        for (FriendEntry friendEntry : SocialService.getInstance().b()) {
            if (!friendEntry.a.equalsIgnoreCase(string)) continue;
            return friendEntry.c;
        }
        return false;
    }

    private List<FriendEntry> b() {
        if (Main.mc.world == null || Main.mc.player == null) {
            return List.of();
        }
        return Main.mc.world.getPlayers().stream().filter((arg_0) -> ((FriendsScreen)this).lambda$getNearbyPlayers$10(arg_0)).map((arg_0) -> ((FriendsScreen)this).lambda$getNearbyPlayers$11(arg_0)).filter(this::lambda$getNearbyPlayers$12).sorted(Comparator.comparingDouble((arg_0) -> ((FriendsScreen)this).lambda$getNearbyPlayers$13(arg_0))).toList();
    }

    private void a(String string) {
        String string2;
        if (string == null || string.isBlank()) {
            return;
        }
        PlayerEntity mc6 = this.b(string.trim());
        if (mc6 != null && TargetFilter.b((Entity)mc6)) {
            return;
        }
        UUID uUID = mc6 != null ? mc6.getUuid() : null;
        String string3 = string2 = mc6 != null ? mc6.getName().getString() : string.trim();
        if (FriendManager.getInstance().a(string2, uUID)) {
            SoundManager.b();
        }
        SocialService.getInstance().mouseScrolled(string2, string2, this::lambda$addByName$14, this::lambda$addByName$15);
    }

    private void a(UUID uUID, String string) {
        if (uUID == null) {
            return;
        }
        try {
            String string2;
            PlayerEntity mc6 = this.a(uUID);
            if (mc6 != null && TargetFilter.b((Entity)mc6)) {
                return;
            }
            String string3 = mc6 != null ? mc6.getName().getString() : (string2 = string == null || string.isBlank() ? uUID.toString().substring(0, 8) : string.trim());
            if (FriendManager.getInstance().a(string2, uUID)) {
                SoundManager.b();
            }
            if (l.matcher(string2).matches()) {
                SocialService.getInstance().mouseScrolled(string2, string2, this::lambda$addByUuid$16, this::lambda$addByUuid$17);
            }
        }
        catch (IllegalArgumentException illegalArgumentException) {
            // empty catch block
        }
    }

    private void c() {
        String string = this.e.toString().trim();
        if (string.isEmpty()) {
            return;
        }
        UUID uUID = this.c(string);
        if (uUID != null) {
            this.a(uUID, string);
            this.e.setLength(0);
            return;
        }
        if (l.matcher(string).matches()) {
            this.getInstance(string);
            this.e.setLength(0);
            return;
        }
        UUID uUID2 = this.c(string);
        if (uUID2 != null) {
            this.a(uUID2, string);
            this.e.setLength(0);
        }
    }

    private PlayerEntity b(String string) {
        if (Main.mc.world == null) {
            return null;
        }
        for (PlayerEntity mc6 : Main.mc.world.getPlayers()) {
            if (mc6 == Main.mc.player || !mc6.getName().getString().equalsIgnoreCase(string)) continue;
            return mc6;
        }
        return null;
    }

    private PlayerEntity a(UUID uUID) {
        if (uUID == null || Main.mc.world == null) {
            return null;
        }
        for (PlayerEntity mc6 : Main.mc.world.getPlayers()) {
            if (!uUID.equals(mc6.getUuid())) continue;
            return mc6;
        }
        return null;
    }

    private UUID c(String string) {
        if (string == null || string.isBlank()) {
            return null;
        }
        try {
            return UUID.fromString(string.trim());
        }
        catch (Exception exception) {
            String string2 = string.replace("-", "").trim();
            if (string2.length() != 32 || !string2.matches("^[0-9a-fA-F]{32}$")) {
                return null;
            }
            String string3 = string2.substring(0, 8) + "-" + string2.substring(8, 12) + "-" + string2.substring(12, 16) + "-" + string2.substring(16, 20) + "-" + string2.substring(20, 32);
            try {
                return UUID.fromString(string3);
            }
            catch (Exception exception2) {
                return null;
            }
        }
    }

    private PlayerEntity b(Friend friend) {
        if (friend == null) {
            return null;
        }
        PlayerEntity mc6 = this.getInstance(friend.b());
        if (mc6 != null) {
            return mc6;
        }
        if (!friend.a().isBlank()) {
            return this.b(friend.a());
        }
        return null;
    }

    private boolean c(Friend friend) {
        PlayerEntity mc6 = this.b(friend);
        return mc6 != null && TargetFilter.b((Entity)mc6);
    }

    private void a(DrawContext mc15, MatrixStack mc13, PlayerEntity mc6, float f2, float f3, float f4, float f5, Color color) {
        if (mc15 == null) {
            return;
        }
        if (mc6 instanceof AbstractClientPlayerEntity) {
            AbstractClientPlayerEntity TrackedPosition = (AbstractClientPlayerEntity)mc6;
            float f6 = RenderScale.h();
            int n2 = Math.round(f2 * f6);
            int n3 = Math.round(f3 * f6);
            int n4 = Math.max(1, Math.round(f4 * f6));
            PlayerSkinDrawer.draw((DrawContext)mc15, (SkinTextures)TrackedPosition.getSkin(), (int)n2, (int)n3, (int)n4);
            return;
        }
        new PanelRenderer(mc13, f2, f3, f4, f4).a(new Color(35, 35, 45, (int)(220.0f * f5))).a(4.0f).j();
        GuiRenderer.a(mc13, "users", f2 + (f4 - 10.0f) * 0.5f, f3 + (f4 - 10.0f) * 0.5f, 10.0f, 10.0f, GuiRenderer.a(color, (int)(220.0f * f5)));
    }

    private void a(MatrixStack mc13, Color color) {
        float f2 = GuiRenderer.a("friends.privacy.popup", this.g ? 1.0f : 0.0f, 0.06f);
        if (f2 < 0.01f) {
            return;
        }
        float f3 = 178.0f;
        float f4 = 118.0f;
        float f5 = this.h + this.j - f3;
        if (f5 < 4.0f) {
            f5 = 4.0f;
        }
        float f6 = this.i - f4 - 6.0f;
        float f7 = GuiRenderer.g(f2);
        float f8 = f5 + f3 * 0.5f;
        float f9 = f6 + f4 * 0.5f;
        float f10 = f8 - f3 * 0.5f * f7;
        float f11 = f9 - f4 * 0.5f * f7;
        float f12 = f3 * f7;
        float f13 = f4 * f7;
        new PanelRenderer(mc13, f10, f11, f12, f13).a(GuiRenderer.a(new Color(18, 18, 18), (int)(230.0f * f2))).a(16.0f, 1.0f).a(8.0f).j();
        GuiRenderer.a(mc13, f10, f11, f12, f13, 1.0f, 8.0f, new Color(58, 58, 76, (int)(130.0f * f2)));
        if (f2 < 0.5f) {
            return;
        }
        float f14 = GuiRenderer.b((f2 - 0.3f) / 0.7f, 0.0f, 1.0f);
        float f15 = 10.0f;
        GuiRenderer.a(mc13, "eye", f10 + f15, f11 + f15 + 1.0f, 10.0f, 10.0f, GuiRenderer.a(color, (int)(215.0f * f14)));
        FontManager.a().a(mc13, new StringConstant("Privacy"), f10 + f15 + 14.0f, f11 + f15 + 2.5f, 7.0f, GuiRenderer.a(Color.WHITE, (int)(228.0f * f14)));
        this.b(mc13, f10 + f12 - f15 - 14.0f, f11 + f15, 14.0f, 14.0f, "cross", f14, new Color(50, 50, 65), () -> ((FriendsScreen)this).lambda$drawPrivacyPopup$18());
        new PanelRenderer(mc13, f10 + f15, f11 + 28.0f, f12 - f15 * 2.0f, 1.0f).a(new Color(255, 255, 255, (int)(13.0f * f14))).j();
        boolean bl = ClientSettings.getInstance().h();
        boolean bl2 = ClientSettings.getInstance().i();
        float f16 = f11 + 38.0f;
        FontManager.a().a(mc13, new StringConstant("Online Status"), f10 + f15, f16 + 2.5f, 6.5f, GuiRenderer.a(new Color(190, 190, 206), (int)(215.0f * f14)));
        this.a(mc13, f10 + f12 - f15 - 36.0f, f16, 36.0f, 16.0f, !bl, "privacy.online", color, f14, this::lambda$drawPrivacyPopup$19);
        float f17 = f11 + 62.0f;
        FontManager.a().a(mc13, new StringConstant("Ghost Mode"), f10 + f15, f17 + 2.5f, 6.5f, GuiRenderer.a(new Color(190, 190, 206), (int)(215.0f * f14)));
        this.a(mc13, f10 + f12 - f15 - 36.0f, f17, 36.0f, 16.0f, bl2, "privacy.ghost", color, f14, this::lambda$drawPrivacyPopup$20);
        String string = bl ? "Appearing offline to everyone" : (bl2 ? "Hidden from non-friends" : "Visible to your friends");
        float f18 = FontManager.a().a(new StringConstant(string), 5.5f);
        FontManager.a().a(mc13, new StringConstant(string), f10 + (f12 - f18) * 0.5f, f11 + f13 - 14.0f, 5.5f, new Color(70, 70, 90, (int)(208.0f * f14)));
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, float f5, boolean bl, String string, Color color, float f6, Runnable runnable) {
        float f7 = GuiRenderer.a("friends.toggle." + string, bl ? 1.0f : 0.0f, 0.14f);
        Color color2 = GuiRenderer.a(new Color(45, 45, 58), color, f7);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(color2, (int)(210.0f * f6))).a(f5 * 0.5f).j().a(0, runnable);
        float f8 = f5 - 4.0f;
        float f9 = f2 + 2.0f + f7 * (f4 - f8 - 4.0f);
        new PanelRenderer(mc13, f9, f3 + 2.0f, f8, f8).a(GuiRenderer.a(Color.WHITE, (int)(245.0f * f6))).a(f8 * 0.5f).j();
    }

    public boolean shouldPause() {
        return false;
    }

    public void close() {
        if (!this.d) {
            this.d = true;
        }
    }

    private static void lambda$drawPrivacyPopup$20() {
        ClientSettings.getInstance().d(!ClientSettings.getInstance().i());
        SoundManager.b();
    }

    private static void lambda$drawPrivacyPopup$19() {
        ClientSettings.getInstance().c(!ClientSettings.getInstance().h());
        SoundManager.b();
    }

    private void lambda$drawPrivacyPopup$18() {
        this.g = false;
        SoundManager.b();
    }

    private static void lambda$addByUuid$17(String string) {
    }

    private static void lambda$addByUuid$16(String string) {
    }

    private static void lambda$addByName$15(String string) {
    }

    private static void lambda$addByName$14(String string) {
    }

    private static double lambda$getNearbyPlayers$13(PlayerEntity mc6) {
        return mc6.squaredDistanceTo((Entity)Main.mc.player);
    }

    private static boolean lambda$getNearbyPlayers$12(PlayerEntity mc6) {
        return !TargetFilter.b((Entity)mc6);
    }

    private static PlayerEntity lambda$getNearbyPlayers$11(AbstractClientPlayerEntity TrackedPosition) {
        return TrackedPosition;
    }

    private static boolean lambda$getNearbyPlayers$10(AbstractClientPlayerEntity TrackedPosition) {
        return TrackedPosition != Main.mc.player;
    }

    private void lambda$drawInputField$9() {
        this.f = true;
    }

    private static void lambda$drawNearbyList$8(boolean bl, PlayerEntity mc6) {
        if (bl) {
            FriendManager.getInstance().a(mc6.getUuid());
        } else {
            FriendManager.getInstance().a(mc6.getName().getString(), mc6.getUuid());
        }
        SoundManager.b();
    }

    private static void lambda$drawFriendsList$7(Friend friend) {
        if (friend.b() != null) {
            FriendManager.getInstance().a(friend.b());
        } else {
            FriendManager.getInstance().a(friend.a());
        }
        if (!friend.a().isBlank()) {
            SocialService.getInstance().a(friend.a(), this::lambda$drawFriendsList$5, this::lambda$drawFriendsList$6);
        }
        SoundManager.b();
    }

    private static void lambda$drawFriendsList$6(String string) {
    }

    private static void lambda$drawFriendsList$5(String string) {
    }

    private boolean lambda$drawFriendsList$4(Friend friend) {
        return !this.c(friend);
    }

    private boolean lambda$render$3(Friend friend) {
        return !this.c(friend);
    }

    private static void lambda$render$2() {
        SoundManager.b();
        Main.mc.setScreen((Screen)DirectMessageScreen.getInstance());
    }

    private void lambda$render$1() {
        this.g = !this.g;
        SoundManager.b();
    }

    private static void lambda$render$0() {
        FriendManager.getInstance().a(true);
        SoundManager.b();
    }
}

