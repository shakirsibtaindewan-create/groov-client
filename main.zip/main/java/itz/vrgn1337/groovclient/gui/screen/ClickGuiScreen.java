/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.screen;

import itz.vrgn1337.groovclient.api.backend.AuthState;
import itz.vrgn1337.groovclient.api.backend.BackendClient;
import itz.vrgn1337.groovclient.api.event.hooks.MouseButtonEvent;
import itz.vrgn1337.groovclient.api.util.SoundManager;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.b.c.HudEditorScreen;
import itz.vrgn1337.groovclient.config.ClientSettings;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.TooltipRenderer;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.screen.AuthStateSwitchMap;
import itz.vrgn1337.groovclient.gui.screen.CategoryPanel;
import itz.vrgn1337.groovclient.gui.screen.ConfigScreen;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import itz.vrgn1337.groovclient.gui.screen.SettingsScreen;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.ButtonSetting;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.HotbarSlotSetting;
import itz.vrgn1337.groovclient.setting.ItemListSetting;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import net.minecraft.client.input.KeyInput;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemConvertible;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.Registries;
import org.lwjgl.glfw.GLFW;

public class ClickGuiScreen
extends Screen {
    private static final ClickGuiScreen a = new ClickGuiScreen();
    private static final String b = "clickgui.open";
    private static final Color c = new Color(10, 10, 10, 130);
    private static final Color d = new Color(0, 0, 0, 60);
    private static final float e = 115.0f;
    private static final float f = 22.0f;
    private static final float g = 16.0f;
    private static final float h = 1.5f;
    private static final float i = 15.0f;
    private static final float j = 15.0f;
    private static final float k = 26.0f;
    private static final float l = 1.5f;
    private static final float m = 4.0f;
    private static final Map<ModuleCategory, String> n = Map.of(ModuleCategory.COMBAT, "combat", ModuleCategory.MOVEMENT, "move", ModuleCategory.VISUAL, "visual", ModuleCategory.Utility, "utility");
    private boolean o;
    private boolean p;
    private final List<CategoryPanel> q = new ArrayList();
    private CategoryPanel r;
    private float s;
    private float t;
    private Module u;
    private KeybindSetting v;
    private boolean w;
    private FloatSetting x;
    private DoubleSetting y;
    private boolean z;
    private boolean A;
    private float B;
    private float C;
    private float D;
    private final HashMap<ModuleCategory, List<Module>> E = new HashMap<>();
    private final HashMap<ModuleCategory, List<Module>> F = new HashMap<>();
    private ColorSetting G;
    private int H;
    private float I;
    private float J;
    private float K;
    private float L;
    private float M;
    private float N;
    private ItemListSetting O;
    private float P;
    private float Q;
    private final StringBuilder R = new StringBuilder();
    private int S;
    private boolean T;
    private DrawContext U;
    private boolean V;
    private boolean W;
    private boolean X;
    private boolean Y;

    public static ClickGuiScreen getInstance() {
        return a;
    }

    protected ClickGuiScreen() {
        super((Text)Text.empty());
    }

    private void b() {
        this.q.clear();
        float f2 = 20.0f;
        float f3 = 30.0f;
        float f4 = 10.0f;
        float f5 = f3;
        for (ModuleCategory moduleCategory : ModuleCategory.values()) {
            Boolean bl;
            float f6 = f2;
            float f7 = f5;
            boolean bl2 = true;
            float[] fArray = ClientSettings.getInstance().c(moduleCategory.name());
            if (fArray != null) {
                f6 = fArray[0];
                f7 = fArray[1];
            }
            if ((bl = ClientSettings.getInstance().d(moduleCategory.name())) != null) {
                bl2 = bl;
            }
            CategoryPanel categoryPanel = new CategoryPanel(moduleCategory, f6, f7);
            categoryPanel.d = bl2;
            this.q.add(categoryPanel);
            f5 += 22.0f + f4;
        }
        this.p = true;
    }

    private void c() {
        for (CategoryPanel categoryPanel : this.q) {
            ClientSettings.getInstance().a(categoryPanel.a.name(), categoryPanel.b, categoryPanel.c, categoryPanel.d);
        }
        ClientSettings.getInstance().k();
    }

    public void init() {
        Main.eventBus().register((Object)a);
        this.o = false;
        this.V = false;
        this.W = false;
        this.X = false;
        this.Y = false;
        this.r = null;
        this.x = null;
        this.y = null;
        this.G = null;
        this.H = 0;
        if (!this.p) {
            this.b();
        }
    }

    public boolean keyPressed(KeyInput mc27) {
        if (this.v != null) {
            if (mc27.key() == 256) {
                this.v.reset();
                this.v = null;
                return true;
            }
            if (mc27.key() != -1) {
                this.v.setKey(mc27.key());
            } else {
                this.v.setKeyFromGui(mc27.scancode());
            }
            this.v = null;
            return true;
        }
        if (this.O != null) {
            String string;
            if (mc27.key() == 256) {
                this.O = null;
                return true;
            }
            if (mc27.key() == 259) {
                if (this.R.length() > 0) {
                    this.R.deleteCharAt(this.R.length() - 1);
                    this.S = 0;
                }
                return true;
            }
            String string2 = string = mc27.key() == 32 ? " " : GLFW.glfwGetKeyName((int)mc27.key(), (int)mc27.scancode());
            if (string != null && !string.isEmpty()) {
                this.R.append(string.toLowerCase());
                this.S = 0;
                return true;
            }
            return true;
        }
        if (mc27.key() == 256 || mc27.key() == 344) {
            this.o = true;
            return true;
        }
        return super.keyPressed(mc27);
    }

    protected void applyBlur(DrawContext mc15) {
    }

    public void render(DrawContext mc15, int n2, int n3, float f2) {
        if (!this.p) {
            this.b();
        }
        MatrixStack mc13 = new MatrixStack();
        mc13.push();
        TooltipRenderer.a();
        float f3 = GuiRenderer.a(b, this.o ? 0.0f : 1.0f, 0.065f);
        if (this.o && f3 <= 0.01f) {
            this.o = false;
            GuiRenderer.b(b);
            Main.mc.setScreen(null);
            mc13.pop();
            return;
        }
        Color[] colorArray = MenuGuiScreen.b();
        new PanelRenderer(mc13, 0.0f, 0.0f, RenderScale.c(), RenderScale.d()).a(GuiRenderer.a(d, (int)((float)d.getAlpha() * f3))).j();
        this.f();
        this.g();
        this.e();
        this.U = mc15;
        this.E.clear();
        this.F.clear();
        for (CategoryPanel categoryPanel : this.q) {
            this.a(mc13, categoryPanel, f3, colorArray);
        }
        this.a(mc13, f3, colorArray);
        this.a(mc13, f3);
        this.b(mc13, f3, colorArray);
        TooltipRenderer.a(mc13, 0.75f);
        mc13.pop();
    }

    private void a(MatrixStack mc13, CategoryPanel categoryPanel, float f2, Color[] colorArray) {
        float f3 = categoryPanel.b;
        float f4 = categoryPanel.c;
        float f5 = 115.0f;
        float f6 = 8.0f;
        float f7 = GuiRenderer.a("clickgui.panel." + categoryPanel.a.name(), categoryPanel.d ? 1.0f : 0.0f, 0.15f);
        float f8 = 0.0f;
        if (f7 > 0.01f) {
            f8 = this.onMouseButton(categoryPanel);
        }
        float f9 = RenderScale.d() * 0.8f;
        float f10 = Math.min(f8, f9) * f7;
        float f11 = 22.0f + f10;
        float f12 = 0.9f + 0.1f * GuiRenderer.g(f2);
        float f13 = f3 + f5 * 0.5f;
        float f14 = f4 + f11 * 0.5f;
        mc13.push();
        mc13.translate(f13, f14, 0.0f);
        mc13.scale(f12, f12, 1.0f);
        mc13.translate(-f13, -f14, 0.0f);
        new PanelRenderer(mc13, f3, f4, f5, f11).a(c).a(16.0f, 1.0f).a(f6).j();
        float f15 = f7 > 0.01f ? f6 : f6;
        float f16 = f7 > 0.5f ? 0.0f : f6 * (1.0f - f7 * 2.0f);
        new PanelRenderer(mc13, f3, f4, f5, 22.0f).a(GuiRenderer.a(colorArray[0], (int)(180.0f * f2)), GuiRenderer.a(colorArray[1], (int)(180.0f * f2)), GuiRenderer.a(colorArray[2], (int)(140.0f * f2)), GuiRenderer.a(colorArray[3], (int)(140.0f * f2))).a(f6, f6, Math.max(0.0f, f16), Math.max(0.0f, f16)).j();
        float f17 = 9.0f;
        float f18 = f3 + 6.0f;
        float f19 = f4 + (22.0f - f17) * 0.5f;
        String string = n.getOrDefault((Object)categoryPanel.a, "utility");
        GuiRenderer.a(mc13, string, f18, f19, f17, f17);
        FontManager.a().a(mc13, categoryPanel.a.a(), f18 + f17 + 4.0f, f4 + 6.16f, 6.5f, GuiRenderer.a(Color.WHITE, (int)(255.0f * f2)));
        StringConstant stringConstant = new StringConstant(categoryPanel.d ? "\u25bc" : "\u25b6");
        float f20 = FontManager.a().a(stringConstant, 5.5f);
        FontManager.a().a(mc13, stringConstant, f3 + f5 - f20 - 6.0f, f4 + 6.6000004f, 5.5f, GuiRenderer.a(Color.WHITE, (int)(180.0f * f2)));
        if (this.r == null && RenderScale.a(f3, f4, f5, 22.0f)) {
            boolean bl;
            boolean bl2 = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
            boolean bl3 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)1) == 1;
            if (bl2 && this.r == null) {
                this.r = categoryPanel;
                this.s = (float)RenderScale.j() - f3;
                this.t = (float)RenderScale.k() - f4;
            }
            if (bl && !categoryPanel.e) {
                categoryPanel.e = true;
                categoryPanel.d = !categoryPanel.d;
                SoundManager.b();
                this.c();
            }
            if (!bl) {
                categoryPanel.e = false;
            }
        } else if (GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)1) != 1) {
            categoryPanel.e = false;
        }
        if (f7 > 0.01f && f10 > 1.0f) {
            float f21 = f4 + 22.0f;
            float f22 = f10;
            GuiRenderer.a(f3, f21, f5, f22 - 1.0f);
            float f23 = Math.max(0.0f, f8 - f9);
            categoryPanel.h = Math.max(-f23, Math.min(0.0f, categoryPanel.h));
            long l2 = System.currentTimeMillis();
            if (categoryPanel.i == 0L) {
                categoryPanel.i = l2;
            }
            float f24 = Math.min((float)(l2 - categoryPanel.i), 50.0f);
            categoryPanel.i = l2;
            float f25 = 12.0f;
            float f26 = 1.0f - (float)Math.exp(-f25 * f24 / 1000.0f);
            categoryPanel.g += (categoryPanel.h - categoryPanel.g) * f26;
            if (Math.abs(categoryPanel.h - categoryPanel.g) < 0.01f) {
                categoryPanel.g = categoryPanel.h;
            }
            categoryPanel.g = Math.max(-f23, Math.min(0.0f, categoryPanel.g));
            float f27 = f21 + 4.0f + categoryPanel.g;
            for (Module module : categoryPanel.f) {
                float f28 = this.a(mc13, module, f3 + 4.0f, f27, f5 - 8.0f, f2, colorArray);
                f27 += f28 + 1.5f;
            }
            GuiRenderer.b();
        }
        mc13.pop();
    }

    private float a(MatrixStack mc13, Module module, float f2, float f3, float f4, float f5, Color[] colorArray) {
        float f6 = GuiRenderer.a("clickgui.mod." + module.getName().a(), module.isEnabled() ? 1.0f : 0.0f, 0.04f);
        Color color = GuiRenderer.a(GuiRenderer.a(new Color(20, 20, 20), 120), GuiRenderer.a(colorArray[0], 160), f6);
        Color color2 = GuiRenderer.a(GuiRenderer.a(new Color(20, 20, 20), 120), GuiRenderer.a(colorArray[1], 160), f6);
        Color color3 = GuiRenderer.a(GuiRenderer.a(new Color(20, 20, 20), 120), GuiRenderer.a(colorArray[2], 140), f6);
        Color color4 = GuiRenderer.a(GuiRenderer.a(new Color(20, 20, 20), 120), GuiRenderer.a(colorArray[3], 140), f6);
        float f7 = 5.0f;
        boolean bl = this.u == module && !module.getSettings().isEmpty();
        float f8 = bl ? this.b(module) : 0.0f;
        float f9 = GuiRenderer.a("clickgui.drop." + module.getName().a(), f8, 0.18f);
        float f10 = f9 > 1.0f ? 0.0f : f7;
        PanelRenderer panelRenderer = new PanelRenderer(mc13, f2, f3, f4, 16.0f).a(color, color2, color3, color4).a(f7, f7, f10, f10).j();
        float f11 = 5.5f;
        float f12 = f2 + 4.0f;
        float f13 = f3 + (16.0f - f11) * 0.5f;
        int n2 = Math.round(f6 * 255.0f);
        int n3 = Math.round((1.0f - f6) * 255.0f);
        GuiRenderer.a(mc13, "cross", f12, f13, f11, f11, GuiRenderer.a(Color.LIGHT_GRAY, n3));
        GuiRenderer.a(mc13, "check", f12, f13, f11, f11, GuiRenderer.a(MenuGuiScreen.c().brighter(), n2));
        FontManager.a().a(mc13, module.getName(), f12 + f11 + 3.0f, f3 + 4.48f, 5.5f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f5)));
        if (!module.isAlwaysListening()) {
            panelRenderer.a(0, () -> ((Module)module).toggle());
        }
        if (!module.getSettings().isEmpty()) {
            panelRenderer.a(1, () -> ((ClickGuiScreen)this).lambda$drawModuleRow$0((Module)module));
        }
        if (RenderScale.b(f2, f3, f2 + f4, f3 + 16.0f)) {
            TooltipRenderer.a(module.getDescription());
        }
        float f14 = 16.0f;
        if (f9 > 0.5f) {
            this.a(mc13, module, f2, f3 + 16.0f, f4, f9, f5, colorArray);
            f14 += f9;
        }
        return f14;
    }

    private void a(MatrixStack mc13, Module module, float f2, float f3, float f4, float f5, float f6, Color[] colorArray) {
        float f7 = 5.0f;
        new PanelRenderer(mc13, f2, f3, f4, f5).a(new Color(0, 0, 0, 0)).a(12.0f, 0.8f).a(0.0f, 0.0f, f7, f7).j();
        float f8 = this.b(module);
        float f9 = f8 > 0.0f ? Math.min(f5 / f8, 1.0f) : 0.0f;
        float f10 = f6 * f9;
        float f11 = f3 + f5;
        float f12 = f2 + 2.0f;
        float f13 = f4 - 4.0f;
        float f14 = f3 + 2.0f;
        for (Setting setting : module.getSettings()) {
            boolean bl;
            if (!setting.isVisible()) continue;
            float f15 = this.a(setting);
            if (f14 + f15 > f11) break;
            boolean bl2 = bl = f9 > 0.85f && !this.h();
            if (bl && RenderScale.b(f12, f14, f12 + f13, f14 + f15)) {
                TooltipRenderer.a(setting.getDescription());
            }
            if (setting instanceof DoubleSetting) {
                DoubleSetting doubleSetting = (DoubleSetting)setting;
                this.a(mc13, doubleSetting, f12, f14, f13, f15, f10, colorArray);
            } else if (setting instanceof FloatSetting) {
                FloatSetting floatSetting = (FloatSetting)setting;
                this.a(mc13, floatSetting, f12, f14, f13, f15, f10, colorArray);
            } else if (setting instanceof ModeSetting) {
                ModeSetting modeSetting = (ModeSetting)setting;
                this.a(mc13, modeSetting, f12, f14, f13, f15, f10, bl, colorArray);
            } else if (setting instanceof ColorSetting) {
                ColorSetting colorSetting = (ColorSetting)setting;
                this.a(mc13, colorSetting, f12, f14, f13, f15, f10, bl);
            } else if (setting instanceof BooleanSetting) {
                BooleanSetting booleanSetting = (BooleanSetting)setting;
                this.a(mc13, booleanSetting, f12, f14, f13, f15, f10, bl, colorArray);
            } else if (setting instanceof KeybindSetting) {
                KeybindSetting keybindSetting = (KeybindSetting)setting;
                this.a(mc13, module, keybindSetting, f12, f14, f13, f15, f10, bl);
            } else if (setting instanceof HotbarSlotSetting) {
                HotbarSlotSetting hotbarSlotSetting = (HotbarSlotSetting)setting;
                this.a(mc13, hotbarSlotSetting, f12, f14, f13, f15, f10, bl, colorArray);
            } else if (setting instanceof ItemListSetting) {
                ItemListSetting itemListSetting = (ItemListSetting)setting;
                this.a(mc13, itemListSetting, f12, f14, f13, f15, f10, bl);
            } else if (setting instanceof ButtonSetting) {
                ButtonSetting buttonSetting = (ButtonSetting)setting;
                this.a(mc13, buttonSetting, f12, f14, f13, f15, f10, bl, colorArray);
            }
            f14 += f15 + 1.5f;
        }
    }

    private void a(MatrixStack mc13, ButtonSetting buttonSetting, float f2, float f3, float f4, float f5, float f6, boolean bl, Color[] colorArray) {
        float f7 = 4.0f;
        boolean bl2 = bl && RenderScale.b(f2, f3, f2 + f4, f3 + f5);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(14, 14, 14), (int)(80.0f * f6))).a(f7).j();
        FontManager.a().a(mc13, buttonSetting.a(), f2 + 4.0f, f3 + f5 * 0.26f, 5.5f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        StringConstant stringConstant = buttonSetting.d();
        float f8 = 5.5f;
        float f9 = 5.0f;
        float f10 = f5 - 4.0f;
        float f11 = FontManager.a().a(stringConstant, f8);
        float f12 = f11 + f9 * 2.0f;
        float f13 = f2 + f4 - f12 - 4.0f;
        float f14 = f3 + (f5 - f10) * 0.5f;
        Color color = GuiRenderer.a(bl2 ? colorArray[0] : new Color(40, 40, 50), (int)(220.0f * f6));
        PanelRenderer panelRenderer = new PanelRenderer(mc13, f13, f14, f12, f10).a(color).a(f7 * 0.7f).j();
        if (bl) {
            panelRenderer.a(0, () -> d.lambda$drawButtonRow$1((ButtonSetting)buttonSetting));
        }
        FontManager.a().a(mc13, stringConstant, f13 + f9, f14 + f10 * 0.22f, f8, GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)));
    }

    private void a(MatrixStack mc13, BooleanSetting booleanSetting, float f2, float f3, float f4, float f5, float f6, boolean bl, Color[] colorArray) {
        float f7 = 4.0f;
        PanelRenderer panelRenderer = new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(14, 14, 14), (int)(80.0f * f6))).a(f7).j();
        if (bl) {
            panelRenderer.a(0, () -> d.lambda$drawBooleanRow$2((BooleanSetting)booleanSetting));
        }
        FontManager.a().a(mc13, booleanSetting.a(), f2 + 4.0f, f3 + f5 * 0.26f, 5.5f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        float f8 = 18.0f;
        float f9 = 8.0f;
        float f10 = f2 + f4 - f8 - 4.0f;
        float f11 = f3 + (f5 - f9) * 0.5f;
        float f12 = GuiRenderer.a("clickgui.bool." + booleanSetting.a().a(), booleanSetting.getValue() ? 1.0f : 0.0f, 0.15f);
        new PanelRenderer(mc13, f10, f11, f8, f9).a(GuiRenderer.a(GuiRenderer.a(new Color(55, 55, 55, 180), colorArray[0], f12), (int)(220.0f * f6))).a(f9 / 2.0f).j();
        float f13 = 6.0f;
        float f14 = f8 - f13 - 2.0f;
        float f15 = f10 + 1.0f + f12 * f14;
        float f16 = f11 + (f9 - f13) * 0.5f;
        new PanelRenderer(mc13, f15, f16, f13, f13).a(GuiRenderer.a(Color.WHITE, (int)(220.0f * f6))).a(f13 / 2.0f).j();
    }

    private void a(MatrixStack mc13, FloatSetting floatSetting, float f2, float f3, float f4, float f5, float f6, Color[] colorArray) {
        float f7 = 5.5f;
        float f8 = 4.0f;
        float f9 = f3 + (f5 - FontManager.a().b(f7)) * 0.5f;
        FontManager.a().a(mc13, floatSetting.d(), f2 + f8, f9, f7, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        StringConstant stringConstant = new StringConstant(floatSetting.format());
        float f10 = FontManager.a().a(stringConstant, f7);
        FontManager.a().a(mc13, stringConstant, f2 + f4 - f8 - f10, f9, f7, GuiRenderer.a(colorArray[0].brighter(), (int)(210.0f * f6)));
        float f11 = FontManager.a().a(floatSetting.d(), f7);
        float f12 = 2.0f;
        float f13 = f2 + f8 + f11 + 4.0f;
        float f14 = f2 + f4 - f8 - f10 - 4.0f - f13;
        if (f14 < 4.0f) {
            f14 = 4.0f;
        }
        float f15 = f3 + (f5 - f12) * 0.5f;
        float f16 = f12 / 2.0f;
        new PanelRenderer(mc13, f13, f15, f14, f12).a(GuiRenderer.a(new Color(90, 90, 90), (int)(200.0f * f6))).a(f16).j();
        float f17 = GuiRenderer.a("clickgui.slider." + floatSetting.d().a(), floatSetting.getStep(), 0.12f);
        float f18 = f14 * f17;
        if (f18 > f12) {
            new PanelRenderer(mc13, f13, f15, f18, f12).a(GuiRenderer.a(colorArray[0], (int)(220.0f * f6)), GuiRenderer.a(colorArray[1], (int)(220.0f * f6)), GuiRenderer.a(colorArray[2], (int)(220.0f * f6)), GuiRenderer.a(colorArray[3], (int)(220.0f * f6))).a(f16).j();
        }
        float f19 = 2.5f;
        float f20 = f13 + f18;
        float f21 = f15 + f12 * 0.5f;
        new PanelRenderer(mc13, f20 - f19, f21 - f19, f19 * 2.0f, f19 * 2.0f).a(GuiRenderer.a(colorArray[0], (int)(240.0f * f6))).a(f19).j();
        this.E.put(floatSetting, new float[]{f13, f3, f14, f5});
    }

    private void a(MatrixStack mc13, DoubleSetting doubleSetting, float f2, float f3, float f4, float f5, float f6, Color[] colorArray) {
        float f7;
        float f8 = 5.5f;
        float f9 = 4.0f;
        float f10 = f3 + (f5 - FontManager.a().b(f8)) * 0.5f;
        FontManager.a().a(mc13, doubleSetting.d(), f2 + f9, f10, f8, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        StringConstant stringConstant = new StringConstant(doubleSetting.j());
        float f11 = FontManager.a().a(stringConstant, f8);
        FontManager.a().a(mc13, stringConstant, f2 + f4 - f9 - f11, f10, f8, GuiRenderer.a(colorArray[0].brighter(), (int)(210.0f * f6)));
        float f12 = FontManager.a().a(doubleSetting.d(), f8);
        float f13 = 2.0f;
        float f14 = f2 + f9 + f12 + 4.0f;
        float f15 = f2 + f4 - f9 - f11 - 4.0f - f14;
        if (f15 < 4.0f) {
            f15 = 4.0f;
        }
        float f16 = f3 + (f5 - f13) * 0.5f;
        float f17 = f13 / 2.0f;
        new PanelRenderer(mc13, f14, f16, f15, f13).a(GuiRenderer.a(new Color(90, 90, 90), (int)(200.0f * f6))).a(f17).j();
        float f18 = doubleSetting.k();
        float f19 = doubleSetting.l();
        float f20 = Math.max(1.0E-4f, f19 - f18);
        float f21 = GuiRenderer.a("clickgui.rlo." + doubleSetting.d().a(), GuiRenderer.b((doubleSetting.d() - f18) / f20, 0.0f, 1.0f), 0.12f);
        float f22 = GuiRenderer.a("clickgui.rhi." + doubleSetting.d().a(), GuiRenderer.b((doubleSetting.f() - f18) / f20, 0.0f, 1.0f), 0.12f);
        if (f22 < f21) {
            f7 = f21;
            f21 = f22;
            f22 = f7;
        }
        f7 = f14 + f15 * f21;
        float f23 = Math.max(0.0f, f15 * (f22 - f21));
        if (f23 > 0.5f) {
            new PanelRenderer(mc13, f7, f16, f23, f13).a(GuiRenderer.a(colorArray[0], (int)(220.0f * f6)), GuiRenderer.a(colorArray[1], (int)(220.0f * f6)), GuiRenderer.a(colorArray[2], (int)(220.0f * f6)), GuiRenderer.a(colorArray[3], (int)(220.0f * f6))).a(f17).j();
        }
        float f24 = 2.5f;
        float f25 = f16 + f13 * 0.5f;
        new PanelRenderer(mc13, f7 - f24, f25 - f24, f24 * 2.0f, f24 * 2.0f).a(GuiRenderer.a(colorArray[0], (int)(240.0f * f6))).a(f24).j();
        new PanelRenderer(mc13, f7 + f23 - f24, f25 - f24, f24 * 2.0f, f24 * 2.0f).a(GuiRenderer.a(colorArray[0], (int)(240.0f * f6))).a(f24).j();
        this.F.put(doubleSetting, new float[]{f14, f3, f15, f5, f7, f7 + f23});
    }

    private void a(MatrixStack mc13, ModeSetting modeSetting, float f2, float f3, float f4, float f5, float f6, boolean bl, Color[] colorArray) {
        float f7 = 3.0f;
        float f8 = 5.0f;
        float f9 = 3.5f;
        float f10 = 2.0f;
        float f11 = 1.5f;
        float f12 = f8 + f10 * 2.0f;
        float f13 = 12.0f;
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(14, 14, 14), (int)(80.0f * f6))).a(f7).j();
        FontManager.a().a(mc13, modeSetting.h(), f2 + 4.0f, f3 + f13 * 0.15f, f8, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        float f14 = f3 + f13;
        float f15 = 0.0f;
        float f16 = f14;
        float f17 = f2 + 4.0f;
        float f18 = f4 - 8.0f;
        Enum[] enumArray = modeSetting.getModes();
        for (int i2 = 0; i2 < enumArray.length; ++i2) {
            StringConstant stringConstant = new StringConstant(ModeSetting.setIndex(enumArray[i2]));
            float f19 = FontManager.a().a(stringConstant, f8) + f9 * 2.0f;
            if (f15 > 0.0f && f15 + f19 > f18) {
                f15 = 0.0f;
                f16 += f12 + f11;
            }
            float f20 = f17 + f15;
            float f21 = f16;
            boolean bl2 = modeSetting.isSelected(i2);
            Color color = bl2 ? GuiRenderer.a(colorArray[0], (int)(200.0f * f6)) : GuiRenderer.a(new Color(40, 40, 40), (int)(160.0f * f6));
            Color color2 = bl2 ? GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)) : GuiRenderer.a(new Color(180, 180, 180), (int)(200.0f * f6));
            PanelRenderer panelRenderer = new PanelRenderer(mc13, f20, f21, f19, f12).a(color).a(f7 * 0.6f).j();
            if (bl) {
                int n2 = i2;
                panelRenderer.a(0, () -> d.lambda$drawModeRow$3((ModeSetting)modeSetting, (int)n2));
            }
            FontManager.a().a(mc13, stringConstant, f20 + f9, f21 + f12 * 0.1f, f8, color2);
            f15 += f19 + f11;
        }
    }

    private void a(MatrixStack mc13, Module module, KeybindSetting keybindSetting, float f2, float f3, float f4, float f5, float f6, boolean bl) {
        float f7 = 3.0f;
        float f8 = 5.5f;
        boolean bl2 = this.v == keybindSetting;
        StringConstant stringConstant = new StringConstant(keybindSetting.d().a() + ":");
        FontManager.a().a(mc13, stringConstant, f2 + 4.0f, f3 + f5 * 0.26f, f8, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        StringConstant stringConstant2 = bl2 ? new StringConstant("Press...") : keybindSetting.g();
        float f9 = FontManager.a().a(stringConstant, f8);
        float f10 = FontManager.a().a(stringConstant2, f8);
        float f11 = f2 + 4.0f + f9 + 3.0f;
        PanelRenderer panelRenderer = new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(14, 14, 14), (int)(80.0f * f6))).a(f7).j();
        if (bl) {
            panelRenderer.a(0, () -> ((ClickGuiScreen)this).lambda$drawKeyRow$4((KeybindSetting)keybindSetting));
            if (!bl2) {
                panelRenderer.a(1, () -> d.lambda$drawKeyRow$5((KeybindSetting)keybindSetting));
            }
        }
        FontManager.a().a(mc13, stringConstant2, f11, f3 + f5 * 0.26f, f8, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
    }

    private void a(MatrixStack mc13, ColorSetting colorSetting, float f2, float f3, float f4, float f5, float f6, boolean bl) {
        float f7 = 3.0f;
        PanelRenderer panelRenderer = new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(14, 14, 14), (int)(60.0f * f6))).a(f7).j();
        FontManager.a().a(mc13, colorSetting.d(), f2 + 4.0f, f3 + f5 * 0.26f, 5.5f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        float f8 = 8.0f;
        float f9 = f2 + f4 - f8 - 4.0f;
        float f10 = f3 + (f5 - f8) * 0.5f;
        new PanelRenderer(mc13, f9, f10, f8, f8).a(GuiRenderer.a(new Color(200, 200, 200), (int)(f6 * 255.0f))).a(2.5f).j();
        new PanelRenderer(mc13, f9, f10, f8, f8).a(GuiRenderer.a(colorSetting.d(), (int)(f6 * 255.0f))).a(2.5f).j();
        if (bl && !this.h()) {
            panelRenderer.a(1, () -> ((ClickGuiScreen)this).lambda$drawColorRow$6((ColorSetting)colorSetting, (float)f9, (float)f3));
        }
    }

    private void a(MatrixStack mc13, HotbarSlotSetting hotbarSlotSetting, float f2, float f3, float f4, float f5, float f6, boolean bl, Color[] colorArray) {
        float f7 = 3.0f;
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(14, 14, 14), (int)(80.0f * f6))).a(f7).j();
        FontManager.a().a(mc13, hotbarSlotSetting.d(), f2 + 4.0f, f3 + 1.5f, 5.0f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        float f8 = 8.0f;
        float f9 = f3 + f5 - f8 - 4.0f;
        float f10 = f4 - 8.0f;
        float f11 = Math.max(0.3f, (f10 - f8 * 9.0f) / 8.0f);
        float f12 = f8 * 9.0f + f11 * 8.0f;
        float f13 = f2 + (f4 - f12) * 0.5f;
        for (int i2 = 0; i2 < 9; ++i2) {
            float f14 = f13 + (float)i2 * (f8 + f11);
            Color color = hotbarSlotSetting.b(i2) ? GuiRenderer.a(colorArray[0], (int)(230.0f * f6)) : GuiRenderer.a(new Color(55, 55, 55), (int)(200.0f * f6));
            PanelRenderer panelRenderer = new PanelRenderer(mc13, f14, f9, f8, f8).a(color).a(2.5f).j();
            if (!bl) continue;
            int n2 = i2;
            panelRenderer.a(0, () -> d.lambda$drawSlotRow$7((HotbarSlotSetting)hotbarSlotSetting, (int)n2));
        }
    }

    private void a(MatrixStack mc13, ItemListSetting itemListSetting, float f2, float f3, float f4, float f5, float f6, boolean bl) {
        float f7 = 3.0f;
        boolean bl2 = this.O == itemListSetting;
        float f8 = GuiRenderer.a("clickgui.reg.hover." + itemListSetting.d().a(), bl2 ? 1.0f : 0.0f, 0.12f);
        Color color = GuiRenderer.a(GuiRenderer.a(new Color(14, 14, 14), (int)(60.0f * f6)), GuiRenderer.a(MenuGuiScreen.c(), (int)(45.0f * f6)), f8);
        PanelRenderer panelRenderer = new PanelRenderer(mc13, f2, f3, f4, f5).a(color).a(f7).j();
        int n2 = itemListSetting.g().size();
        StringConstant stringConstant = new StringConstant(itemListSetting.d().a() + " (" + n2 + ")");
        FontManager.a().a(mc13, stringConstant, f2 + 4.0f, f3 + f5 * 0.26f, 5.0f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        if (itemListSetting.e() == Registries.ITEM && this.U != null) {
            ItemListSetting itemListSetting2 = itemListSetting;
            List list = itemListSetting2.g();
            int n3 = Math.min(3, list.size());
            float f9 = 8.0f;
            float f10 = 1.5f;
            float f11 = f2 + f4 - 4.0f - (float)n3 * (f9 + f10) + f10;
            for (int i2 = 0; i2 < n3; ++i2) {
                ItemStack mc33 = new ItemStack((ItemConvertible)list.get(i2));
                float f12 = f11 + (float)i2 * (f9 + f10);
                float f13 = f3 + (f5 - f9) * 0.5f;
                float f14 = RenderScale.h();
                this.U.getMatrices().pushMatrix();
                this.U.getMatrices().translate(f12 * f14, f13 * f14);
                float f15 = f9 / 16.0f * f14;
                this.U.getMatrices().scale(f15, f15);
                this.U.drawItem(mc33, 0, 0);
                this.U.getMatrices().popMatrix();
            }
        }
        if (bl && !this.d()) {
            panelRenderer.a(1, () -> ((ClickGuiScreen)this).lambda$drawRegistriesRow$8((ItemListSetting)itemListSetting, (float)f2, (float)f4, (float)f3));
        }
    }

    private void a(ItemListSetting itemListSetting, float f2, float f3) {
        if (this.O == itemListSetting) {
            this.O = null;
            return;
        }
        this.O = itemListSetting;
        this.P = f2;
        this.Q = f3;
        this.R.setLength(0);
        this.S = 0;
        this.T = false;
        GuiRenderer.b("clickgui.reg.popup", 0.0f);
    }

    private void a(MatrixStack mc13, float f2) {
        float f3;
        float f4;
        float f5;
        int n2;
        if (this.O == null) {
            return;
        }
        float f6 = GuiRenderer.a("clickgui.reg.popup", 1.0f, 0.06f);
        float f7 = GuiRenderer.g(f6);
        if (f6 < 0.01f) {
            return;
        }
        ItemListSetting itemListSetting = this.O;
        boolean bl = itemListSetting.e() == Registries.ITEM;
        float f8 = bl ? 175.0f : 145.0f;
        float f9 = bl ? 18.0f : 16.0f;
        float f10 = 18.0f;
        float f11 = 16.0f;
        float f12 = 5.0f;
        int n3 = 8;
        String string = this.R.toString().toLowerCase();
        List list = this.T ? itemListSetting.g() : itemListSetting.f();
        List list2 = list.stream().filter(arg_0 -> ((ClickGuiScreen)this).lambda$drawRegistriesPopup$9((ItemListSetting)itemListSetting, (String)string, arg_0)).collect(Collectors.toList());
        int n4 = list2.size();
        int n5 = Math.min(n3, n4);
        float f13 = (float)n5 * f9;
        float f14 = f12 + f11 + f12 + f10 + f12 + f13 + f12;
        float f15 = this.P + 6.0f;
        float f16 = this.Q;
        if (f15 + f8 > RenderScale.c()) {
            f15 = this.P - f8 - 6.0f;
        }
        if (f16 + f14 > RenderScale.d()) {
            f16 = RenderScale.d() - f14 - 4.0f;
        }
        float f17 = f7;
        float f18 = f15 + f8 * 0.5f;
        float f19 = f16 + f14 * 0.5f;
        float f20 = f18 - f8 * 0.5f * f17;
        float f21 = f19 - f14 * 0.5f * f17;
        float f22 = f8 * f17;
        float f23 = f14 * f17;
        int n6 = (int)(230.0f * f6 * f2);
        new PanelRenderer(mc13, f20, f21, f22, f23).a(GuiRenderer.a(new Color(18, 18, 18), n6)).a(16.0f, 1.0f).a(7.0f).j();
        if (f6 < 0.4f) {
            return;
        }
        float f24 = GuiRenderer.b((f6 - 0.3f) / 0.7f, 0.0f, 1.0f) * f2;
        float f25 = f21 + f12 * f17;
        float f26 = (f22 - f12 * 2.0f * f17) * 0.5f;
        float f27 = f20 + f12 * f17;
        float f28 = f27 + f26;
        float f29 = f11 * f17;
        float f30 = GuiRenderer.a("clickgui.reg.tab.all", this.T ? 0.0f : 1.0f, 0.12f);
        float f31 = GuiRenderer.a("clickgui.reg.tab.sel", this.T ? 1.0f : 0.0f, 0.12f);
        int n7 = (int)(f24 * 255.0f);
        new PanelRenderer(mc13, f27, f25, f26, f29).a(GuiRenderer.a(MenuGuiScreen.c(), (int)(40.0f * f30 * f24))).a(4.0f * f17).j().a(0, () -> ((ClickGuiScreen)this).lambda$drawRegistriesPopup$10());
        GuiRenderer.a(mc13, "search", f27 + (f26 - 8.0f * f17) * 0.5f, f25 + (f29 - 8.0f * f17) * 0.5f, 8.0f * f17, 8.0f * f17, GuiRenderer.a(Color.WHITE, n7));
        new PanelRenderer(mc13, f28, f25, f26, f29).a(GuiRenderer.a(MenuGuiScreen.c(), (int)(40.0f * f31 * f24))).a(4.0f * f17).j().a(0, () -> ((ClickGuiScreen)this).lambda$drawRegistriesPopup$11());
        GuiRenderer.a(mc13, "check", f28 + (f26 - 8.0f * f17) * 0.5f, f25 + (f29 - 8.0f * f17) * 0.5f, 8.0f * f17, 8.0f * f17, GuiRenderer.a(Color.WHITE, n7));
        float f32 = f20 + f12 * f17;
        float f33 = f22 - f12 * 2.0f * f17;
        float f34 = f10 * f17;
        new PanelRenderer(mc13, f32, f25 += f29 + f12 * f17, f33, f34).a(GuiRenderer.a(new Color(30, 30, 30), (int)(200.0f * f24))).a(4.0f * f17).j();
        StringConstant stringConstant = this.R.length() > 0 ? new StringConstant(this.R.toString()) : new StringConstant("Search...");
        Color color = this.R.length() > 0 ? GuiRenderer.a(Color.WHITE, n7) : GuiRenderer.a(new Color(110, 110, 110), n7);
        FontManager.a().a(mc13, stringConstant, f32 + 4.0f * f17, f25 + f34 * 0.23f, 5.5f * f17, color);
        f25 += f34 + f12 * f17;
        int n8 = Math.max(0, n4 - n3);
        this.S = Math.max(0, Math.min(this.S, n8));
        for (int i2 = 0; i2 < n5 && (n2 = this.S + i2) < list2.size(); ++i2) {
            String string2;
            Object t = list2.get(n2);
            f5 = f20 + f12 * f17;
            f4 = f25 + (float)i2 * f9 * f17;
            f3 = f22 - f12 * 2.0f * f17;
            float f35 = f9 * f17;
            boolean bl2 = itemListSetting.a(t);
            Identifier mc19 = this.a(itemListSetting, t);
            if (mc19 == null) continue;
            new PanelRenderer(mc13, f5, f4, f3, f35).a(bl2 ? GuiRenderer.a(MenuGuiScreen.c(), (int)(50.0f * f24)) : GuiRenderer.a(new Color(40, 40, 40), (int)(70.0f * f24))).a(3.0f * f17).j();
            float f36 = 4.0f * f17;
            if (bl && this.U != null && t instanceof Item) {
                Item string2_p;
                string2_p = (Item)t;
                ItemStack mc33 = new ItemStack((ItemConvertible)string2_p);
                float f37 = f35 - 4.0f * f17;
                float f38 = f5 + 2.0f * f17;
                float f39 = f4 + (f35 - f37) * 0.5f;
                float f40 = RenderScale.h();
                this.U.getMatrices().pushMatrix();
                this.U.getMatrices().translate(f38 * f40, f39 * f40);
                float f41 = f37 / 16.0f * f40;
                this.U.getMatrices().scale(f41, f41);
                this.U.drawItem(mc33, 0, 0);
                this.U.getMatrices().popMatrix();
                f36 = f37 + 4.0f * f17;
            }
            string2_p = mc19.getPath().replace("_", " ");
            FontManager.a().a(mc13, new StringConstant(string2_p), f5 + f36, f4 + f35 * 0.25f, 5.2f * f17, GuiRenderer.a(Color.WHITE, n7));
            if (bl2) {
                GuiRenderer.a(mc13, "check", f5 + f3 - 8.0f * f17, f4 + f35 * 0.25f, 6.0f * f17, 6.0f * f17, GuiRenderer.a(MenuGuiScreen.c(), n7));
            }
            if (!(f6 > 0.85f)) continue;
            new PanelRenderer(mc13, f5, f4, f3, f35).a(new Color(0, 0, 0, 0)).j().a(0, () -> d.lambda$drawRegistriesPopup$12((ItemListSetting)itemListSetting, t));
        }
        if (n4 > n3) {
            float f42 = f25;
            float f43 = (float)n5 * f9 * f17;
            float f44 = f20 + f22 - 4.0f * f17;
            f5 = 2.0f * f17;
            new PanelRenderer(mc13, f44, f42, f5, f43).a(GuiRenderer.a(new Color(40, 40, 40), (int)(100.0f * f24))).a(1.0f * f17).j();
            f4 = Math.max(10.0f * f17, f43 * (float)n5 / (float)n4);
            f3 = f42 + (f43 - f4) * (float)this.S / (float)Math.max(1, n8);
            new PanelRenderer(mc13, f44, f3, f5, f4).a(GuiRenderer.a(MenuGuiScreen.c(), (int)(180.0f * f24))).a(1.0f * f17).j();
        }
    }

    private Identifier a(ItemListSetting itemListSetting, Object object) {
        return itemListSetting.e().getId(object);
    }

    private boolean d() {
        if (this.O == null) {
            return false;
        }
        float f2 = this.O.e() == Registries.ITEM ? 175.0f : 145.0f;
        float f3 = 180.0f;
        float f4 = this.P + 6.0f;
        if (f4 + f2 > RenderScale.c()) {
            f4 = this.P - f2 - 6.0f;
        }
        float f5 = this.Q;
        return RenderScale.b(f4 - 8.0f, f5 - 8.0f, f4 + f2 + 8.0f, f5 + f3 + 8.0f);
    }

    private void a(ColorSetting colorSetting, float f2, float f3) {
        if (this.G == colorSetting) {
            this.G = null;
            this.H = 0;
        } else {
            this.G = colorSetting;
            this.H = 0;
            this.M = f2;
            this.N = f3;
            GuiRenderer.b("clickgui.cpicker." + colorSetting.d().a(), 0.0f);
        }
    }

    private void a(MatrixStack mc13, float f2, Color[] colorArray) {
        float f3;
        float f4;
        Color color;
        if (this.G == null) {
            return;
        }
        ColorSetting colorSetting = this.G;
        String string = "clickgui.cpicker." + colorSetting.d().a();
        float f5 = GuiRenderer.a(string, 1.0f, 0.06f);
        float f6 = GuiRenderer.g(f5);
        if (f5 < 0.01f) {
            return;
        }
        float f7 = 100.0f;
        float f8 = 95.0f;
        float f9 = this.M + 16.0f;
        float f10 = this.N;
        if (f9 + f7 > RenderScale.c()) {
            f9 = this.M - f7 - 10.0f;
        }
        if (f10 + f8 > RenderScale.d()) {
            f10 = RenderScale.d() - f8 - 5.0f;
        }
        float f11 = f6;
        float f12 = f9 + f7 * 0.5f;
        float f13 = f10 + f8 * 0.5f;
        float f14 = f12 - f7 * 0.5f * f11;
        float f15 = f13 - f8 * 0.5f * f11;
        float f16 = f7 * f11;
        float f17 = f8 * f11;
        this.I = f14;
        this.J = f15;
        this.K = f16;
        this.L = f17;
        float f18 = 8.0f;
        int n2 = (int)(230.0f * f5);
        new PanelRenderer(mc13, f14, f15, f16, f17).a(GuiRenderer.a(new Color(18, 18, 18), n2)).a(16.0f, 1.0f).a(f18).j();
        if (f5 < 0.5f) {
            return;
        }
        float f19 = GuiRenderer.b((f5 - 0.3f) / 0.7f, 0.0f, 1.0f);
        float f20 = 6.0f;
        float f21 = f17 - f20 * 2.0f;
        float f22 = f14 + f20;
        float f23 = f15 + f20;
        float f24 = 8.0f;
        float f25 = 5.0f;
        float f26 = f22 + f21 + f25;
        float f27 = f26 + f24 + f25;
        float[] fArray = colorSetting.e();
        int n3 = (int)(f19 * 255.0f);
        Color color2 = Color.getHSBColor(fArray[0], 1.0f, 1.0f);
        new PanelRenderer(mc13, f22, f23, f21, f21).a(GuiRenderer.a(Color.WHITE, n3), GuiRenderer.a(color2, n3), GuiRenderer.a(Color.WHITE, n3), GuiRenderer.a(color2, n3)).a(2.0f).j();
        new PanelRenderer(mc13, f22, f23, f21, f21).a(GuiRenderer.a(Color.BLACK, n3), GuiRenderer.a(Color.BLACK, n3), new Color(0, 0, 0, 0), new Color(0, 0, 0, 0)).a(2.0f).j();
        float f28 = f22 + fArray[1] * f21;
        float f29 = f23 + (1.0f - fArray[2]) * f21;
        float f30 = 2.5f;
        new PanelRenderer(mc13, f28 - f30, f29 - f30, f30 * 2.0f, f30 * 2.0f).a(GuiRenderer.a(Color.WHITE, n3)).a(f30).j();
        int n4 = 12;
        float f31 = f21 / (float)n4;
        for (int i2 = 0; i2 < n4; ++i2) {
            Color color3 = GuiRenderer.a(Color.getHSBColor((float)i2 / (float)n4, 1.0f, 1.0f), n3);
            color = GuiRenderer.a(Color.getHSBColor((float)(i2 + 1) / (float)n4, 1.0f, 1.0f), n3);
            float f32 = f23 + (float)i2 * f31;
            f4 = i2 == 0 ? 2.0f : 0.0f;
            f3 = i2 == n4 - 1 ? 2.0f : 0.0f;
            new PanelRenderer(mc13, f26, f32, f24, f31).a(color, color, color3, color3).a(f4, f4, f3, f3).j();
        }
        float f33 = f23 + fArray[0] * f21;
        float f34 = 2.0f;
        new PanelRenderer(mc13, f26 - 1.0f, f33 - f34 * 0.5f, f24 + 2.0f, f34).a(GuiRenderer.a(Color.WHITE, n3)).a(f34 * 0.5f).j();
        new PanelRenderer(mc13, f27, f23, f24, f21).a(GuiRenderer.a(new Color(140, 140, 140), n3)).a(2.0f).j();
        color = GuiRenderer.a(colorSetting.d(), n3);
        Color color4 = GuiRenderer.a(new Color(colorSetting.d().getRed(), colorSetting.d().getGreen(), colorSetting.d().getBlue(), 0), 0);
        new PanelRenderer(mc13, f27, f23, f24, f21).a(color4, color4, color, color).a(2.0f).j();
        f4 = 1.0f - (float)colorSetting.f() / 255.0f;
        f3 = f23 + f4 * f21;
        new PanelRenderer(mc13, f27 - 1.0f, f3 - f34 * 0.5f, f24 + 2.0f, f34).a(GuiRenderer.a(Color.WHITE, n3)).a(f34 * 0.5f).j();
    }

    private void b(MatrixStack mc13, float f2, Color[] colorArray) {
        String string;
        String string2_p;
        float f3 = 55.0f;
        float f4 = 14.0f;
        float f5 = 3.0f;
        float f6 = 6.0f;
        float f7 = 6.0f;
        float f8 = 5.0f;
        AuthState authState = BackendClient.getInstance().g();
        if (authState == AuthState.AUTHENTICATED && BackendClient.getInstance().h() != null) {
            string2_p = BackendClient.getInstance().h().a();
            string = "users";
        } else {
            string2_p = "Login";
            string = "keyboard";
        }
        this.a(mc13, f6, f7, f3, f4, f8, string, string2_p, f2, colorArray, "clickgui.btn.auth", () -> ((ClickGuiScreen)this).lambda$drawBottomBar$13((AuthState)authState), () -> ((ClickGuiScreen)this).lambda$drawBottomBar$14(), arg_0 -> ((ClickGuiScreen)this).lambda$drawBottomBar$15(arg_0));
        Color color = switch (AuthStateSwitchMap.a[authState.ordinal()]) {
            case 1 -> new Color(80, 220, 100, 255);
            case 2 -> new Color(255, 200, 50, 255);
            default -> new Color(220, 70, 70, 255);
        };
        float f9 = 2.0f;
        new PanelRenderer(mc13, f6 + 3.0f, f7 + f4 - f9 * 2.0f - 1.5f, f9 * 2.0f, f9 * 2.0f).a(color).a(f9).j();
        this.a(mc13, f6 + (f3 + f5), f7, f3, f4, f8, "folder", "Configs", f2, colorArray, "clickgui.btn.config", () -> ((ClickGuiScreen)this).lambda$drawBottomBar$16(), () -> ((ClickGuiScreen)this).lambda$drawBottomBar$17(), arg_0 -> ((ClickGuiScreen)this).lambda$drawBottomBar$18(arg_0));
        this.a(mc13, f6 + (f3 + f5) * 2.0f, f7, f3, f4, f8, "visual", "Settings", f2, colorArray, "clickgui.btn.settings", () -> ((ClickGuiScreen)this).lambda$drawBottomBar$19(), () -> ((ClickGuiScreen)this).lambda$drawBottomBar$20(), arg_0 -> ((ClickGuiScreen)this).lambda$drawBottomBar$21(arg_0));
        this.a(mc13, f6 + (f3 + f5) * 3.0f, f7, f3, f4, f8, "visual", "HUD Editor", f2, colorArray, "clickgui.btn.hud", () -> ((ClickGuiScreen)this).lambda$drawBottomBar$22(), () -> ((ClickGuiScreen)this).lambda$drawBottomBar$23(), arg_0 -> ((ClickGuiScreen)this).lambda$drawBottomBar$24(arg_0));
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, String string, String string2_p, float f7, Color[] colorArray, String string3, Runnable runnable, BooleanSupplier booleanSupplier, Consumer consumer) {
        float f8 = GuiRenderer.a(string3, RenderScale.a(f2, f3, f4, f5) ? 1.0f : 0.0f, 0.12f);
        Color color = GuiRenderer.a(new Color(14, 14, 14, 130), GuiRenderer.a(colorArray[0], 180), f8);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(color).a(14.0f, 1.0f).a(f6).j();
        if (RenderScale.a(f2, f3, f4, f5)) {
            boolean bl;
            boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
            if (bl && !booleanSupplier.getAsBoolean()) {
                SoundManager.b();
                runnable.run();
                return;
            }
            if (!bl) {
                consumer.accept(false);
            }
        }
        float f9 = 6.0f;
        float f10 = f2 + 4.0f;
        float f11 = f3 + (f5 - f9) * 0.5f;
        GuiRenderer.a(mc13, string, f10, f11, f9, f9, GuiRenderer.a(Color.WHITE, (int)(200.0f + 55.0f * f8)));
        FontManager.a().a(mc13, new StringConstant(string2_p), f10 + f9 + 2.0f, f3 + f5 * 0.25f, 5.0f, GuiRenderer.a(Color.WHITE, (int)(200.0f + 55.0f * f8)));
    }

    private void e() {
        boolean bl;
        boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
        if (!bl) {
            if (this.r != null) {
                this.c();
                this.r = null;
            }
            return;
        }
        if (this.r != null) {
            this.r.b = (float)RenderScale.j() - this.s;
            this.r.c = (float)RenderScale.k() - this.t;
        }
    }

    private void f() {
        boolean bl;
        float f2 = (float)RenderScale.j();
        float f3 = (float)RenderScale.k();
        boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
        if (!bl) {
            this.x = null;
            this.y = null;
            this.A = false;
        } else {
            if (this.x == null && this.y == null) {
                float[] fArray;
                for (Map.Entry entry : this.E.entrySet()) {
                    fArray = (float[])entry.getValue();
                    if (!(f2 >= fArray[0]) || !(f2 <= fArray[0] + fArray[2]) || !(f3 >= fArray[1]) || !(f3 <= fArray[1] + fArray[3])) continue;
                    this.x = (FloatSetting)entry.getKey();
                    this.C = fArray[0];
                    this.D = fArray[2];
                    break;
                }
                if (this.x == null) {
                    for (Map.Entry entry : this.F.entrySet()) {
                        fArray = (float[])entry.getValue();
                        if (!(f2 >= fArray[0]) || !(f2 <= fArray[0] + fArray[2]) || !(f3 >= fArray[1]) || !(f3 <= fArray[1] + fArray[3])) continue;
                        this.y = (DoubleSetting)entry.getKey();
                        this.C = fArray[0];
                        this.D = fArray[2];
                        float f4 = fArray[5];
                        float f5 = fArray[4];
                        if (Math.abs(f4 - f5) <= 7.0f) {
                            this.A = true;
                            float f6 = GuiRenderer.b((f2 - this.C) / this.D, 0.0f, 1.0f);
                            this.B = this.y.k() + (this.y.l() - this.y.k()) * f6;
                            break;
                        }
                        this.A = false;
                        this.z = Math.abs(f2 - f4) <= Math.abs(f2 - f5);
                        break;
                    }
                }
            }
            if (this.x != null) {
                float f7 = (f2 - this.C) / this.D;
                this.x.setValueFromGui(f7);
            }
            if (this.y != null) {
                float f8 = GuiRenderer.b((f2 - this.C) / this.D, 0.0f, 1.0f);
                float f9 = this.y.k() + (this.y.l() - this.y.k()) * f8;
                if (this.A) {
                    float f10 = Math.max(this.y.m(), 0.001f);
                    if (f9 > this.B + f10) {
                        this.z = true;
                        this.A = false;
                    } else if (f9 < this.B - f10) {
                        this.z = false;
                        this.A = false;
                    }
                } else if (this.z) {
                    this.y.b(f9);
                } else {
                    this.y.a(f9);
                }
            }
        }
    }

    private void g() {
        boolean bl;
        if (this.G == null) {
            return;
        }
        float f2 = (float)RenderScale.j();
        float f3 = (float)RenderScale.k();
        boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
        if (!bl) {
            this.H = 0;
            return;
        }
        ColorSetting colorSetting = this.G;
        float[] fArray = colorSetting.e();
        float f4 = 6.0f;
        float f5 = this.L - f4 * 2.0f;
        float f6 = this.I + f4;
        float f7 = this.J + f4;
        float f8 = 8.0f;
        float f9 = 5.0f;
        float f10 = f6 + f5 + f9;
        float f11 = f10 + f8 + f9;
        if (this.H == 0) {
            if (f2 >= f6 && f2 <= f6 + f5 && f3 >= f7 && f3 <= f7 + f5) {
                this.H = 1;
            } else if (f2 >= f10 && f2 <= f10 + f8 && f3 >= f7 && f3 <= f7 + f5) {
                this.H = 2;
            } else if (f2 >= f11 && f2 <= f11 + f8 && f3 >= f7 && f3 <= f7 + f5) {
                this.H = 3;
            }
        }
        if (this.H == 1) {
            float f12 = GuiRenderer.b((f2 - f6) / f5, 0.0f, 1.0f);
            float f13 = 1.0f - GuiRenderer.b((f3 - f7) / f5, 0.0f, 1.0f);
            colorSetting.a(fArray[0], f12, f13, colorSetting.f());
        } else if (this.H == 2) {
            float f14 = GuiRenderer.b((f3 - f7) / f5, 0.0f, 1.0f);
            colorSetting.a(f14, fArray[1], fArray[2], colorSetting.f());
        } else if (this.H == 3) {
            float f15 = 1.0f - GuiRenderer.b((f3 - f7) / f5, 0.0f, 1.0f);
            colorSetting.a(fArray[0], fArray[1], fArray[2], Math.round(f15 * 255.0f));
        }
    }

    private boolean h() {
        if (this.G == null) {
            return false;
        }
        float f2 = (float)RenderScale.j();
        float f3 = (float)RenderScale.k();
        return f2 >= this.I && f2 <= this.I + this.K && f3 >= this.J && f3 <= this.J + this.L;
    }

    public boolean mouseScrolled(double d2, double d3, double d4, double d5) {
        if (this.O != null && this.d()) {
            int n2 = this.T ? this.O.g().size() : this.O.f().size();
            int n3 = 8;
            int n4 = Math.max(0, n2 - n3);
            this.S -= (int)Math.signum(d5);
            this.S = Math.max(0, Math.min(this.S, n4));
            return true;
        }
        for (int i2 = this.q.size() - 1; i2 >= 0; --i2) {
            float f2;
            float f3;
            float f4;
            CategoryPanel categoryPanel = (CategoryPanel)this.q.get(i2);
            if (!categoryPanel.d || !RenderScale.a(categoryPanel.b, categoryPanel.c, 115.0f, f4 = 22.0f + Math.min(f3 = this.onMouseButton(categoryPanel), f2 = RenderScale.d() * 0.65f))) continue;
            categoryPanel.h += (float)(d5 * 8.0);
            float f5 = Math.max(0.0f, f3 - f2);
            categoryPanel.h = Math.max(-f5, Math.min(0.0f, categoryPanel.h));
            return true;
        }
        return super.mouseScrolled(d2, d3, d4, d5);
    }

    public boolean shouldPause() {
        return false;
    }

    public void close() {
        this.v = null;
        this.w = false;
        Main.eventBus().unregister((Object)a);
        if (!this.o) {
            this.o = true;
        }
    }

    private void onMouseButton(MouseButtonEvent mouseButtonEvent) {
        if (Main.mc.currentScreen != this || this.v == null) {
            return;
        }
        if (mouseButtonEvent.action != 1) {
            return;
        }
        if (this.w && mouseButtonEvent.button == 0) {
            this.w = false;
            return;
        }
        this.v.resetKey(mouseButtonEvent.button);
        this.v = null;
        this.w = false;
    }

    private void a(Module module) {
        if (this.u == module) {
            this.u = null;
        } else {
            this.u = module;
            this.G = null;
            this.H = 0;
        }
    }

    private float a(CategoryPanel categoryPanel) {
        float f2 = 4.0f;
        for (Module module : categoryPanel.f) {
            f2 += 17.5f;
            if (this.u != module || module.getSettings().isEmpty()) continue;
            float f3 = this.b(module);
            float f4 = GuiRenderer.a("clickgui.drop." + module.getName().a(), f3, 0.18f);
            f2 += f4;
        }
        return f2;
    }

    private float b(Module module) {
        float f2 = 3.0f;
        for (Setting setting : module.getSettings()) {
            if (!setting.isVisible()) continue;
            f2 += this.a(setting) + 1.5f;
        }
        return f2;
    }

    private float a(Setting setting) {
        if (setting instanceof ModeSetting) {
            ModeSetting modeSetting = (ModeSetting)setting;
            return this.onMouseButton(modeSetting);
        }
        if (setting instanceof HotbarSlotSetting) {
            return 26.0f;
        }
        if (setting instanceof FloatSetting || setting instanceof DoubleSetting) {
            return 15.0f;
        }
        return 15.0f;
    }

    private float a(ModeSetting modeSetting) {
        float f2 = 5.0f;
        float f3 = 3.5f;
        float f4 = 1.5f;
        float f5 = 12.0f;
        float f6 = f2 + 4.0f;
        float f7 = 99.0f;
        float f8 = 0.0f;
        int n2 = 1;
        for (Enum enum_ : modeSetting.getModes()) {
            StringConstant stringConstant = new StringConstant(ModeSetting.setIndex(enum_));
            float f9 = FontManager.a().a(stringConstant, f2) + f3 * 2.0f;
            if (f8 > 0.0f && f8 + f9 > f7) {
                ++n2;
                f8 = 0.0f;
            }
            f8 += f9 + f4;
        }
        return f5 + (float)n2 * (f6 + f4);
    }

    public void i() {
        this.o = false;
        GuiRenderer.b(b, 0.0f);
        Main.mc.setScreen((Screen)a);
    }

    private void lambda$drawBottomBar$24(Boolean bl) {
        this.V = bl;
    }

    private boolean lambda$drawBottomBar$23() {
        return this.V;
    }

    private void lambda$drawBottomBar$22() {
        this.V = true;
        Main.mc.setScreen((Screen)HudEditorScreen.getInstance());
    }

    private void lambda$drawBottomBar$21(Boolean bl) {
        this.X = bl;
    }

    private boolean lambda$drawBottomBar$20() {
        return this.X;
    }

    private void lambda$drawBottomBar$19() {
        this.X = true;
        Main.mc.setScreen((Screen)SettingsScreen.getInstance());
    }

    private void lambda$drawBottomBar$18(Boolean bl) {
        this.W = bl;
    }

    private boolean lambda$drawBottomBar$17() {
        return this.W;
    }

    private void lambda$drawBottomBar$16() {
        this.W = true;
        Main.mc.setScreen((Screen)ConfigScreen.getInstance());
    }

    private void lambda$drawBottomBar$15(Boolean bl) {
        this.Y = bl;
    }

    private boolean lambda$drawBottomBar$14() {
        return this.Y;
    }

    private void lambda$drawBottomBar$13(AuthState authState) {
        this.Y = true;
        if (authState == AuthState.AUTHENTICATED) {
            BackendClient.getInstance().f();
        } else {
            BackendClient.getInstance().e();
        }
    }

    private static void lambda$drawRegistriesPopup$12(ItemListSetting itemListSetting, Object object) {
        ItemListSetting itemListSetting2 = itemListSetting;
        itemListSetting2.b(object);
        SoundManager.b();
    }

    private void lambda$drawRegistriesPopup$11() {
        if (!this.T) {
            this.T = true;
            this.S = 0;
            SoundManager.b();
        }
    }

    private void lambda$drawRegistriesPopup$10() {
        if (this.T) {
            this.T = false;
            this.S = 0;
            SoundManager.b();
        }
    }

    private boolean lambda$drawRegistriesPopup$9(ItemListSetting itemListSetting, String string, Object object) {
        Identifier mc19 = this.a(itemListSetting, object);
        return mc19 != null && (string.isEmpty() || mc19.getPath().contains(string));
    }

    private void lambda$drawRegistriesRow$8(ItemListSetting itemListSetting, float f2, float f3, float f4) {
        this.a(itemListSetting, f2 + f3, f4);
        SoundManager.b();
    }

    private static void lambda$drawSlotRow$7(HotbarSlotSetting hotbarSlotSetting, int n2) {
        hotbarSlotSetting.a(n2);
        SoundManager.b();
    }

    private void lambda$drawColorRow$6(ColorSetting colorSetting, float f2, float f3) {
        this.a(colorSetting, f2, f3);
        SoundManager.b();
    }

    private static void lambda$drawKeyRow$5(KeybindSetting keybindSetting) {
        keybindSetting.reset();
        SoundManager.b();
    }

    private void lambda$drawKeyRow$4(KeybindSetting keybindSetting) {
        this.v = keybindSetting;
        this.w = true;
        SoundManager.b();
    }

    private static void lambda$drawModeRow$3(ModeSetting modeSetting, int n2) {
        if (modeSetting.isMulti()) {
            modeSetting.toggleIndex(n2);
        } else {
            modeSetting.setIndex(n2);
        }
        SoundManager.b();
    }

    private static void lambda$drawBooleanRow$2(BooleanSetting booleanSetting) {
        booleanSetting.reset();
        SoundManager.b();
    }

    private static void lambda$drawButtonRow$1(ButtonSetting buttonSetting) {
        buttonSetting.e();
        SoundManager.b();
    }

    private void lambda$drawModuleRow$0(Module module) {
        this.a(module);
        SoundManager.b();
    }
}

