/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.screen;

import itz.vrgn1337.groovclient.api.backend.AuthState;

class AuthStateSwitchMap {
    static final int[] a = new int[AuthState.values().length];

    static {
        try {
            AuthStateSwitchMap.a[AuthState.AUTHENTICATED.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            AuthStateSwitchMap.a[AuthState.CONNECTING.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

