/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.screen;

import itz.vrgn1337.groovclient.api.backend.AuthState;
import itz.vrgn1337.groovclient.api.backend.BackendClient;
import itz.vrgn1337.groovclient.api.event.Priority;
import itz.vrgn1337.groovclient.api.event.hooks.KeyEvent;
import itz.vrgn1337.groovclient.api.event.hooks.MouseButtonEvent;
import itz.vrgn1337.groovclient.api.util.SoundManager;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.b.c.HudEditorScreen;
import itz.vrgn1337.groovclient.config.ClientSettings;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.TooltipRenderer;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.screen.ClickGuiScreen;
import itz.vrgn1337.groovclient.gui.screen.ConfigScreen;
import itz.vrgn1337.groovclient.gui.screen.SettingsScreen;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.ModuleManager;
import itz.vrgn1337.groovclient.setting.BooleanSetting;
import itz.vrgn1337.groovclient.setting.ButtonSetting;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import itz.vrgn1337.groovclient.setting.DoubleSetting;
import itz.vrgn1337.groovclient.setting.FloatSetting;
import itz.vrgn1337.groovclient.setting.HotbarSlotSetting;
import itz.vrgn1337.groovclient.setting.ItemListSetting;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import itz.vrgn1337.groovclient.setting.ModeSetting;
import itz.vrgn1337.groovclient.setting.Setting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.minecraft.client.input.KeyInput;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemConvertible;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.Registries;
import org.lwjgl.glfw.GLFW;

public class MenuGuiScreen
extends Screen {
    private static final MenuGuiScreen a = new MenuGuiScreen();
    private static final String b = "menu.gui.open";
    private static boolean c;
    private static int d;
    private boolean e;
    private static ModuleCategory f;
    private static final float g = 500.0f;
    private static final float h = 315.0f;
    private static final float i = 12.0f;
    private static final float j = 25.0f;
    private static final float k = 7.5f;
    private static final float l = 25.0f;
    private static final float m = 20.0f;
    private static final float n = 50.0f;
    private static float o;
    private static float p;
    private static float q;
    private static float r;
    private static float s;
    private static float t;
    private static float u;
    private static boolean v;
    private static boolean w;
    private static Color x;
    private static final Color y;
    private static boolean z;
    private static final Map A;
    private static ModuleCategory B;
    private static ModuleCategory C;
    private static int D;
    private static final List E;
    private static final List F;
    private static final List G;
    private static final List H;
    private static Color[] I;
    private Module J = null;
    private FloatSetting K = null;
    private DoubleSetting L = null;
    private boolean M = false;
    private boolean N = false;
    private float O = 0.0f;
    private float P;
    private float Q;
    private final HashMap<ModuleCategory, List<Module>> R = new HashMap<>();
    private final HashMap<ModuleCategory, List<Module>> S = new HashMap<>();
    private KeybindSetting T = null;
    private boolean U = false;
    private boolean V = false;
    private boolean W = false;
    private boolean X = false;
    private boolean Y = false;
    private boolean Z = false;
    private final StringBuilder aa = new StringBuilder();
    private final List ab = new ArrayList();
    private ColorSetting ac = null;
    private int ad = 0;
    private float ae;
    private float af;
    private float ag;
    private float ah;
    private float ai;
    private ItemListSetting aj = null;
    private float ak;
    private float al;
    private final StringBuilder am = new StringBuilder();
    private int an = 0;
    private boolean ao = false;
    private DrawContext ap = null;
    private FloatSetting aq = null;
    private float ar = 0.0f;
    private long as = 0L;
    private float at = 0.0f;
    private long au = 0L;
    private static final float av = 5.0f;
    private static final float aw = 22.0f;
    private static final float ax = 22.0f;
    private static final float ay = 36.0f;
    private static final float az = 3.0f;
    private final Map aA = new HashMap();
    private final Map aB = new HashMap();
    private long aC = 0L;
    private float aD;
    private float aE;
    private float aF;
    private float aG;
    private static final float aH = 6.0f;
    private static final float aI = 3.0f;
    private static final float aJ = 3.0f;
    private static final float aK = 16.0f;
    private static final Color aL;

    public static MenuGuiScreen getInstance() {
        return a;
    }

    public void a(Color color) {
        x = color;
        I = new Color[]{x, x.darker(), x.darker().darker(), x.darker().darker().darker()};
    }

    public void a(boolean bl) {
        z = bl;
    }

    public static Color[] b() {
        return I;
    }

    public static Color c() {
        return I[0];
    }

    public static float d() {
        return q;
    }

    protected MenuGuiScreen() {
        super((Text)Text.empty());
    }

    public void init() {
        Main.eventBus().register((Object)a);
    }

    @Priority(value=2100)
    private void onKey(KeyEvent keyEvent) {
        if (Main.mc.player == null) {
            return;
        }
        if (Main.mc.currentScreen != null) {
            return;
        }
        if (keyEvent.key == d) {
            if (ClientSettings.getInstance().f() == 1) {
                ClickGuiScreen.getInstance().i();
            } else {
                MenuGuiScreen.a.e = false;
                GuiRenderer.b(b, 0.0f);
                Main.mc.setScreen((Screen)a);
            }
        }
    }

    public boolean keyPressed(KeyInput mc27) {
        if (this.T != null) {
            if (mc27.key() == 256) {
                this.T.reset();
                this.l();
                return true;
            }
            if (mc27.key() != -1) {
                this.T.setKey(mc27.key());
            } else {
                this.T.setKeyFromGui(mc27.scancode());
            }
            this.l();
            return true;
        }
        if (this.aj != null) {
            String string;
            if (mc27.key() == 256) {
                this.aj = null;
                return true;
            }
            if (mc27.key() == 259) {
                if (this.am.length() > 0) {
                    this.am.deleteCharAt(this.am.length() - 1);
                    this.an = 0;
                }
                return true;
            }
            String string2 = string = mc27.key() == 32 ? " " : GLFW.glfwGetKeyName((int)mc27.key(), (int)mc27.scancode());
            if (string != null && !string.isEmpty()) {
                this.am.append(string.toLowerCase());
                this.an = 0;
                return true;
            }
            return true;
        }
        if (this.Z) {
            String string;
            if (mc27.key() == 256) {
                this.j();
                return true;
            }
            if (mc27.key() == 259) {
                if (this.aa.length() > 0) {
                    this.aa.deleteCharAt(this.aa.length() - 1);
                    this.k();
                }
                if (this.aa.length() == 0) {
                    this.j();
                }
                return true;
            }
            String string3 = string = mc27.key() == 32 ? " " : GLFW.glfwGetKeyName((int)mc27.key(), (int)mc27.scancode());
            if (string != null && !string.isEmpty()) {
                this.aa.append(string.toLowerCase());
                this.k();
                return true;
            }
            return true;
        }
        if (mc27.key() != 256 && mc27.key() != d) {
            String string = GLFW.glfwGetKeyName((int)mc27.key(), (int)mc27.scancode());
            if (ModuleManager.getInstance().b(mc27.key(), mc27.scancode())) {
                return true;
            }
            if (string != null && !string.isEmpty()) {
                this.i();
                this.aa.append(string.toLowerCase());
                this.k();
                return true;
            }
        }
        if (mc27.key() == 256 || mc27.key() == d) {
            this.e = true;
            return true;
        }
        return super.keyPressed(mc27);
    }

    protected void applyBlur(DrawContext mc15) {
    }

    public void render(DrawContext mc15, int n2, int n3, float f2) {
        if (!c) {
            E.addAll(ModuleManager.a(ModuleCategory.COMBAT));
            F.addAll(ModuleManager.a(ModuleCategory.MOVEMENT));
            G.addAll(ModuleManager.a(ModuleCategory.VISUAL));
            H.addAll(ModuleManager.a(ModuleCategory.Utility));
            c = true;
        }
        MatrixStack mc13 = new MatrixStack();
        mc13.push();
        TooltipRenderer.a();
        float f3 = GuiRenderer.a(b, this.e ? 0.0f : 1.0f, 0.065f);
        if (this.e && f3 <= 0.01f) {
            this.e = false;
            GuiRenderer.b(b);
            Main.mc.setScreen(null);
            mc13.pop();
            return;
        }
        float f4 = 0.6f + GuiRenderer.g(f3) * 0.15f;
        float f5 = (RenderScale.c() - 24.0f) / 500.0f;
        float f6 = (RenderScale.d() - 24.0f) / 315.0f;
        float f7 = Math.max(0.45f, Math.min(f5, f6));
        q = Math.min(f4, f7);
        float f8 = RenderScale.b(500.0f * q);
        float f9 = RenderScale.c(315.0f * q);
        o = f8 + t;
        p = f9 + u;
        this.a(f8, f9);
        this.g();
        this.e();
        this.ap = mc15;
        this.h();
        this.a(mc13);
        this.b(mc13);
        this.c(mc13);
        this.a(mc13, this.aD, this.aE, this.aF);
        this.h(mc13);
        this.i(mc13);
        this.d(mc13);
        this.e(mc13);
        this.f(mc13);
        this.g(mc13);
        TooltipRenderer.a(mc13, q);
        mc13.pop();
    }

    private void a(float f2, float f3) {
        boolean bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
        float f4 = (float)RenderScale.j();
        float f5 = (float)RenderScale.k();
        float f6 = 24.0f * q;
        boolean bl2 = RenderScale.a(o, p, 500.0f * q, f6);
        if (bl && !w && bl2 && !this.f() && !this.n()) {
            v = true;
            r = f4 - o;
            s = f5 - p;
        }
        if (!bl) {
            v = false;
        }
        if (v) {
            o = f4 - r;
            p = f5 - s;
            t = o - f2;
            u = p - f3;
        }
        w = bl;
    }

    private void a(MatrixStack mc13) {
        PanelRenderer panelRenderer = new PanelRenderer(mc13, o, p, 500.0f * q, 315.0f * q).a(I[0], I[1], I[2], I[3]).a();
        if (z) {
            panelRenderer.a(y).a(20.0f, 1.0f).d();
        } else {
            panelRenderer.b(1.5f, 4.0f, 2.0f, 0.5f);
        }
        panelRenderer.j();
    }

    private void b(MatrixStack mc13) {
        float f2 = 20.0f * q;
        float f3 = 100.0f * q;
        float f4 = 315.0f * q - f2 * 2.0f;
        float f5 = o + f2;
        float f6 = p + f2;
        ModuleCategory[] moduleCategoryArray = ModuleCategory.values();
        int n2 = moduleCategoryArray.length;
        if (n2 == 0) {
            return;
        }
        float f7 = f4 / (float)n2;
        float f8 = 9.0f * q;
        float f9 = Math.min(f7 * 0.48f, f3 * 0.28f) * 0.5f;
        float f10 = 10.0f * q;
        float f11 = f10 + f9 + 6.0f * q;
        float f12 = f7 * 0.5f - 4.0f * q;
        new PanelRenderer(mc13, f5, f6, f3, f4).a(y).a(20.0f, 1.0f).a(f8).j();
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            if (moduleCategoryArray[i2] != B) continue;
            n3 = i2;
            break;
        }
        float f13 = GuiRenderer.a("menu.category.selector.index", (float)n3, 0.22f);
        float f14 = f6 + f7 * f13;
        float f15 = GuiRenderer.b(1.0f - f13, 0.0f, 1.0f);
        float f16 = GuiRenderer.b(f13 - ((float)n2 - 2.0f), 0.0f, 1.0f);
        float f17 = f8 * f15;
        float f18 = f8 * f16;
        new PanelRenderer(mc13, f5, f14, f3, f7).a(GuiRenderer.a(I[0], 215), GuiRenderer.a(I[1], 215), GuiRenderer.a(I[2], 205), GuiRenderer.a(I[3], 205)).a(f17, f17, f18, f18).j();
        for (int i3 = 0; i3 < n2; ++i3) {
            ModuleCategory moduleCategory = moduleCategoryArray[i3];
            float f19 = f6 + f7 * (float)i3;
            boolean bl = i3 == 0;
            boolean bl2 = i3 == n2 - 1;
            float f20 = bl ? f8 : 0.0f;
            float f21 = bl2 ? f8 : 0.0f;
            new PanelRenderer(mc13, f5, f19, f3, f7).a(GuiRenderer.a(new Color(14, 14, 14), 115)).a(f20, f20, f21, f21).j().a(0, () -> ((MenuGuiScreen)this).lambda$drawCategories$0((ModuleCategory)moduleCategory));
            float f22 = f19 + (f7 - f9) * 0.5f;
            GuiRenderer.a(mc13, A.getOrDefault((Object)moduleCategory, "utility"), f5 + f10, f22, f9, f9);
            FontManager.a().a(mc13, moduleCategory.a(), f5 + f11, f19 + f12, 9.0f * q, Color.WHITE);
        }
    }

    private void c(MatrixStack mc13) {
        float f2;
        this.R.clear();
        this.S.clear();
        float f3 = 40.0f * q;
        float f4 = 40.0f * q;
        float f5 = o + 140.0f * q;
        float f6 = p + f3;
        float f7 = 325.0f * q;
        float f8 = 315.0f * q - f3 - f4;
        this.aD = f5;
        this.aE = f6;
        this.aF = f7;
        this.aG = f8;
        GuiRenderer.a(f5, f6, f7, f8);
        boolean bl = RenderScale.a(f5, f6, f7, f8);
        float f9 = GuiRenderer.a("menu.search.overlay", this.Z ? 1.0f : 0.0f, 0.16f);
        if (f9 < 0.99f) {
            f2 = 1.0f - f9;
            for (ModuleCategory moduleCategory : ModuleCategory.values()) {
                List<Module> list = this.c(moduleCategory);
                if (list.isEmpty()) continue;
                float f10 = GuiRenderer.a("menu.category.content." + moduleCategory.name(), moduleCategory == B ? 1.0f : 0.0f, 0.2f) * f2;
                if (f10 <= 0.01f) continue;
                boolean bl2 = moduleCategory == B;
                float f11 = bl2 ? (float)D : (float)(-D);
                float f12 = (1.0f - f10) * (16.0f * q) * f11;
                boolean bl3 = !this.Z && moduleCategory == B && f10 > 0.85f && bl && !this.f();
                float f13 = this.a(moduleCategory);
                this.a(mc13, list, f10, f12, bl3, f13);
            }
        }
        if (f9 > 0.01f) {
            f2 = (1.0f - f9) * 10.0f * q;
            boolean bl4 = this.Z && f9 > 0.85f && bl && !this.f();
            this.a(mc13, this.ab, f9, f2, bl4, 0.0f);
        }
        GuiRenderer.b();
        if (ClientSettings.getInstance().e() && !this.Z) {
            this.a(mc13, f5, f6, f7, f8);
        }
        if (C != null && (f2 = GuiRenderer.a("menu.category.content." + C.name(), 0.0f, 0.2f)) <= 0.01f) {
            C = null;
        }
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, float f5) {
        ModuleCategory moduleCategory = B;
        float f6 = this.b(moduleCategory);
        if (f6 <= 0.5f) {
            return;
        }
        float f7 = this.a(moduleCategory);
        float f8 = -f7 / f6;
        float f9 = f5 / (f5 + f6);
        float f10 = 3.0f * q;
        float f11 = f2 + f4 + 2.0f * q;
        float f12 = f5 - 4.0f * q;
        float f13 = f3 + 2.0f * q;
        float f14 = Math.max(12.0f * q, f12 * f9);
        float f15 = f13 + f8 * (f12 - f14);
        float f16 = GuiRenderer.a("menu.scrollbar.track", RenderScale.a(f11 - 4.0f * q, f3, f10 + 8.0f * q, f5) ? 1.0f : 0.0f, 0.12f);
        new PanelRenderer(mc13, f11, f13, f10, f12).a(GuiRenderer.a(new Color(255, 255, 255), (int)(10.0f + 15.0f * f16))).a(f10 * 0.5f).j();
        Color color = GuiRenderer.a(new Color(255, 255, 255, 60), GuiRenderer.a(I[0], 160), f16);
        new PanelRenderer(mc13, f11, f15, f10, f14).a(color).a(f10 * 0.5f).j();
    }

    private void a(MatrixStack mc13, List list, float f2, float f3, boolean bl, float f4) {
        float f5 = 0.0f;
        int n2 = 0;
        for (Module module : list) {
            boolean bl2;
            float f6 = GuiRenderer.a("menu.module.gradient." + String.valueOf(module.getName()), module.isEnabled() ? 1.0f : 0.0f, 0.02f);
            Color color = GuiRenderer.a(y, GuiRenderer.a(I[0], 160), f6);
            Color color2 = GuiRenderer.a(y, GuiRenderer.a(I[1], 160), f6);
            Color color3 = GuiRenderer.a(y, GuiRenderer.a(I[2], 160), f6);
            Color color4 = GuiRenderer.a(y, GuiRenderer.a(I[3], 160), f6);
            Color color5 = GuiRenderer.a(new Color(0, 0, 0, 0), color, f2);
            Color color6 = GuiRenderer.a(new Color(0, 0, 0, 0), color2, f2);
            Color color7 = GuiRenderer.a(new Color(0, 0, 0, 0), color3, f2);
            Color color8 = GuiRenderer.a(new Color(0, 0, 0, 0), color4, f2);
            int n3 = Math.round(f6 * f2 * 255.0f);
            int n4 = Math.round((1.0f - f6) * f2 * 255.0f);
            int n5 = Math.round(f2 * 255.0f);
            float f7 = o + 140.0f * q + f3;
            float f8 = p + (40.0f + 31.0f * (float)n2) * q + f5 + f4;
            float f9 = 325.0f * q;
            float f10 = 25.0f * q;
            float f11 = 8.0f * q;
            float f12 = 25.0f * q;
            float f13 = 7.5000005f * q;
            float f14 = 7.5f * q;
            boolean bl3 = module == this.J;
            float f15 = bl3 && !module.getSettings().isEmpty() ? this.b(module) : 0.0f;
            float f16 = GuiRenderer.a("menu.dropdown." + module.getName().a(), f15, 0.2f);
            float f17 = 12.0f * q;
            float f18 = f17 * (1.0f - GuiRenderer.b(f16 / Math.max(f17, f16), 0.0f, 1.0f));
            module.onLoad();
            PanelRenderer panelRenderer = new PanelRenderer(mc13, f7, f8, f9, f10).a(color5, color6, color7, color8).a(16.0f, 1.0f).a(f17, f17, f18, f18).a(module.getName(), GuiRenderer.a(Color.WHITE, n5), f11, false).d(f12, f13).j().i();
            boolean bl4 = bl2 = module.isAlwaysListening() || module.isHidden();
            if (bl) {
                if (!module.isAlwaysListening()) {
                    panelRenderer.a(0, () -> ((Module)module).toggle());
                }
                if (!module.getSettings().isEmpty()) {
                    panelRenderer.a(1, () -> ((MenuGuiScreen)this).lambda$drawModuleList$1((Module)module));
                }
                if (RenderScale.b(f7, f8, f7 + f9, f8 + f10)) {
                    TooltipRenderer.a(module.getDescription());
                }
            }
            float f19 = f7 + 8.0f * q;
            float f20 = f8 + (f10 - f14) * 0.5f;
            if (!bl2) {
                GuiRenderer.a(mc13, "cross", f19, f20, f14, f14, GuiRenderer.a(Color.LIGHT_GRAY, n4));
                GuiRenderer.a(mc13, "check", f19, f20, f14, f14, GuiRenderer.a(x.brighter(), n3));
            } else {
                GuiRenderer.a(mc13, "keyboard", f19, f20, f14, f14, Color.LIGHT_GRAY);
            }
            if (f16 > 0.5f) {
                float f21 = f8 + f10;
                this.a(mc13, module, f7, f21, f9, f16, f2, bl);
                f5 += f16;
            }
            ++n2;
        }
    }

    private void a(MatrixStack mc13, Module module, float f2, float f3, float f4, float f5, float f6, boolean bl) {
        float f7 = 9.0f * q;
        new PanelRenderer(mc13, f2, f3, f4, f5).a(new Color(0, 0, 0, 0)).a(16.0f, 1.0f).a(0.0f, 0.0f, f7, f7).j();
        float f8 = this.b(module);
        float f9 = f8 > 0.0f ? GuiRenderer.b(f5 / f8, 0.0f, 1.0f) : 0.0f;
        float f10 = f6 * f9;
        float f11 = f3 + f5;
        float f12 = f2 + 5.0f * q;
        float f13 = f4 - 10.0f * q;
        float f14 = f3 + 5.0f * q;
        for (Setting setting : module.getSettings()) {
            Setting setting2;
            float f15;
            if (!setting.isVisible()) continue;
            if (setting instanceof DoubleSetting) {
                f15 = 22.0f * q;
            } else if (setting instanceof FloatSetting) {
                f15 = 22.0f * q;
            } else if (setting instanceof ModeSetting) {
                setting2 = (ModeSetting)setting;
                f15 = this.a((ModeSetting)setting2);
            } else {
                f15 = setting instanceof HotbarSlotSetting ? 36.0f * q : 22.0f * q;
            }
            if (f14 + f15 > f11) break;
            if (bl && RenderScale.b(f12, f14, f12 + f13, f14 + f15)) {
                TooltipRenderer.a(setting.getDescription());
            }
            if (setting instanceof DoubleSetting) {
                setting2 = (DoubleSetting)setting;
                this.a(mc13, (DoubleSetting)setting2, f12, f14, f13, f15, f10);
            } else if (setting instanceof FloatSetting) {
                FloatSetting floatSetting = (FloatSetting)setting;
                this.a(mc13, floatSetting, f12, f14, f13, f15, f10);
            } else if (setting instanceof ModeSetting) {
                ModeSetting modeSetting = (ModeSetting)setting;
                this.a(mc13, modeSetting, f12, f14, f13, f15, f10, bl);
            } else if (setting instanceof ColorSetting) {
                ColorSetting colorSetting = (ColorSetting)setting;
                this.a(mc13, colorSetting, f12, f14, f13, f15, f10, bl);
            } else if (setting instanceof BooleanSetting) {
                BooleanSetting booleanSetting = (BooleanSetting)setting;
                this.a(mc13, booleanSetting, f12, f14, f13, f15, f10, bl);
            } else if (setting instanceof KeybindSetting) {
                KeybindSetting keybindSetting = (KeybindSetting)setting;
                this.a(mc13, module, keybindSetting, f12, f14, f13, f15, f10, bl);
            } else if (setting instanceof HotbarSlotSetting) {
                HotbarSlotSetting hotbarSlotSetting = (HotbarSlotSetting)setting;
                this.a(mc13, hotbarSlotSetting, f12, f14, f13, f15, f10, bl);
            } else if (setting instanceof ItemListSetting) {
                ItemListSetting itemListSetting = (ItemListSetting)setting;
                this.a(mc13, itemListSetting, f12, f14, f13, f15, f10, bl);
            } else if (setting instanceof ButtonSetting) {
                ButtonSetting buttonSetting = (ButtonSetting)setting;
                this.a(mc13, buttonSetting, f12, f14, f13, f15, f10, bl);
            }
            f14 += f15 + 3.0f * q;
        }
    }

    private void a(MatrixStack mc13, BooleanSetting booleanSetting, float f2, float f3, float f4, float f5, float f6, boolean bl) {
        float f7 = 6.0f * q;
        PanelRenderer panelRenderer = new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(14, 14, 14), (int)(80.0f * f6))).a(f7).j();
        if (bl) {
            panelRenderer.a(0, () -> e.lambda$drawBooleanRow$2((BooleanSetting)booleanSetting));
        }
        FontManager.a().a(mc13, booleanSetting.a(), f2 + 7.0f * q, f3 + f5 * 0.28f, 7.0f * q, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        float f8 = 26.0f * q;
        float f9 = 12.0f * q;
        float f10 = f2 + f4 - f8 - 7.0f * q;
        float f11 = f3 + (f5 - f9) * 0.5f;
        float f12 = GuiRenderer.a("setting.bool." + booleanSetting.a().a(), booleanSetting.getValue() ? 1.0f : 0.0f, 0.15f);
        new PanelRenderer(mc13, f10, f11, f8, f9).a(GuiRenderer.a(GuiRenderer.a(new Color(55, 55, 55, 180), I[0], f12), (int)(220.0f * f6))).a(f9 / 2.0f).j();
        float f13 = 8.0f * q;
        float f14 = f8 - f13 - 4.0f * q;
        float f15 = f10 + 2.0f * q + f12 * f14;
        float f16 = f11 + (f9 - f13) * 0.5f;
        new PanelRenderer(mc13, f15, f16, f13, f13).a(GuiRenderer.a(Color.WHITE, (int)(220.0f * f6))).a(f13 / 2.0f).j();
    }

    private void a(MatrixStack mc13, ButtonSetting buttonSetting, float f2, float f3, float f4, float f5, float f6, boolean bl) {
        float f7 = 6.0f * q;
        boolean bl2 = bl && RenderScale.b(f2, f3, f2 + f4, f3 + f5);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(14, 14, 14), (int)(80.0f * f6))).a(f7).j();
        FontManager.a().a(mc13, buttonSetting.a(), f2 + 7.0f * q, f3 + f5 * 0.28f, 7.0f * q, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        StringConstant stringConstant = buttonSetting.d();
        float f8 = 6.5f * q;
        float f9 = 8.0f * q;
        float f10 = f5 - 6.0f * q;
        float f11 = FontManager.a().a(stringConstant, f8);
        float f12 = f11 + f9 * 2.0f;
        float f13 = f2 + f4 - f12 - 6.0f * q;
        float f14 = f3 + (f5 - f10) * 0.5f;
        Color color = GuiRenderer.a(bl2 ? I[0] : new Color(40, 40, 50), (int)(220.0f * f6));
        PanelRenderer panelRenderer = new PanelRenderer(mc13, f13, f14, f12, f10).a(color).a(f7 * 0.7f).j();
        if (bl) {
            panelRenderer.a(0, () -> e.lambda$drawButtonRow$3((ButtonSetting)buttonSetting));
        }
        FontManager.a().a(mc13, stringConstant, f13 + f9, f14 + f10 * 0.22f, f8, GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)));
    }

    private float a(ModeSetting modeSetting) {
        float f2 = 7.0f * q;
        float f3 = 6.0f * q;
        float f4 = 3.0f * q;
        float f5 = 16.0f * q;
        float f6 = f2 + 6.0f * q;
        float f7 = 265.0f * q - 14.0f * q;
        float f8 = 0.0f;
        int n2 = 1;
        for (Enum enum_ : modeSetting.getModes()) {
            StringConstant stringConstant = new StringConstant(ModeSetting.setIndex(enum_));
            float f9 = FontManager.a().a(stringConstant, f2) + f3 * 2.0f;
            if (f8 > 0.0f && f8 + f9 > f7) {
                ++n2;
                f8 = 0.0f;
            }
            f8 += f9 + f4;
        }
        return f5 + (float)n2 * (f6 + f4);
    }

    private void a(MatrixStack mc13, ModeSetting modeSetting, float f2, float f3, float f4, float f5, float f6, boolean bl) {
        float f7 = 6.0f * q;
        float f8 = 7.0f * q;
        float f9 = 6.0f * q;
        float f10 = 3.0f * q;
        float f11 = 3.0f * q;
        float f12 = f8 + f10 * 2.0f;
        float f13 = 16.0f * q;
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(14, 14, 14), (int)(80.0f * f6))).a(f7).j();
        StringConstant stringConstant = modeSetting.h();
        FontManager.a().a(mc13, stringConstant, f2 + 7.0f * q, f3 + f13 * 0.18f, f8, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        float f14 = f3 + f13;
        float f15 = 0.0f;
        float f16 = f14;
        float f17 = f2 + 7.0f * q;
        float f18 = f4 - 14.0f * q;
        Enum[] enumArray = modeSetting.getModes();
        for (int i2 = 0; i2 < enumArray.length; ++i2) {
            StringConstant stringConstant2 = new StringConstant(ModeSetting.setIndex(enumArray[i2]));
            float f19 = FontManager.a().a(stringConstant2, f8) + f9 * 2.0f;
            if (f15 > 0.0f && f15 + f19 > f18) {
                f15 = 0.0f;
                f16 += f12 + f11;
            }
            float f20 = f17 + f15;
            float f21 = f16;
            boolean bl2 = modeSetting.isSelected(i2);
            Color color = bl2 ? GuiRenderer.a(I[0], (int)(200.0f * f6)) : GuiRenderer.a(new Color(40, 40, 40), (int)(160.0f * f6));
            Color color2 = bl2 ? GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)) : GuiRenderer.a(new Color(180, 180, 180), (int)(200.0f * f6));
            PanelRenderer panelRenderer = new PanelRenderer(mc13, f20, f21, f19, f12).a(color).a(f7 * 0.7f).j();
            if (bl) {
                int n2 = i2;
                panelRenderer.a(0, () -> e.lambda$drawModeRow$4((ModeSetting)modeSetting, (int)n2));
            }
            FontManager.a().a(mc13, stringConstant2, f20 + f9, f21 + f12 * 0.1f, f8, color2);
            f15 += f19 + f11;
        }
    }

    private void a(MatrixStack mc13, Module module, KeybindSetting keybindSetting, float f2, float f3, float f4, float f5, float f6, boolean bl) {
        float f7 = 6.0f * q;
        boolean bl2 = this.T == keybindSetting;
        float f8 = 7.0f * q;
        StringConstant stringConstant = new StringConstant(keybindSetting.d().a() + ":");
        float f9 = f2 + 7.0f * q;
        FontManager.a().a(mc13, stringConstant, f9, f3 + f5 * 0.28f, f8, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        StringConstant stringConstant2 = bl2 ? new StringConstant("Press...") : keybindSetting.g();
        float f10 = FontManager.a().a(stringConstant, f8);
        float f11 = FontManager.a().a(stringConstant2, f8);
        float f12 = Math.max(4.0f * q, Math.min(7.0f * q, f11 * 0.18f));
        float f13 = 12.0f * q;
        float f14 = f9 + f10 + 6.0f * q;
        float f15 = Math.max(16.0f * q, f2 + f4 - 7.0f * q - f14);
        float f16 = Math.max(16.0f * q, f11 + f12 * 2.0f);
        float f17 = Math.min(f15, f16);
        float f18 = 4.0f * q;
        float f19 = f9 - f18;
        float f20 = f14 + f17 + f18 - f19;
        PanelRenderer panelRenderer = new PanelRenderer(mc13, f19, f3, f20, f5).a(GuiRenderer.a(new Color(14, 14, 14), (int)(80.0f * f6))).a(f7).j();
        if (bl) {
            panelRenderer.a(0, () -> ((MenuGuiScreen)this).lambda$drawKeyRow$5((Module)module, (KeybindSetting)keybindSetting));
            if (!bl2) {
                panelRenderer.a(1, () -> e.lambda$drawKeyRow$6((KeybindSetting)keybindSetting));
            }
        }
        float f21 = f14 + (f17 - f11) * 0.5f;
        FontManager.a().a(mc13, stringConstant2, f21, f3 + f5 * 0.28f, f8, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
    }

    private void a(MatrixStack mc13, FloatSetting floatSetting, float f2, float f3, float f4, float f5, float f6) {
        float f7 = 7.0f * q;
        float f8 = 7.0f * q;
        float f9 = f3 + (f5 - FontManager.a().b(f7)) * 0.5f;
        FontManager.a().a(mc13, floatSetting.d(), f2 + f8, f9, f7, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        StringConstant stringConstant = new StringConstant(floatSetting.format());
        float f10 = FontManager.a().a(stringConstant, f7);
        FontManager.a().a(mc13, stringConstant, f2 + f4 - f8 - f10, f9, f7, GuiRenderer.a(I[0].brighter(), (int)(210.0f * f6)));
        float f11 = FontManager.a().a(floatSetting.d(), f7);
        float f12 = 3.0f * q;
        float f13 = f2 + f8 + f11 + 8.0f * q;
        float f14 = f2 + f4 - f8 - f10 - 6.0f * q - f13;
        if (f14 < 4.0f * q) {
            f14 = 4.0f * q;
        }
        float f15 = f3 + (f5 - f12) * 0.5f;
        float f16 = f12 / 2.0f;
        new PanelRenderer(mc13, f13, f15, f14, f12).a(GuiRenderer.a(new Color(90, 90, 90), (int)(200.0f * f6))).a(f16).j();
        float f17 = GuiRenderer.a("slider." + floatSetting.d().a(), floatSetting.getStep(), 0.12f);
        float f18 = f14 * f17;
        if (f18 > f12) {
            new PanelRenderer(mc13, f13, f15, f18, f12).a(GuiRenderer.a(I[0], (int)(220.0f * f6)), GuiRenderer.a(I[1], (int)(220.0f * f6)), GuiRenderer.a(I[2], (int)(220.0f * f6)), GuiRenderer.a(I[3], (int)(220.0f * f6))).a(f16).j();
        }
        float f19 = 3.5f * q;
        float f20 = f13 + f18;
        float f21 = f15 + f12 * 0.5f;
        new PanelRenderer(mc13, f20 - f19, f21 - f19, f19 * 2.0f, f19 * 2.0f).a(GuiRenderer.a(I[0], (int)(240.0f * f6))).a(f19).j();
        float f22 = f5;
        this.R.put(floatSetting, new float[]{f13, f3, f14, f22});
    }

    private void a(MatrixStack mc13, DoubleSetting doubleSetting, float f2, float f3, float f4, float f5, float f6) {
        float f7;
        float f8 = 7.0f * q;
        float f9 = 7.0f * q;
        float f10 = f3 + (f5 - FontManager.a().b(f8)) * 0.5f;
        FontManager.a().a(mc13, doubleSetting.d(), f2 + f9, f10, f8, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        StringConstant stringConstant = new StringConstant(doubleSetting.j());
        float f11 = FontManager.a().a(stringConstant, f8);
        FontManager.a().a(mc13, stringConstant, f2 + f4 - f9 - f11, f10, f8, GuiRenderer.a(I[0].brighter(), (int)(210.0f * f6)));
        float f12 = FontManager.a().a(doubleSetting.d(), f8);
        float f13 = 3.0f * q;
        float f14 = f2 + f9 + f12 + 8.0f * q;
        float f15 = f2 + f4 - f9 - f11 - 6.0f * q - f14;
        if (f15 < 4.0f * q) {
            f15 = 4.0f * q;
        }
        float f16 = f3 + (f5 - f13) * 0.5f;
        float f17 = f13 / 2.0f;
        new PanelRenderer(mc13, f14, f16, f15, f13).a(GuiRenderer.a(new Color(90, 90, 90), (int)(200.0f * f6))).a(f17).j();
        float f18 = doubleSetting.k();
        float f19 = doubleSetting.l();
        float f20 = Math.max(1.0E-4f, f19 - f18);
        float f21 = GuiRenderer.a("range.lo." + doubleSetting.d().a(), GuiRenderer.b((doubleSetting.d() - f18) / f20, 0.0f, 1.0f), 0.12f);
        float f22 = GuiRenderer.a("range.hi." + doubleSetting.d().a(), GuiRenderer.b((doubleSetting.f() - f18) / f20, 0.0f, 1.0f), 0.12f);
        if (f22 < f21) {
            f7 = f21;
            f21 = f22;
            f22 = f7;
        }
        f7 = f14 + f15 * f21;
        float f23 = Math.max(0.0f, f15 * (f22 - f21));
        if (f23 > 0.5f) {
            new PanelRenderer(mc13, f7, f16, f23, f13).a(GuiRenderer.a(I[0], (int)(220.0f * f6)), GuiRenderer.a(I[1], (int)(220.0f * f6)), GuiRenderer.a(I[2], (int)(220.0f * f6)), GuiRenderer.a(I[3], (int)(220.0f * f6))).a(f17).j();
        }
        float f24 = 3.5f * q;
        float f25 = f7;
        float f26 = f7 + f23;
        float f27 = f16 + f13 * 0.5f;
        new PanelRenderer(mc13, f25 - f24, f27 - f24, f24 * 2.0f, f24 * 2.0f).a(GuiRenderer.a(I[0], (int)(240.0f * f6))).a(f24).j();
        new PanelRenderer(mc13, f26 - f24, f27 - f24, f24 * 2.0f, f24 * 2.0f).a(GuiRenderer.a(I[0], (int)(240.0f * f6))).a(f24).j();
        this.S.put(doubleSetting, new float[]{f14, f3, f15, f5, f25, f26});
    }

    private void a(MatrixStack mc13, HotbarSlotSetting hotbarSlotSetting, float f2, float f3, float f4, float f5, float f6, boolean bl) {
        float f7 = 6.0f * q;
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(14, 14, 14), (int)(80.0f * f6))).a(f7).j();
        float f8 = 7.0f * q;
        float f9 = 6.0f * q;
        FontManager.a().a(mc13, hotbarSlotSetting.d(), f2 + f9, f3 + 3.0f * q, f8, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        float f10 = 12.0f * q;
        float f11 = f3 + f5 - f10 - 6.0f * q;
        float f12 = f4 - f9 * 2.0f;
        float f13 = Math.max(0.4f * q, (f12 - f10 * 9.0f) / 8.0f);
        float f14 = f10 * 9.0f + f13 * 8.0f;
        float f15 = f2 + (f4 - f14) * 0.5f;
        for (int i2 = 0; i2 < 9; ++i2) {
            float f16 = f15 + (float)i2 * (f10 + f13);
            Color color = hotbarSlotSetting.b(i2) ? GuiRenderer.a(I[0], (int)(230.0f * f6)) : GuiRenderer.a(new Color(55, 55, 55), (int)(200.0f * f6));
            PanelRenderer panelRenderer = new PanelRenderer(mc13, f16, f11, f10, f10).a(color).a(2.8f * q).j();
            if (!bl) continue;
            int n2 = i2;
            panelRenderer.a(0, () -> e.lambda$drawSlotRow$7((HotbarSlotSetting)hotbarSlotSetting, (int)n2));
        }
    }

    private void d(MatrixStack mc13) {
        float f2 = 70.0f * q;
        float f3 = 18.0f * q;
        float f4 = 70.0f * q;
        float f5 = 70.0f * q;
        float f6 = o + 500.0f * q - f2 - f5 - f4 - 20.0f * q - 8.0f * q;
        float f7 = p + 315.0f * q - f3 - 15.0f * q;
        float f8 = 6.0f * q;
        float f9 = GuiRenderer.a("menu.config.btn.hover", RenderScale.a(f6, f7, f2, f3) ? 1.0f : 0.0f, 0.12f);
        Color color = GuiRenderer.a(new Color(14, 14, 14, 130), GuiRenderer.a(I[0], 180), f9);
        new PanelRenderer(mc13, f6, f7, f2, f3).a(color).a(14.0f, 1.0f).a(f8).j();
        if (RenderScale.a(f6, f7, f2, f3)) {
            boolean bl;
            boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
            if (bl && !this.W) {
                this.W = true;
                SoundManager.b();
                Main.mc.setScreen((Screen)ConfigScreen.getInstance());
                return;
            }
            if (!bl) {
                this.W = false;
            }
        }
        float f10 = 8.0f * q;
        float f11 = f6 + 6.0f * q;
        float f12 = f7 + (f3 - f10) * 0.5f;
        GuiRenderer.a(mc13, "folder", f11, f12, f10, f10, GuiRenderer.a(Color.WHITE, (int)(200.0f + 55.0f * f9)));
        FontManager.a().a(mc13, new StringConstant("Configs"), f11 + f10 + 4.0f * q, f7 + f3 * 0.28f, 6.5f * q, GuiRenderer.a(Color.WHITE, (int)(200.0f + 55.0f * f9)));
    }

    private void e(MatrixStack mc13) {
        float f2 = 70.0f * q;
        float f3 = 18.0f * q;
        float f4 = 70.0f * q;
        float f5 = o + 500.0f * q - f2 - f4 - 20.0f * q - 4.0f * q;
        float f6 = p + 315.0f * q - f3 - 15.0f * q;
        float f7 = 6.0f * q;
        float f8 = GuiRenderer.a("menu.settings.btn.hover", RenderScale.a(f5, f6, f2, f3) ? 1.0f : 0.0f, 0.12f);
        Color color = GuiRenderer.a(new Color(14, 14, 14, 130), GuiRenderer.a(I[0], 180), f8);
        new PanelRenderer(mc13, f5, f6, f2, f3).a(color).a(14.0f, 1.0f).a(f7).j();
        if (RenderScale.a(f5, f6, f2, f3)) {
            boolean bl;
            boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
            if (bl && !this.X) {
                this.X = true;
                SoundManager.b();
                Main.mc.setScreen((Screen)SettingsScreen.getInstance());
                return;
            }
            if (!bl) {
                this.X = false;
            }
        }
        float f9 = 8.0f * q;
        float f10 = f5 + 6.0f * q;
        float f11 = f6 + (f3 - f9) * 0.5f;
        GuiRenderer.a(mc13, "visual", f10, f11, f9, f9, GuiRenderer.a(Color.WHITE, (int)(200.0f + 55.0f * f8)));
        FontManager.a().a(mc13, new StringConstant("Settings"), f10 + f9 + 4.0f * q, f6 + f3 * 0.28f, 6.5f * q, GuiRenderer.a(Color.WHITE, (int)(200.0f + 55.0f * f8)));
    }

    private void f(MatrixStack mc13) {
        float f2 = 70.0f * q;
        float f3 = 18.0f * q;
        float f4 = o + 500.0f * q - f2 - 20.0f * q;
        float f5 = p + 315.0f * q - f3 - 15.0f * q;
        float f6 = 6.0f * q;
        float f7 = GuiRenderer.a("menu.hud.btn.hover", RenderScale.a(f4, f5, f2, f3) ? 1.0f : 0.0f, 0.12f);
        Color color = GuiRenderer.a(new Color(14, 14, 14, 130), GuiRenderer.a(I[0], 180), f7);
        new PanelRenderer(mc13, f4, f5, f2, f3).a(color).a(14.0f, 1.0f).a(f6).j();
        if (RenderScale.a(f4, f5, f2, f3)) {
            boolean bl;
            boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
            if (bl && !this.V) {
                this.V = true;
                SoundManager.b();
                Main.mc.setScreen((Screen)HudEditorScreen.getInstance());
                return;
            }
            if (!bl) {
                this.V = false;
            }
        }
        float f8 = 8.0f * q;
        float f9 = f4 + 6.0f * q;
        float f10 = f5 + (f3 - f8) * 0.5f;
        GuiRenderer.a(mc13, "visual", f9, f10, f8, f8, GuiRenderer.a(Color.WHITE, (int)(200.0f + 55.0f * f7)));
        FontManager.a().a(mc13, new StringConstant("HUD Editor"), f9 + f8 + 4.0f * q, f5 + f3 * 0.28f, 6.5f * q, GuiRenderer.a(Color.WHITE, (int)(200.0f + 55.0f * f7)));
    }

    private void g(MatrixStack mc13) {
        String string;
        String string2;
        Color color;
        AuthState authState = BackendClient.getInstance().g();
        switch (authState) {
            case AUTHENTICATED: {
                Color color2 = new Color(80, 220, 100, 255);
                break;
            }
            case CONNECTING: {
                Color color2 = new Color(255, 200, 50, 255);
                break;
            }
            default: {
                Color color2 = color = new Color(220, 70, 70, 255);
            }
        }
        if (authState == AuthState.AUTHENTICATED && BackendClient.getInstance().h() != null) {
            string2 = BackendClient.getInstance().h().a();
            string = "users";
        } else {
            string2 = "Login";
            string = "keyboard";
        }
        float f2 = 70.0f * q;
        float f3 = 18.0f * q;
        float f4 = o + 500.0f * q - f2 - 20.0f * q;
        float f5 = p + 15.0f * q;
        float f6 = 6.0f * q;
        float f7 = GuiRenderer.a("menu.auth.btn.hover", RenderScale.a(f4, f5, f2, f3) ? 1.0f : 0.0f, 0.12f);
        Color color3 = GuiRenderer.a(new Color(14, 14, 14, 130), GuiRenderer.a(I[0], 180), f7);
        new PanelRenderer(mc13, f4, f5, f2, f3).a(color3).a(14.0f, 1.0f).a(f6).j();
        if (RenderScale.a(f4, f5, f2, f3)) {
            boolean bl;
            boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
            if (bl && !this.Y) {
                this.Y = true;
                SoundManager.b();
                if (authState == AuthState.AUTHENTICATED) {
                    BackendClient.getInstance().f();
                } else {
                    BackendClient.getInstance().e();
                }
            }
            if (!bl) {
                this.Y = false;
            }
        }
        float f8 = 8.0f * q;
        float f9 = f4 + 6.0f * q;
        float f10 = f5 + (f3 - f8) * 0.5f;
        GuiRenderer.a(mc13, string, f9, f10, f8, f8, GuiRenderer.a(Color.WHITE, (int)(200.0f + 55.0f * f7)));
        FontManager.a().a(mc13, new StringConstant(string2), f9 + f8 + 4.0f * q, f5 + f3 * 0.28f, 6.5f * q, GuiRenderer.a(Color.WHITE, (int)(200.0f + 55.0f * f7)));
        float f11 = 2.5f * q;
        new PanelRenderer(mc13, f4 + 4.0f * q, f5 + f3 - f11 * 2.0f - 2.0f * q, f11 * 2.0f, f11 * 2.0f).a(color).a(f11).j();
    }

    private void a(MatrixStack mc13, ColorSetting colorSetting, float f2, float f3, float f4, float f5, float f6, boolean bl) {
        float f7 = 6.0f * q;
        PanelRenderer panelRenderer = new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(40, 40, 40), (int)(60.0f * f6))).a(f7).a(20.0f, 0.8f).j();
        FontManager.a().a(mc13, colorSetting.d(), f2 + 7.0f * q, f3 + f5 * 0.28f, 7.0f * q, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        float f8 = 12.0f * q;
        float f9 = f2 + f4 - f8 - 7.0f * q;
        float f10 = f3 + (f5 - f8) * 0.5f;
        float f11 = 3.0f * q;
        new PanelRenderer(mc13, f9, f10, f8, f8).a(GuiRenderer.a(new Color(200, 200, 200), (int)(f6 * 255.0f))).a(f11).j();
        new PanelRenderer(mc13, f9, f10, f8, f8).a(GuiRenderer.a(colorSetting.d(), (int)(f6 * 255.0f))).a(f11).j();
        if (bl && !this.f()) {
            panelRenderer.a(1, () -> ((MenuGuiScreen)this).lambda$drawColorRow$8((ColorSetting)colorSetting, (float)f9, (float)f3));
        }
    }

    private void a(ColorSetting colorSetting, float f2, float f3) {
        if (this.ac == colorSetting) {
            this.ac = null;
            this.ad = 0;
        } else {
            this.ac = colorSetting;
            this.ad = 0;
            this.ae = f3;
            GuiRenderer.b("setting.colorpicker." + colorSetting.d().a(), 0.0f);
        }
    }

    private void h(MatrixStack mc13) {
        float f2;
        float f3;
        Color color;
        if (this.ac == null) {
            return;
        }
        ColorSetting colorSetting = this.ac;
        String string = "setting.colorpicker." + colorSetting.d().a();
        float f4 = GuiRenderer.a(string, 1.0f, 0.06f);
        float f5 = GuiRenderer.g(f4);
        if (f4 < 0.01f) {
            return;
        }
        float f6 = 130.0f * q;
        float f7 = 120.0f * q;
        float f8 = 6.0f * q;
        float f9 = this.aD + this.aF + f8 + 4.0f * q;
        float f10 = this.ae;
        float f11 = f5;
        float f12 = f9 + f6 * 0.5f;
        float f13 = f10 + f7 * 0.5f;
        float f14 = f12 - f6 * 0.5f * f11;
        float f15 = f13 - f7 * 0.5f * f11;
        float f16 = f6 * f11;
        float f17 = f7 * f11;
        this.af = f14;
        this.ag = f15;
        this.ah = f16;
        this.ai = f17;
        float f18 = 9.0f * q;
        int n2 = (int)(230.0f * f4);
        float f19 = f14 - f8 * 0.5f;
        float f20 = f15 + f17 * 0.35f;
        new PanelRenderer(mc13, f19, f20, f8, f8).a(GuiRenderer.a(new Color(18, 18, 18), n2)).a(2.0f * q).j();
        new PanelRenderer(mc13, f14, f15, f16, f17).a(GuiRenderer.a(new Color(18, 18, 18), n2)).a(16.0f, 1.0f).a(f18).j();
        if (f4 < 0.5f) {
            return;
        }
        float f21 = GuiRenderer.b((f4 - 0.3f) / 0.7f, 0.0f, 1.0f);
        float f22 = 8.0f * q;
        float f23 = f17 - f22 * 2.0f;
        float f24 = f14 + f22;
        float f25 = f15 + f22;
        float f26 = 10.0f * q;
        float f27 = 6.0f * q;
        float f28 = f24 + f23 + f27;
        float f29 = f28 + f26 + f27;
        float[] fArray = colorSetting.e();
        Color color2 = Color.getHSBColor(fArray[0], 1.0f, 1.0f);
        int n3 = (int)(f21 * 255.0f);
        new PanelRenderer(mc13, f24, f25, f23, f23).a(GuiRenderer.a(Color.WHITE, n3), GuiRenderer.a(color2, n3), GuiRenderer.a(Color.WHITE, n3), GuiRenderer.a(color2, n3)).a(2.0f * q).j();
        new PanelRenderer(mc13, f24, f25, f23, f23).a(GuiRenderer.a(Color.BLACK, n3), GuiRenderer.a(Color.BLACK, n3), new Color(0, 0, 0, 0), new Color(0, 0, 0, 0)).a(2.0f * q).j();
        float f30 = f24 + fArray[1] * f23;
        float f31 = f25 + (1.0f - fArray[2]) * f23;
        float f32 = 3.0f * q;
        new PanelRenderer(mc13, f30 - f32, f31 - f32, f32 * 2.0f, f32 * 2.0f).a(GuiRenderer.a(Color.WHITE, n3)).a(f32).j();
        int n4 = 12;
        float f33 = f23 / (float)n4;
        for (int i2 = 0; i2 < n4; ++i2) {
            Color color3 = GuiRenderer.a(Color.getHSBColor((float)i2 / (float)n4, 1.0f, 1.0f), n3);
            color = GuiRenderer.a(Color.getHSBColor((float)(i2 + 1) / (float)n4, 1.0f, 1.0f), n3);
            float f34 = f25 + (float)i2 * f33;
            f3 = i2 == 0 ? 2.0f * q : 0.0f;
            f2 = i2 == n4 - 1 ? 2.0f * q : 0.0f;
            new PanelRenderer(mc13, f28, f34, f26, f33).a(color, color, color3, color3).a(f3, f3, f2, f2).j();
        }
        float f35 = f25 + fArray[0] * f23;
        float f36 = 2.0f * q;
        new PanelRenderer(mc13, f28 - 1.0f * q, f35 - f36 * 0.5f, f26 + 2.0f * q, f36).a(GuiRenderer.a(Color.WHITE, n3)).a(f36 * 0.5f).j();
        new PanelRenderer(mc13, f29, f25, f26, f23).a(GuiRenderer.a(new Color(140, 140, 140), n3)).a(2.0f * q).j();
        color = GuiRenderer.a(colorSetting.d(), n3);
        Color color4 = GuiRenderer.a(new Color(colorSetting.d().getRed(), colorSetting.d().getGreen(), colorSetting.d().getBlue(), 0), 0);
        new PanelRenderer(mc13, f29, f25, f26, f23).a(color4, color4, color, color).a(2.0f * q).j();
        f3 = 1.0f - (float)colorSetting.f() / 255.0f;
        f2 = f25 + f3 * f23;
        new PanelRenderer(mc13, f29 - 1.0f * q, f2 - f36 * 0.5f, f26 + 2.0f * q, f36).a(GuiRenderer.a(Color.WHITE, n3)).a(f36 * 0.5f).j();
    }

    private void e() {
        boolean bl;
        if (this.ac == null) {
            return;
        }
        double[] dArray = new double[1];
        double[] dArray2 = new double[1];
        GLFW.glfwGetCursorPos((long)Main.mc.getWindow().getHandle(), (double[])dArray, (double[])dArray2);
        float f2 = (float)(dArray[0] / (double)Main.mc.getWindow().getScaleFactor());
        float f3 = (float)(dArray2[0] / (double)Main.mc.getWindow().getScaleFactor());
        boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
        if (!bl) {
            this.ad = 0;
            return;
        }
        ColorSetting colorSetting = this.ac;
        float[] fArray = colorSetting.e();
        float f4 = 8.0f * q;
        float f5 = this.ah;
        float f6 = this.ai;
        float f7 = this.af;
        float f8 = this.ag;
        float f9 = f6 - f4 * 2.0f;
        float f10 = f7 + f4;
        float f11 = f8 + f4;
        float f12 = 10.0f * q;
        float f13 = 6.0f * q;
        float f14 = f10 + f9 + f13;
        float f15 = f14 + f12 + f13;
        if (this.ad == 0) {
            if (f2 >= f10 && f2 <= f10 + f9 && f3 >= f11 && f3 <= f11 + f9) {
                this.ad = 1;
            } else if (f2 >= f14 && f2 <= f14 + f12 && f3 >= f11 && f3 <= f11 + f9) {
                this.ad = 2;
            } else if (f2 >= f15 && f2 <= f15 + f12 && f3 >= f11 && f3 <= f11 + f9) {
                this.ad = 3;
            }
        }
        if (this.ad == 1) {
            float f16 = GuiRenderer.b((f2 - f10) / f9, 0.0f, 1.0f);
            float f17 = 1.0f - GuiRenderer.b((f3 - f11) / f9, 0.0f, 1.0f);
            colorSetting.a(fArray[0], f16, f17, colorSetting.f());
        } else if (this.ad == 2) {
            float f18 = GuiRenderer.b((f3 - f11) / f9, 0.0f, 1.0f);
            colorSetting.a(f18, fArray[1], fArray[2], colorSetting.f());
        } else if (this.ad == 3) {
            float f19 = 1.0f - GuiRenderer.b((f3 - f11) / f9, 0.0f, 1.0f);
            colorSetting.a(fArray[0], fArray[1], fArray[2], Math.round(f19 * 255.0f));
        }
    }

    private boolean f() {
        if (this.ac == null) {
            return false;
        }
        double[] dArray = new double[1];
        double[] dArray2 = new double[1];
        GLFW.glfwGetCursorPos((long)Main.mc.getWindow().getHandle(), (double[])dArray, (double[])dArray2);
        float f2 = (float)(dArray[0] / (double)Main.mc.getWindow().getScaleFactor());
        float f3 = (float)(dArray2[0] / (double)Main.mc.getWindow().getScaleFactor());
        return f2 >= this.af && f2 <= this.af + this.ah && f3 >= this.ag && f3 <= this.ag + this.ai;
    }

    public boolean shouldPause() {
        return false;
    }

    public void close() {
        this.l();
        this.j();
        if (!this.e) {
            this.e = true;
        }
    }

    private void a(Module module) {
        this.J = this.J == module ? null : module;
        this.ac = null;
        this.ad = 0;
        this.aj = null;
    }

    private float b(Module module) {
        List<Setting> list = module.getSettings();
        if (list.isEmpty()) {
            return 0.0f;
        }
        float f2 = 10.0f * q;
        for (Setting setting : list) {
            float f3;
            if (!setting.isVisible()) continue;
            if (setting instanceof ModeSetting) {
                ModeSetting modeSetting = (ModeSetting)setting;
                f3 = this.a(modeSetting);
            } else {
                f3 = setting instanceof FloatSetting || setting instanceof DoubleSetting ? 22.0f * q : (setting instanceof HotbarSlotSetting ? 36.0f * q : 22.0f * q);
            }
            f2 += f3 + 3.0f * q;
        }
        return f2 -= 3.0f * q;
    }

    private void g() {
        double[] dArray = new double[1];
        double[] dArray2 = new double[1];
        GLFW.glfwGetCursorPos((long)Main.mc.getWindow().getHandle(), (double[])dArray, (double[])dArray2);
        float f2 = (float)(dArray[0] / (double)Main.mc.getWindow().getScaleFactor());
        float f3 = (float)(dArray2[0] / (double)Main.mc.getWindow().getScaleFactor());
        boolean bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
        long l2 = System.currentTimeMillis();
        if (!bl) {
            if (this.K != null) {
                this.aq = this.K;
                this.as = l2;
                this.K = null;
            }
            this.L = null;
            this.N = false;
        } else {
            float f4;
            if (this.K == null && this.L == null) {
                float[] fArray;
                for (Map.Entry entry : this.R.entrySet()) {
                    fArray = (float[])entry.getValue();
                    if (!(f2 >= fArray[0]) || !(f2 <= fArray[0] + fArray[2]) || !(f3 >= fArray[1]) || !(f3 <= fArray[1] + fArray[3])) continue;
                    this.K = (FloatSetting)entry.getKey();
                    this.P = fArray[0];
                    this.Q = fArray[2];
                    this.at = this.K.getStep();
                    this.au = l2;
                    this.aq = null;
                    this.ar = 0.0f;
                    break;
                }
                if (this.K == null) {
                    for (Map.Entry entry : this.S.entrySet()) {
                        fArray = (float[])entry.getValue();
                        if (!(f2 >= fArray[0]) || !(f2 <= fArray[0] + fArray[2]) || !(f3 >= fArray[1]) || !(f3 <= fArray[1] + fArray[3])) continue;
                        this.L = (DoubleSetting)entry.getKey();
                        this.P = fArray[0];
                        this.Q = fArray[2];
                        float f5 = fArray[4];
                        f4 = fArray[5];
                        float f6 = 7.0f * q;
                        float f7 = Math.abs(f4 - f5);
                        if (f7 <= f6 * 0.7f) {
                            this.N = true;
                            float f8 = GuiRenderer.b((f2 - this.P) / this.Q, 0.0f, 1.0f);
                            this.O = this.L.k() + (this.L.l() - this.L.k()) * f8;
                        } else {
                            this.N = false;
                            this.M = Math.abs(f2 - f4) <= Math.abs(f2 - f5);
                        }
                        this.aq = null;
                        this.ar = 0.0f;
                        break;
                    }
                }
            }
            if (this.K != null) {
                float f9 = this.K.getStep();
                float f10 = (f2 - this.P) / this.Q;
                this.K.setValueFromGui(f10);
                long l3 = l2 - this.au;
                if (l3 > 0L) {
                    f4 = (this.K.getStep() - f9) / (float)l3;
                    this.ar = this.ar * 0.4f + f4 * 0.6f;
                }
                this.at = this.K.getStep();
                this.au = l2;
            }
            if (this.L != null) {
                float f11 = (f2 - this.P) / this.Q;
                f11 = GuiRenderer.b(f11, 0.0f, 1.0f);
                float f12 = this.L.k() + (this.L.l() - this.L.k()) * f11;
                if (this.N) {
                    float f13 = Math.max(this.L.m(), 0.001f);
                    if (f12 > this.O + f13) {
                        this.M = true;
                        this.N = false;
                    } else if (f12 < this.O - f13) {
                        this.M = false;
                        this.N = false;
                    } else {
                        return;
                    }
                }
                if (this.M) {
                    this.L.b(f12);
                } else {
                    this.L.a(f12);
                }
            }
        }
        if (this.aq != null && this.K == null) {
            long l4 = l2 - this.as;
            this.as = l2;
            if (l4 > 0L && Math.abs(this.ar) > 5.0E-5f) {
                this.aq.setValueFromGui(this.aq.getStep() + this.ar * (float)l4);
                this.ar *= (float)Math.exp(-0.005f * (float)l4);
            } else {
                this.ar = 0.0f;
                this.aq = null;
            }
        }
    }

    public boolean mouseScrolled(double d2, double d3, double d4, double d5) {
        if (this.aj != null && this.n()) {
            int n2 = d5 > 0.0 ? -1 : 1;
            this.an = Math.max(0, this.an + n2);
            return true;
        }
        if (!this.b((float)d2, (float)d3)) {
            return super.mouseScrolled(d2, d3, d4, d5);
        }
        if (Math.abs(d5) < 1.0E-4) {
            return true;
        }
        ModuleCategory moduleCategory = B;
        float f2 = this.aB.getOrDefault((Object)moduleCategory, Float.valueOf(0.0f)).floatValue();
        this.aB.put(moduleCategory, Float.valueOf(f2 += (float)(d5 * (double)0.16f * (double)q)));
        this.aC = System.currentTimeMillis();
        return true;
    }

    private void h() {
        long l2 = System.currentTimeMillis();
        if (this.aC == 0L) {
            this.aC = l2;
            return;
        }
        long l3 = l2 - this.aC;
        this.aC = l2;
        if (l3 <= 0L) {
            return;
        }
        for (ModuleCategory moduleCategory : ModuleCategory.values()) {
            float f2 = this.aA.getOrDefault((Object)moduleCategory, Float.valueOf(0.0f)).floatValue();
            float f3 = this.aB.getOrDefault((Object)moduleCategory, Float.valueOf(0.0f)).floatValue();
            float f4 = this.b(moduleCategory);
            if (Math.abs(f3) > 5.0E-5f) {
                f2 += f3 * (float)l3;
                f3 *= (float)Math.exp(-0.01f * (float)l3);
            } else {
                f3 = 0.0f;
            }
            float f5 = -f4;
            if (f2 > 0.0f) {
                f2 *= 0.65f;
                f3 = 0.0f;
            } else if (f2 < f5) {
                f2 = f5 + (f2 - f5) * 0.65f;
                f3 = 0.0f;
            }
            if (f4 <= 0.5f) {
                f2 = 0.0f;
                f3 = 0.0f;
            }
            this.aA.put(moduleCategory, Float.valueOf(f2));
            this.aB.put(moduleCategory, Float.valueOf(f3));
        }
    }

    private float a(ModuleCategory moduleCategory) {
        float f2 = this.aA.getOrDefault((Object)moduleCategory, Float.valueOf(0.0f)).floatValue();
        float f3 = this.b(moduleCategory);
        float f4 = -f3;
        if (f2 > 0.0f) {
            f2 = 0.0f;
        }
        if (f2 < f4) {
            f2 = f4;
        }
        return f2;
    }

    private float b(ModuleCategory moduleCategory) {
        float f2;
        List<Module> list = this.c(moduleCategory);
        if (list.isEmpty()) {
            return 0.0f;
        }
        float f3 = 31.0f * q;
        float f4 = (float)list.size() * f3;
        if (!list.isEmpty()) {
            f4 -= 6.0f * q;
        }
        if (this.J != null && this.J.getCategory() == moduleCategory) {
            f4 += this.b(this.J);
        }
        if ((f2 = this.aG) <= 0.0f) {
            float f5 = 40.0f * q;
            float f6 = 40.0f * q;
            f2 = 315.0f * q - f5 - f6;
        }
        return Math.max(0.0f, f4 - f2);
    }

    private List<Module> c(ModuleCategory moduleCategory) {
        return switch (moduleCategory) {
            default -> throw new MatchException(null, null);
            case ModuleCategory.COMBAT -> E;
            case ModuleCategory.MOVEMENT -> F;
            case ModuleCategory.VISUAL -> G;
            case ModuleCategory.Utility -> H;
        };
    }

    private boolean b(float f2, float f3) {
        return f2 >= this.aD && f2 <= this.aD + this.aF && f3 >= this.aE && f3 <= this.aE + this.aG;
    }

    private void i() {
        this.Z = true;
        this.aa.setLength(0);
        this.ab.clear();
        this.J = null;
        this.ac = null;
        this.ad = 0;
    }

    private void j() {
        this.Z = false;
        this.aa.setLength(0);
        this.ab.clear();
    }

    private void k() {
        this.ab.clear();
        if (this.aa.length() == 0) {
            return;
        }
        String string = this.aa.toString().toLowerCase();
        for (Module module : ModuleManager.c()) {
            if (!MenuGuiScreen.a(module.getName().a(), string)) continue;
            this.ab.add(module);
        }
    }

    private static boolean a(String string, String string2) {
        int n2 = string.length();
        int n3 = string2.length();
        for (int i2 = 0; i2 < n2; ++i2) {
            int n4 = 0;
            int n5 = i2;
            while (n5 < n2 && n4 < n3) {
                char c2 = string.charAt(n5);
                if (MenuGuiScreen.a(c2)) {
                    ++n5;
                    continue;
                }
                if (Character.toLowerCase(c2) != string2.charAt(n4)) break;
                ++n4;
                ++n5;
            }
            if (n4 != n3) continue;
            return true;
        }
        return false;
    }

    private static boolean a(char c2) {
        return c2 == '\u00a7' || c2 == '\u00b6' || c2 == '\u2020' || c2 == '\u2021' || c2 == '\u00ac' || Character.getType(c2) == 16 || c2 == '\u200b' || c2 == '\u200c' || c2 == '\u200d' || c2 == '\ufeff' || c2 == '\u00ad';
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4) {
        float f5 = GuiRenderer.a("menu.search.open", this.Z ? 1.0f : 0.0f, 0.14f);
        if (f5 <= 0.01f) {
            return;
        }
        float f6 = 22.0f * q;
        float f7 = f4 * 0.6f * f5;
        float f8 = f2 + (f4 - f7) * 0.5f;
        float f9 = f3 - f6 - 6.0f * q;
        float f10 = f6 * 0.5f;
        int n2 = (int)(f5 * 255.0f);
        new PanelRenderer(mc13, f8, f9, f7, f6).a(GuiRenderer.a(new Color(10, 10, 10), (int)(160.0f * f5))).a(16.0f, 1.0f).a(f10).j();
        float f11 = 8.0f * q;
        float f12 = f8 + 8.0f * q;
        float f13 = f9 + (f6 - f11) * 0.5f;
        GuiRenderer.a(mc13, "search", f12, f13, f11, f11, GuiRenderer.a(aL, n2));
        float f14 = f12 + f11 + 5.0f * q;
        float f15 = f9 + f6 * 0.28f;
        float f16 = 7.0f * q;
        if (this.aa.length() == 0) {
            FontManager.a().a(mc13, new StringConstant("Search..."), f14, f15, f16, GuiRenderer.a(aL, (int)(120.0f * f5)));
        } else {
            boolean bl;
            FontManager.a().a(mc13, new StringConstant(this.aa.toString()), f14, f15, f16, GuiRenderer.a(Color.WHITE, n2));
            float f17 = FontManager.a().a(new StringConstant(this.aa.toString()), f16);
            boolean bl2 = bl = System.currentTimeMillis() / 500L % 2L == 0L;
            if (bl) {
                new PanelRenderer(mc13, f14 + f17 + 1.0f, f9 + f6 * 0.25f, 1.0f, f6 * 0.5f).a(GuiRenderer.a(Color.WHITE, n2)).j();
            }
        }
    }

    private void d(ModuleCategory moduleCategory) {
        if (moduleCategory == null || moduleCategory == B) {
            return;
        }
        int n2 = this.e(B);
        int n3 = this.e(moduleCategory);
        D = n3 >= n2 ? 1 : -1;
        C = B;
        B = moduleCategory;
        f = moduleCategory;
        this.l();
        this.j();
        this.J = null;
        this.ac = null;
        this.ad = 0;
        this.K = null;
        this.L = null;
        this.N = false;
        this.aq = null;
        this.ar = 0.0f;
    }

    private void onMouseButton(MouseButtonEvent mouseButtonEvent) {
        if (Main.mc.currentScreen != this || this.T == null) {
            return;
        }
        if (mouseButtonEvent.action != 1) {
            return;
        }
        if (this.U && mouseButtonEvent.button == 0) {
            this.U = false;
            return;
        }
        this.T.resetKey(mouseButtonEvent.button);
        this.l();
    }

    private void a(Module module, KeybindSetting keybindSetting) {
        this.T = keybindSetting;
        this.U = true;
    }

    private void l() {
        this.T = null;
        this.U = false;
    }

    public boolean m() {
        return this.T != null;
    }

    private void a(MatrixStack mc13, ItemListSetting itemListSetting, float f2, float f3, float f4, float f5, float f6, boolean bl) {
        float f7 = 6.0f * q;
        boolean bl2 = this.aj == itemListSetting;
        float f8 = GuiRenderer.a("setting.reg.hover." + itemListSetting.d().a(), bl2 ? 1.0f : 0.0f, 0.12f);
        Color color = GuiRenderer.a(GuiRenderer.a(new Color(40, 40, 40), (int)(60.0f * f6)), GuiRenderer.a(x, (int)(40.0f * f6)), f8);
        PanelRenderer panelRenderer = new PanelRenderer(mc13, f2, f3, f4, f5).a(color).a(f7).a(20.0f, 0.8f).j();
        int n2 = itemListSetting.g().size();
        StringConstant stringConstant = new StringConstant(itemListSetting.d().a() + " (" + n2 + ")");
        FontManager.a().a(mc13, stringConstant, f2 + 7.0f * q, f3 + f5 * 0.28f, 6.5f * q, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        if (itemListSetting.e() == Registries.ITEM && this.ap != null) {
            ItemListSetting itemListSetting2 = itemListSetting;
            List<ItemStack> list = itemListSetting2.g();
            int n3 = Math.min(3, list.size());
            float f9 = 10.0f * q;
            float f10 = 2.0f * q;
            float f11 = f2 + f4 - 7.0f * q - (float)n3 * (f9 + f10) + f10;
            for (int i2 = 0; i2 < n3; ++i2) {
                ItemStack mc33 = new ItemStack((ItemConvertible)list.get(i2));
                float f12 = f11 + (float)i2 * (f9 + f10);
                float f13 = f3 + (f5 - f9) * 0.5f;
                float f14 = RenderScale.h();
                this.ap.getMatrices().pushMatrix();
                this.ap.getMatrices().translate(f12 * f14, f13 * f14);
                float f15 = f9 / 16.0f * f14;
                this.ap.getMatrices().scale(f15, f15);
                this.ap.drawItem(mc33, 0, 0);
                this.ap.getMatrices().popMatrix();
            }
            if (list.size() > 3) {
                StringConstant stringConstant2 = new StringConstant("+" + (list.size() - 3));
                float f16 = f11 - FontManager.a().a(stringConstant2, 5.5f * q) - 3.0f * q;
                FontManager.a().a(mc13, stringConstant2, f16, f3 + f5 * 0.32f, 5.5f * q, GuiRenderer.a(new Color(180, 180, 180), (int)(200.0f * f6)));
            }
        } else {
            StringConstant stringConstant3 = new StringConstant(String.valueOf(n2));
            float f17 = Math.max(14.0f * q, FontManager.a().a(stringConstant3, 6.0f * q) + 6.0f * q);
            float f18 = 12.0f * q;
            float f19 = f2 + f4 - f17 - 7.0f * q;
            float f20 = f3 + (f5 - f18) * 0.5f;
            new PanelRenderer(mc13, f19, f20, f17, f18).a(GuiRenderer.a(x, (int)(80.0f * f6))).a(f18 * 0.5f).j();
            FontManager.a().a(mc13, stringConstant3, f19 + (f17 - FontManager.a().a(stringConstant3, 6.0f * q)) * 0.5f, f20 + f18 * 0.15f, 6.0f * q, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        }
        if (bl && !this.n()) {
            panelRenderer.a(1, () -> ((MenuGuiScreen)this).lambda$drawRegistriesRow$9((ItemListSetting)itemListSetting, (float)f2, (float)f3));
        }
    }

    private void a(ItemListSetting itemListSetting, float f2, float f3) {
        if (this.aj == itemListSetting) {
            this.aj = null;
        } else {
            this.aj = itemListSetting;
            this.am.setLength(0);
            this.an = 0;
            this.ao = false;
            this.ak = f2;
            this.al = f3;
            GuiRenderer.b("setting.registries.popup", 0.0f);
        }
    }

    private void i(MatrixStack mc13) {
        float f2;
        float f3;
        int n2;
        if (this.aj == null) {
            return;
        }
        String string = "setting.registries.popup";
        float f4 = GuiRenderer.a(string, 1.0f, 0.06f);
        float f5 = GuiRenderer.g(f4);
        if (f4 < 0.01f) {
            return;
        }
        ItemListSetting itemListSetting = this.aj;
        boolean bl = itemListSetting.e() == Registries.ITEM;
        float f6 = (bl ? 180.0f : 150.0f) * q;
        float f7 = (bl ? 20.0f : 18.0f) * q;
        float f8 = 20.0f * q;
        float f9 = 6.0f * q;
        float f10 = 18.0f * q;
        int n3 = 8;
        String string2 = this.am.toString().toLowerCase();
        List<ItemStack> list = this.ao ? itemListSetting.g() : itemListSetting.f();
        List<ItemStack> list2 = list.stream().filter(arg_0 -> ((MenuGuiScreen)this).lambda$drawRegistriesPopup$10((ItemListSetting)itemListSetting, (String)string2, arg_0)).collect(Collectors.toList());
        int n4 = list2.size();
        int n5 = Math.min(n3, n4);
        float f11 = (float)n5 * f7;
        float f12 = f9 + f10 + f9 * 0.5f + f8 + f9 * 0.5f + f11 + f9;
        float f13 = 6.0f * q;
        float f14 = this.aD + this.aF + f13 + 4.0f * q;
        float f15 = this.al;
        if (f14 + f6 * f5 > RenderScale.c()) {
            f14 = this.ak - f6 * f5 - f13;
        }
        if (f15 + f12 * f5 > RenderScale.d()) {
            f15 = RenderScale.d() - f12 * f5 - 4.0f;
        }
        float f16 = f5;
        float f17 = f14 + f6 * 0.5f;
        float f18 = f15 + f12 * 0.5f;
        float f19 = f17 - f6 * 0.5f * f16;
        float f20 = f18 - f12 * 0.5f * f16;
        float f21 = f6 * f16;
        float f22 = f12 * f16;
        float f23 = 9.0f * q;
        int n6 = (int)(230.0f * f4);
        float f24 = f19 - f13 * 0.5f;
        float f25 = f20 + f22 * 0.3f;
        new PanelRenderer(mc13, f24, f25, f13, f13).a(GuiRenderer.a(new Color(18, 18, 18), n6)).a(2.0f * q).j();
        new PanelRenderer(mc13, f19, f20, f21, f22).a(GuiRenderer.a(new Color(18, 18, 18), n6)).a(16.0f, 1.0f).a(f23).j();
        if (f4 < 0.4f) {
            return;
        }
        float f26 = GuiRenderer.b((f4 - 0.3f) / 0.7f, 0.0f, 1.0f);
        Color color = x;
        float f27 = 6.5f * f16;
        float f28 = f20 + f9 * f16;
        float f29 = (f21 - f9 * 2.0f * f16) * 0.5f;
        float f30 = f19 + f9 * f16;
        float f31 = f30 + f29;
        float f32 = f10 * f16;
        float f33 = GuiRenderer.a("reg.tab.all", this.ao ? 0.0f : 1.0f, 0.12f);
        float f34 = GuiRenderer.a("reg.tab.sel", this.ao ? 1.0f : 0.0f, 0.12f);
        float f35 = 10.0f * f16;
        float f36 = (f32 - f35) * 0.5f;
        new PanelRenderer(mc13, f30, f28, f29, f32).a(GuiRenderer.a(color, (int)(40.0f * f33 * f26 * 255.0f))).a(4.0f * f16).j().a(0, () -> ((MenuGuiScreen)this).lambda$drawRegistriesPopup$11());
        GuiRenderer.a(mc13, "search", f30 + (f29 - f35) * 0.5f, f28 + f36, f35, f35, GuiRenderer.a(GuiRenderer.a(new Color(150, 150, 150), Color.WHITE, f33), (int)(f26 * 255.0f)));
        new PanelRenderer(mc13, f31, f28, f29, f32).a(GuiRenderer.a(color, (int)(40.0f * f34 * f26 * 255.0f))).a(4.0f * f16).j().a(0, () -> ((MenuGuiScreen)this).lambda$drawRegistriesPopup$12());
        GuiRenderer.a(mc13, "check", f31 + (f29 - f35) * 0.5f, f28 + f36, f35, f35, GuiRenderer.a(GuiRenderer.a(new Color(150, 150, 150), Color.WHITE, f34), (int)(f26 * 255.0f)));
        float f37 = f21 - f9 * 2.0f * f16;
        float f38 = f19 + f9 * f16;
        float f39 = f8 * f16;
        new PanelRenderer(mc13, f38, f28 += f32 + f9 * 0.5f * f16, f37, f39).a(GuiRenderer.a(new Color(30, 30, 30), (int)(f26 * 200.0f))).a(4.0f * f16).j();
        StringConstant stringConstant = this.am.length() > 0 ? new StringConstant(this.am.toString()) : new StringConstant("Search...");
        Color color2 = this.am.length() > 0 ? GuiRenderer.a(Color.WHITE, (int)(f26 * 230.0f)) : GuiRenderer.a(new Color(100, 100, 100), (int)(f26 * 180.0f));
        FontManager.a().a(mc13, stringConstant, f38 + 5.0f * f16, f28 + f39 * 0.25f, f27, color2);
        int n7 = Math.max(0, n4 - n3);
        this.an = Math.max(0, Math.min(this.an, n7));
        float f40 = f28 += f39 + f9 * 0.5f * f16;
        float f41 = f11 * f16;
        if (f4 > 0.85f && RenderScale.b(f19, f40, f19 + f21, f40 + f41)) {
            double[] dArray = new double[1];
        }
        for (int i2 = 0; i2 < n5 && (n2 = this.an + i2) < list2.size(); ++i2) {
            Object object;
            Object object2;
            Object t = list2.get(n2);
            f3 = f19 + f9 * f16;
            f2 = f28 + (float)i2 * f7 * f16;
            float f42 = f21 - f9 * 2.0f * f16;
            float f43 = f7 * f16;
            boolean bl2 = itemListSetting.a(t);
            Identifier mc19 = this.a(itemListSetting, t);
            if (mc19 == null) continue;
            float f44 = GuiRenderer.a("reg.item." + mc19.toString(), RenderScale.b(f3, f2, f3 + f42, f2 + f43) ? 1.0f : 0.0f, 0.12f);
            Color color3 = bl2 ? GuiRenderer.a(color, (int)(Math.max(25.0f, 45.0f * f44) * f26 * 255.0f / 255.0f)) : GuiRenderer.a(new Color(40, 40, 40), (int)(Math.max(0.0f, 40.0f * f44) * f26));
            new PanelRenderer(mc13, f3, f2, f42, f43).a(color3).a(3.0f * f16).j();
            float f45 = 4.0f * f16;
            if (bl && this.ap != null) {
                object2 = (Item)t;
                object = new ItemStack((ItemConvertible)object2);
                float f46 = f43 - 6.0f * f16;
                float f47 = f3 + 2.0f * f16;
                float f48 = f2 + (f43 - f46) * 0.5f;
                float f49 = RenderScale.h();
                this.ap.getMatrices().pushMatrix();
                this.ap.getMatrices().translate(f47 * f49, f48 * f49);
                float f50 = f46 / 16.0f * f49;
                this.ap.getMatrices().scale(f50, f50);
                this.ap.drawItem(object, 0, 0);
                this.ap.getMatrices().popMatrix();
                f45 = f46 + 5.0f * f16;
            }
            object2 = mc19.getPath().replace("_", " ");
            object = bl2 ? GuiRenderer.a(Color.WHITE, (int)(f26 * 240.0f)) : GuiRenderer.a(GuiRenderer.a(new Color(180, 180, 180), Color.WHITE, f44), (int)(f26 * 220.0f));
            FontManager.a().a(mc13, new StringConstant((String)object2), f3 + f45, f2 + f43 * 0.28f, f27 * 0.88f, (Color)object);
            if (bl2) {
                GuiRenderer.a(mc13, "check", f3 + f42 - 9.0f * f16, f2 + f43 * 0.25f, 7.0f * f16, 7.0f * f16, GuiRenderer.a(color, (int)(f26 * 255.0f)));
            }
            if (!(f4 > 0.85f)) continue;
            new PanelRenderer(mc13, f3, f2, f42, f43).a(new Color(0, 0, 0, 0)).j().a(0, () -> e.lambda$drawRegistriesPopup$13((ItemListSetting)itemListSetting, t));
        }
        if (n4 > n3) {
            float f51 = f19 + f21 - 4.0f * f16;
            float f52 = f41;
            float f53 = f40;
            new PanelRenderer(mc13, f51, f53, 2.0f * f16, f52).a(GuiRenderer.a(new Color(40, 40, 40), (int)(f26 * 100.0f))).a(1.0f * f16).j();
            f3 = Math.max(10.0f * f16, f52 * (float)n5 / (float)n4);
            f2 = f53 + (f52 - f3) * (float)this.an / (float)Math.max(1, n7);
            new PanelRenderer(mc13, f51, f2, 2.0f * f16, f3).a(GuiRenderer.a(color, (int)(f26 * 180.0f))).a(1.0f * f16).j();
        }
        if (f4 > 0.85f) {
            boolean bl3;
            boolean bl4 = bl3 = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
            if (bl3 && !RenderScale.b(f19, f20, f19 + f21, f20 + f22)) {
                this.aj = null;
            }
        }
    }

    private Identifier a(ItemListSetting itemListSetting, Object object) {
        return itemListSetting.e().getId(object);
    }

    private boolean n() {
        if (this.aj == null) {
            return false;
        }
        float f2 = 6.0f * q;
        float f3 = this.aD + this.aF + f2 + 4.0f * q;
        boolean bl = this.aj.e() == Registries.ITEM;
        float f4 = (bl ? 180.0f : 150.0f) * q;
        float f5 = 250.0f * q;
        return RenderScale.b(f3 - 10.0f, this.al - 10.0f, f3 + f4 + 10.0f, this.al + f5 + 10.0f);
    }

    private int e(ModuleCategory moduleCategory) {
        ModuleCategory[] moduleCategoryArray = ModuleCategory.values();
        for (int i2 = 0; i2 < moduleCategoryArray.length; ++i2) {
            if (moduleCategoryArray[i2] != moduleCategory) continue;
            return i2;
        }
        return 0;
    }

    private static void lambda$drawRegistriesPopup$13(ItemListSetting itemListSetting, Object object) {
        ItemListSetting itemListSetting2 = itemListSetting;
        itemListSetting2.b(object);
        SoundManager.b();
    }

    private void lambda$drawRegistriesPopup$12() {
        if (!this.ao) {
            this.ao = true;
            this.an = 0;
            SoundManager.b();
        }
    }

    private void lambda$drawRegistriesPopup$11() {
        if (this.ao) {
            this.ao = false;
            this.an = 0;
            SoundManager.b();
        }
    }

    private boolean lambda$drawRegistriesPopup$10(ItemListSetting itemListSetting, String string, Object object) {
        Identifier mc19 = this.a(itemListSetting, object);
        return mc19 != null && (string.isEmpty() || mc19.getPath().contains(string));
    }

    private void lambda$drawRegistriesRow$9(ItemListSetting itemListSetting, float f2, float f3) {
        this.a(itemListSetting, f2, f3);
        SoundManager.b();
    }

    private void lambda$drawColorRow$8(ColorSetting colorSetting, float f2, float f3) {
        this.a(colorSetting, f2, f3);
        SoundManager.b();
    }

    private static void lambda$drawSlotRow$7(HotbarSlotSetting hotbarSlotSetting, int n2) {
        hotbarSlotSetting.a(n2);
        SoundManager.b();
    }

    private static void lambda$drawKeyRow$6(KeybindSetting keybindSetting) {
        keybindSetting.reset();
        SoundManager.b();
    }

    private void lambda$drawKeyRow$5(Module module, KeybindSetting keybindSetting) {
        this.a(module, keybindSetting);
        SoundManager.b();
    }

    private static void lambda$drawModeRow$4(ModeSetting modeSetting, int n2) {
        if (modeSetting.isMulti()) {
            modeSetting.toggleIndex(n2);
        } else {
            modeSetting.setIndex(n2);
        }
        SoundManager.b();
    }

    private static void lambda$drawButtonRow$3(ButtonSetting buttonSetting) {
        buttonSetting.e();
        SoundManager.b();
    }

    private static void lambda$drawBooleanRow$2(BooleanSetting booleanSetting) {
        booleanSetting.reset();
        SoundManager.b();
    }

    private void lambda$drawModuleList$1(Module module) {
        this.a(module);
        SoundManager.b();
    }

    private void lambda$drawCategories$0(ModuleCategory moduleCategory) {
        this.d(moduleCategory);
        SoundManager.b();
    }

    static {
        d = 344;
        f = ModuleCategory.COMBAT;
        q = 1.0f;
        x = new Color(103, 177, 237, 255);
        y = new Color(10, 10, 10, 100);
        A = Map.of(ModuleCategory.COMBAT, "combat", ModuleCategory.MOVEMENT, "move", ModuleCategory.VISUAL, "visual", ModuleCategory.Utility, "utility");
        B = ModuleCategory.COMBAT;
        C = null;
        D = 1;
        E = new ArrayList();
        F = new ArrayList();
        G = new ArrayList();
        H = new ArrayList();
        I = new Color[]{x, x.darker(), x.darker().darker(), x.darker().darker().darker()};
        aL = new Color(150, 150, 150);
    }
}

