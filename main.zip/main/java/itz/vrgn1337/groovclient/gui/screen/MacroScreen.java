/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.screen;

import itz.vrgn1337.groovclient.api.util.SoundManager;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.screen.MacroStepTypeSwitchMap;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import itz.vrgn1337.groovclient.macro.MacroInputAction;
import itz.vrgn1337.groovclient.macro.MacroProfile;
import itz.vrgn1337.groovclient.macro.MacroStep;
import itz.vrgn1337.groovclient.macro.MacroStepType;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleManager;
import itz.vrgn1337.groovclient.module.utility.Macros;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import java.awt.Color;
import java.util.List;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;

public class MacroScreen
extends Screen {
    private static final MacroScreen a = new MacroScreen();
    private static final String b = "macro.screen.open";
    private static final Color c = new Color(0, 0, 0, 80);
    private static final Color d = new Color(12, 12, 16);
    private static final Color e = new Color(28, 28, 34);
    private static final Color f = new Color(45, 45, 55);
    private static final Color g = new Color(40, 40, 48);
    private boolean h = false;
    private MacroProfile i;
    private boolean j = false;
    private MacroProfile k = null;
    private MacroStep l = null;
    private final StringBuilder m = new StringBuilder();
    private float n = 0.0f;
    private float o = 0.0f;
    private MacroStep p = null;
    private float q = 0.0f;
    private boolean r = false;

    public static MacroScreen getInstance() {
        return a;
    }

    protected MacroScreen() {
        super((Text)Text.empty());
    }

    public void init() {
        this.h = false;
        this.j = false;
        this.k = null;
        this.l = null;
        this.p = null;
        this.r = false;
        if (this.i == null && !Macros.s().isEmpty()) {
            this.i = (MacroProfile)Macros.s().get(0);
        }
        GuiRenderer.b(b, 0.0f);
    }

    protected void applyBlur(DrawContext mc15) {
    }

    public boolean shouldPause() {
        return false;
    }

    public void close() {
        if (!this.h) {
            this.h = true;
        }
    }

    public boolean keyPressed(KeyInput mc27) {
        int n2 = mc27.key();
        int n3 = mc27.scancode();
        if (this.k != null) {
            if (n2 == 256) {
                this.k.a(-1);
                this.k = null;
                return true;
            }
            this.k.a(n2);
            this.k = null;
            return true;
        }
        if (n2 == 256) {
            if (this.j) {
                this.j = false;
                return true;
            }
            if (this.l != null) {
                this.b();
                this.l = null;
                return true;
            }
            this.h = true;
            return true;
        }
        if (this.j && this.i != null) {
            if (n2 == 257) {
                this.j = false;
                return true;
            }
            if (n2 == 259) {
                String string = this.i.a();
                if (!string.isEmpty()) {
                    this.i.a(string.substring(0, string.length() - 1));
                }
                return true;
            }
            String string = GLFW.glfwGetKeyName((int)n2, (int)n3);
            if (string != null && !string.isEmpty() && this.i.a().length() < 24) {
                boolean bl = (mc27.modifiers() & 1) != 0;
                this.i.a(this.i.a() + (bl ? string.toUpperCase() : string));
                return true;
            }
            if (n2 == 32 && this.i.a().length() < 24) {
                this.i.a(this.i.a() + " ");
                return true;
            }
            return true;
        }
        if (this.l != null) {
            if (n2 == 257) {
                this.b();
                this.l = null;
                return true;
            }
            if (n2 == 259) {
                if (this.m.length() > 0) {
                    this.m.deleteCharAt(this.m.length() - 1);
                }
                return true;
            }
            int n4 = -1;
            if (n2 >= 48 && n2 <= 57) {
                n4 = n2 - 48;
            } else if (n2 >= 320 && n2 <= 329) {
                n4 = n2 - 320;
            }
            if (n4 >= 0 && this.m.length() < 6) {
                this.m.append(n4);
            }
            return true;
        }
        return super.keyPressed(mc27);
    }

    public boolean mouseScrolled(double d2, double d3, double d4, double d5) {
        float f2 = (float)RenderScale.j();
        if (f2 < this.e() + 200.0f) {
            this.n -= (float)d5 * 18.0f;
        } else {
            this.o -= (float)d5 * 18.0f;
        }
        return true;
    }

    private void b() {
        if (this.l == null) {
            return;
        }
        if (this.m.length() == 0) {
            return;
        }
        try {
            this.l.b(Integer.parseInt(this.m.toString()));
        }
        catch (NumberFormatException numberFormatException) {
            // empty catch block
        }
    }

    private float c() {
        return 540.0f;
    }

    private float d() {
        return 380.0f;
    }

    private float e() {
        return (RenderScale.c() - this.c()) * 0.5f;
    }

    private float f() {
        return (RenderScale.d() - this.d()) * 0.5f;
    }

    public void render(DrawContext mc15, int n2, int n3, float f2) {
        MatrixStack mc13 = new MatrixStack();
        float f3 = GuiRenderer.a(b, this.h ? 0.0f : 1.0f, 0.06f);
        if (this.h && f3 <= 0.01f) {
            this.h = false;
            GuiRenderer.b(b);
            Main.mc.setScreen(null);
            return;
        }
        float f4 = RenderScale.c();
        float f5 = RenderScale.d();
        new PanelRenderer(mc13, 0.0f, 0.0f, f4, f5).a(GuiRenderer.a(c, (int)((float)c.getAlpha() * f3))).j();
        float f6 = this.c();
        float f7 = this.d();
        float f8 = this.e();
        float f9 = this.f();
        float f10 = GuiRenderer.g(f3);
        float f11 = 0.9f + 0.1f * f10;
        float f12 = f8 + f6 * 0.5f;
        float f13 = f9 + f7 * 0.5f;
        mc13.push();
        mc13.translate(f12, f13, 0.0f);
        mc13.scale(f11, f11, 1.0f);
        mc13.translate(-f12, -f13, 0.0f);
        new PanelRenderer(mc13, f8, f9, f6, f7).a(GuiRenderer.a(d, (int)(240.0f * f3))).a(16.0f, 1.0f).a(12.0f).j();
        Color color = MenuGuiScreen.c();
        int n4 = (int)(255.0f * f3);
        float f14 = 36.0f;
        FontManager.a().a(mc13, new StringConstant("Macros"), f8 + 14.0f, f9 + f14 * 0.32f, 10.0f, GuiRenderer.a(Color.WHITE, n4));
        float f15 = 50.0f;
        float f16 = 18.0f;
        float f17 = f8 + f6 - f15 - 12.0f;
        float f18 = f9 + (f14 - f16) * 0.5f;
        this.a(mc13, f17, f18, f15, f16, "Done", color, f3, () -> ((MacroScreen)this).lambda$render$0());
        new PanelRenderer(mc13, f8 + 12.0f, f9 + f14 - 1.0f, f6 - 24.0f, 1.0f).a(GuiRenderer.a(new Color(255, 255, 255), (int)(20.0f * f3))).j();
        float f19 = f9 + f14 + 8.0f;
        float f20 = f7 - f14 - 14.0f;
        float f21 = 170.0f;
        float f22 = 10.0f;
        float f23 = f8 + 10.0f;
        float f24 = f23 + f21 + f22;
        float f25 = f6 - 10.0f - f21 - f22 - 10.0f;
        this.b(mc13, f23, f19, f21, f20, f3);
        this.b(mc13, f24, f19, f25, f20, f3);
        mc13.pop();
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6) {
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(20, 20, 26), (int)(180.0f * f6))).a(8.0f).j();
        float f7 = 24.0f;
        FontManager.a().a(mc13, new StringConstant("Profiles"), f2 + 8.0f, f3 + 7.0f, 7.0f, GuiRenderer.a(Color.WHITE, (int)(220.0f * f6)));
        float f8 = 16.0f;
        float f9 = f2 + f4 - f8 - 6.0f;
        float f10 = f3 + (f7 - f8) * 0.5f;
        this.a(mc13, f9, f10, f8, "+", f6, () -> ((MacroScreen)this).lambda$drawProfileList$1());
        float f11 = f3 + f7;
        float f12 = f5 - f7 - 4.0f;
        GuiRenderer.a(f2 + 2.0f, f11, f4 - 4.0f, f12);
        float f13 = 22.0f;
        float f14 = 3.0f;
        List list = Macros.s();
        float f15 = Math.max(0.0f, (float)list.size() * (f13 + f14) - f12);
        if (this.n < 0.0f) {
            this.n = 0.0f;
        }
        if (this.n > f15) {
            this.n = f15;
        }
        float f16 = f11 + 2.0f - this.n;
        for (int i2 = 0; i2 < list.size(); ++i2) {
            MacroProfile macroProfile = (MacroProfile)list.get(i2);
            float f17 = f2 + 4.0f;
            float f18 = f4 - 8.0f;
            boolean bl = macroProfile == this.i;
            boolean bl2 = RenderScale.a(f17, f16, f18, f13);
            Color color = bl ? GuiRenderer.a(MenuGuiScreen.c(), (int)(170.0f * f6)) : GuiRenderer.a(bl2 ? f : e, (int)(200.0f * f6));
            MacroProfile macroProfile2 = macroProfile;
            new PanelRenderer(mc13, f17, f16, f18, f13).a(color).a(5.0f).j().a(0, () -> ((MacroScreen)this).lambda$drawProfileList$2((MacroProfile)macroProfile2));
            FontManager.a().a(mc13, new StringConstant(macroProfile.a()), f17 + 7.0f, f16 + 6.0f, 6.5f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
            String string = KeybindSetting.j(macroProfile.b()).a();
            StringConstant stringConstant = new StringConstant(string);
            float f19 = FontManager.a().a(stringConstant, 5.5f);
            FontManager.a().a(mc13, stringConstant, f17 + f18 - f19 - 6.0f, f16 + 8.0f, 5.5f, GuiRenderer.a(new Color(200, 200, 200), (int)(180.0f * f6)));
            f16 += f13 + f14;
        }
        GuiRenderer.b();
    }

    private void b(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6) {
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(new Color(20, 20, 26), (int)(180.0f * f6))).a(8.0f).j();
        if (this.i == null) {
            StringConstant stringConstant = new StringConstant("Select or create a profile");
            float f7 = FontManager.a().a(stringConstant, 7.0f);
            FontManager.a().a(mc13, stringConstant, f2 + (f4 - f7) * 0.5f, f3 + f5 * 0.5f - 4.0f, 7.0f, GuiRenderer.a(new Color(200, 200, 200), (int)(200.0f * f6)));
            return;
        }
        float f8 = 10.0f;
        float f9 = 24.0f;
        float f10 = f4 - 250.0f;
        float f11 = f2 + f8;
        float f12 = f3 + f8;
        boolean bl = this.j;
        Color color = bl ? MenuGuiScreen.c() : new Color(60, 60, 70);
        new PanelRenderer(mc13, f11, f12, f10, f9).a(GuiRenderer.a(e, (int)(220.0f * f6))).a(5.0f).j().a(0, () -> ((MacroScreen)this).lambda$drawProfileEditor$3());
        new PanelRenderer(mc13, f11, f12 + f9 - 1.0f, f10, 1.0f).a(GuiRenderer.a(color, (int)(200.0f * f6))).j();
        String string = this.i.a() + (bl ? "_" : "");
        FontManager.a().a(mc13, new StringConstant(string), f11 + 7.0f, f12 + 7.0f, 7.0f, GuiRenderer.a(Color.WHITE, (int)(230.0f * f6)));
        float f13 = 130.0f;
        float f14 = f11 + f10 + 6.0f;
        boolean bl2 = this.k == this.i;
        String string2 = "Bind: " + (bl2 ? "Press..." : KeybindSetting.j(this.i.b()).a());
        this.a(mc13, f14, f12, f13, f9, string2, bl2 ? MenuGuiScreen.c() : new Color(50, 50, 60), f6, () -> ((MacroScreen)this).lambda$drawProfileEditor$4());
        float f15 = 60.0f;
        float f16 = f14 + f13 + 6.0f;
        this.a(mc13, f16, f12, f15, f9, "Delete", new Color(180, 50, 50), f6, () -> ((MacroScreen)this).lambda$drawProfileEditor$5());
        float f17 = f12 + f9 + 8.0f;
        float f18 = f5 - (f17 - f3) - f8 - 28.0f;
        GuiRenderer.a(f2 + f8, f17, f4 - f8 * 2.0f, f18);
        float f19 = 28.0f;
        float f20 = 5.0f;
        List list = this.i.c();
        float f21 = Math.max(0.0f, (float)list.size() * (f19 + f20) - f18);
        if (this.o < 0.0f) {
            this.o = 0.0f;
        }
        if (this.o > f21) {
            this.o = f21;
        }
        float f22 = f17 - this.o;
        for (int i2 = 0; i2 < list.size(); ++i2) {
            this.a(mc13, (MacroStep)list.get(i2), i2, f2 + f8, f22, f4 - f8 * 2.0f, f19, f6);
            f22 += f19 + f20;
        }
        GuiRenderer.b();
        this.a(list, f17, f19, f20);
        float f23 = f3 + f5 - f8 - 22.0f;
        float f24 = 110.0f;
        this.a(mc13, f2 + f8, f23, f24, 22.0f, "+ Add Step", MenuGuiScreen.c(), f6, () -> ((MacroScreen)this).lambda$drawProfileEditor$6());
        float f25 = 80.0f;
        this.a(mc13, f2 + f8 + f24 + 6.0f, f23, f25, 22.0f, "Run Now", new Color(60, 140, 60), f6, () -> ((MacroScreen)this).lambda$drawProfileEditor$7());
    }

    private void a(List list, float f2, float f3, float f4) {
        boolean bl;
        boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
        if (this.p != null) {
            if (!bl) {
                this.p = null;
            } else {
                int n2 = list.indexOf(this.p);
                if (n2 < 0) {
                    this.p = null;
                } else {
                    float f5 = (float)RenderScale.k() + this.o;
                    int n3 = (int)Math.floor((f5 - f2) / (f3 + f4));
                    if (n3 < 0) {
                        n3 = 0;
                    }
                    if (n3 > list.size() - 1) {
                        n3 = list.size() - 1;
                    }
                    if (n3 != n2) {
                        this.i.a(n2, n3);
                    }
                }
            }
        }
        this.r = bl;
    }

    private static Module g() {
        for (Module module : ModuleManager.c()) {
            if (!(module instanceof Macros)) continue;
            return module;
        }
        return null;
    }

    private void a(MatrixStack mc13, MacroStep macroStep, int n2, float f2, float f3, float f4, float f5, float f6) {
        float f7;
        float f8;
        Color color = switch (MacroStepTypeSwitchMap.a[macroStep.a().ordinal()]) {
            default -> throw new MatchException(null, null);
            case 1 -> new Color(60, 90, 160);
            case 2 -> new Color(120, 90, 40);
            case 3 -> new Color(50, 130, 70);
            case 4 -> new Color(120, 60, 130);
        };
        boolean bl = this.p == macroStep;
        int n3 = (int)((float)(bl ? 230 : 180) * f6);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(GuiRenderer.a(color.darker(), n3)).a(6.0f).j();
        float f9 = 8.0f;
        PanelRenderer panelRenderer = new PanelRenderer(mc13, f2, f3, f9, f5).a(GuiRenderer.a(color.brighter(), (int)(230.0f * f6))).a(3.0f).j();
        if (this.p == null) {
            panelRenderer.a(0, () -> ((MacroScreen)this).lambda$drawStepRow$8((MacroStep)macroStep, (float)f3));
        }
        float f10 = f2 + f9 + 4.0f;
        MacroStepType[] macroStepTypeArray = MacroStepType.values();
        StringConstant stringConstant = new StringConstant(macroStep.a().name());
        float f11 = Math.max(44.0f, FontManager.a().a(stringConstant, 6.5f) + 10.0f);
        new PanelRenderer(mc13, f10, f3 + 5.0f, f11, f5 - 10.0f).a(GuiRenderer.a(g, (int)(220.0f * f6))).a(4.0f).j().a(0, () -> b.lambda$drawStepRow$9((MacroStep)macroStep, (MacroStepType[])macroStepTypeArray)).a(1, () -> b.lambda$drawStepRow$10((MacroStep)macroStep, (MacroStepType[])macroStepTypeArray));
        FontManager.a().a(mc13, stringConstant, f10 + 5.0f, f3 + f5 * 0.32f, 6.5f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)));
        f10 += f11 + 6.0f;
        switch (MacroStepTypeSwitchMap.a[macroStep.a().ordinal()]) {
            case 1: {
                this.a(mc13, f10, f3, "Slot:", f6);
                f10 += 22.0f;
                f8 = 10.0f;
                f7 = 11.0f;
                for (int i2 = 0; i2 < 9; ++i2) {
                    int n4 = i2;
                    boolean bl2 = macroStep.b() == i2;
                    Color color2 = bl2 ? GuiRenderer.a(Color.WHITE, (int)(220.0f * f6)) : GuiRenderer.a(g, (int)(200.0f * f6));
                    new PanelRenderer(mc13, f10, f3 + 6.0f, f8, f5 - 12.0f).a(color2).a(2.5f).j().a(0, () -> b.lambda$drawStepRow$11((MacroStep)macroStep, (int)n4));
                    StringConstant stringConstant2 = new StringConstant(String.valueOf(i2 + 1));
                    float f12 = FontManager.a().a(stringConstant2, 5.5f);
                    FontManager.a().a(mc13, stringConstant2, f10 + (f8 - f12) * 0.5f, f3 + f5 * 0.33f, 5.5f, bl2 ? new Color(20, 20, 20) : Color.WHITE);
                    f10 += f7;
                }
                break;
            }
            case 2: {
                this.b(mc13, macroStep, f10, f3, f5, f6);
                break;
            }
            case 3: {
                f10 = this.b(mc13, macroStep, f10, f3, f5, f6);
                break;
            }
            case 4: {
                f10 = this.b(mc13, macroStep, f10, f3, f5, f6);
                this.b(mc13, macroStep, f10 + 6.0f, f3, f5, f6);
            }
        }
        f8 = f3 + 5.0f;
        f7 = f5 - 10.0f;
        float f13 = 18.0f;
        float f14 = f2 + f4 - f13 - 3.0f;
        new PanelRenderer(mc13, f14, f8, f13, f7).a(GuiRenderer.a(new Color(150, 50, 50), (int)(220.0f * f6))).a(3.0f).j().a(0, () -> ((MacroScreen)this).lambda$drawStepRow$12((int)n2));
        float f15 = f7 - 6.0f;
        GuiRenderer.a(mc13, "cross", f14 + (f13 - f15) * 0.5f, f8 + (f7 - f15) * 0.5f, f15, f15, GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)));
    }

    private void a(MatrixStack mc13, float f2, float f3, String string, float f4) {
        FontManager.a().a(mc13, new StringConstant(string), f2, f3 + 11.0f, 6.0f, GuiRenderer.a(new Color(220, 220, 220), (int)(220.0f * f4)));
    }

    private void a(MatrixStack mc13, MacroStep macroStep, float f2, float f3, float f4, float f5) {
        boolean bl = this.l == macroStep;
        String string = bl ? this.m.toString() + "_" : macroStep.c() + " ms";
        StringConstant stringConstant = new StringConstant(string);
        float f6 = 60.0f;
        Color color = bl ? GuiRenderer.a(MenuGuiScreen.c().darker(), (int)(220.0f * f5)) : GuiRenderer.a(g, (int)(220.0f * f5));
        new PanelRenderer(mc13, f2, f3 + 6.0f, f6, f4 - 12.0f).a(color).a(4.0f).j().a(0, () -> ((MacroScreen)this).lambda$drawMsField$13((MacroStep)macroStep));
        FontManager.a().a(mc13, stringConstant, f2 + 6.0f, f3 + f4 * 0.3f, 6.5f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f5)));
    }

    private float b(MatrixStack mc13, MacroStep macroStep, float f2, float f3, float f4, float f5) {
        MacroInputAction[] macroInputActionArray = MacroInputAction.values();
        StringConstant stringConstant = new StringConstant(macroStep.d().name());
        float f6 = Math.max(54.0f, FontManager.a().a(stringConstant, 6.5f) + 14.0f);
        new PanelRenderer(mc13, f2, f3 + 5.0f, f6, f4 - 10.0f).a(GuiRenderer.a(g, (int)(220.0f * f5))).a(4.0f).j().a(0, () -> b.lambda$drawActionPicker$14((MacroStep)macroStep, (MacroInputAction[])macroInputActionArray)).a(1, () -> b.lambda$drawActionPicker$15((MacroStep)macroStep, (MacroInputAction[])macroInputActionArray));
        FontManager.a().a(mc13, stringConstant, f2 + 7.0f, f3 + f4 * 0.32f, 6.5f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f5)));
        return f2 + f6;
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, float f5, String string, Color color, float f6, Runnable runnable) {
        boolean bl = RenderScale.a(f2, f3, f4, f5);
        Color color2 = GuiRenderer.a(bl ? color.brighter() : color, (int)(220.0f * f6));
        new PanelRenderer(mc13, f2, f3, f4, f5).a(color2).a(5.0f).j().a(0, () -> b.lambda$drawButton$16((Runnable)runnable));
        StringConstant stringConstant = new StringConstant(string);
        float f7 = FontManager.a().a(stringConstant, 6.5f);
        FontManager.a().a(mc13, stringConstant, f2 + (f4 - f7) * 0.5f, f3 + f5 * 0.3f, 6.5f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f6)));
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, String string, float f5, Runnable runnable) {
        new PanelRenderer(mc13, f2, f3, f4, f4).a(GuiRenderer.a(MenuGuiScreen.c(), (int)(220.0f * f5))).a(4.0f).j().a(0, () -> b.lambda$drawIconButton$17((Runnable)runnable));
        StringConstant stringConstant = new StringConstant(string);
        float f6 = FontManager.a().a(stringConstant, 7.0f);
        FontManager.a().a(mc13, stringConstant, f2 + (f4 - f6) * 0.5f, f3 + f4 * 0.22f, 7.0f, GuiRenderer.a(Color.WHITE, (int)(240.0f * f5)));
    }

    private static void lambda$drawIconButton$17(Runnable runnable) {
        runnable.run();
        SoundManager.b();
    }

    private static void lambda$drawButton$16(Runnable runnable) {
        runnable.run();
        SoundManager.b();
    }

    private static void lambda$drawActionPicker$15(MacroStep macroStep, MacroInputAction[] macroInputActionArray) {
        int n2 = (macroStep.d().ordinal() - 1 + macroInputActionArray.length) % macroInputActionArray.length;
        macroStep.a(macroInputActionArray[n2]);
    }

    private static void lambda$drawActionPicker$14(MacroStep macroStep, MacroInputAction[] macroInputActionArray) {
        int n2 = (macroStep.d().ordinal() + 1) % macroInputActionArray.length;
        macroStep.a(macroInputActionArray[n2]);
    }

    private void lambda$drawMsField$13(MacroStep macroStep) {
        if (this.l != null && this.l != macroStep) {
            this.b();
        }
        this.l = macroStep;
        this.m.setLength(0);
        this.m.append(macroStep.c());
    }

    private void lambda$drawStepRow$12(int n2) {
        this.i.b(n2);
    }

    private static void lambda$drawStepRow$11(MacroStep macroStep, int n2) {
        macroStep.a(n2);
    }

    private static void lambda$drawStepRow$10(MacroStep macroStep, MacroStepType[] macroStepTypeArray) {
        int n2 = (macroStep.a().ordinal() - 1 + macroStepTypeArray.length) % macroStepTypeArray.length;
        macroStep.a(macroStepTypeArray[n2]);
        SoundManager.b();
    }

    private static void lambda$drawStepRow$9(MacroStep macroStep, MacroStepType[] macroStepTypeArray) {
        int n2 = (macroStep.a().ordinal() + 1) % macroStepTypeArray.length;
        macroStep.a(macroStepTypeArray[n2]);
        SoundManager.b();
    }

    private void lambda$drawStepRow$8(MacroStep macroStep, float f2) {
        this.p = macroStep;
        this.q = f2;
    }

    private void lambda$drawProfileEditor$7() {
        Module module = MacroScreen.g();
        if (module instanceof Macros) {
            Macros macros = (Macros)module;
            macros.a(this.i);
        }
    }

    private void lambda$drawProfileEditor$6() {
        this.i.a(new MacroStep(MacroStepType.Wait));
        SoundManager.b();
    }

    private void lambda$drawProfileEditor$5() {
        Macros.s().remove(this.i);
        this.i = Macros.s().isEmpty() ? null : (MacroProfile)Macros.s().get(0);
        this.j = false;
        this.k = null;
    }

    private void lambda$drawProfileEditor$4() {
        this.k = this.i;
    }

    private void lambda$drawProfileEditor$3() {
        this.j = true;
    }

    private void lambda$drawProfileList$2(MacroProfile macroProfile) {
        this.i = macroProfile;
        this.j = false;
        SoundManager.b();
    }

    private void lambda$drawProfileList$1() {
        String string = "Macro " + (Macros.s().size() + 1);
        MacroProfile macroProfile = new MacroProfile(string);
        Macros.s().add(macroProfile);
        this.i = macroProfile;
        SoundManager.b();
    }

    private void lambda$render$0() {
        this.h = true;
    }
}

