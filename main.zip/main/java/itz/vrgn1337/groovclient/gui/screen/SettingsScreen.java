/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.screen;

import itz.vrgn1337.groovclient.api.util.SelfDestruct;
import itz.vrgn1337.groovclient.api.util.SoundManager;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.config.ClientSettings;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.screen.FriendsScreen;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleManager;
import itz.vrgn1337.groovclient.setting.ColorSetting;
import java.awt.Color;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;

public class SettingsScreen
extends Screen {
    private static final SettingsScreen a = new SettingsScreen();
    private static final String b = "settings.screen.open";
    private static final Color c = new Color(0, 0, 0, 80);
    private boolean d = false;
    private final ColorSetting color = new ColorSetting(new StringConstant("Color"), new StringConstant("Theme Color"), ClientSettings.getInstance().b());
    private int f = 0;
    private boolean g = false;

    public static SettingsScreen getInstance() {
        return a;
    }

    protected SettingsScreen() {
        super((Text)Text.empty());
    }

    public void init() {
        this.d = false;
        this.color.a(ClientSettings.getInstance().b());
        GuiRenderer.b(b, 0.0f);
    }

    public boolean keyPressed(KeyInput mc27) {
        if (mc27.key() == 256) {
            this.d = true;
            return true;
        }
        return super.keyPressed(mc27);
    }

    protected void applyBlur(DrawContext mc15) {
    }

    public void render(DrawContext mc15, int n2, int n3, float f2) {
        boolean bl;
        MatrixStack mc13 = new MatrixStack();
        float f3 = GuiRenderer.a(b, this.d ? 0.0f : 1.0f, 0.06f);
        if (this.d && f3 <= 0.01f) {
            this.d = false;
            GuiRenderer.b(b);
            Main.mc.setScreen(null);
            return;
        }
        float f4 = RenderScale.c();
        float f5 = RenderScale.d();
        new PanelRenderer(mc13, 0.0f, 0.0f, f4, f5).a(GuiRenderer.a(c, (int)((float)c.getAlpha() * f3))).j();
        float f6 = 280.0f;
        float f7 = 418.0f;
        float f8 = (f4 - f6) * 0.5f;
        float f9 = (f5 - f7) * 0.5f;
        float f10 = GuiRenderer.g(f3);
        float f11 = 0.85f + 0.15f * f10;
        float f12 = f8 + f6 * 0.5f;
        float f13 = f9 + f7 * 0.5f;
        mc13.push();
        mc13.translate(f12, f13, 0.0f);
        mc13.scale(f11, f11, 1.0f);
        mc13.translate(-f12, -f13, 0.0f);
        new PanelRenderer(mc13, f8, f9, f6, f7).a(GuiRenderer.a(new Color(12, 12, 16), (int)(240.0f * f3))).a(16.0f, 1.0f).a(12.0f).j();
        Color color = MenuGuiScreen.c();
        int n4 = (int)(255.0f * f3);
        float f14 = 40.0f;
        float f15 = 14.0f;
        float f16 = f8 + 14.0f;
        float f17 = f9 + (f14 - f15) * 0.5f;
        GuiRenderer.a(mc13, "visual", f16, f17, f15, f15, GuiRenderer.a(color, n4));
        FontManager.a().a(mc13, new StringConstant("Settings"), f16 + f15 + 8.0f, f9 + f14 * 0.28f, 10.0f, GuiRenderer.a(Color.WHITE, n4));
        new PanelRenderer(mc13, f8 + 12.0f, f9 + f14 - 1.0f, f6 - 24.0f, 1.0f).a(GuiRenderer.a(new Color(255, 255, 255), (int)(20.0f * f3))).j();
        float f18 = f9 + f14 + 10.0f;
        float f19 = 14.0f;
        FontManager.a().a(mc13, new StringConstant("Theme Color"), f8 + f19, f18, 7.5f, GuiRenderer.a(Color.WHITE, n4));
        float f20 = f18 + 16.0f;
        this.a(mc13, f8 + f19, f20, f3);
        this.a(f8 + f19, f20);
        float f21 = f20 + 110.0f + 14.0f;
        this.getInstance(mc13, f8 + f19, f21, f6 - f19 * 2.0f, f3);
        float f22 = f21 + 30.0f;
        this.b(mc13, f8 + f19, f22, f6 - f19 * 2.0f, f3);
        float f23 = f22 + 30.0f;
        this.c(mc13, f8 + f19, f23, f6 - f19 * 2.0f, f3);
        float f24 = f23 + 30.0f;
        this.d(mc13, f8 + f19, f24, f6 - f19 * 2.0f, f3);
        float f25 = f24 + 30.0f;
        this.color(mc13, f8 + f19, f25, f6 - f19 * 2.0f, f3);
        float f26 = f25 + 34.0f;
        this.f(mc13, f8 + f19, f26, f6 - f19 * 2.0f, f3);
        float f27 = f26 + 30.0f;
        this.g(mc13, f8 + f19, f27, f6 - f19 * 2.0f, f3);
        mc13.pop();
        boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
        if (!bl) {
            this.f = 0;
        }
        this.g = bl;
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4) {
        float f5;
        float f6;
        Color color;
        float f7 = 100.0f;
        float f8 = 10.0f;
        float f9 = 6.0f;
        float f10 = f2 + f7 + f9;
        float f11 = f10 + f8 + f9;
        float[] fArray = this.color.e();
        int n2 = (int)(f4 * 255.0f);
        Color color2 = Color.getHSBColor(fArray[0], 1.0f, 1.0f);
        new PanelRenderer(mc13, f2, f3, f7, f7).a(GuiRenderer.a(Color.WHITE, n2), GuiRenderer.a(color2, n2), GuiRenderer.a(Color.WHITE, n2), GuiRenderer.a(color2, n2)).a(2.0f).j();
        new PanelRenderer(mc13, f2, f3, f7, f7).a(GuiRenderer.a(Color.BLACK, n2), GuiRenderer.a(Color.BLACK, n2), new Color(0, 0, 0, 0), new Color(0, 0, 0, 0)).a(2.0f).j();
        float f12 = f2 + fArray[1] * f7;
        float f13 = f3 + (1.0f - fArray[2]) * f7;
        float f14 = 3.0f;
        new PanelRenderer(mc13, f12 - f14, f13 - f14, f14 * 2.0f, f14 * 2.0f).a(GuiRenderer.a(Color.WHITE, n2)).a(f14).j();
        int n3 = 12;
        float f15 = f7 / (float)n3;
        for (int j = 0; j < n3; ++j) {
            Color color3 = GuiRenderer.a(Color.getHSBColor((float)j / (float)n3, 1.0f, 1.0f), n2);
            color = GuiRenderer.a(Color.getHSBColor((float)(j + 1) / (float)n3, 1.0f, 1.0f), n2);
            float f16 = f3 + (float)j * f15;
            f6 = j == 0 ? 2.0f : 0.0f;
            f5 = j == n3 - 1 ? 2.0f : 0.0f;
            new PanelRenderer(mc13, f10, f16, f8, f15).a(color, color, color3, color3).a(f6, f6, f5, f5).j();
        }
        float f17 = f3 + fArray[0] * f7;
        float f18 = 2.0f;
        new PanelRenderer(mc13, f10 - 1.0f, f17 - f18 * 0.5f, f8 + 2.0f, f18).a(GuiRenderer.a(Color.WHITE, n2)).a(f18 * 0.5f).j();
        new PanelRenderer(mc13, f11, f3, f8, f7).a(GuiRenderer.a(new Color(140, 140, 140), n2)).a(2.0f).j();
        color = GuiRenderer.a(this.color.d(), n2);
        Color color4 = GuiRenderer.a(new Color(this.color.d().getRed(), this.color.d().getGreen(), this.color.d().getBlue(), 0), 0);
        new PanelRenderer(mc13, f11, f3, f8, f7).a(color4, color4, color, color).a(2.0f).j();
        f6 = 1.0f - (float)this.color.f() / 255.0f;
        f5 = f3 + f6 * f7;
        new PanelRenderer(mc13, f11 - 1.0f, f5 - f18 * 0.5f, f8 + 2.0f, f18).a(GuiRenderer.a(Color.WHITE, n2)).a(f18 * 0.5f).j();
        float f19 = f11 + f8 + f9;
        float f20 = 20.0f;
        new PanelRenderer(mc13, f19, f3, f20, f20).a(GuiRenderer.a(this.color.d(), n2)).a(4.0f).j();
    }

    private void a(float f2, float f3) {
        boolean bl;
        boolean bl2 = bl = GLFW.glfwGetMouseButton((long)Main.mc.getWindow().getHandle(), (int)0) == 1;
        if (!bl) {
            this.f = 0;
            return;
        }
        float f4 = (float)RenderScale.j();
        float f5 = (float)RenderScale.k();
        float f6 = 100.0f;
        float f7 = 10.0f;
        float f8 = 6.0f;
        float f9 = f2 + f6 + f8;
        float f10 = f9 + f7 + f8;
        float[] fArray = this.color.e();
        if (this.f == 0) {
            if (f4 >= f2 && f4 <= f2 + f6 && f5 >= f3 && f5 <= f3 + f6) {
                this.f = 1;
            } else if (f4 >= f9 && f4 <= f9 + f7 && f5 >= f3 && f5 <= f3 + f6) {
                this.f = 2;
            } else if (f4 >= f10 && f4 <= f10 + f7 && f5 >= f3 && f5 <= f3 + f6) {
                this.f = 3;
            }
        }
        if (this.f == 1) {
            float f11 = GuiRenderer.b((f4 - f2) / f6, 0.0f, 1.0f);
            float f12 = 1.0f - GuiRenderer.b((f5 - f3) / f6, 0.0f, 1.0f);
            this.color.a(fArray[0], f11, f12, this.color.f());
            ClientSettings.getInstance().a(this.color.d());
        } else if (this.f == 2) {
            float f13 = GuiRenderer.b((f5 - f3) / f6, 0.0f, 1.0f);
            this.color.a(f13, fArray[1], fArray[2], this.color.f());
            ClientSettings.getInstance().a(this.color.d());
        } else if (this.f == 3) {
            float f14 = 1.0f - GuiRenderer.b((f5 - f3) / f6, 0.0f, 1.0f);
            this.color.a(fArray[0], fArray[1], fArray[2], Math.round(f14 * 255.0f));
            ClientSettings.getInstance().a(this.color.d());
        }
    }

    private void a(MatrixStack mc13, float f2, float f3, float f4, float f5) {
        int n2 = (int)(f5 * 255.0f);
        Color color = MenuGuiScreen.c();
        boolean bl = ClientSettings.getInstance().c();
        FontManager.a().a(mc13, new StringConstant("Blur Background"), f2, f3 + 3.0f, 7.5f, GuiRenderer.a(Color.WHITE, n2));
        float f6 = 28.0f;
        float f7 = 14.0f;
        float f8 = f2 + f4 - f6;
        float f9 = f3 + 1.0f;
        float f10 = GuiRenderer.a("settings.blur.toggle", bl ? 1.0f : 0.0f, 0.12f);
        Color color2 = GuiRenderer.a(new Color(50, 50, 55), color, f10);
        new PanelRenderer(mc13, f8, f9, f6, f7).a(GuiRenderer.a(color2, (int)(200.0f * f5))).a(f7 * 0.5f).j().a(0, this::lambda$drawBlurToggle$0);
        float f11 = f7 * 0.4f;
        float f12 = f8 + f11 + 2.0f + f10 * (f6 - f11 * 2.0f - 4.0f);
        float f13 = f9 + f7 * 0.5f;
        new PanelRenderer(mc13, f12 - f11, f13 - f11, f11 * 2.0f, f11 * 2.0f).a(GuiRenderer.a(Color.WHITE, n2)).a(f11).j();
    }

    private void b(MatrixStack mc13, float f2, float f3, float f4, float f5) {
        int n2 = (int)(f5 * 255.0f);
        Color color = MenuGuiScreen.c();
        boolean bl = ClientSettings.getInstance().e();
        FontManager.a().a(mc13, new StringConstant("Scrollbar"), f2, f3 + 3.0f, 7.5f, GuiRenderer.a(Color.WHITE, n2));
        float f6 = 28.0f;
        float f7 = 14.0f;
        float f8 = f2 + f4 - f6;
        float f9 = f3 + 1.0f;
        float f10 = GuiRenderer.a("settings.scrollbar.toggle", bl ? 1.0f : 0.0f, 0.12f);
        Color color2 = GuiRenderer.a(new Color(50, 50, 55), color, f10);
        new PanelRenderer(mc13, f8, f9, f6, f7).a(GuiRenderer.a(color2, (int)(200.0f * f5))).a(f7 * 0.5f).j().a(0, this::lambda$drawScrollbarToggle$1);
        float f11 = f7 * 0.4f;
        float f12 = f8 + f11 + 2.0f + f10 * (f6 - f11 * 2.0f - 4.0f);
        float f13 = f9 + f7 * 0.5f;
        new PanelRenderer(mc13, f12 - f11, f13 - f11, f11 * 2.0f, f11 * 2.0f).a(GuiRenderer.a(Color.WHITE, n2)).a(f11).j();
    }

    private void c(MatrixStack mc13, float f2, float f3, float f4, float f5) {
        int n2 = (int)(f5 * 255.0f);
        Color color = MenuGuiScreen.c();
        int n3 = ClientSettings.getInstance().f();
        FontManager.a().a(mc13, new StringConstant("GUI Style"), f2, f3 + 3.0f, 7.5f, GuiRenderer.a(Color.WHITE, n2));
        float f6 = 55.0f;
        float f7 = 16.0f;
        float f8 = 3.0f;
        String[] stringArray = new String[]{"ClickGUI", "MenuGUI"};
        int[] nArray = new int[]{1, 0};
        float f9 = (float)stringArray.length * f6 + (float)(stringArray.length - 1) * f8;
        float f10 = f2 + f4 - f9;
        float f11 = f3;
        for (int i2 = 0; i2 < stringArray.length; ++i2) {
            float f12 = f10 + (float)i2 * (f6 + f8);
            boolean bl = n3 == nArray[i2];
            float f13 = GuiRenderer.a("settings.guistyle." + i2, RenderScale.a(f12, f11, f6, f7) ? 1.0f : 0.0f, 0.12f);
            Color color2 = bl ? GuiRenderer.a(color, (int)(200.0f * f5)) : GuiRenderer.a(GuiRenderer.a(new Color(30, 30, 35), new Color(50, 50, 55), f13), (int)(200.0f * f5));
            int n4 = nArray[i2];
            new PanelRenderer(mc13, f12, f11, f6, f7).a(color2).a(6.0f).j().a(0, () -> this.lambda$drawGuiStyleSelector$2((int)n4));
            StringConstant stringConstant = new StringConstant(stringArray[i2]);
            float f14 = FontManager.a().a(stringConstant, 6.5f);
            FontManager.a().a(mc13, stringConstant, f12 + (f6 - f14) * 0.5f, f11 + f7 * 0.25f, 6.5f, GuiRenderer.a(bl ? Color.WHITE : new Color(180, 180, 180), n2));
        }
    }

    private void d(MatrixStack mc13, float f2, float f3, float f4, float f5) {
        int n2 = (int)(f5 * 255.0f);
        Color color = MenuGuiScreen.c();
        int n3 = ClientSettings.getInstance().d();
        FontManager.a().a(mc13, new StringConstant("GUI Scale"), f2, f3 + 3.0f, 7.5f, GuiRenderer.a(Color.WHITE, n2));
        float f6 = 32.0f;
        float f7 = 16.0f;
        float f8 = 3.0f;
        String[] stringArray = new String[]{"Auto", "2", "3", "4", "5"};
        int[] nArray = new int[]{0, 2, 3, 4, 5};
        float f9 = (float)stringArray.length * f6 + (float)(stringArray.length - 1) * f8;
        float f10 = f2 + f4 - f9;
        float f11 = f3;
        for (int i2 = 0; i2 < stringArray.length; ++i2) {
            float f12 = f10 + (float)i2 * (f6 + f8);
            boolean bl = n3 == nArray[i2];
            float f13 = GuiRenderer.a("settings.scale." + i2, RenderScale.a(f12, f11, f6, f7) ? 1.0f : 0.0f, 0.12f);
            Color color2 = bl ? GuiRenderer.a(color, (int)(200.0f * f5)) : GuiRenderer.a(GuiRenderer.a(new Color(30, 30, 35), new Color(50, 50, 55), f13), (int)(200.0f * f5));
            int n4 = nArray[i2];
            new PanelRenderer(mc13, f12, f11, f6, f7).a(color2).a(6.0f).j().a(0, () -> this.lambda$drawGuiScaleSelector$3((int)n4));
            StringConstant stringConstant = new StringConstant(stringArray[i2]);
            float f14 = FontManager.a().a(stringConstant, 6.5f);
            FontManager.a().a(mc13, stringConstant, f12 + (f6 - f14) * 0.5f, f11 + f7 * 0.25f, 6.5f, GuiRenderer.a(bl ? Color.WHITE : new Color(180, 180, 180), n2));
        }
    }

    private void e(MatrixStack mc13, float f2, float f3, float f4, float f5) {
        int n2 = (int)(f5 * 255.0f);
        Color color = MenuGuiScreen.c();
        String string = ClientSettings.getInstance().g();
        FontManager.a().a(mc13, new StringConstant("Font"), f2, f3 + 3.0f, 7.5f, GuiRenderer.a(Color.WHITE, n2));
        float f6 = 58.0f;
        float f7 = 16.0f;
        float f8 = 3.0f;
        String[] stringArray = new String[]{"Regular", "Minecraft"};
        String[] stringArray2 = new String[]{"regular", "minecraft"};
        float f9 = (float)stringArray.length * f6 + (float)(stringArray.length - 1) * f8;
        float f10 = f2 + f4 - f9;
        float f11 = f3;
        for (int i2 = 0; i2 < stringArray.length; ++i2) {
            float f12 = f10 + (float)i2 * (f6 + f8);
            boolean bl = stringArray2[i2].equals(string);
            float f13 = GuiRenderer.a("settings.font." + i2, RenderScale.a(f12, f11, f6, f7) ? 1.0f : 0.0f, 0.12f);
            Color color2 = bl ? GuiRenderer.a(color, (int)(200.0f * f5)) : GuiRenderer.a(GuiRenderer.a(new Color(30, 30, 35), new Color(50, 50, 55), f13), (int)(200.0f * f5));
            String string2 = stringArray2[i2];
            new PanelRenderer(mc13, f12, f11, f6, f7).a(color2).a(6.0f).j().a(0, () -> this.lambda$drawFontSelector$4((String)string2));
            StringConstant stringConstant = new StringConstant(stringArray[i2]);
            float f14 = FontManager.a().a(stringConstant, 6.5f);
            FontManager.a().a(mc13, stringConstant, f12 + (f6 - f14) * 0.5f, f11 + f7 * 0.25f, 6.5f, GuiRenderer.a(bl ? Color.WHITE : new Color(180, 180, 180), n2));
        }
    }

    private void f(MatrixStack mc13, float f2, float f3, float f4, float f5) {
        int n2 = (int)(f5 * 255.0f);
        Color color = MenuGuiScreen.c();
        FontManager.a().a(mc13, new StringConstant("Friends"), f2, f3 + 3.0f, 7.5f, GuiRenderer.a(Color.WHITE, n2));
        float f6 = 86.0f;
        float f7 = 16.0f;
        float f8 = f2 + f4 - f6;
        float f9 = f3;
        float f10 = GuiRenderer.a("settings.friends.btn", RenderScale.a(f8, f9, f6, f7) ? 1.0f : 0.0f, 0.12f);
        Color color2 = GuiRenderer.a(GuiRenderer.a(new Color(35, 35, 40), new Color(55, 55, 65), f10), (int)(200.0f * f5));
        new PanelRenderer(mc13, f8, f9, f6, f7).a(color2).a(6.0f).j().a(0, this::lambda$drawFriendsButton$5);
        float f11 = 8.0f;
        float f12 = f8 + 8.0f;
        float f13 = f9 + (f7 - f11) * 0.5f;
        GuiRenderer.a(mc13, "users", f12, f13, f11, f11, GuiRenderer.a(color, n2));
        FontManager.a().a(mc13, new StringConstant("Manage"), f12 + f11 + 4.0f, f9 + f7 * 0.25f, 6.5f, GuiRenderer.a(Color.WHITE, n2));
    }

    private void g(MatrixStack mc13, float f2, float f3, float f4, float f5) {
        int n2 = (int)(f5 * 255.0f);
        FontManager.a().a(mc13, new StringConstant("Self Destruct"), f2, f3 + 3.0f, 7.5f, GuiRenderer.a(Color.WHITE, n2));
        float f6 = 86.0f;
        float f7 = 16.0f;
        float f8 = f2 + f4 - f6;
        float f9 = f3;
        float f10 = GuiRenderer.a("settings.selfdestruct.btn", RenderScale.a(f8, f9, f6, f7) ? 1.0f : 0.0f, 0.12f);
        Color color = new Color(200, 40, 40);
        Color color2 = new Color(240, 60, 60);
        Color color3 = GuiRenderer.a(GuiRenderer.a(color, color2, f10), (int)(220.0f * f5));
        new PanelRenderer(mc13, f8, f9, f6, f7).a(color3).a(6.0f).j().a(0, this::lambda$drawSelfDestructButton$6);
        float f11 = 8.0f;
        float f12 = f8 + 8.0f;
        float f13 = f9 + (f7 - f11) * 0.5f;
        GuiRenderer.a(mc13, "remove", f12, f13, f11, f11, GuiRenderer.a(Color.WHITE, n2));
        FontManager.a().a(mc13, new StringConstant("Detonate"), f12 + f11 + 4.0f, f9 + f7 * 0.25f, 6.5f, GuiRenderer.a(Color.WHITE, n2));
    }

    public boolean shouldPause() {
        return false;
    }

    public void close() {
        if (!this.d) {
            this.d = true;
        }
    }

    private static void lambda$drawSelfDestructButton$6() {
        SoundManager.b();
        for (Module module : ModuleManager.c()) {
            if (!module.isEnabled()) continue;
            module.b(false);
        }
        Main.destroyed = true;
        Main.eventBus().unregisterAll();
        Main.mc.setScreen(null);
        SelfDestruct.detonate();
    }

    private static void lambda$drawFriendsButton$5() {
        SoundManager.b();
        Main.mc.setScreen((Screen)FriendsScreen.getInstance());
    }

    private static void lambda$drawFontSelector$4(String string) {
        SoundManager.b();
        ClientSettings.getInstance().a(string);
    }

    private static void lambda$drawGuiScaleSelector$3(int n2) {
        SoundManager.b();
        ClientSettings.getInstance().a(n2);
    }

    private static void lambda$drawGuiStyleSelector$2(int n2) {
        SoundManager.b();
        ClientSettings.getInstance().b(n2);
    }

    private static void lambda$drawScrollbarToggle$1() {
        SoundManager.b();
        ClientSettings.getInstance().b(!ClientSettings.getInstance().e());
    }

    private static void lambda$drawBlurToggle$0() {
        SoundManager.b();
        ClientSettings.getInstance().a(!ClientSettings.getInstance().c());
    }
}

