/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.screen;

import itz.vrgn1337.groovclient.macro.MacroStepType;

class MacroStepTypeSwitchMap {
    static final int[] a = new int[MacroStepType.values().length];

    static {
        try {
            MacroStepTypeSwitchMap.a[MacroStepType.Swap.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            MacroStepTypeSwitchMap.a[MacroStepType.Wait.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            MacroStepTypeSwitchMap.a[MacroStepType.Press.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            MacroStepTypeSwitchMap.a[MacroStepType.Hold.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

