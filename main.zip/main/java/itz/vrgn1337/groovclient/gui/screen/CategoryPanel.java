/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.screen;

import itz.vrgn1337.groovclient.module.ModuleCategory;
import itz.vrgn1337.groovclient.module.ModuleManager;
import java.util.ArrayList;
import java.util.List;

class CategoryPanel {
    ModuleCategory a;
    float b;
    float c;
    boolean d = true;
    boolean e;
    List<Module> f = new ArrayList<>();
    float g;
    float h;
    long i;

    CategoryPanel(ModuleCategory moduleCategory, float f2, float f3) {
        this.a = moduleCategory;
        this.b = f2;
        this.c = f3;
        this.f.addAll(ModuleManager.a(moduleCategory));
    }
}

