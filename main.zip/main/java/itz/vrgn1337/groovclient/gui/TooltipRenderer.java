/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import java.awt.Color;
import net.minecraft.client.util.math.MatrixStack;

public class TooltipRenderer {
    private static StringConstant a = null;
    private static float b = 0.0f;
    private static long c = 0L;
    private static boolean d = false;
    private static final long e = 350L;
    private static final float f = 7.0f;
    private static final float g = 5.0f;
    private static final float h = 6.5f;
    private static final float i = 10.0f;
    private static final float j = 10.0f;

    private TooltipRenderer() {
    }

    public static void a() {
        d = false;
    }

    public static void a(StringConstant stringConstant) {
        if (stringConstant == null) {
            return;
        }
        String string = stringConstant.a();
        if (string == null || string.isEmpty()) {
            return;
        }
        d = true;
        if (a == null || !a.a().equals(string)) {
            a = stringConstant;
            c = System.currentTimeMillis();
        }
    }

    public static void a(MatrixStack mc13, float f2) {
        long l2;
        if (!d) {
            a = null;
            c = 0L;
        }
        float f3 = 0.0f;
        if (d && a != null && (l2 = System.currentTimeMillis() - c) >= 350L) {
            f3 = 1.0f;
        }
        if ((b = GuiRenderer.a("tooltip.show", f3, 0.1f)) < 0.01f || a == null) {
            return;
        }
        float f4 = 6.5f * f2;
        float f5 = 7.0f * f2;
        float f6 = 5.0f * f2;
        float f7 = FontManager.a().a(a, f4);
        float f8 = FontManager.a().b(f4);
        float f9 = f7 + f5 * 2.0f;
        float f10 = f8 + f6 * 2.0f;
        float f11 = (float)RenderScale.j();
        float f12 = (float)RenderScale.k();
        float f13 = f11 + 10.0f * f2;
        float f14 = f12 + 10.0f * f2;
        float f15 = RenderScale.c();
        float f16 = RenderScale.d();
        if (f13 + f9 > f15 - 4.0f) {
            f13 = f11 - f9 - 4.0f * f2;
        }
        if (f14 + f10 > f16 - 4.0f) {
            f14 = f12 - f10 - 4.0f * f2;
        }
        float f17 = (1.0f - b) * 4.0f * f2;
        int n2 = Math.round(b * 220.0f);
        int n3 = Math.round(b * 255.0f);
        float f18 = 4.8f * f2;
        new PanelRenderer(mc13, f13, f14 += f17, f9, f10).a(new Color(10, 10, 10, n2)).d().a(12.0f, 1.0f).a(f18).j();
        FontManager.a().a(mc13, a, f13 + f5, f14 + f6 * 0.75f, f4, GuiRenderer.a(Color.WHITE, n3));
    }
}

