/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.hud;

public enum CrosshairShape {
    CROSS("Cross"), DOT("Dot"), CIRCLE("Circle"), T_SHAPE("T"), X_SHAPE("X"), SQUARE("Square"), BRACKET("Bracket");
    public final String displayName;

    private CrosshairShape(String displayName) {
        this.displayName = displayName;

    }

}

