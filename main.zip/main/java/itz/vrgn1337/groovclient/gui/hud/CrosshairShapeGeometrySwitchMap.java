/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.hud;

import itz.vrgn1337.groovclient.gui.hud.CrosshairShape;

class CrosshairShapeGeometrySwitchMap {
    static final int[] a = new int[CrosshairShape.values().length];

    static {
        try {
            CrosshairShapeGeometrySwitchMap.a[CrosshairShape.CROSS.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            CrosshairShapeGeometrySwitchMap.a[CrosshairShape.T_SHAPE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            CrosshairShapeGeometrySwitchMap.a[CrosshairShape.X_SHAPE.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            CrosshairShapeGeometrySwitchMap.a[CrosshairShape.DOT.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            CrosshairShapeGeometrySwitchMap.a[CrosshairShape.CIRCLE.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            CrosshairShapeGeometrySwitchMap.a[CrosshairShape.SQUARE.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            CrosshairShapeGeometrySwitchMap.a[CrosshairShape.BRACKET.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

