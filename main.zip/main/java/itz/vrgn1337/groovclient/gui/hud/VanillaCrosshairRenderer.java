/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.hud;

import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.hud.CrosshairConfig;
import itz.vrgn1337.groovclient.gui.hud.CrosshairShape;
import net.minecraft.client.gui.DrawContext;

public final class VanillaCrosshairRenderer {
    private VanillaCrosshairRenderer() {
    }

    public static boolean a(DrawContext mc15) {
        float f2;
        CrosshairConfig crosshairConfig = CrosshairConfig.getInstance();
        if (!crosshairConfig.b()) {
            return false;
        }
        int n2 = Main.mc.getWindow().getScaledWidth() / 2;
        int n3 = Main.mc.getWindow().getScaledHeight() / 2;
        float f3 = 0.0f;
        if (crosshairConfig.m() && Main.mc.player != null) {
            double d2 = Main.mc.player.getVelocity().x;
            double d3 = Main.mc.player.getVelocity().z;
            f2 = (float)Math.sqrt(d2 * d2 + d3 * d3);
            f3 = GuiRenderer.a("crosshair.spread", Math.min(1.0f, f2 * 3.0f) * crosshairConfig.n(), 0.08f);
        }
        int n4 = Math.max(0, Math.round(crosshairConfig.d()));
        int n5 = Math.max(1, Math.round(crosshairConfig.e()));
        int n6 = Math.max(0, Math.round(crosshairConfig.f() + f3));
        int n7 = crosshairConfig.g().getRGB();
        VanillaCrosshairRenderer.a(mc15, n2, n3, n4, n5, n6, n7, crosshairConfig.c(), crosshairConfig);
        if (crosshairConfig.k()) {
            int n8 = Math.max(1, Math.round(crosshairConfig.l()));
            mc15.fill(n2 - n8 / 2, n3 - n8 / 2, n2 - n8 / 2 + n8, n3 - n8 / 2 + n8, n7);
        }
        if ((f2 = crosshairConfig.p()) > 0.01f) {
            int n9 = crosshairConfig.j().getRGB() & 0xFFFFFF;
            int n10 = (int)(255.0f * f2) & 0xFF;
            int n11 = n10 << 24 | n9;
            int n12 = 4 + Math.round(2.0f * (1.0f - f2));
            int n13 = 4;
            mc15.fill(n2 - n13 - n12, n3 - n13, n2 - n13, n3 - n13 + 1, n11);
            mc15.fill(n2 - n13, n3 - n13 - n12, n2 - n13 + 1, n3 - n13, n11);
            mc15.fill(n2 + n13, n3 - n13, n2 + n13 + n12, n3 - n13 + 1, n11);
            mc15.fill(n2 + n13, n3 - n13 - n12, n2 + n13 + 1, n3 - n13, n11);
            mc15.fill(n2 - n13 - n12, n3 + n13, n2 - n13, n3 + n13 + 1, n11);
            mc15.fill(n2 - n13, n3 + n13, n2 - n13 + 1, n3 + n13 + n12, n11);
            mc15.fill(n2 + n13, n3 + n13, n2 + n13 + n12, n3 + n13 + 1, n11);
            mc15.fill(n2 + n13, n3 + n13, n2 + n13 + 1, n3 + n13 + n12, n11);
        }
        return true;
    }

    private static void a(DrawContext mc15, int n2, int n3, int n4, int n5, int n6, int n7, CrosshairShape crosshairShape, CrosshairConfig crosshairConfig) {
        switch (crosshairShape) {
            case CROSS: {
                mc15.fill(n2 - n6 - n4, n3 - n5 / 2, n2 - n6, n3 - n5 / 2 + n5, n7);
                mc15.fill(n2 + n6, n3 - n5 / 2, n2 + n6 + n4, n3 - n5 / 2 + n5, n7);
                mc15.fill(n2 - n5 / 2, n3 - n6 - n4, n2 - n5 / 2 + n5, n3 - n6, n7);
                mc15.fill(n2 - n5 / 2, n3 + n6, n2 - n5 / 2 + n5, n3 + n6 + n4, n7);
                break;
            }
            case T_SHAPE: {
                mc15.fill(n2 - n6 - n4, n3 - n5 / 2, n2 - n6, n3 - n5 / 2 + n5, n7);
                mc15.fill(n2 + n6, n3 - n5 / 2, n2 + n6 + n4, n3 - n5 / 2 + n5, n7);
                mc15.fill(n2 - n5 / 2, n3 + n6, n2 - n5 / 2 + n5, n3 + n6 + n4, n7);
                break;
            }
            case X_SHAPE: {
                int n8 = Math.max(1, n4);
                for (int i2 = 1; i2 <= n8; ++i2) {
                    int n9 = n6 + i2 - 1;
                    mc15.fill(n2 - n9 - 1, n3 - n9 - 1, n2 - n9, n3 - n9, n7);
                    mc15.fill(n2 + n9, n3 - n9 - 1, n2 + n9 + 1, n3 - n9, n7);
                    mc15.fill(n2 - n9 - 1, n3 + n9, n2 - n9, n3 + n9 + 1, n7);
                    mc15.fill(n2 + n9, n3 + n9, n2 + n9 + 1, n3 + n9 + 1, n7);
                }
                break;
            }
            case DOT: {
                int n10 = Math.max(1, Math.round(crosshairConfig.l()));
                mc15.fill(n2 - n10 / 2, n3 - n10 / 2, n2 - n10 / 2 + n10, n3 - n10 / 2 + n10, n7);
                break;
            }
            case CIRCLE: {
                int n11 = Math.max(1, n4);
                int n12 = Math.max(1, n5);
                VanillaCrosshairRenderer.a(mc15, n2, n3, n11, n12, n7);
                break;
            }
            case SQUARE: {
                int n13 = Math.max(1, n4);
                int n14 = Math.max(1, n5);
                mc15.fill(n2 - n13, n3 - n13, n2 + n13, n3 - n13 + n14, n7);
                mc15.fill(n2 - n13, n3 + n13 - n14, n2 + n13, n3 + n13, n7);
                mc15.fill(n2 - n13, n3 - n13, n2 - n13 + n14, n3 + n13, n7);
                mc15.fill(n2 + n13 - n14, n3 - n13, n2 + n13, n3 + n13, n7);
                break;
            }
            case BRACKET: {
                int n15 = Math.max(1, Math.round((float)n4 * 0.6f));
                int n16 = n6 + n4;
                int n17 = Math.max(1, n5);
                mc15.fill(n2 - n16, n3 - n16, n2 - n16 + n15, n3 - n16 + n17, n7);
                mc15.fill(n2 - n16, n3 - n16, n2 - n16 + n17, n3 - n16 + n15, n7);
                mc15.fill(n2 + n16 - n15, n3 - n16, n2 + n16, n3 - n16 + n17, n7);
                mc15.fill(n2 + n16 - n17, n3 - n16, n2 + n16, n3 - n16 + n15, n7);
                mc15.fill(n2 - n16, n3 + n16 - n17, n2 - n16 + n15, n3 + n16, n7);
                mc15.fill(n2 - n16, n3 + n16 - n15, n2 - n16 + n17, n3 + n16, n7);
                mc15.fill(n2 + n16 - n15, n3 + n16 - n17, n2 + n16, n3 + n16, n7);
                mc15.fill(n2 + n16 - n17, n3 + n16 - n15, n2 + n16, n3 + n16, n7);
            }
        }
    }

    private static void a(DrawContext mc15, int n2, int n3, int n4, int n5, int n6) {
        for (int i2 = -n4; i2 <= n4; ++i2) {
            for (int i3 = -n4; i3 <= n4; ++i3) {
                int n7 = i3 * i3 + i2 * i2;
                if (n7 > n4 * n4 || n7 < (n4 - n5) * (n4 - n5)) continue;
                mc15.fill(n2 + i3, n3 + i2, n2 + i3 + 1, n3 + i2 + 1, n6);
            }
        }
    }
}

