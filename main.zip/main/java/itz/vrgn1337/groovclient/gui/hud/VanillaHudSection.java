/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.hud;

public enum VanillaHudSection {
    HOTBAR("Hotbar", 0.5f, 1.0f, -93.0f, -30.0f, 186.0f, 26.0f), CHAT("Chat", 0.0f, 1.0f, 4.0f, -50.0f, 220.0f, 90.0f), SCOREBOARD("Scoreboard", 1.0f, 0.5f, -120.0f, -60.0f, 110.0f, 120.0f), BOSSBAR("Boss Bar", 0.5f, 0.0f, -92.0f, 12.0f, 184.0f, 26.0f), POTIONS("Potions", 1.0f, 0.0f, -60.0f, 4.0f, 56.0f, 80.0f), SELECTED("Item Name", 0.5f, 1.0f, -60.0f, -60.0f, 120.0f, 12.0f), CROSSHAIR("Crosshair", 0.5f, 0.5f, -6.0f, -6.0f, 12.0f, 12.0f);
    public final String displayName;
    public final float anchorX;
    public final float anchorY;
    public final float defaultOffsetX;
    public final float defaultOffsetY;
    public final float boxW;
    public final float boxH;

    private VanillaHudSection(String displayName, float anchorX, float anchorY, float defaultOffsetX, float defaultOffsetY, float boxW, float boxH) {
        this.displayName = (String)displayName;
        this.anchorX = anchorX;
        this.anchorY = anchorY;
        this.defaultOffsetX = defaultOffsetX;
        this.defaultOffsetY = defaultOffsetY;
        this.boxW = boxW;
        this.boxH = boxH;

    }

}

