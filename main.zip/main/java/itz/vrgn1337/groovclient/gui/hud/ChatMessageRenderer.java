/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.hud;

import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.hud.HudDrawUtil;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudElementSettings;
import java.awt.Color;
import java.util.List;
import net.minecraft.client.gui.hud.ChatHudLine;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.util.math.MatrixStack;

public final class ChatMessageRenderer {
    private static final float a = 9.0f;
    private static final float b = 3.0f;
    private static final float c = 2.0f;
    private static final int d = 200;

    private ChatMessageRenderer() {
    }

    public static void a(DrawContext mc15, ChatHud mc73, List list, TextRenderer PackResourceMetadata, int n2, boolean bl, VanillaHudElementSettings vanillaHudElementSettings) {
        int n3;
        if (list == null || list.isEmpty()) {
            return;
        }
        float f2 = vanillaHudElementSettings.j();
        float f3 = vanillaHudElementSettings.g().boxW * f2;
        float f4 = vanillaHudElementSettings.g().boxH * f2;
        float f5 = vanillaHudElementSettings.b();
        float f6 = vanillaHudElementSettings.c() + f4;
        int n4 = Math.max(1, (int)(f4 / 9.0f));
        int n5 = list.size();
        int n6 = Math.min(n5, n4);
        MatrixStack mc13 = new MatrixStack();
        int n7 = 0;
        for (int i2 = 0; i2 < n6; ++i2) {
            ChatHudLine.Visible mc74 = (ChatHudLine.Visible)list.get(i2);
            n3 = n2 - mc74.addedTime();
            if (!bl && n3 >= 200) continue;
            ++n7;
        }
        if (n7 == 0) {
            return;
        }
        float f7 = (float)n7 * 9.0f * f2;
        HudDrawUtil.a(mc13, vanillaHudElementSettings, f5, f6 - f7, f3, f7);
        float f8 = RenderScale.h();
        mc15.getMatrices().pushMatrix();
        mc15.getMatrices().scale(f8, f8);
        for (n3 = 0; n3 < n6; ++n3) {
            float f9;
            ChatHudLine.Visible mc75 = (ChatHudLine.Visible)list.get(n3);
            int n8 = n2 - mc75.addedTime();
            if (!bl && n8 >= 200) continue;
            float f10 = 1.0f;
            if (!bl) {
                f9 = (float)n8 / 200.0f;
                f10 = Math.max(0.0f, 1.0f - f9);
                f10 *= f10;
            }
            f9 = f6 - (float)(n3 + 1) * 9.0f * f2;
            int n9 = (int)(f10 * 255.0f) << 24 | 0xFFFFFF;
            mc15.drawText(PackResourceMetadata, mc75.content(), Math.round(f5 + 3.0f), Math.round(f9 + 2.0f), n9, false);
        }
        mc15.getMatrices().popMatrix();
    }

    public static float a(int n2) {
        float f2 = 3.0f;
        if ((float)n2 >= f2) {
            return 0.0f;
        }
        float f3 = (float)n2 / f2;
        f3 = 1.0f - (1.0f - f3) * (1.0f - f3) * (1.0f - f3);
        return (1.0f - f3) * 4.0f;
    }

    private static void a() {
        Main.mc.hashCode();
        Color.class.getName();
        GuiRenderer.class.getName();
    }
}

