/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.hud;

import itz.vrgn1337.groovclient.api.util.render.GlassStyle;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.api.util.render.ThemeVariant;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudElementSettings;
import java.awt.Color;
import net.minecraft.item.ItemStack;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

public final class HudDrawUtil {
    public static final Color a = new Color(255, 255, 255, 42);

    private HudDrawUtil() {
    }

    public static void a(MatrixStack mc13, VanillaHudElementSettings vanillaHudElementSettings, float f2, float f3, float f4, float f5) {
        if (f4 <= 0.0f || f5 <= 0.0f) {
            return;
        }
        float f6 = vanillaHudElementSettings.m();
        Color color = new Color(vanillaHudElementSettings.k(), true);
        new PanelRenderer(mc13, f2 - f6, f3 - f6, f4 + f6 * 2.0f, f5 + f6 * 2.0f).a(vanillaHudElementSettings.l()).a(vanillaHudElementSettings.a(color)).j();
    }

    public static void a(MatrixStack mc13, float f2, float f3, float f4, float f5, float f6, Color color, Color color2) {
        if (f4 <= 0.0f || f5 <= 0.0f) {
            return;
        }
        GlassStyle glassStyle = GlassStyle.getInstance().a(ThemeVariant.VIBRANT).a(color).a(1.2f, color2).i(0.28f);
        new PanelRenderer(mc13, f2, f3, f4, f5).a(f6).a(glassStyle).j();
    }

    public static void a(DrawContext mc15, ItemStack mc33, float f2, float f3) {
        if (mc33.isEmpty()) {
            return;
        }
        float f4 = RenderScale.h();
        mc15.getMatrices().pushMatrix();
        mc15.getMatrices().translate(f2 * f4, f3 * f4);
        mc15.getMatrices().scale(f4, f4);
        mc15.drawItem(mc33, 0, 0);
        mc15.drawStackOverlay(MinecraftClient.getInstance().textRenderer, mc33, 0, 0);
        mc15.getMatrices().popMatrix();
    }

    public static int a(float f2) {
        return Math.round(f2 * RenderScale.h());
    }
}

