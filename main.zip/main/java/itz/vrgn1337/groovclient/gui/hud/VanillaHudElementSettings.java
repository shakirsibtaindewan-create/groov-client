/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.hud;

import itz.vrgn1337.groovclient.api.util.render.GlassStyle;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.api.util.render.ThemeVariant;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudSection;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

public class VanillaHudElementSettings {
    public static final String a = "enabled";
    public static final String b = "animation";
    private final VanillaHudSection c;
    private float d;
    private float e;
    private float f = 1.0f;
    private int g = 0x2AFFFFFF;
    private float h = 8.0f;
    private float i = 5.0f;
    private final Map j = new HashMap();
    private final Map k = new HashMap();

    public VanillaHudElementSettings(VanillaHudSection vanillaHudSection) {
        this.c = vanillaHudSection;
        this.d = vanillaHudSection.defaultOffsetX;
        this.e = vanillaHudSection.defaultOffsetY;
        this.a();
    }

    private void a() {
        this.j.put(a, false);
        this.j.put(b, true);
        switch (this.c.ordinal()) {
            case 1: {
                this.k.put("anim_style", "slide_up");
                break;
            }
            case 0: {
                this.k.put("slot_anim", "smooth");
                break;
            }
        }
    }

    public float b() {
        return RenderScale.c() * this.c.anchorX + this.d;
    }

    public float c() {
        return RenderScale.d() * this.c.anchorY + this.e;
    }

    public float d() {
        return this.c.boxW * this.f;
    }

    public float e() {
        return this.c.boxH * this.f;
    }

    public void a(float f2, float f3) {
        this.d = f2 - RenderScale.c() * this.c.anchorX;
        this.e = f3 - RenderScale.d() * this.c.anchorY;
    }

    public void f() {
        this.d = this.c.defaultOffsetX;
        this.e = this.c.defaultOffsetY;
    }

    public VanillaHudSection g() {
        return this.c;
    }

    public float h() {
        return this.d;
    }

    public float i() {
        return this.e;
    }

    public void a(float f2) {
        this.d = f2;
    }

    public void b(float f2) {
        this.e = f2;
    }

    public float j() {
        return this.f;
    }

    public void c(float f2) {
        this.f = Math.max(0.25f, Math.min(4.0f, f2));
    }

    public int k() {
        return this.g;
    }

    public void a(int n2) {
        this.g = n2;
    }

    public float l() {
        return this.h;
    }

    public void d(float f2) {
        this.h = Math.max(0.0f, Math.min(20.0f, f2));
    }

    public float m() {
        return this.i;
    }

    public void e(float f2) {
        this.i = Math.max(0.0f, Math.min(20.0f, f2));
    }

    public boolean n() {
        return this.a(a);
    }

    public boolean a(String string) {
        return this.j.getOrDefault(string, false);
    }

    public void a(String string, boolean bl) {
        this.j.put(string, bl);
    }

    public void b(String string) {
        this.j.put(string, !this.a(string));
    }

    public Map o() {
        return this.j;
    }

    public String c(String string) {
        return (String)this.k.get(string);
    }

    public String a(String string, String string2) {
        return this.k.getOrDefault(string, string2);
    }

    public void b(String string, String string2) {
        this.k.put(string, string2);
    }

    public Map p() {
        return this.k;
    }

    public GlassStyle a(Color color) {
        GlassStyle glassStyle = GlassStyle.getInstance().a(ThemeVariant.LIGHT);
        if (color != null) {
            glassStyle.ordinal(color);
            int n2 = color.getAlpha();
            float f2 = ((float)color.getRed() * 0.2126f + (float)color.getGreen() * 0.7152f + (float)color.getBlue() * 0.0722f) / 255.0f;
            if (n2 > 110 && f2 < 0.35f) {
                glassStyle.e(1.2f).f(0.95f).i(0.5f).h(0.05f);
            } else if (n2 < 60) {
                glassStyle.e(1.55f).f(1.07f).h(0.09f);
            }
        }
        return glassStyle;
    }
}

