/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.hud;

import itz.vrgn1337.groovclient.gui.hud.CrosshairShape;
import java.awt.Color;

public final class CrosshairConfig {
    private static final CrosshairConfig a = new CrosshairConfig();
    private boolean b = false;
    private CrosshairShape c = CrosshairShape.CROSS;
    private float d = 5.0f;
    private float e = 1.0f;
    private float f = 2.0f;
    private Color g = Color.WHITE;
    private boolean h = true;
    private float i = 250.0f;
    private Color j = new Color(255, 60, 60);
    private boolean k = false;
    private float l = 1.0f;
    private boolean m = false;
    private float n = 3.0f;
    private long o = 0L;

    public static CrosshairConfig getInstance() {
        return a;
    }

    private CrosshairConfig() {
    }

    public boolean b() {
        return this.b;
    }

    public void a(boolean bl) {
        this.b = bl;
    }

    public CrosshairShape c() {
        return this.c;
    }

    public void a(CrosshairShape crosshairShape) {
        if (crosshairShape != null) {
            this.c = crosshairShape;
        }
    }

    public float d() {
        return this.d;
    }

    public void a(float f2) {
        this.d = Math.max(0.0f, Math.min(20.0f, f2));
    }

    public float e() {
        return this.e;
    }

    public void b(float f2) {
        this.e = Math.max(0.25f, Math.min(6.0f, f2));
    }

    public float f() {
        return this.f;
    }

    public void c(float f2) {
        this.f = Math.max(0.0f, Math.min(15.0f, f2));
    }

    public Color g() {
        return this.g;
    }

    public void a(Color color) {
        if (color != null) {
            this.g = color;
        }
    }

    public boolean h() {
        return this.h;
    }

    public void b(boolean bl) {
        this.h = bl;
    }

    public float i() {
        return this.i;
    }

    public void d(float f2) {
        this.i = Math.max(50.0f, Math.min(2000.0f, f2));
    }

    public Color j() {
        return this.j;
    }

    public void b(Color color) {
        if (color != null) {
            this.j = color;
        }
    }

    public boolean k() {
        return this.k;
    }

    public void c(boolean bl) {
        this.k = bl;
    }

    public float l() {
        return this.l;
    }

    public void e(float f2) {
        this.l = Math.max(0.5f, Math.min(6.0f, f2));
    }

    public boolean m() {
        return this.m;
    }

    public void d(boolean bl) {
        this.m = bl;
    }

    public float n() {
        return this.n;
    }

    public void f(float f2) {
        this.n = Math.max(0.0f, Math.min(20.0f, f2));
    }

    public void o() {
        this.o = System.currentTimeMillis();
    }

    public float p() {
        if (!this.h) {
            return 0.0f;
        }
        long l2 = System.currentTimeMillis() - this.o;
        if ((float)l2 >= this.i) {
            return 0.0f;
        }
        return 1.0f - (float)l2 / this.i;
    }
}

