/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.hud;

import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.hud.CrosshairConfig;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudElementSettings;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudSection;
import java.util.EnumMap;
import java.util.Map;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;

public final class VanillaHudConfigRegistry {
    private static final VanillaHudConfigRegistry a = new VanillaHudConfigRegistry();
    private final Map b = new EnumMap(VanillaHudSection.class);
    private boolean c = false;

    public static VanillaHudConfigRegistry getInstance() {
        return a;
    }

    private VanillaHudConfigRegistry() {
        for (VanillaHudSection vanillaHudSection : VanillaHudSection.values()) {
            this.b.put(vanillaHudSection, new VanillaHudElementSettings(vanillaHudSection));
        }
    }

    public void b() {
        Main.eventBus().register(this);
    }

    private void onAttackEventPost(AttackEvent.Post attackEvent$Post) {
        CrosshairConfig.getInstance().o();
    }

    public VanillaHudElementSettings a(VanillaHudSection vanillaHudSection) {
        return (VanillaHudElementSettings)this.b.get((Object)vanillaHudSection);
    }

    public Iterable<VanillaHudElementSettings> c() {
        return this.b.values();
    }

    public float a(VanillaHudElementSettings vanillaHudElementSettings) {
        return vanillaHudElementSettings.b();
    }

    public float b(VanillaHudElementSettings vanillaHudElementSettings) {
        return vanillaHudElementSettings.c();
    }

    public boolean d() {
        return this.c;
    }

    public void a(boolean bl) {
        this.c = bl;
    }
}

