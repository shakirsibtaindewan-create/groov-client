/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.hud;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.hud.HudDrawUtil;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudElementSettings;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import java.awt.Color;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.text.Style;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.TextColor;
import net.minecraft.client.network.ClientPlayerEntity;

public final class HotbarRenderer {
    private static final float a = 18.0f;
    private static final float b = 2.0f;
    private static final float c = 4.0f;
    private static final int d = 9;
    private static final float e = 14.0f;
    private static int f = -1;
    private static long g = 0L;

    private HotbarRenderer() {
    }

    public static float a() {
        return 186.0f;
    }

    public static float b() {
        return 26.0f;
    }

    public static void a(DrawContext mc15, VanillaHudElementSettings vanillaHudElementSettings) {
        float f2;
        float f3;
        ClientPlayerEntity mc59 = Main.mc.player;
        if (mc59 == null) {
            return;
        }
        float f4 = vanillaHudElementSettings.b();
        float f5 = vanillaHudElementSettings.c();
        float f6 = vanillaHudElementSettings.j();
        float f7 = HotbarRenderer.a() * f6;
        float f8 = HotbarRenderer.b() * f6;
        float f9 = 18.0f * f6;
        float f10 = 2.0f * f6;
        float f11 = 4.0f * f6;
        MatrixStack mc13 = new MatrixStack();
        PlayerInventory mc34 = mc59.getInventory();
        int n2 = mc34.getSelectedSlot();
        ItemStack mc33 = mc59.getOffHandStack();
        float f12 = 26.0f * f6;
        float f13 = 14.0f * f6;
        float f14 = f4 - f13 - f12;
        float f15 = f5;
        if (!mc33.isEmpty()) {
            HudDrawUtil.a(mc13, vanillaHudElementSettings, f14, f15, f12, f12);
        }
        HudDrawUtil.a(mc13, vanillaHudElementSettings, f4, f5, f7, f8);
        Color color = MenuGuiScreen.c();
        if (!mc33.isEmpty()) {
            float f16 = f12 * 0.12f;
            f3 = f12 * 0.14f;
            f2 = f12 - f16 * 2.0f;
            new PanelRenderer(mc13, f14 + f16, f15 + f16, f3, f2).a(GuiRenderer.a(color, 210)).a(f3 * 0.5f).j();
        }
        for (int i2 = 0; i2 < 9; ++i2) {
            f3 = f4 + f11 + (float)i2 * (f9 + f10);
            f2 = f5 + f11;
            new PanelRenderer(mc13, f3, f2, f9, f9).a(new Color(255, 255, 255, 22), new Color(255, 255, 255, 16), new Color(255, 255, 255, 12), new Color(0, 0, 0, 30)).a(3.0f * f6).j();
        }
        if (!mc33.isEmpty()) {
            float f17 = f14 + f11;
            f3 = f15 + f11;
            new PanelRenderer(mc13, f17, f3, f9, f9).a(new Color(255, 255, 255, 22), new Color(255, 255, 255, 16), new Color(255, 255, 255, 12), new Color(0, 0, 0, 30)).a(3.0f * f6).j();
        }
        float f18 = f4 + f11 + (float)n2 * (f9 + f10);
        f3 = GuiRenderer.a("groov.hotbar.sel", f18, 0.22f);
        f2 = f5 + f11;
        float f19 = 2.4f * f6;
        new PanelRenderer(mc13, f3 - f19, f2 - f19, f9 + f19 * 2.0f, f9 + f19 * 2.0f).a(GuiRenderer.a(color, 70)).a(5.0f * f6).j();
        float f20 = 0.9f * f6;
        new PanelRenderer(mc13, f3 - f20, f2 - f20, f9 + f20 * 2.0f, f9 + f20 * 2.0f).a(GuiRenderer.a(color, 230)).a(4.0f * f6).j();
        new PanelRenderer(mc13, f3, f2, f9, f9).a(new Color(255, 255, 255, 55), new Color(255, 255, 255, 28), new Color(255, 255, 255, 18), new Color(255, 255, 255, 8)).a(3.0f * f6).j();
        float f21 = RenderScale.h();
        mc15.getMatrices().pushMatrix();
        if (Math.abs(f6 - 1.0f) > 0.001f) {
            mc15.getMatrices().translate(f4 * f21, f5 * f21);
            mc15.getMatrices().scale(f6, f6);
            mc15.getMatrices().translate(-f4 * f21, -f5 * f21);
        }
        for (int i3 = 0; i3 < 9; ++i3) {
            ItemStack mc68 = mc34.getStack(i3);
            if (mc68.isEmpty()) continue;
            float f22 = f4 + 4.0f + (float)i3 * 20.0f + 1.0f;
            float f23 = f5 + 4.0f + 1.0f;
            HudDrawUtil.a(mc15, mc68, f22, f23);
        }
        if (!mc33.isEmpty()) {
            float f24 = f4 - 14.0f - 18.0f - 4.0f + 1.0f;
            float f25 = f5 + 4.0f + 1.0f;
            HudDrawUtil.a(mc15, mc33, f24, f25);
        }
        mc15.getMatrices().popMatrix();
    }

    public static void b(DrawContext mc15, VanillaHudElementSettings vanillaHudElementSettings) {
        float f2;
        long l2;
        ClientPlayerEntity mc59 = Main.mc.player;
        if (mc59 == null) {
            return;
        }
        PlayerInventory mc34 = mc59.getInventory();
        int n2 = mc34.getSelectedSlot();
        ItemStack mc33 = mc34.getStack(n2);
        if (f != n2) {
            f = n2;
            g = System.currentTimeMillis();
        }
        if ((float)(l2 = System.currentTimeMillis() - g) > (f2 = 1800.0f) || mc33.isEmpty()) {
            return;
        }
        float f3 = 1.0f - (float)l2 / f2;
        float f4 = Math.min(1.0f, f3 * 3.0f);
        float f5 = Math.min(1.0f, (float)l2 / 220.0f);
        float f6 = (1.0f - f5) * 4.0f;
        float f7 = vanillaHudElementSettings.j();
        float f8 = vanillaHudElementSettings.b();
        float f9 = vanillaHudElementSettings.c();
        float f10 = HotbarRenderer.a() * f7;
        float f11 = f8 + f10 * 0.5f;
        float f12 = f9;
        Text mc45 = mc33.getName();
        String string = mc45.getString();
        Color color = HotbarRenderer.a(mc45);
        StringConstant stringConstant = new StringConstant(string);
        float f13 = 5.5f;
        float f14 = FontManager.a().a(stringConstant, f13);
        float f15 = 9.0f;
        float f16 = 5.5f;
        float f17 = f14 + f15 * 2.0f;
        float f18 = f13 + f16 * 2.0f;
        float f19 = f11 - f17 * 0.5f;
        float f20 = f12 - f18 - 36.0f + f6;
        Color color2 = HotbarRenderer.a(color, 0.55f);
        Color color3 = new Color(255, 255, 255, (int)(48.0f * f4));
        Color color4 = new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), (int)(235.0f * f4));
        MatrixStack mc13 = new MatrixStack();
        HudDrawUtil.a(mc13, f19, f20, f17, f18, Math.min(f18 * 0.5f, 7.0f), color3, color4);
        float f21 = Math.min(f17 * 0.45f, f14);
        new PanelRenderer(mc13, f11 - f21 * 0.5f, f20 + f18 - 1.4f, f21, 0.8f).a(new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), (int)(210.0f * f4))).a(0.4f).j();
        Color color5 = new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), (int)(255.0f * f4));
        Color color6 = new Color(0, 0, 0, (int)(140.0f * f4));
        float f22 = f20 + (f18 - f13) * 0.5f;
        FontManager.a().b(mc13, stringConstant, f11, f22 - 2.0f, f13, color5, 0.0f, color6);
    }

    private static Color a(Text mc45) {
        try {
            TextColor mc76;
            Style mc77 = mc45.getStyle();
            TextColor mc78 = mc76 = mc77 != null ? mc77.getColor() : null;
            if (mc76 != null) {
                return new Color(mc76.getRgb());
            }
            for (Text mc79 : mc45.getSiblings()) {
                Style mc80 = mc79.getStyle();
                TextColor mc81 = mc80 != null ? mc80.getColor() : null;
                if (mc81 == null) continue;
                return new Color(mc81.getRgb());
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return Color.WHITE;
    }

    private static Color a(Color color, float f2) {
        float f3 = 1.0f - f2;
        int n2 = Math.min(255, (int)((float)color.getRed() * f3 + 255.0f * f2));
        int n3 = Math.min(255, (int)((float)color.getGreen() * f3 + 255.0f * f2));
        int n4 = Math.min(255, (int)((float)color.getBlue() * f3 + 255.0f * f2));
        return new Color(n2, n3, n4);
    }
}

