/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.hud;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.PanelRenderer;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.font.FontManager;
import itz.vrgn1337.groovclient.gui.font.MsdfFont;
import itz.vrgn1337.groovclient.gui.hud.HudDrawUtil;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudElementSettings;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import net.minecraft.text.Text;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.AbstractTeam;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.MutableText;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;

public final class VanillaHudRenderer {
    private static final float a = 7.0f;
    private static final float b = 9.5f;
    private static final float c = 10.5f;
    private static final float d = 4.0f;
    private static final float e = 6.0f;
    private static final float f = 8.0f;
    private static final int g = 15;

    private VanillaHudRenderer() {
    }

    public static void a(DrawContext mc15, TextRenderer PackResourceMetadata, VanillaHudElementSettings vanillaHudElementSettings) {
        float f2;
        if (Main.mc.world == null) {
            return;
        }
        Scoreboard VehicleMoveS2CPacket = Main.mc.world.getScoreboard();
        ScoreboardObjective mc82 = VehicleMoveS2CPacket.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (mc82 == null) {
            return;
        }
        Collection collection = VehicleMoveS2CPacket.getScoreboardEntries(mc82);
        List<ScoreboardEntry> list = new ArrayList<ScoreboardEntry>(collection);
        list.sort(Comparator.comparingInt(ScoreboardEntry::comp_2128).reversed());
        if (list.size() > 15) {
            list = list.subList(0, 15);
        }
        MsdfFont msdfFont = FontManager.a();
        String string = mc82.getDisplayName().getString();
        StringConstant stringConstant = new StringConstant(VanillaHudRenderer.a(string));
        ArrayList<StringConstant> arrayList = new ArrayList<StringConstant>(list.size());
        ArrayList<StringConstant> arrayList2 = new ArrayList<StringConstant>(list.size());
        float f3 = msdfFont.a(stringConstant, 7.0f);
        for (ScoreboardEntry mc83 : list) {
            String string2 = VanillaHudRenderer.a(VehicleMoveS2CPacket, mc83);
            String string3 = String.valueOf(mc83.value());
            StringConstant stringConstant2 = new StringConstant(VanillaHudRenderer.a(string2));
            StringConstant stringConstant3 = new StringConstant(string3);
            arrayList.add(stringConstant2);
            arrayList2.add(stringConstant3);
            f2 = msdfFont.a(stringConstant2, 7.0f) + 8.0f + msdfFont.a(stringConstant3, 7.0f);
            if (!(f2 > f3)) continue;
            f3 = f2;
        }
        float f4 = vanillaHudElementSettings.j();
        float f5 = f3 + 12.0f;
        float f6 = 26.5f + (float)list.size() * 9.5f;
        float f7 = f5 * f4;
        float f8 = f6 * f4;
        float f9 = vanillaHudElementSettings.b();
        f2 = vanillaHudElementSettings.c();
        MatrixStack mc13 = new MatrixStack();
        HudDrawUtil.a(mc13, vanillaHudElementSettings, f9, f2, f7, f8);
        Color color = MenuGuiScreen.c();
        float f10 = f2 + 18.5f * f4;
        float f11 = f9 + 6.0f * f4;
        float f12 = (f5 - 12.0f) * f4;
        new PanelRenderer(mc13, f11, f10, f12, 0.6f * f4).a(new Color(255, 255, 255, 0), GuiRenderer.a(color, 140), new Color(255, 255, 255, 0), GuiRenderer.a(color, 140)).j();
        float f13 = Math.min(f12 * 0.28f, 36.0f * f4);
        new PanelRenderer(mc13, f11 + f12 * 0.5f - f13 * 0.5f, f10 - 0.4f * f4, f13, 1.6f * f4).a(GuiRenderer.a(color, 220)).a(0.8f * f4).j();
        float f14 = f9 + f7 * 0.5f;
        float f15 = f2 + 6.0f * f4;
        msdfFont.b(mc13, stringConstant, f14, f15, 7.0f * f4, Color.WHITE, 0.0f, null);
        float f16 = f2 + 20.5f * f4;
        Color color2 = new Color(232, 236, 245);
        Color color3 = new Color(255, 120, 120);
        for (int i2 = 0; i2 < list.size(); ++i2) {
            float f17 = f16 + (float)i2 * 9.5f * f4;
            StringConstant stringConstant4 = (StringConstant)arrayList.get(i2);
            StringConstant stringConstant5 = (StringConstant)arrayList2.get(i2);
            float f18 = 1.0f - (float)i2 * 0.018f;
            f18 = Math.max(0.55f, f18);
            Color color4 = VanillaHudRenderer.a(color2, (int)(255.0f * f18));
            Color color5 = VanillaHudRenderer.a(color3, (int)(255.0f * f18));
            msdfFont.a(mc13, stringConstant4, f9 + 6.0f * f4, f17, 7.0f * f4, color4);
            float f19 = msdfFont.a(stringConstant5, 7.0f * f4);
            msdfFont.a(mc13, stringConstant5, f9 + f7 - 6.0f * f4 - f19, f17, 7.0f * f4, color5);
        }
    }

    private static String a(Scoreboard VehicleMoveS2CPacket, ScoreboardEntry mc83) {
        String string = mc83.owner();
        Team EmptyBlockView = VehicleMoveS2CPacket.getScoreHolderTeam(string);
        MutableText mc84 = EmptyBlockView != null ? Team.decorateName((AbstractTeam)EmptyBlockView, (Text)Text.literal((String)string)) : Text.literal((String)string);
        return mc84.getString();
    }

    private static String a(String string) {
        if (string == null) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder(string.length());
        for (int i2 = 0; i2 < string.length(); ++i2) {
            char c2 = string.charAt(i2);
            if (c2 == '\u00a7' && i2 + 1 < string.length()) {
                ++i2;
                continue;
            }
            stringBuilder.append(c2);
        }
        return stringBuilder.toString();
    }

    private static Color a(Color color, int n2) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.max(0, Math.min(255, n2)));
    }
}

