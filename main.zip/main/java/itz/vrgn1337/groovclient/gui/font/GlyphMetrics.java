/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.font;

public class GlyphMetrics {
    public int a;
    public int b;
    public float c;
    public float d;
    public float e;
    public float f;
    public float g;
    public float h;
    public float i;
    public float j;
    public float k;
    public float l;
    public float m;
    public float n;
    public float o;
    public float p;
    public float q;
    public float r;
}

