/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.font;

import itz.vrgn1337.groovclient.gui.font.MsdfFont;

public class FontManager {
    public static final String a = "regular";
    public static final String b = "minecraft";
    private static MsdfFont c;
    private static MsdfFont d;
    private static String e;

    public static MsdfFont a() {
        return FontManager.a(e);
    }

    public static MsdfFont a(String string) {
        FontManager.b();
        String string2 = FontManager.c(string);
        return b.equals(string2) ? d : c;
    }

    public static void b() {
        if (c == null) {
            c = new MsdfFont(a);
        }
        if (d == null) {
            try {
                d = new MsdfFont(b);
            }
            catch (RuntimeException runtimeException) {
                d = c;
            }
        }
    }

    public static void b(String string) {
        e = FontManager.c(string);
        FontManager.b();
    }

    public static String c() {
        return e;
    }

    public static String c(String string) {
        if (string == null) {
            return a;
        }
        String string2 = string.trim().toLowerCase();
        if (b.equals(string2)) {
            return b;
        }
        return a;
    }

    public static void d() {
        c = null;
        d = null;
        FontManager.b();
    }

    static {
        e = a;
    }
}

