/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.gui.font;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.vertex.VertexFormat;
import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.api.util.render.GlProgram;
import itz.vrgn1337.groovclient.api.util.render.GuiRenderer;
import itz.vrgn1337.groovclient.api.util.render.RenderScale;
import itz.vrgn1337.groovclient.api.util.render.Shaders;
import itz.vrgn1337.groovclient.gui.font.GlyphMetrics;
import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.gl.GlBackend;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.render.BuiltBuffer;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public class MsdfFont {
    private static final MinecraftClient a = MinecraftClient.getInstance();
    private final NativeImageBackedTexture b;
    private final GlyphMetrics[] c = new GlyphMetrics[0x400000];
    private int d = -1;
    private int e = -1;
    private int f = -1;
    private int g = -1;
    private int h = -1;
    private int i = -1;
    private int j = -1;
    private int k = -1;
    private int l = -1;
    private int m = -1;
    private int n = -1;
    private int o = -1;
    private int p = -1;
    private int q = -1;
    private final float[] r = new float[16];
    private final float[] s = new float[16];
    private float t = -1.0f;
    private float u = -1.0f;
    private final float[] v = new float[4];
    private final float[] w = new float[]{0.0f, 0.0f, 0.0f, 1.0f};

    public MsdfFont(String string) {
        InputStream inputStream;
        Shaders.x();
        try {
            inputStream = MsdfFont.class.getResourceAsStream("/assets/groovclient/fonts/" + string + ".png");
            if (inputStream == null) {
                throw new IOException("Font image not found: " + string);
            }
            String string2 = "groovclient:fonts/" + string;
            this.b = new NativeImageBackedTexture(() -> b.lambda$new$0((String)string2), NativeImage.read((InputStream)inputStream));
            inputStream.close();
        }
        catch (IOException iOException) {
            throw new RuntimeException(iOException);
        }
        try {
            inputStream = MsdfFont.class.getResourceAsStream("/assets/groovclient/fonts/" + string + ".json");
            try {
                if (inputStream == null) {
                    throw new IOException("Font json not found: " + string);
                }
                this.a(inputStream);
            }
            finally {
                if (inputStream != null) {
                    inputStream.close();
                }
            }
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    private int a() {
        if (this.d == -1) {
            try {
                this.d = ((GlTexture)this.b.getGlTexture()).getGlId();
            }
            catch (Exception exception) {
                return -1;
            }
        }
        return this.d;
    }

    private int b() {
        int n2 = a.getWindow().getFramebufferWidth();
        int n3 = a.getWindow().getFramebufferHeight();
        if (this.e == -1 || n2 != this.f || n3 != this.g) {
            try {
                Framebuffer mc37 = a.getFramebuffer();
                GpuTexture gpuTexture = mc37.getColorAttachment();
                if (!(gpuTexture instanceof GlTexture)) {
                    return -1;
                }
                GlTexture mc18 = (GlTexture)gpuTexture;
                GpuDevice gpuDevice = RenderSystem.getDevice();
                if (!(gpuDevice instanceof GlBackend)) {
                    return -1;
                }
                GlBackend mc38 = (GlBackend)gpuDevice;
                this.e = mc18.getOrCreateFramebuffer(mc38.getBufferManager(), mc37.getDepthAttachment());
                this.f = n2;
                this.g = n3;
            }
            catch (Exception exception) {
                return -1;
            }
        }
        return this.e;
    }

    private void a(GlProgram glProgram) {
        int n2 = glProgram.c();
        if (n2 == this.h) {
            return;
        }
        this.h = n2;
        this.i = GL20.glGetUniformLocation((int)n2, (CharSequence)"ModelViewMat");
        this.j = GL20.glGetUniformLocation((int)n2, (CharSequence)"ProjMat");
        this.k = GL20.glGetUniformLocation((int)n2, (CharSequence)"Sampler0");
        this.l = GL20.glGetUniformLocation((int)n2, (CharSequence)"ColorModulator");
        this.m = GL20.glGetUniformLocation((int)n2, (CharSequence)"pxRange");
        this.n = GL20.glGetUniformLocation((int)n2, (CharSequence)"time");
        this.o = GL20.glGetUniformLocation((int)n2, (CharSequence)"resolution");
        this.p = GL20.glGetUniformLocation((int)n2, (CharSequence)"speed");
        this.q = GL20.glGetUniformLocation((int)n2, (CharSequence)"glowColor");
    }

    private void c() {
        float f2 = RenderScale.c();
        float f3 = RenderScale.d();
        if (f2 == this.t && f3 == this.u) {
            return;
        }
        this.t = f2;
        this.u = f3;
        this.r[0] = 2.0f / f2;
        this.r[1] = 0.0f;
        this.r[2] = 0.0f;
        this.r[3] = 0.0f;
        this.r[4] = 0.0f;
        this.r[5] = -2.0f / f3;
        this.r[6] = 0.0f;
        this.r[7] = 0.0f;
        this.r[8] = 0.0f;
        this.r[9] = 0.0f;
        this.r[10] = -1.0f;
        this.r[11] = 0.0f;
        this.r[12] = -1.0f;
        this.r[13] = 1.0f;
        this.r[14] = 0.0f;
        this.r[15] = 1.0f;
    }

    private float a(float f2) {
        return f2 * 1.1f;
    }

    private static boolean a(char c2) {
        return c2 == '\u00a7' || c2 == '\u00b6' || c2 == '\u2020' || c2 == '\u2021' || c2 == '\u00ac';
    }

    public float a(StringConstant stringConstant, float f2) {
        float f3 = this.a(f2);
        float f4 = 0.0f;
        String string = stringConstant.a();
        for (int i2 = 0; i2 < string.length(); ++i2) {
            int n2;
            GlyphMetrics glyphMetrics;
            char c2 = string.charAt(i2);
            if (MsdfFont.a(c2) || (glyphMetrics = this.c[n2 = stringConstant.a(i2)]) == null) continue;
            f4 += f3 * glyphMetrics.j;
        }
        return f4;
    }

    public float b(float f2) {
        float f3 = this.a(f2);
        GlyphMetrics glyphMetrics = this.c[73];
        return glyphMetrics != null ? f3 * glyphMetrics.e : f3;
    }

    private void a(InputStream inputStream) {
        JsonObject jsonObject = JsonParser.parseReader((Reader)new InputStreamReader(inputStream)).getAsJsonObject();
        JsonObject jsonObject2 = jsonObject.getAsJsonObject("atlas");
        int n2 = jsonObject2.get("width").getAsInt();
        int n3 = jsonObject2.get("height").getAsInt();
        JsonObject jsonObject3 = jsonObject.getAsJsonObject("metrics");
        int n4 = jsonObject3.get("emSize").getAsInt();
        float f2 = jsonObject3.get("lineHeight").getAsFloat();
        float f3 = jsonObject3.get("ascender").getAsFloat();
        float f4 = jsonObject3.get("descender").getAsFloat();
        float f5 = jsonObject3.get("underlineY").getAsFloat();
        float f6 = jsonObject3.get("underlineThickness").getAsFloat();
        JsonArray jsonArray = jsonObject.getAsJsonArray("glyphs");
        for (JsonElement jsonElement : jsonArray) {
            JsonObject jsonObject4;
            JsonObject jsonObject5 = jsonElement.getAsJsonObject();
            GlyphMetrics glyphMetrics = new GlyphMetrics();
            glyphMetrics.a = jsonObject5.get("unicode").getAsInt();
            glyphMetrics.j = jsonObject5.get("advance").getAsFloat();
            glyphMetrics.b = n4;
            glyphMetrics.e = f2;
            glyphMetrics.f = f3;
            glyphMetrics.g = f4;
            glyphMetrics.h = f5;
            glyphMetrics.i = f6;
            glyphMetrics.c = n2;
            glyphMetrics.d = n3;
            if (jsonObject5.has("planeBounds")) {
                jsonObject4 = jsonObject5.getAsJsonObject("planeBounds");
                glyphMetrics.k = jsonObject4.get("left").getAsFloat();
                glyphMetrics.l = jsonObject4.get("bottom").getAsFloat();
                glyphMetrics.m = jsonObject4.get("right").getAsFloat();
                glyphMetrics.n = jsonObject4.get("top").getAsFloat();
            }
            if (jsonObject5.has("atlasBounds")) {
                jsonObject4 = jsonObject5.getAsJsonObject("atlasBounds");
                glyphMetrics.o = jsonObject4.get("left").getAsFloat();
                glyphMetrics.p = jsonObject4.get("bottom").getAsFloat();
                glyphMetrics.q = jsonObject4.get("right").getAsFloat();
                glyphMetrics.r = jsonObject4.get("top").getAsFloat();
            }
            this.c[glyphMetrics.a] = glyphMetrics;
        }
    }

    public void a(MatrixStack mc13, StringConstant stringConstant, float f2, float f3) {
        this.a(mc13, stringConstant, f2, f3, 10.0f, Color.WHITE, 0.0f, null, true);
    }

    public void a(MatrixStack mc13, StringConstant stringConstant, float f2, float f3, float f4) {
        this.a(mc13, stringConstant, f2, f3, f4, Color.WHITE, 0.0f, null, true);
    }

    public void a(MatrixStack mc13, StringConstant stringConstant, float f2, float f3, float f4, Color color) {
        this.a(mc13, stringConstant, f2, f3, f4, color, 0.0f, null, true);
    }

    public void a(MatrixStack mc13, StringConstant stringConstant, float f2, float f3, float f4, Color color, float f5) {
        this.a(mc13, stringConstant, f2, f3, f4, color, f5, null, true);
    }

    public void a(MatrixStack mc13, StringConstant stringConstant, float f2, float f3, float f4, Color color, float f5, Color color2) {
        this.a(mc13, stringConstant, f2, f3, f4, color, f5, color2, true);
    }

    public void b(MatrixStack mc13, StringConstant stringConstant, float f2, float f3, float f4, Color color) {
        this.a(mc13, stringConstant, f2, f3, f4, color, 0.0f, null, false);
    }

    public void b(MatrixStack mc13, StringConstant stringConstant, float f2, float f3) {
        float f4 = this.a(stringConstant, 10.0f);
        this.a(mc13, stringConstant, f2 - f4 / 2.0f, f3, 10.0f, Color.WHITE, 0.0f, null, true);
    }

    public void b(MatrixStack mc13, StringConstant stringConstant, float f2, float f3, float f4) {
        float f5 = this.a(stringConstant, f4);
        this.a(mc13, stringConstant, f2 - f5 / 2.0f, f3, f4, Color.WHITE, 0.0f, null, true);
    }

    public void c(MatrixStack mc13, StringConstant stringConstant, float f2, float f3, float f4, Color color) {
        float f5 = this.a(stringConstant, f4);
        this.a(mc13, stringConstant, f2 - f5 / 2.0f, f3, f4, color, 0.0f, null, true);
    }

    public void b(MatrixStack mc13, StringConstant stringConstant, float f2, float f3, float f4, Color color, float f5) {
        float f6 = this.a(stringConstant, f4);
        this.a(mc13, stringConstant, f2 - f6 / 2.0f, f3, f4, color, f5, null, true);
    }

    public void b(MatrixStack mc13, StringConstant stringConstant, float f2, float f3, float f4, Color color, float f5, Color color2) {
        float f6 = this.a(stringConstant, f4);
        this.a(mc13, stringConstant, f2 - f6 / 2.0f, f3, f4, color, f5, color2, true);
    }

    private void a(MatrixStack mc13, StringConstant stringConstant, float f2, float f3, float f4, Color color, float f5, Color color2, boolean bl) {
        BuiltBuffer mc25;
        float f6;
        float f7;
        float f8;
        float f9;
        float f10;
        float f11;
        int n2;
        float f12;
        GlProgram glProgram = Shaders.g();
        if (glProgram == null) {
            return;
        }
        int n3 = this.a();
        if (n3 == -1) {
            return;
        }
        int n4 = this.b();
        if (n4 == -1) {
            return;
        }
        float f13 = this.a(f4);
        Matrix4f matrix4f = mc13.peek().getPositionMatrix();
        String string = stringConstant.a();
        int n5 = GL11.glGetInteger((int)36006);
        int n6 = GL11.glGetInteger((int)35725);
        GL30.glBindFramebuffer((int)36160, (int)n4);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL13.glActiveTexture((int)33984);
        GL11.glBindTexture((int)3553, (int)n3);
        glProgram.a();
        this.a(glProgram);
        matrix4f.get(this.s);
        this.c();
        if (this.i >= 0) {
            GL20.glUniformMatrix4fv((int)this.i, (boolean)false, (float[])this.s);
        }
        if (this.j >= 0) {
            GL20.glUniformMatrix4fv((int)this.j, (boolean)false, (float[])this.r);
        }
        if (this.k >= 0) {
            GL20.glUniform1i((int)this.k, (int)0);
        }
        if (this.l >= 0) {
            GL20.glUniform4f((int)this.l, (float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
        if (this.m >= 0) {
            GL20.glUniform1f((int)this.m, (float)4.0f);
        }
        float f14 = (float)(System.currentTimeMillis() % 1000000L) / 1000.0f;
        if (this.n >= 0) {
            GL20.glUniform1f((int)this.n, (float)f14);
        }
        if (this.o >= 0) {
            GL20.glUniform2f((int)this.o, (float)RenderScale.e(), (float)RenderScale.f());
        }
        if (this.p >= 0) {
            GL20.glUniform1f((int)this.p, (float)f5);
        }
        if (this.q >= 0) {
            if (f5 > 0.0f && color2 != null) {
                GL20.glUniform4f((int)this.q, (float)((float)color2.getRed() / 255.0f), (float)((float)color2.getGreen() / 255.0f), (float)((float)color2.getBlue() / 255.0f), (float)((float)color2.getAlpha() / 255.0f));
            } else {
                GL20.glUniform4f((int)this.q, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
            }
        }
        this.v[0] = (float)color.getRed() / 255.0f;
        this.v[1] = (float)color.getGreen() / 255.0f;
        this.v[2] = (float)color.getBlue() / 255.0f;
        this.v[3] = (float)color.getAlpha() / 255.0f;
        BufferBuilder mc23 = new BufferBuilder(new BufferAllocator(string.length() * (bl ? 2 : 1) * 4 * 24 + 64), VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        boolean bl2 = false;
        float f15 = 0.5f;
        if (bl) {
            f12 = f2 + f15;
            float f16 = f3 + f15;
            float f17 = f12;
            for (n2 = 0; n2 < string.length(); ++n2) {
                int n7;
                GlyphMetrics glyphMetrics;
                char c2 = string.charAt(n2);
                if (MsdfFont.a(c2) || (glyphMetrics = this.c[n7 = stringConstant.a(n2)]) == null) continue;
                if (glyphMetrics.m - glyphMetrics.k != 0.0f) {
                    f11 = f17 + glyphMetrics.k * f13;
                    f10 = f17 + glyphMetrics.m * f13;
                    f9 = f16 + glyphMetrics.f * f13 - glyphMetrics.n * f13;
                    f8 = f16 + glyphMetrics.f * f13 - glyphMetrics.l * f13;
                    f7 = glyphMetrics.o / glyphMetrics.c;
                    f6 = glyphMetrics.q / glyphMetrics.c;
                    float f18 = glyphMetrics.r / glyphMetrics.d;
                    float f19 = glyphMetrics.p / glyphMetrics.d;
                    mc23.vertex((Matrix4fc)matrix4f, f11, f9, 0.0f).texture(f7, 1.0f - f18).color(this.w[0], this.w[1], this.w[2], this.w[3]);
                    mc23.vertex((Matrix4fc)matrix4f, f11, f8, 0.0f).texture(f7, 1.0f - f19).color(this.w[0], this.w[1], this.w[2], this.w[3]);
                    mc23.vertex((Matrix4fc)matrix4f, f10, f8, 0.0f).texture(f6, 1.0f - f19).color(this.w[0], this.w[1], this.w[2], this.w[3]);
                    mc23.vertex((Matrix4fc)matrix4f, f10, f9, 0.0f).texture(f6, 1.0f - f18).color(this.w[0], this.w[1], this.w[2], this.w[3]);
                    bl2 = true;
                }
                f17 += f13 * glyphMetrics.j;
            }
        }
        f12 = f2;
        for (int i2 = 0; i2 < string.length(); ++i2) {
            GlyphMetrics glyphMetrics;
            char c3 = string.charAt(i2);
            if (MsdfFont.a(c3) || (glyphMetrics = this.c[n2 = stringConstant.a(i2)]) == null) continue;
            if (glyphMetrics.m - glyphMetrics.k != 0.0f) {
                float f20 = f12 + glyphMetrics.k * f13;
                float f21 = f12 + glyphMetrics.m * f13;
                f11 = f3 + glyphMetrics.f * f13 - glyphMetrics.n * f13;
                f10 = f3 + glyphMetrics.f * f13 - glyphMetrics.l * f13;
                f9 = glyphMetrics.o / glyphMetrics.c;
                f8 = glyphMetrics.q / glyphMetrics.c;
                f7 = glyphMetrics.r / glyphMetrics.d;
                f6 = glyphMetrics.p / glyphMetrics.d;
                mc23.vertex((Matrix4fc)matrix4f, f20, f11, 0.0f).texture(f9, 1.0f - f7).color(this.v[0], this.v[1], this.v[2], this.v[3]);
                mc23.vertex((Matrix4fc)matrix4f, f20, f10, 0.0f).texture(f9, 1.0f - f6).color(this.v[0], this.v[1], this.v[2], this.v[3]);
                mc23.vertex((Matrix4fc)matrix4f, f21, f10, 0.0f).texture(f8, 1.0f - f6).color(this.v[0], this.v[1], this.v[2], this.v[3]);
                mc23.vertex((Matrix4fc)matrix4f, f21, f11, 0.0f).texture(f8, 1.0f - f7).color(this.v[0], this.v[1], this.v[2], this.v[3]);
                bl2 = true;
            }
            f12 += f13 * glyphMetrics.j;
        }
        if (bl2 && (mc25 = mc23.endNullable()) != null) {
            GuiRenderer.a(mc25);
        }
        GL20.glUseProgram((int)n6);
        GL30.glBindFramebuffer((int)36160, (int)n5);
    }

    public void d() {
        this.e = -1;
        this.f = -1;
        this.g = -1;
        this.t = -1.0f;
        this.u = -1.0f;
    }

    private static String lambda$new$0(String string) {
        return string;
    }
}

