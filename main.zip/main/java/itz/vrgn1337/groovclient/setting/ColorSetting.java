/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.setting;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.setting.Setting;
import java.awt.Color;

public class ColorSetting
extends Setting {
    private Color d;

    public ColorSetting(StringConstant stringConstant, StringConstant stringConstant2, Color color) {
        super(stringConstant, stringConstant2);
        this.d = color;
    }

    public Color d() {
        return this.d;
    }

    public void a(Color color) {
        this.d = color;
    }

    public float[] e() {
        return Color.RGBtoHSB(this.d.getRed(), this.d.getGreen(), this.d.getBlue(), null);
    }

    public int f() {
        return this.d.getAlpha();
    }

    public void a(float f, float f2, float f3, int n) {
        Color color = Color.getHSBColor(f, f2, f3);
        this.d = new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.max(0, Math.min(255, n)));
    }
}

