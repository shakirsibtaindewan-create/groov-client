/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.setting;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.setting.Setting;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class KeybindSetting
extends Setting {
    public static final int d = -1;
    private static final int e = 1000;
    private static final int f = 2000;
    private long g;
    private int h;

    public KeybindSetting(StringConstant stringConstant, StringConstant stringConstant2, int n) {
        super(stringConstant, stringConstant2);
        this.h = n;
    }

    public int getKey() {
        return this.h;
    }

    public void setKey(int n) {
        this.h = n;
    }

    public void resetKey(int n) {
        if (n == 1) {
            this.g = System.currentTimeMillis();
        }
        this.h = KeybindSetting.getKey(n);
    }

    public void setKeyFromGui(int n) {
        this.h = KeybindSetting.reset(n);
    }

    public void reset() {
        if (this.h == KeybindSetting.getKey(1) && System.currentTimeMillis() - this.g < 500L) {
            return;
        }
        this.h = -1;
    }

    public boolean isBound() {
        if (this.h == -1) {
            return false;
        }
        long l2 = MinecraftClient.getInstance().getWindow().getHandle();
        if (KeybindSetting.isBound(this.h)) {
            return GLFW.glfwGetMouseButton((long)l2, (int)KeybindSetting.h(this.h)) == 1;
        }
        if (KeybindSetting.g(this.h)) {
            return false;
        }
        return GLFW.glfwGetKey((long)l2, (int)this.h) == 1;
    }

    public StringConstant g() {
        return KeybindSetting.j(this.h);
    }

    public static int d(int n) {
        return 1000 + n;
    }

    public static int e(int n) {
        return 2000 + n;
    }

    public static boolean f(int n) {
        return n >= 1000 && n < 2000;
    }

    public static boolean g(int n) {
        return n >= 2000;
    }

    public static boolean isBound(int n) {
        return f(n) || g(n);
    }

    public static int h(int n) {
        return n - 1000;
    }

    public static int i(int n) {
        return n - 2000;
    }

    public static StringConstant j(int n) {
        if (n == -1) {
            return new StringConstant("None");
        }
        if (KeybindSetting.isBound(n)) {
            int n2 = KeybindSetting.h(n);
            return new StringConstant((String)(switch (n2) {
                case 0 -> "Mouse Left";
                case 1 -> "Mouse Right";
                case 2 -> "Mouse Middle";
                case 3 -> "Mouse 4";
                case 4 -> "Mouse 5";
                case 5 -> "Mouse 6";
                case 6 -> "Mouse 7";
                case 7 -> "Mouse 8";
                default -> "Mouse " + n2;
            }));
        }
        if (KeybindSetting.g(n)) {
            return new StringConstant("Scancode " + KeybindSetting.i(n));
        }
        String string = GLFW.glfwGetKeyName((int)n, (int)0);
        if (string != null && !string.isBlank()) {
            return new StringConstant(string.toUpperCase());
        }
        if (n >= 290 && n <= 314) {
            return new StringConstant("F" + (n - 290 + 1));
        }
        return new StringConstant((String)(switch (n) {
            case 32 -> "Space";
            case 256 -> "Escape";
            case 257 -> "Enter";
            case 258 -> "Tab";
            case 259 -> "Backspace";
            case 260 -> "Insert";
            case 261 -> "Delete";
            case 262 -> "Right";
            case 263 -> "Left";
            case 264 -> "Down";
            case 265 -> "Up";
            case 266 -> "Page Up";
            case 267 -> "Page Down";
            case 268 -> "Home";
            case 269 -> "End";
            case 280 -> "Caps Lock";
            case 281 -> "Scroll Lock";
            case 282 -> "Num Lock";
            case 283 -> "Print Screen";
            case 284 -> "Pause";
            case 340 -> "Left Shift";
            case 341 -> "Left Ctrl";
            case 342 -> "Left Alt";
            case 343 -> "Left Super";
            case 344 -> "Right Shift";
            case 345 -> "Right Ctrl";
            case 346 -> "Right Alt";
            case 347 -> "Right Super";
            case 348 -> "Menu";
            default -> "Key " + n;
        }));
    }
}

