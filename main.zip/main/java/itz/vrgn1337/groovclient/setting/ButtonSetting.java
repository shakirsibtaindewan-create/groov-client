/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.setting;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.setting.Setting;

public class ButtonSetting
extends Setting {
    private final StringConstant d;
    private final Runnable e;

    public ButtonSetting(StringConstant stringConstant, StringConstant stringConstant2, StringConstant stringConstant3, Runnable runnable) {
        super(stringConstant, stringConstant2);
        this.d = stringConstant3;
        this.e = runnable;
    }

    public StringConstant d() {
        return this.d;
    }

    public void e() {
        if (this.e != null) {
            this.e.run();
        }
    }
}

