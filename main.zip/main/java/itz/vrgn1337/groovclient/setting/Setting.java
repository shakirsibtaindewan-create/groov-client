/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.setting;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;

public class Setting {
    private final StringConstant a;
    private final StringConstant b;
    private boolean c = true;

    public Setting(StringConstant stringConstant, StringConstant stringConstant2) {
        this.a = stringConstant;
        this.b = stringConstant2;
    }

    public StringConstant getName() {
        return this.a;
    }

    public StringConstant getDescription() {
        return this.b;
    }

    public void setVisible(boolean bl) {
        this.c = bl;
    }

    public boolean isVisible() {
        return this.c;
    }
}

