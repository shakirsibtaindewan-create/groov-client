/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.setting;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.concurrent.ThreadLocalRandom;

public class DoubleSetting
extends Setting {
    private final float d;
    private final float e;
    private final float f;
    private final float g;
    private float h;
    private float i;

    public DoubleSetting(StringConstant stringConstant, StringConstant stringConstant2, float f, float f2, float f3, float f4, float f5, float f6) {
        super(stringConstant, stringConstant2);
        this.d = f3;
        this.e = f4;
        this.f = f5;
        this.g = Math.max(0.0f, f6);
        this.a(f, f2);
    }

    public void a(float f, float f2) {
        float f3;
        float f4;
        float f5 = this.d(this.c(f));
        if (f5 > (f4 = this.d(this.c(f2)))) {
            f3 = f5;
            f5 = f4;
            f4 = f3;
        }
        if ((f3 = f4 - f5) > this.g) {
            f4 = f5 + this.g;
            if ((f4 = this.d(this.c(f4))) < f5) {
                f5 = this.d(this.c(f4));
            }
        }
        this.h = f5;
        this.i = f4;
    }

    public void a(float f) {
        float f2 = this.d(this.c(f));
        if (f2 > this.i) {
            f2 = this.i;
        }
        if (this.i - f2 > this.g) {
            this.i = this.d(this.c(f2 + this.g));
        }
        this.h = f2;
    }

    public void b(float f) {
        float f2 = this.d(this.c(f));
        if (f2 < this.h) {
            f2 = this.h;
        }
        if (f2 - this.h > this.g) {
            this.h = this.d(this.c(f2 - this.g));
        }
        this.i = f2;
    }

    public float d() {
        return this.h;
    }

    public int e() {
        return Math.round(this.h);
    }

    public float f() {
        return this.i;
    }

    public int g() {
        return Math.round(this.i);
    }

    public int h() {
        return (int)this.i();
    }

    public float i() {
        float f = Math.min(this.h, this.i);
        float f2 = Math.max(this.h, this.i);
        if (Math.abs(f2 - f) < 1.0E-6f) {
            return f;
        }
        float f3 = (float)ThreadLocalRandom.current().nextDouble(f, f2);
        return this.d(this.c(f3));
    }

    public String j() {
        if (this.f >= 1.0f) {
            return this.e() + " - " + this.g();
        }
        return String.format("%.2f - %.2f", Float.valueOf(this.h), Float.valueOf(this.i));
    }

    public float k() {
        return this.d;
    }

    public float l() {
        return this.e;
    }

    public float m() {
        return this.f;
    }

    public float n() {
        return this.g;
    }

    private float c(float f) {
        return Math.max(this.d, Math.min(this.e, f));
    }

    private float d(float f) {
        if (this.f <= 0.0f) {
            return f;
        }
        return (float)Math.round(f / this.f) * this.f;
    }
}

