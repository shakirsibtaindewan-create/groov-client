/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.setting;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.setting.Setting;

public class BooleanSetting
extends Setting {
    private boolean d;

    public BooleanSetting(StringConstant stringConstant, StringConstant stringConstant2, boolean bl) {
        super(stringConstant, stringConstant2);
        this.d = bl;
    }

    public boolean getValue() {
        return this.d;
    }

    public void setValue(boolean bl) {
        this.d = bl;
    }

    public void reset() {
        this.d = !this.d;
    }
}

