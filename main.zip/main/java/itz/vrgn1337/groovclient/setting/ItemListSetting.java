/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.setting;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ItemListSetting
extends Setting {
    private final Registry d;
    private final List<Object> e = new ArrayList<>();
    private final List<Object> f = new ArrayList<>();

    public <T> ItemListSetting(StringConstant stringConstant, StringConstant stringConstant2, Registry<T> mc115, Predicate<T> predicate, List<T> list) {
        super(stringConstant, stringConstant2);
        this.d = (Registry)mc115;
        if (predicate != null) {
            mc115.stream().filter(predicate).forEach(this.e::add);
        } else {
            mc115.stream().forEach(this.e::add);
        }
        if (list != null) {
            this.f.addAll(list);
        }
    }

    public boolean a(Object object) {
        return this.f.contains(object);
    }

    public void b(Object object) {
        if (this.f.contains(object)) {
            this.f.remove(object);
        } else {
            this.f.add(object);
        }
    }

    public String c(Object object) {
        Identifier mc19 = this.d.getId(object);
        if (mc19 == null) {
            return "?";
        }
        return mc19.getPath().replace("_", " ");
    }

    public Identifier d(Object object) {
        return this.d.getId(object);
    }

    public String d() {
        StringBuilder stringBuilder = new StringBuilder();
        for (Object e : this.f) {
            Identifier mc19 = this.d.getId(e);
            if (mc19 == null) continue;
            stringBuilder.append(mc19.toString()).append(";");
        }
        return stringBuilder.toString();
    }

    public void a(String string) {
        String[] stringArray;
        this.f.clear();
        block0: for (String string2 : stringArray = string.split(";")) {
            Identifier mc19;
            if (string2.isEmpty() || (mc19 = Identifier.tryParse((String)string2)) == null) continue;
            for (Object e : this.e) {
                Identifier mc116 = this.d.getId(e);
                if (mc116 == null || !mc116.equals((Object)mc19)) continue;
                this.f.add(e);
                continue block0;
            }
        }
    }

    public Registry e() {
        return this.d;
    }

    public List f() {
        return this.e;
    }

    public List g() {
        return this.f;
    }
}

