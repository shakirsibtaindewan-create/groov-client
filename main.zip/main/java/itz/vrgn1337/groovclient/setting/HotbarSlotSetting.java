/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.setting;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.ArrayList;

public class HotbarSlotSetting
extends Setting {
    private final boolean[] d = new boolean[9];
    private final boolean e;

    public HotbarSlotSetting(StringConstant stringConstant, StringConstant stringConstant2, boolean[] blArray) {
        this(stringConstant, stringConstant2, blArray, false);
    }

    public HotbarSlotSetting(StringConstant stringConstant, StringConstant stringConstant2, boolean[] blArray, boolean bl) {
        super(stringConstant, stringConstant2);
        this.e = bl;
        if (blArray != null) {
            int n = Math.min(blArray.length, this.d.length);
            System.arraycopy(blArray, 0, this.d, 0, n);
        }
    }

    public void a(int n) {
        boolean bl;
        if (n < 0 || n >= this.d.length) {
            return;
        }
        boolean bl2 = bl = !this.d[n];
        if (this.e && bl) {
            for (int i = 0; i < this.d.length; ++i) {
                this.d[i] = false;
            }
        }
        this.d[n] = bl;
    }

    public void a(int n, boolean bl) {
        if (n < 0 || n >= this.d.length) {
            return;
        }
        if (this.e && bl) {
            for (int i = 0; i < this.d.length; ++i) {
                this.d[i] = false;
            }
        }
        this.d[n] = bl;
    }

    public boolean b(int n) {
        return n >= 0 && n < this.d.length && this.d[n];
    }

    public boolean[] d() {
        return (boolean[])this.d.clone();
    }

    public int[] e() {
        ArrayList<Integer> arrayList = new ArrayList<Integer>(9);
        for (int i = 0; i < this.d.length; ++i) {
            if (!this.d[i]) continue;
            arrayList.add(i);
        }
        int[] nArray = new int[arrayList.size()];
        for (int i = 0; i < arrayList.size(); ++i) {
            nArray[i] = (Integer)arrayList.get(i);
        }
        return nArray;
    }

    public boolean f() {
        return this.e;
    }

    public int g() {
        for (int i = 0; i < this.d.length; ++i) {
            if (!this.d[i]) continue;
            return i;
        }
        return -1;
    }
}

