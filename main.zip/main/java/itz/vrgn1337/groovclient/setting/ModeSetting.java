/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.setting;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.setting.Setting;
import java.util.EnumSet;

public class ModeSetting
extends Setting {
    private final Enum[] d;
    private int e;
    private final boolean f;
    private final EnumSet g;

    public ModeSetting(StringConstant stringConstant, StringConstant stringConstant2, Enum enum_) {
        this(stringConstant, stringConstant2, enum_, false);
    }

    public ModeSetting(StringConstant stringConstant, StringConstant stringConstant2, Enum enum_, boolean bl) {
        super(stringConstant, stringConstant2);
        this.d = (Enum[])enum_.getDeclaringClass().getEnumConstants();
        this.e = enum_.ordinal();
        this.f = bl;
        this.g = EnumSet.of(enum_);
    }

    public Enum getValue() {
        return this.d[this.e];
    }

    public void cycleNext() {
        this.e = (this.e + 1) % this.d.length;
    }

    public void cyclePrevious() {
        this.e = (this.e - 1 + this.d.length) % this.d.length;
    }

    public Enum[] getModes() {
        return this.d;
    }

    public int getIndex() {
        return this.e;
    }

    public void setIndex(int n) {
        this.e = Math.max(0, Math.min(n, this.d.length - 1));
    }

    public boolean isMulti() {
        return this.f;
    }

    public boolean isSelected(int n) {
        if (!this.f) {
            return n == this.e;
        }
        return this.g.contains(this.d[n]);
    }

    public void toggleIndex(int n) {
        Enum enum_ = this.d[n];
        if (this.g.contains(enum_)) {
            if (this.g.size() > 1) {
                this.g.remove(enum_);
            }
        } else {
            this.g.add(enum_);
        }
    }

    public EnumSet getSelectedSet() {
        return this.g;
    }

    public String getValueName() {
        String string = this.d[this.e].name();
        if (string.isEmpty()) {
            return string;
        }
        return Character.toUpperCase(string.charAt(0)) + string.substring(1).toLowerCase();
    }

    public static String a(Enum enum_) {
        String string = enum_.name();
        if (string.isEmpty()) {
            return string;
        }
        return Character.toUpperCase(string.charAt(0)) + string.substring(1).toLowerCase();
    }
}

