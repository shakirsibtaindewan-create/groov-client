/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.setting;

import itz.vrgn1337.groovclient.api.util.protection.StringConstant;
import itz.vrgn1337.groovclient.setting.Setting;

public class FloatSetting
extends Setting {
    private final float d;
    private final float e;
    private final float f;
    private float g;

    public FloatSetting(StringConstant stringConstant, StringConstant stringConstant2, float f, float f2, float f3) {
        this(stringConstant, stringConstant2, f, f2, f3, 0.1f);
    }

    public FloatSetting(StringConstant stringConstant, StringConstant stringConstant2, float f, float f2, float f3, float f4) {
        super(stringConstant, stringConstant2);
        this.d = f;
        this.e = f2;
        this.f = f4;
        this.g = this.getValue(f3);
    }

    public float getValue() {
        return this.g;
    }

    public int getPercent() {
        return (int)this.g;
    }

    public float getMin() {
        return this.d;
    }

    public float getMax() {
        return this.e;
    }

    public void setValue(float f) {
        this.g = this.getValue(this.c(f));
    }

    public float getStep() {
        if (this.e - this.d == 0.0f) {
            return 0.0f;
        }
        return (this.g - this.d) / (this.e - this.d);
    }

    public void setValueFromGui(float f) {
        this.setValue(this.d + (this.e - this.d) * Math.max(0.0f, Math.min(1.0f, f)));
    }

    public String format() {
        if (this.f >= 1.0f || this.g % 1.0f == 0.0f) {
            return String.valueOf((int)this.g);
        }
        return String.format("%.1f", Float.valueOf(this.g));
    }

    private float c(float f) {
        if (this.f <= 0.0f) {
            return f;
        }
        return (float)Math.round(f / this.f) * this.f;
    }

    private float d(float f) {
        return Math.max(this.d, Math.min(this.e, f));
    }
}

