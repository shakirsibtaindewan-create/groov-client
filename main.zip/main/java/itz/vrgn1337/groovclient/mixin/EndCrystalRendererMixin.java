/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.util.bridge.EntityShaderBridge;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EndCrystalEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={EndCrystalEntityRenderer.class})
public abstract class EndCrystalRendererMixin {
    private static final ThreadLocal groovclient$wrapped = ThreadLocal.withInitial(EndCrystalRendererMixin::lambda$static$0);

    @ModifyVariable(method={"render"}, at=@At(value="HEAD"), ordinal=0, argsOnly=true)
    private OrderedRenderCommandQueue groovclient$wrapCollector(OrderedRenderCommandQueue mc11) {
        OrderedRenderCommandQueue mc89 = EntityShaderBridge.tryWrapNonLivingCollector(mc11);
        groovclient$wrapped.set(mc89 != mc11);
        return mc89;
    }

    @Inject(method={"method_3908"}, at={@At(value="RETURN")})
    private void groovclient$onRenderReturn(CallbackInfo callbackInfo) {
        if (((Boolean)groovclient$wrapped.get()).booleanValue()) {
            EntityShaderBridge.onRenderComplete();
            groovclient$wrapped.set(false);
        }
    }

    private static Boolean lambda$static$0() {
        return false;
    }
}

