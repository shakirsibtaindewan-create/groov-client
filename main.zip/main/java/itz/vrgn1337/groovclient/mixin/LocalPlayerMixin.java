/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.entity.Entity;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.MovementPacketEvent;
import itz.vrgn1337.groovclient.api.event.hooks.TickMovementEvent;
import itz.vrgn1337.groovclient.api.event.hooks.MovementPacketEvent;
import itz.vrgn1337.groovclient.api.event.hooks.TickMovementEvent;

@Mixin(value={ClientPlayerEntity.class})
public class LocalPlayerMixin {
    @Inject(method={"tickMovement"}, at={@At(value="HEAD")})
    private void onAiStepPre(CallbackInfo callbackInfo) {
        Main.eventBus().post(TickMovementEvent.Pre.getInstance());
    }

    @Inject(method={"method_6007"}, at={@At(value="RETURN")})
    private void onAiStepPost(CallbackInfo callbackInfo) {
        Main.eventBus().post(TickMovementEvent.Post.getInstance());
    }

    @Inject(method={"method_3136"}, at={@At(value="HEAD")}, cancellable=true)
    private void onSendPositionPre(CallbackInfo callbackInfo) {
        if (((MovementPacketEvent.Pre)Main.eventBus().post(MovementPacketEvent.Pre.getInstance())).isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"method_3136"}, at={@At(value="RETURN")})
    private void onSendPositionPost(CallbackInfo callbackInfo) {
        Main.eventBus().post(MovementPacketEvent.Post.getInstance());
    }

    @Redirect(method={"method_5773", "method_3136"}, at=@At(value="INVOKE", target="Lnet/minecraft/Entity;method_36454()F"), require=0)
    private float groovclient$silentYaw(Entity mc2) {
        if (mc2 != this || Main.mc.player != mc2 || !RotationManager.getInstance().d()) {
            return mc2.getYaw();
        }
        return RotationManager.getInstance().k();
    }

    @Redirect(method={"method_5773", "method_3136"}, at=@At(value="INVOKE", target="Lnet/minecraft/Entity;method_36455()F"), require=0)
    private float groovclient$silentPitch(Entity mc2) {
        if (mc2 != this || Main.mc.player != mc2 || !RotationManager.getInstance().d()) {
            return mc2.getPitch();
        }
        return RotationManager.getInstance().l();
    }
}

