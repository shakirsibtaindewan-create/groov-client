/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.event.hooks.PlayerRenderEvent;
import itz.vrgn1337.groovclient.api.util.bridge.EntityShaderBridge;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={PlayerEntityRenderer.class})
public class AvatarRendererMixin {
    @Inject(method={"setupTransforms(Lnet/minecraft/PlayerEntityRenderState;Lnet/minecraft/MatrixStack;FF)V"}, at={@At(value="HEAD")})
    private void onSetupRotations(PlayerEntityRenderState mc85, MatrixStack mc13, float f2, float f3, CallbackInfo callbackInfo) {
        if (mc85.id == Main.mc.player.getId() && mc85 instanceof PlayerEntityRenderState) {
            Main.eventBus().post(PlayerRenderEvent.get((AbstractClientPlayerEntity)Main.mc.player, (LivingEntityRenderState)mc85));
        }
    }

    @Inject(method={"method_62355(Lnet/minecraft/LivingEntity;Lnet/minecraft/LivingEntityRenderState;F)V"}, at={@At(value="RETURN")})
    private void onExtractRenderState(LivingEntity mc58, LivingEntityRenderState mc10, float f2, CallbackInfo callbackInfo) {
        if (mc58 instanceof AbstractClientPlayerEntity) {
            AbstractClientPlayerEntity TrackedPosition = (AbstractClientPlayerEntity)mc58;
            if (mc10 instanceof PlayerEntityRenderState) {
                EntityShaderBridge.cacheSkinTexture(TrackedPosition);
            }
        }
    }
}

