/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.util.bridge.GameRendererMixinBridge;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderWorldEvent;

@Mixin(value={GameRenderer.class})
public class GameRendererMixin {
    private float groovclient$pickPrevYaw;
    private float groovclient$pickPrevPitch;
    private boolean groovclient$pickOverride;

    @Inject(method={"updateCrosshairTarget"}, at={@At(value="HEAD")})
    private void groovclient$onPickPre(float f2, CallbackInfo callbackInfo) {
        if (Main.mc.player == null || !RotationManager.getInstance().d()) {
            return;
        }
        this.groovclient$pickPrevYaw = Main.mc.player.getYaw();
        this.groovclient$pickPrevPitch = Main.mc.player.getPitch();
        Main.mc.player.setYaw(RotationManager.getInstance().k());
        Main.mc.player.setPitch(RotationManager.getInstance().l());
        this.groovclient$pickOverride = true;
    }

    @Inject(method={"method_3190"}, at={@At(value="RETURN")})
    private void groovclient$onPickPost(float f2, CallbackInfo callbackInfo) {
        if (!this.groovclient$pickOverride) {
            return;
        }
        Main.mc.player.setYaw(this.groovclient$pickPrevYaw);
        Main.mc.player.setPitch(this.groovclient$pickPrevPitch);
        this.groovclient$pickOverride = false;
    }

    @Inject(method={"renderWorld"}, at={@At(value="HEAD")})
    private void onRenderWorldPre(RenderTickCounter mc16, CallbackInfo callbackInfo) {
        GameRendererMixinBridge.capture((GameRenderer)this, mc16);
        Main.eventBus().post(RenderWorldEvent.Pre.get(new MatrixStack(), mc16));
    }

    @Inject(method={"method_3188"}, at={@At(value="RETURN")})
    private void onRenderWorldPost(RenderTickCounter mc16, CallbackInfo callbackInfo) {
        Main.eventBus().post(RenderWorldEvent.Post.get(new MatrixStack(), mc16));
    }
}

