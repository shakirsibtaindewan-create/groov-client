/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.WorldChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import itz.vrgn1337.groovclient.api.event.hooks.BlockStateEvent;
import itz.vrgn1337.groovclient.api.event.hooks.BlockStateEvent;

@Mixin(value={WorldChunk.class})
public class LevelChunkMixin {
    @Inject(method={"setBlockState"}, at={@At(value="HEAD")})
    private void onSetBlockStatePre(BlockPos mc0, BlockState mc1, int n2, CallbackInfoReturnable callbackInfoReturnable) {
        Main.eventBus().post(BlockStateEvent.Pre.get(mc0, mc1));
    }

    @Inject(method={"method_12010"}, at={@At(value="RETURN")})
    private void onSetBlockStatePost(BlockPos mc0, BlockState mc1, int n2, CallbackInfoReturnable callbackInfoReturnable) {
        Main.eventBus().post(BlockStateEvent.Post.get(mc0, mc1));
    }
}

