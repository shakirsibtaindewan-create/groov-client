/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.b.c.HudEditorScreen;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.gui.hud.HotbarRenderer;
import itz.vrgn1337.groovclient.gui.hud.VanillaCrosshairRenderer;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudConfigRegistry;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudElementSettings;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudRenderer;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudSection;
import itz.vrgn1337.groovclient.gui.screen.ClickGuiScreen;
import itz.vrgn1337.groovclient.gui.screen.ConfigScreen;
import itz.vrgn1337.groovclient.gui.screen.DirectMessageScreen;
import itz.vrgn1337.groovclient.gui.screen.FriendsScreen;
import itz.vrgn1337.groovclient.gui.screen.MenuGuiScreen;
import itz.vrgn1337.groovclient.gui.screen.SettingsScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RenderHUDEvent;

@Mixin(value={InGameHud.class})
public class GuiMixin {
    @Inject(method={"render"}, at={@At(value="HEAD")})
    private void onRenderHudPre(DrawContext mc15, RenderTickCounter mc16, CallbackInfo callbackInfo) {
        Main.eventBus().post(RenderHUDEvent.Pre.get(mc15, mc16));
    }

    @Inject(method={"method_1753"}, at={@At(value="RETURN")})
    private void onRenderHudPost(DrawContext mc15, RenderTickCounter mc16, CallbackInfo callbackInfo) {
        Main.eventBus().post(RenderHUDEvent.Post.get(mc15, mc16));
    }

    @Inject(method={"method_55803", "method_55802", "method_70837", "method_1736"}, at={@At(value="HEAD")}, cancellable=true)
    private void groov$suppressWhenGroovScreen(DrawContext mc15, RenderTickCounter mc16, CallbackInfo callbackInfo) {
        if (GuiMixin.groov$suppressedByScreen()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"method_1736"}, at={@At(value="HEAD")}, cancellable=true)
    private void groov$onRenderCrosshair(DrawContext mc15, RenderTickCounter mc16, CallbackInfo callbackInfo) {
        if (GuiMixin.groov$suppressedByScreen()) {
            return;
        }
        if (VanillaCrosshairRenderer.a(mc15)) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"method_1759"}, at={@At(value="HEAD")}, cancellable=true)
    private void groov$onRenderHotbar(DrawContext mc15, RenderTickCounter mc16, CallbackInfo callbackInfo) {
        if (GuiMixin.groov$suppressedByScreen()) {
            callbackInfo.cancel();
            return;
        }
        VanillaHudElementSettings vanillaHudElementSettings = VanillaHudConfigRegistry.getInstance().a(VanillaHudSection.HOTBAR);
        if (vanillaHudElementSettings == null || !vanillaHudElementSettings.n()) {
            return;
        }
        if (VanillaHudConfigRegistry.getInstance().d()) {
            return;
        }
        HotbarRenderer.a(mc15, vanillaHudElementSettings);
        callbackInfo.cancel();
    }

    @Inject(method={"method_1749(Lnet/minecraft/DrawContext;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void groov$onRenderSelectedItemName(DrawContext mc15, CallbackInfo callbackInfo) {
        if (GuiMixin.groov$suppressedByScreen()) {
            callbackInfo.cancel();
            return;
        }
        VanillaHudElementSettings vanillaHudElementSettings = VanillaHudConfigRegistry.getInstance().a(VanillaHudSection.HOTBAR);
        if (vanillaHudElementSettings == null || !vanillaHudElementSettings.n()) {
            return;
        }
        if (VanillaHudConfigRegistry.getInstance().d()) {
            return;
        }
        HotbarRenderer.b(mc15, vanillaHudElementSettings);
        callbackInfo.cancel();
    }

    @Inject(method={"method_55803"}, at={@At(value="HEAD")}, cancellable=true)
    private void groov$onRenderScoreboard(DrawContext mc15, RenderTickCounter mc16, CallbackInfo callbackInfo) {
        if (GuiMixin.groov$suppressedByScreen()) {
            callbackInfo.cancel();
            return;
        }
        VanillaHudElementSettings vanillaHudElementSettings = VanillaHudConfigRegistry.getInstance().a(VanillaHudSection.SCOREBOARD);
        if (vanillaHudElementSettings == null || !vanillaHudElementSettings.n()) {
            return;
        }
        if (VanillaHudConfigRegistry.getInstance().d()) {
            return;
        }
        VanillaHudRenderer.a(mc15, Main.mc.textRenderer, vanillaHudElementSettings);
        callbackInfo.cancel();
    }

    @Unique
    private static boolean groov$suppressedByScreen() {
        Screen mc29 = MinecraftClient.getInstance().currentScreen;
        return mc29 instanceof MenuGuiScreen || mc29 instanceof ClickGuiScreen || mc29 instanceof HudEditorScreen || mc29 instanceof ConfigScreen || mc29 instanceof SettingsScreen || mc29 instanceof FriendsScreen || mc29 instanceof DirectMessageScreen;
    }
}

