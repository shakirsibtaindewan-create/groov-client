/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin.accessor;

import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.render.OverlayTexture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={OverlayTexture.class})
public interface OverlayTextureAccessor {
    @Accessor(value="texture")
    public NativeImageBackedTexture getTexture();
}

