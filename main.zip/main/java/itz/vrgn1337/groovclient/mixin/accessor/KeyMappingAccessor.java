/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin.accessor;

import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={KeyBinding.class})
public interface KeyMappingAccessor {
    @Accessor(value="boundKey")
    public InputUtil.Key getKey();
}

