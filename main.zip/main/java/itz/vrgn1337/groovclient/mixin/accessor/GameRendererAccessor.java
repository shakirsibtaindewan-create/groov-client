/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin.accessor;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={GameRenderer.class})
public interface GameRendererAccessor {
    @Invoker(value="updateCrosshairTarget")
    public void invokePick(float var1);

    @Invoker(value="getFov")
    public float invokeGetFov(Camera var1, float var2, boolean var3);
}

