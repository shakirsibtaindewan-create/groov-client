/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin.accessor;

import net.minecraft.screen.slot.Slot;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={HandledScreen.class})
public interface AbstractContainerScreenAccessor {
    @Accessor(value="x")
    public int getLeftPos();

    @Accessor(value="y")
    public int getTopPos();

    @Accessor(value="focusedSlot")
    public Slot getHoveredSlot();
}

