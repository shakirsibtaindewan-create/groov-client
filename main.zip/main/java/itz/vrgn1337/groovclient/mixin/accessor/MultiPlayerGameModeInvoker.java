/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin.accessor;

import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.network.SequencedPacketCreator;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={ClientPlayerInteractionManager.class})
public interface MultiPlayerGameModeInvoker {
    @Invoker(value="syncSelectedSlot")
    public void ensureHasSentCarriedItem();

    @Invoker(value="sendSequencedPacket")
    public void startPrediction(ClientWorld var1, SequencedPacketCreator var2);

    @Invoker(value="interactItem")
    public ActionResult invokeUseItem(PlayerEntity var1, Hand var2);

    @Accessor(value="blockBreakingCooldown")
    public void setDestroyDelay(int var1);
}

