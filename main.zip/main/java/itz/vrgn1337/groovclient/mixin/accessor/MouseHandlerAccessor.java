/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin.accessor;

import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={Mouse.class})
public interface MouseHandlerAccessor {
    @Accessor(value="x")
    public void setXpos(double var1);

    @Accessor(value="y")
    public void setYpos(double var1);
}

