/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin.accessor;

import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={LivingEntity.class})
public interface LivingEntityAccessor {
    @Accessor(value="jumpingCooldown")
    public void setNoJumpDelay(int var1);
}

