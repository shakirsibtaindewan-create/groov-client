/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin.accessor;

import net.minecraft.client.input.KeyInput;
import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={Keyboard.class})
public interface KeyboardHandlerInvoker {
    @Invoker(value="onKey")
    public void onKey(long var1, @KeyInput.KeyAction int var3, KeyInput var4);
}

