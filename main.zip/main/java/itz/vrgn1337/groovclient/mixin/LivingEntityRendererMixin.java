/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.event.hooks.LivingEntityRenderEvent;
import itz.vrgn1337.groovclient.api.util.bridge.EntityShaderBridge;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.model.Model;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={LivingEntityRenderer.class})
public abstract class LivingEntityRendererMixin {
    private static final ThreadLocal groovclient$wrapping = ThreadLocal.withInitial(LivingEntityRendererMixin::lambda$static$0);

    @Shadow
    public abstract EntityModel getModel();

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Inject(method={"render(Lnet/minecraft/LivingEntityRenderState;Lnet/minecraft/MatrixStack;Lnet/minecraft/OrderedRenderCommandQueue;Lnet/minecraft/CameraRenderState;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void onLivingEntityRender(LivingEntityRenderState mc10, MatrixStack mc13, OrderedRenderCommandQueue mc11, CameraRenderState mc46, CallbackInfo callbackInfo) {
        if (((Boolean)groovclient$wrapping.get()).booleanValue()) {
            return;
        }
        LivingEntityRenderEvent livingEntityRenderEvent = LivingEntityRenderEvent.get(mc10, mc11, (Model)this.getModel(), mc13);
        Main.eventBus().post(livingEntityRenderEvent);
        if (livingEntityRenderEvent.isCancelled()) {
            callbackInfo.cancel();
            return;
        }
        OrderedRenderCommandQueue mc89 = EntityShaderBridge.tryWrapCollector(mc10, mc11);
        if (mc89 != mc11) {
            groovclient$wrapping.set(true);
            try {
                ((LivingEntityRenderer)this).render(mc10, mc13, mc89, mc46);
            }
            finally {
                groovclient$wrapping.set(false);
                EntityShaderBridge.onRenderComplete();
            }
            callbackInfo.cancel();
        }
    }

    private static Boolean lambda$static$0() {
        return false;
    }
}

