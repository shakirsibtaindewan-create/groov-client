/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.util.BindManager;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.HotbarSwapEvent;
import itz.vrgn1337.groovclient.api.event.hooks.HotbarSwapEvent;

@Mixin(value={PlayerInventory.class})
public class InventoryMixin {
    @Inject(method={"setSelectedSlot"}, at={@At(value="HEAD")}, cancellable=true)
    private void onSetSelectedSlot(int n2, CallbackInfo callbackInfo) {
        if (this != MinecraftClient.getInstance().player.getInventory()) {
            return;
        }
        if (!BindManager.d()) {
            callbackInfo.cancel();
            return;
        }
        if (((HotbarSwapEvent.Pre)Main.eventBus().post(HotbarSwapEvent.Pre.get(n2))).isCancelled()) {
            callbackInfo.cancel();
        }
    }
}

