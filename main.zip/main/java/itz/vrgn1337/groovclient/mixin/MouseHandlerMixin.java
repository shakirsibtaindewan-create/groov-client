/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.event.hooks.MouseButtonEvent;
import itz.vrgn1337.groovclient.api.event.hooks.MouseScrollEvent;
import itz.vrgn1337.groovclient.api.util.rotation.TweenUtil;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.client.input.MouseInput;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateMouseEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateMouseEvent;

@Mixin(value={Mouse.class})
public class MouseHandlerMixin {
    @Inject(method={"onMouseButton"}, at={@At(value="HEAD")})
    private void onMouseButton(long l2, MouseInput mc28, int n2, CallbackInfo callbackInfo) {
        Main.eventBus().post(MouseButtonEvent.get(l2, mc28.button(), n2, mc28.modifiers()));
    }

    @Inject(method={"method_1598"}, at={@At(value="HEAD")})
    private void onMouseScroll(long l2, double d2, double d3, CallbackInfo callbackInfo) {
        Main.eventBus().post(MouseScrollEvent.get(d2, d3));
    }

    @Inject(method={"method_55793"}, at={@At(value="HEAD")})
    private void onUpdateMousePre(CallbackInfo callbackInfo) {
        Main.eventBus().post(UpdateMouseEvent.Pre.getInstance());
    }

    @Inject(method={"method_55793"}, at={@At(value="RETURN")})
    private void onUpdateMousePost(CallbackInfo callbackInfo) {
        Main.eventBus().post(UpdateMouseEvent.Post.getInstance());
        TweenUtil.getInstance().b();
    }
}

