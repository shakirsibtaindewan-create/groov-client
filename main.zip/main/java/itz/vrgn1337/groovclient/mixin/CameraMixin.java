/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.CameraEvent;
import itz.vrgn1337.groovclient.api.event.hooks.CameraEvent;

@Mixin(value={Camera.class})
public abstract class CameraMixin {
    @Shadow
    protected abstract void setPos(double var1, double var3, double var5);

    @Shadow
    protected abstract void setRotation(float var1, float var2);

    @Shadow
    public abstract Vec3d getCameraPos();

    @Shadow
    public abstract float getYaw();

    @Shadow
    public abstract float getPitch();

    @Inject(method={"update"}, at={@At(value="HEAD")}, cancellable=true)
    private void onSetupPre(World mc3, Entity mc2, boolean bl, boolean bl2, float f2, CallbackInfo callbackInfo) {
        CameraEvent.Pre cameraEvent$Pre = CameraEvent.Pre.get(mc2, bl, bl2, f2);
        Main.eventBus().post(cameraEvent$Pre);
        if (cameraEvent$Pre.isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"method_19321"}, at={@At(value="RETURN")})
    private void onSetupPost(World mc3, Entity mc2, boolean bl, boolean bl2, float f2, CallbackInfo callbackInfo) {
        Vec3d VanillaChestLootTableGenerator = this.getCameraPos();
        CameraEvent.Post cameraEvent$Post = CameraEvent.Post.get(VanillaChestLootTableGenerator.x, VanillaChestLootTableGenerator.y, VanillaChestLootTableGenerator.z, this.getYaw(), this.getPitch());
        Main.eventBus().post(cameraEvent$Post);
        if (cameraEvent$Post.isPosModified()) {
            this.setPos(cameraEvent$Post.x, cameraEvent$Post.y, cameraEvent$Post.z);
        }
        if (cameraEvent$Post.isRotationModified()) {
            this.setRotation(cameraEvent$Post.yaw, cameraEvent$Post.pitch);
        }
    }
}

