/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.entity.Entity;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.EntitySpawnEvent;
import itz.vrgn1337.groovclient.api.event.hooks.EntitySpawnEvent;

@Mixin(value={ClientWorld.class})
public class ClientLevelMixin {
    @Inject(method={"addEntity"}, at={@At(value="HEAD")})
    private void onEntitySpawnPre(Entity mc2, CallbackInfo callbackInfo) {
        Main.eventBus().post(EntitySpawnEvent.Pre.get(mc2));
    }

    @Inject(method={"method_53875"}, at={@At(value="RETURN")})
    private void onEntitySpawnPost(Entity mc2, CallbackInfo callbackInfo) {
        Main.eventBus().post(EntitySpawnEvent.Post.get(mc2));
    }
}

