/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin.compat.modmenu;

import java.util.List;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

public final class ModMenuMixinPlugin
implements IMixinConfigPlugin {
    private boolean modMenuPresent;

    public void onLoad(String string) {
        this.modMenuPresent = FabricLoader.getInstance().isModLoaded("modmenu");
    }

    public boolean shouldApplyMixin(String string, String string2) {
        return this.modMenuPresent;
    }

    public String getRefMapperConfig() {
        return null;
    }

    public void acceptTargets(Set set, Set set2) {
    }

    public List getMixins() {
        return null;
    }

    public void preApply(String string, ClassNode classNode, String string2, IMixinInfo iMixinInfo) {
    }

    public void postApply(String string, ClassNode classNode, String string2, IMixinInfo iMixinInfo) {
    }
}

