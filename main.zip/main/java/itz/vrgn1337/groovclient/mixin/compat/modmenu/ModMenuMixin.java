/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin.compat.modmenu;

import java.lang.reflect.Field;
import java.util.Map;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(targets={"com/terraformersmc/modmenu/ModMenu"}, remap=false)
public class ModMenuMixin {
    @Inject(method={"onInitializeClient"}, at={@At(value="RETURN")}, remap=false, require=0)
    private void groovclient$hideFromList(CallbackInfo callbackInfo) {
        try {
            Class<?> clazz = Class.forName("com.terraformersmc.modmenu.ModMenu");
            Field field = clazz.getField("MODS");
            Object object = field.get(null);
            if (object instanceof Map) {
                Map map = (Map)object;
                map.remove("groovclient");
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

