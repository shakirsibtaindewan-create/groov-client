/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.gui.hud.ChatMessageRenderer;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudConfigRegistry;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudElementSettings;
import itz.vrgn1337.groovclient.gui.hud.VanillaHudSection;
import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ChatHud.class})
public abstract class ChatComponentMixin {
    private List visibleMessages;

    @Inject(method={"render"}, at={@At(value="HEAD")}, cancellable=true)
    private void groov$customChatRender(DrawContext mc15, TextRenderer PackResourceMetadata, int n2, int n3, int n4, boolean bl, boolean bl2, CallbackInfo callbackInfo) {
        VanillaHudElementSettings vanillaHudElementSettings = VanillaHudConfigRegistry.getInstance().a(VanillaHudSection.CHAT);
        if (vanillaHudElementSettings == null || !vanillaHudElementSettings.n()) {
            return;
        }
        if (VanillaHudConfigRegistry.getInstance().d()) {
            return;
        }
        ChatMessageRenderer.a(mc15, (ChatHud)this, this.visibleMessages, PackResourceMetadata, n2, bl2, vanillaHudElementSettings);
        callbackInfo.cancel();
    }
}

