/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.world.World;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.ChangeWorldEvent;
import itz.vrgn1337.groovclient.api.event.hooks.ChangeWorldEvent;

@Mixin(value={ClientPlayNetworkHandler.class})
public class ClientPacketListenerMixin {
    @Inject(method={"onGameJoin"}, at={@At(value="HEAD")})
    private void onHandleLoginPre(GameJoinS2CPacket mc87, CallbackInfo callbackInfo) {
        Main.eventBus().post(ChangeWorldEvent.Pre.get(null));
    }

    @Inject(method={"method_11120"}, at={@At(value="RETURN")})
    private void onHandleLoginPost(GameJoinS2CPacket mc87, CallbackInfo callbackInfo) {
        ClientWorld NarrationMessageBuilder = MinecraftClient.getInstance().world;
        Main.eventBus().post(ChangeWorldEvent.Post.get((World)NarrationMessageBuilder));
    }

    @Inject(method={"method_11117"}, at={@At(value="HEAD")})
    private void onHandleRespawnPre(PlayerRespawnS2CPacket mc88, CallbackInfo callbackInfo) {
        Main.eventBus().post(ChangeWorldEvent.Pre.get((World)MinecraftClient.getInstance().world));
    }

    @Inject(method={"method_11117"}, at={@At(value="RETURN")})
    private void onHandleRespawnPost(PlayerRespawnS2CPacket mc88, CallbackInfo callbackInfo) {
        Main.eventBus().post(ChangeWorldEvent.Post.get((World)MinecraftClient.getInstance().world));
    }
}

