/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.ClickSlotEvent;
import itz.vrgn1337.groovclient.api.event.hooks.DestroyBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractEntityEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractItemEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RightClickEntityEvent;
import itz.vrgn1337.groovclient.api.event.hooks.BreakBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.ClickSlotEvent;
import itz.vrgn1337.groovclient.api.event.hooks.DestroyBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractBlockEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractEntityEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InteractItemEvent;
import itz.vrgn1337.groovclient.api.event.hooks.RightClickEntityEvent;

@Mixin(value={ClientPlayerInteractionManager.class})
public class MultiPlayerGameModeMixin {
    @Inject(method={"breakBlock"}, at={@At(value="HEAD")}, cancellable=true)
    private void onDestroyPre(BlockPos mc0, CallbackInfoReturnable callbackInfoReturnable) {
        if (((DestroyBlockEvent.Pre)Main.eventBus().post(DestroyBlockEvent.Pre.get(mc0))).isCancelled()) {
            callbackInfoReturnable.setReturnValue((Object)false);
        }
    }

    @Inject(method={"method_2899"}, at={@At(value="RETURN")})
    private void onDestroyPost(BlockPos mc0, CallbackInfoReturnable callbackInfoReturnable) {
        Main.eventBus().post(DestroyBlockEvent.Post.get(mc0));
    }

    @Inject(method={"method_2896"}, at={@At(value="HEAD")}, cancellable=true)
    private void onInteractBlockPre(ClientPlayerEntity mc59, Hand mc8, BlockHitResult mc7, CallbackInfoReturnable callbackInfoReturnable) {
        if (((InteractBlockEvent.Pre)Main.eventBus().post(InteractBlockEvent.Pre.get((PlayerEntity)mc59, mc7))).isCancelled()) {
            callbackInfoReturnable.setReturnValue((Object)ActionResult.PASS);
        }
    }

    @Inject(method={"interactBlock"}, at={@At(value="RETURN")})
    private void onInteractBlockPost(ClientPlayerEntity mc59, Hand mc8, BlockHitResult mc7, CallbackInfoReturnable callbackInfoReturnable) {
        Main.eventBus().post(InteractBlockEvent.Post.get((PlayerEntity)mc59, mc7));
    }

    @Inject(method={"method_2905"}, at={@At(value="HEAD")}, cancellable=true)
    private void onInteractEntityPre(PlayerEntity mc6, Entity mc2, Hand mc8, CallbackInfoReturnable callbackInfoReturnable) {
        if (((InteractEntityEvent.Pre)Main.eventBus().post(InteractEntityEvent.Pre.get(mc6))).isCancelled()) {
            callbackInfoReturnable.cancel();
        }
    }

    @Inject(method={"method_2905"}, at={@At(value="RETURN")})
    private void onInteractEntityPost(PlayerEntity mc6, Entity mc2, Hand mc8, CallbackInfoReturnable callbackInfoReturnable) {
        Main.eventBus().post(InteractEntityEvent.Post.get(mc6));
    }

    @Inject(method={"method_2919"}, at={@At(value="HEAD")}, cancellable=true)
    private void onUseItemPre(PlayerEntity mc6, Hand mc8, CallbackInfoReturnable callbackInfoReturnable) {
        if (((InteractItemEvent.Pre)Main.eventBus().post(InteractItemEvent.Pre.get(mc6, mc8))).isCancelled()) {
            callbackInfoReturnable.cancel();
        }
    }

    @Inject(method={"method_2919"}, at={@At(value="RETURN")})
    private void onUseItemPost(PlayerEntity mc6, Hand mc8, CallbackInfoReturnable callbackInfoReturnable) {
        Main.eventBus().post(InteractItemEvent.Post.get(mc6, mc8));
    }

    @Inject(method={"method_2906"}, at={@At(value="HEAD")}, cancellable=true)
    private void onClickSlotPre(int n2, int n3, int n4, SlotActionType mc5, PlayerEntity mc6, CallbackInfo callbackInfo) {
        if (((ClickSlotEvent.Pre)Main.eventBus().post(ClickSlotEvent.Pre.get(n3, n4, mc5))).isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"method_2906"}, at={@At(value="RETURN")})
    private void onClickSlotPost(int n2, int n3, int n4, SlotActionType mc5, PlayerEntity mc6, CallbackInfo callbackInfo) {
        Main.eventBus().post(ClickSlotEvent.Post.get(n3, n4, mc5));
    }

    @Inject(method={"method_2910"}, at={@At(value="HEAD")}, cancellable=true)
    private void onStartDestroyPre(BlockPos mc0, Direction mc63, CallbackInfoReturnable callbackInfoReturnable) {
        if (((BreakBlockEvent.Pre)Main.eventBus().post(BreakBlockEvent.Pre.getInstance())).isCancelled()) {
            callbackInfoReturnable.setReturnValue((Object)false);
        }
    }

    @Inject(method={"method_2910"}, at={@At(value="RETURN")})
    private void onStartDestroyPost(BlockPos mc0, Direction mc63, CallbackInfoReturnable callbackInfoReturnable) {
        Main.eventBus().post(BreakBlockEvent.Post.getInstance());
    }

    @Inject(method={"method_2917"}, at={@At(value="HEAD")}, cancellable=true)
    private void onInteractAtPre(PlayerEntity mc6, Entity mc2, EntityHitResult mc26, Hand mc8, CallbackInfoReturnable callbackInfoReturnable) {
        if (((RightClickEntityEvent.Pre)Main.eventBus().post(RightClickEntityEvent.Pre.get(mc6, mc2, mc8))).isCancelled()) {
            callbackInfoReturnable.cancel();
        }
    }

    @Inject(method={"method_2917"}, at={@At(value="RETURN")})
    private void onInteractAtPost(PlayerEntity mc6, Entity mc2, EntityHitResult mc26, Hand mc8, CallbackInfoReturnable callbackInfoReturnable) {
        Main.eventBus().post(RightClickEntityEvent.Post.get(mc6, mc2, mc8));
    }
}

