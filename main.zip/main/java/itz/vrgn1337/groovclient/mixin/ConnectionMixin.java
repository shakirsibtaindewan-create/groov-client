/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import io.netty.channel.ChannelHandlerContext;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketSendEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketReceiveEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PacketSendEvent;

@Mixin(value={ClientConnection.class})
public class ConnectionMixin {
    @Inject(method={"send(Lnet/minecraft/Packet;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void onSendPre(Packet mc14, CallbackInfo callbackInfo) {
        if (((PacketSendEvent.Pre)Main.eventBus().post(PacketSendEvent.Pre.get(mc14))).isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"method_10743(Lnet/minecraft/Packet;)V"}, at={@At(value="RETURN")})
    private void onSendPost(Packet mc14, CallbackInfo callbackInfo) {
        Main.eventBus().post(PacketSendEvent.Post.get(mc14));
    }

    @Inject(method={"method_10770(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/Packet;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void onReceivePre(ChannelHandlerContext channelHandlerContext, Packet mc14, CallbackInfo callbackInfo) {
        if (((PacketReceiveEvent.Pre)Main.eventBus().post(PacketReceiveEvent.Pre.get(mc14))).isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"method_10770(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/Packet;)V"}, at={@At(value="RETURN")})
    private void onReceivePost(ChannelHandlerContext channelHandlerContext, Packet mc14, CallbackInfo callbackInfo) {
        Main.eventBus().post(PacketReceiveEvent.Post.get(mc14));
    }
}

