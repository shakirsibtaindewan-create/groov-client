/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.util.bridge.EntityShaderBridge;
import itz.vrgn1337.groovclient.api.util.bridge.ViewModelBridge;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.util.Hand;
import net.minecraft.util.Arm;
import net.minecraft.item.ItemStack;
import net.minecraft.item.consume.UseAction;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={HeldItemRenderer.class})
public abstract class ItemInHandRendererMixin {
    private static final ThreadLocal groovclient$wrapped = ThreadLocal.withInitial(ItemInHandRendererMixin::lambda$static$0);

    @ModifyVariable(method={"renderFirstPersonItem"}, at=@At(value="HEAD"), ordinal=0, argsOnly=true)
    private OrderedRenderCommandQueue groovclient$wrapCollector(OrderedRenderCommandQueue mc11) {
        OrderedRenderCommandQueue mc89 = EntityShaderBridge.tryWrapHeldItemCollector(mc11);
        groovclient$wrapped.set(mc89 != mc11);
        return mc89;
    }

    @Inject(method={"method_3228"}, at={@At(value="RETURN")})
    private void groovclient$onRenderReturn(CallbackInfo callbackInfo) {
        if (((Boolean)groovclient$wrapped.get()).booleanValue()) {
            EntityShaderBridge.onRenderComplete();
            groovclient$wrapped.set(false);
        }
    }

    @Inject(method={"method_3228"}, at={@At(value="HEAD")})
    private void groovclient$applyViewModel(AbstractClientPlayerEntity TrackedPosition, float f2, float f3, Hand mc8, float f4, ItemStack mc33, float f5, MatrixStack mc13, OrderedRenderCommandQueue mc11, int n2, CallbackInfo callbackInfo) {
        ViewModelBridge.applyTransform(mc13, mc8);
    }

    @ModifyVariable(method={"method_3228"}, at=@At(value="HEAD"), ordinal=3, argsOnly=true)
    private float groovclient$modifyEquipProgress(float f2) {
        return ViewModelBridge.oldBlockSwing ? 0.0f : f2;
    }

    @Redirect(method={"method_3228"}, at=@At(value="INVOKE", target="Lnet/minecraft/ItemStack;method_7976()Lnet/minecraft/UseAction;", ordinal=0))
    private UseAction groovclient$hookUseAnimation(ItemStack mc33) {
        if (ViewModelBridge.swordBlock && mc33.isIn(ItemTags.SWORDS)) {
            return UseAction.BLOCK;
        }
        return mc33.getUseAction();
    }

    @Redirect(method={"method_3228"}, at=@At(value="INVOKE", target="Lnet/minecraft/AbstractClientPlayerEntity;isUsingItem()Z", ordinal=1))
    private boolean groovclient$hookIsUsingItem(AbstractClientPlayerEntity TrackedPosition) {
        if (ViewModelBridge.swordBlock) {
            return true;
        }
        return TrackedPosition.isUsingItem();
    }

    @Redirect(method={"renderFirstPersonItem"}, at=@At(value="INVOKE", target="Lnet/minecraft/AbstractClientPlayerEntity;method_6058()Lnet/minecraft/Hand;", ordinal=1))
    private Hand groovclient$hookActiveHand(AbstractClientPlayerEntity TrackedPosition) {
        if (ViewModelBridge.swordBlock) {
            return Hand.MAIN_HAND;
        }
        return TrackedPosition.getActiveHand();
    }

    @Redirect(method={"renderFirstPersonItem"}, at=@At(value="INVOKE", target="Lnet/minecraft/AbstractClientPlayerEntity;method_6014()I", ordinal=2))
    private int groovclient$hookUseItemRemainingTicks(AbstractClientPlayerEntity TrackedPosition) {
        if (ViewModelBridge.swordBlock) {
            return 7200;
        }
        return TrackedPosition.getItemUseTimeLeft();
    }

    @Inject(method={"renderFirstPersonItem"}, slice={@Slice(from=@At(value="INVOKE", target="Lnet/minecraft/ItemStack;method_7976()Lnet/minecraft/UseAction;"))}, at={@At(value="INVOKE", target="Lnet/minecraft/HeldItemRenderer;method_3224(Lnet/minecraft/MatrixStack;Lnet/minecraft/Arm;F)V", ordinal=0, shift=At.Shift.AFTER)})
    private void groovclient$blockAnimation(AbstractClientPlayerEntity TrackedPosition, float f2, float f3, Hand mc8, float f4, ItemStack mc33, float f5, MatrixStack mc13, OrderedRenderCommandQueue mc11, int n2, CallbackInfo callbackInfo) {
        if (!ViewModelBridge.swordBlock || !mc33.isIn(ItemTags.SWORDS)) {
            return;
        }
        Arm mc91 = mc8 == Hand.MAIN_HAND ? TrackedPosition.getMainArm() : TrackedPosition.getMainArm().getOpposite();
        ItemInHandRendererMixin.groovclient$applyOneSevenBlock(mc13, mc91, f4);
    }

    @Unique
    private static void groovclient$applyOneSevenBlock(MatrixStack mc13, Arm mc91, float f2) {
        int n2 = mc91 == Arm.RIGHT ? 1 : -1;
        mc13.translate((float)n2 * -0.1f, 0.1f, 0.0f);
        float f3 = MathHelper.sin((double)(f2 * f2 * (float)Math.PI));
        mc13.multiply((Quaternionfc)RotationAxis.POSITIVE_Y.rotationDegrees((float)n2 * (45.0f + f3 * -20.0f)));
        float f4 = MathHelper.sin((double)((float)Math.sqrt(f2) * (float)Math.PI));
        mc13.multiply((Quaternionfc)RotationAxis.POSITIVE_Z.rotationDegrees((float)n2 * f4 * -20.0f));
        mc13.multiply((Quaternionfc)RotationAxis.POSITIVE_X.rotationDegrees(f4 * -80.0f));
        mc13.multiply((Quaternionfc)RotationAxis.POSITIVE_Y.rotationDegrees((float)n2 * -45.0f));
    }

    private static Boolean lambda$static$0() {
        return false;
    }
}

