/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.KeybindEvent;
import itz.vrgn1337.groovclient.api.event.hooks.KeybindEvent;

@Mixin(value={KeyBinding.class})
public class KeyMappingMixin {
    @Inject(method={"onKeyPressed"}, at={@At(value="HEAD")})
    private static void onKeybindClick(InputUtil.Key FunctionCommand, CallbackInfo callbackInfo) {
        Main.eventBus().post(KeybindEvent.Pre.get(FunctionCommand.getCode()));
    }

    @Inject(method={"method_1420"}, at={@At(value="RETURN")})
    private static void onKeybindClickPost(InputUtil.Key FunctionCommand, CallbackInfo callbackInfo) {
        Main.eventBus().post(KeybindEvent.Post.get(FunctionCommand.getCode()));
    }
}

