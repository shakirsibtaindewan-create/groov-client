/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.PlayerJumpEvent;
import itz.vrgn1337.groovclient.api.event.hooks.TravelEvent;
import itz.vrgn1337.groovclient.api.event.hooks.VelocityEvent;
import itz.vrgn1337.groovclient.api.event.hooks.PlayerJumpEvent;
import itz.vrgn1337.groovclient.api.event.hooks.TravelEvent;
import itz.vrgn1337.groovclient.api.event.hooks.VelocityEvent;

@Mixin(value={LivingEntity.class})
public class LivingEntityMixin {
    @Inject(method={"travel"}, at={@At(value="HEAD")}, cancellable=true)
    private void onTravelPre(Vec3d VanillaChestLootTableGenerator, CallbackInfo callbackInfo) {
        if (!(this instanceof ClientPlayerEntity)) {
            return;
        }
        if (((TravelEvent.Pre)Main.eventBus().post(TravelEvent.Pre.getInstance())).isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"method_6091"}, at={@At(value="RETURN")})
    private void onTravelPost(Vec3d VanillaChestLootTableGenerator, CallbackInfo callbackInfo) {
        if (!(this instanceof ClientPlayerEntity)) {
            return;
        }
        Main.eventBus().post(TravelEvent.Post.getInstance());
    }

    @Inject(method={"method_6043"}, at={@At(value="HEAD")}, cancellable=true)
    private void onJumpPre(CallbackInfo callbackInfo) {
        if (!(this instanceof ClientPlayerEntity)) {
            return;
        }
        if (((PlayerJumpEvent.Pre)Main.eventBus().post(PlayerJumpEvent.Pre.getInstance())).isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"method_6043"}, at={@At(value="RETURN")})
    private void onJumpPost(CallbackInfo callbackInfo) {
        if (!(this instanceof ClientPlayerEntity)) {
            return;
        }
        Main.eventBus().post(PlayerJumpEvent.Post.getInstance());
    }

    @Inject(method={"method_6005"}, at={@At(value="HEAD")}, cancellable=true)
    private void onKnockbackPre(double d2, double d3, double d4, CallbackInfo callbackInfo) {
        if (!(this instanceof ClientPlayerEntity)) {
            return;
        }
        Vec3d VanillaChestLootTableGenerator = ((LivingEntity)this).getVelocity();
        if (((VelocityEvent.Pre)Main.eventBus().post(VelocityEvent.Pre.get(d3, VanillaChestLootTableGenerator.y, d4, (float)d2, VanillaChestLootTableGenerator))).isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"method_6005"}, at={@At(value="RETURN")})
    private void onKnockbackPost(double d2, double d3, double d4, CallbackInfo callbackInfo) {
        if (!(this instanceof ClientPlayerEntity)) {
            return;
        }
        Vec3d VanillaChestLootTableGenerator = ((LivingEntity)this).getVelocity();
        Main.eventBus().post(VelocityEvent.Post.get(d3, VanillaChestLootTableGenerator.y, d4, (float)d2, VanillaChestLootTableGenerator));
    }

    @Redirect(method={"method_6043"}, at=@At(value="NEW", target="Lnet/minecraft/Vec3d;"), require=0)
    private Vec3d groovclient$jumpVec(double d2, double d3, double d4) {
        if (!this.isLocalPlayerActive()) {
            return new Vec3d(d2, d3, d4);
        }
        float f2 = RotationManager.getInstance().k() * ((float)Math.PI / 180);
        return new Vec3d((double)(-MathHelper.sin((double)f2) * 0.2f), 0.0, (double)(MathHelper.cos((double)f2) * 0.2f));
    }

    @Redirect(method={"calcGlidingVelocity", "method_61430"}, at=@At(value="INVOKE", target="Lnet/minecraft/LivingEntity;getPitch()F"), require=0)
    private float groovclient$calcGlidePitchLiving(LivingEntity mc58) {
        if (mc58 != this || !this.isLocalPlayerActive()) {
            return mc58.getPitch();
        }
        return RotationManager.getInstance().l();
    }

    @Redirect(method={"calcGlidingVelocity", "method_61430"}, at=@At(value="INVOKE", target="Lnet/minecraft/Entity;method_36455()F"), require=0)
    private float groovclient$calcGlidePitchEntity(Entity mc2) {
        if (mc2 != this || !this.isLocalPlayerActive()) {
            return mc2.getPitch();
        }
        return RotationManager.getInstance().l();
    }

    @Redirect(method={"calcGlidingVelocity", "method_61430"}, at=@At(value="INVOKE", target="Lnet/minecraft/Entity;method_5720()Lnet/minecraft/Vec3d;"), require=0)
    private Vec3d groovclient$calcGlideLookAngle(Entity mc2) {
        if (mc2 != this || !this.isLocalPlayerActive()) {
            return mc2.getRotationVector();
        }
        return Vec3d.fromPolar((float)RotationManager.getInstance().l(), (float)RotationManager.getInstance().l());
    }

    @Redirect(method={"method_5773"}, at=@At(value="INVOKE", target="Lnet/minecraft/LivingEntity;method_36454()F"), require=0)
    private float groovclient$bodyYawTickLiving(LivingEntity mc58) {
        if (mc58 != this || !this.isLocalPlayerActive()) {
            return mc58.getYaw();
        }
        return RotationManager.getInstance().k();
    }

    @Redirect(method={"method_5773"}, at=@At(value="INVOKE", target="Lnet/minecraft/Entity;method_36454()F"), require=0)
    private float groovclient$bodyYawTickEntity(Entity mc2) {
        if (mc2 != this || !this.isLocalPlayerActive()) {
            return mc2.getYaw();
        }
        return RotationManager.getInstance().k();
    }

    @Redirect(method={"turnHead"}, at=@At(value="INVOKE", target="Lnet/minecraft/LivingEntity;method_36454()F"), require=0)
    private float groovclient$bodyYawTurnHeadLiving(LivingEntity mc58) {
        if (mc58 != this || !this.isLocalPlayerActive()) {
            return mc58.getYaw();
        }
        return RotationManager.getInstance().k();
    }

    @Redirect(method={"turnHead"}, at=@At(value="INVOKE", target="Lnet/minecraft/Entity;method_36454()F"), require=0)
    private float groovclient$bodyYawTurnHeadEntity(Entity mc2) {
        if (mc2 != this || !this.isLocalPlayerActive()) {
            return mc2.getYaw();
        }
        return RotationManager.getInstance().k();
    }

    @Unique
    private boolean isLocalPlayerActive() {
        return this == Main.mc.player && RotationManager.getInstance().d();
    }
}

