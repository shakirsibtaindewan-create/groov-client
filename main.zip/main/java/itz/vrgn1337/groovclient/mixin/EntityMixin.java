/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={Entity.class})
public class EntityMixin {
    @Shadow
    protected static Vec3d movementInputToVelocity(Vec3d VanillaChestLootTableGenerator, float f2, float f3) {
        return null;
    }

    @Redirect(method={"updateVelocity"}, at=@At(value="INVOKE", target="Lnet/minecraft/Entity;method_18795(Lnet/minecraft/Vec3d;FF)Lnet/minecraft/Vec3d;"), require=0)
    private Vec3d groovclient$moveRelativeSilentYaw(Vec3d VanillaChestLootTableGenerator, float f2, float f3) {
        float f4 = f3;
        if (this == Main.mc.player && RotationManager.getInstance().d()) {
            f4 = RotationManager.getInstance().k();
        }
        return EntityMixin.movementInputToVelocity(VanillaChestLootTableGenerator, f2, f4);
    }

    @Inject(method={"method_5720", "method_5802"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void groovclient$getSilentRotationVector(CallbackInfoReturnable callbackInfoReturnable) {
        if (this != Main.mc.player || !RotationManager.getInstance().d()) {
            return;
        }
        callbackInfoReturnable.setReturnValue((Object)Vec3d.fromPolar((float)RotationManager.getInstance().l(), (float)RotationManager.getInstance().k()));
    }
}

