/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.util.BindManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.mixin.accessor.GameRendererAccessor;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.ItemUseEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;
import itz.vrgn1337.groovclient.api.event.hooks.AttackEvent;
import itz.vrgn1337.groovclient.api.event.hooks.ItemUseEvent;
import itz.vrgn1337.groovclient.api.event.hooks.UpdateEvent;

@Mixin(value={MinecraftClient.class})
public class MinecraftMixin {
    private boolean groovclient$attackBypassing;

    @Inject(method={"tick"}, at={@At(value="HEAD")})
    private void onTickPre(CallbackInfo callbackInfo) {
        this.groovclient$refreshServerRotationHitResult();
        Main.eventBus().post(UpdateEvent.Pre.getInstance());
    }

    @Inject(method={"method_1574"}, at={@At(value="RETURN")})
    private void onTickPost(CallbackInfo callbackInfo) {
        Main.eventBus().post(UpdateEvent.Post.getInstance());
    }

    @Inject(method={"method_1536"}, at={@At(value="HEAD")}, cancellable=true)
    private void onAttackPre(CallbackInfoReturnable callbackInfoReturnable) {
        this.groovclient$attackBypassing = false;
        this.groovclient$refreshServerRotationHitResult();
        if (!BindManager.c()) {
            callbackInfoReturnable.setReturnValue((Object)false);
            return;
        }
        BindManager.j();
        this.groovclient$attackBypassing = true;
        if (((AttackEvent.Pre)Main.eventBus().post(AttackEvent.Pre.getInstance())).isCancelled()) {
            callbackInfoReturnable.setReturnValue((Object)false);
        }
    }

    @Inject(method={"method_1536"}, at={@At(value="RETURN")})
    private void onAttackPost(CallbackInfoReturnable callbackInfoReturnable) {
        if (this.groovclient$attackBypassing) {
            BindManager.k();
            this.groovclient$attackBypassing = false;
        }
        Main.eventBus().post(AttackEvent.Post.getInstance());
    }

    @Inject(method={"method_1583"}, at={@At(value="HEAD")}, cancellable=true)
    private void onItemUsePre(CallbackInfo callbackInfo) {
        this.groovclient$refreshServerRotationHitResult();
        if (!BindManager.c()) {
            callbackInfo.cancel();
            return;
        }
        if (((ItemUseEvent.Pre)Main.eventBus().post(ItemUseEvent.Pre.getInstance())).isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"method_1583"}, at={@At(value="RETURN")})
    private void onItemUsePost(CallbackInfo callbackInfo) {
        Main.eventBus().post(ItemUseEvent.Post.getInstance());
    }

    private void groovclient$refreshServerRotationHitResult() {
        if (Main.mc == null || Main.mc.player == null || Main.mc.gameRenderer == null) {
            return;
        }
        if (!RotationManager.getInstance().d()) {
            return;
        }
        float f2 = Main.mc.player.getYaw();
        float f3 = Main.mc.player.getPitch();
        Main.mc.player.setYaw(RotationManager.getInstance().k());
        Main.mc.player.setPitch(RotationManager.getInstance().l());
        try {
            ((GameRendererAccessor)Main.mc.gameRenderer).invokePick(1.0f);
        }
        finally {
            Main.mc.player.setYaw(f2);
            Main.mc.player.setPitch(f3);
        }
    }
}

