/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.event.hooks.KeyEvent;
import itz.vrgn1337.groovclient.entrypoint.Main;
import itz.vrgn1337.groovclient.module.Module;
import itz.vrgn1337.groovclient.module.ModuleManager;
import itz.vrgn1337.groovclient.setting.KeybindSetting;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.InputEvent;
import itz.vrgn1337.groovclient.api.event.hooks.InputEvent;

@Mixin(value={Keyboard.class})
public class KeyboardHandlerMixin {
    @Inject(method={"onKey"}, at={@At(value="HEAD")})
    private void onKeyPress(long l2, int n2, KeyInput mc27, CallbackInfo callbackInfo) {
        int n3 = mc27.key();
        Main.eventBus().post(KeyEvent.get(l2, n3, mc27.scancode(), n2, mc27.modifiers()));
        if (n2 == 1) {
            Main.eventBus().post(InputEvent.Press.get(l2, n3, false));
            if (Main.mc.currentScreen == null) {
                int n4 = mc27.scancode();
                int n5 = KeybindSetting.reset(n4);
                for (Module module : ModuleManager.c()) {
                    int n6 = module.getKeybind().d();
                    if (n6 == -1 || n6 != n3 && n6 != n5) continue;
                    module.toggleWithHud();
                }
            }
        } else if (n2 == 0) {
            Main.eventBus().post(InputEvent.Release.get(l2, n3, false));
        }
        Main.eventBus().post(InputEvent.CancellableInput.get(l2, n3, n2));
    }
}

