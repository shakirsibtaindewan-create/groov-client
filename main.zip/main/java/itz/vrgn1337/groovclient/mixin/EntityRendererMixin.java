/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.module.visual.Nametags;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.render.entity.EntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={EntityRenderer.class})
public abstract class EntityRendererMixin {
    @Inject(method={"hasLabel"}, at={@At(value="HEAD")}, cancellable=true)
    private void onShouldShowName(Entity mc2, double d2, CallbackInfoReturnable callbackInfoReturnable) {
        PlayerEntity mc6;
        if (mc2 instanceof PlayerEntity && Nametags.onRenderHUDEventPost(mc6 = (PlayerEntity)mc2)) {
            callbackInfoReturnable.cancel();
        }
    }
}

