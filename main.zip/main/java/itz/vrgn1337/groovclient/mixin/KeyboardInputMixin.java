/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationMode;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import itz.vrgn1337.groovclient.api.event.hooks.KeyboardInputEvent;
import itz.vrgn1337.groovclient.api.event.hooks.KeyboardInputEvent;

@Mixin(value={KeyboardInput.class})
public class KeyboardInputMixin {
    private static volatile boolean shouldSkipByAA = false;

    @Redirect(method={"tick"}, at=@At(value="NEW", target="Lnet/minecraft/PlayerInput;"), require=0)
    private PlayerInput groovclient$modifyTickInput(boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5, boolean bl6, boolean bl7) {
        PlayerInput mc9;
        PlayerInput mc92 = new PlayerInput(bl, bl2, bl3, bl4, bl5, bl6, bl7);
        KeyboardInputEvent.Pre keyboardInputEvent$Pre = KeyboardInputEvent.Pre.get(mc92);
        Main.eventBus().post(keyboardInputEvent$Pre);
        PlayerInput mc93 = mc9 = keyboardInputEvent$Pre.input == null ? mc92 : keyboardInputEvent$Pre.input;
        if (Main.mc.player == null) {
            return mc9;
        }
        if (!RotationUtils.a()) {
            return mc9;
        }
        if (shouldSkipByAA) {
            return mc9;
        }
        if (RotationManager.b != RotationMode.PROPER) {
            return mc9;
        }
        float f2 = this.multiplier(mc9.forward(), mc9.backward());
        float f3 = this.multiplier(mc9.left(), mc9.right());
        if (f2 == 0.0f && f3 == 0.0f) {
            return mc9;
        }
        float f4 = MathHelper.wrapDegrees((float)(Main.mc.player.getYaw() - RotationManager.p()));
        float f5 = f4 * ((float)Math.PI / 180);
        float f6 = MathHelper.cos((double)f5);
        float f7 = MathHelper.sin((double)f5);
        float f8 = f3 * f6 - f2 * f7;
        float f9 = f2 * f6 + f3 * f7;
        int n2 = Math.round(f9);
        int n3 = Math.round(f8);
        boolean bl8 = n2 > 0;
        boolean bl9 = n2 < 0;
        bl3 = n3 > 0;
        bl4 = n3 < 0;
        return new PlayerInput(bl8, bl9, bl3, bl4, mc9.jump(), mc9.sneak(), mc9.sprint() && bl8);
    }

    @Inject(method={"method_3129"}, at={@At(value="RETURN")})
    private void onTickPost(CallbackInfo callbackInfo) {
        Main.eventBus().post(KeyboardInputEvent.Post.getInstance());
    }

    private float multiplier(boolean bl, boolean bl2) {
        if (bl == bl2) {
            return 0.0f;
        }
        return bl ? 1.0f : -1.0f;
    }
}

