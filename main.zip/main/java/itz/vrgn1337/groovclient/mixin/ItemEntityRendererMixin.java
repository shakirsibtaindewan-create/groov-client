/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.util.bridge.EntityShaderBridge;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ItemEntityRenderer.class})
public abstract class ItemEntityRendererMixin {
    private static final ThreadLocal groovclient$wrapping = ThreadLocal.withInitial(ItemEntityRendererMixin::lambda$static$0);

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Inject(method={"render"}, at={@At(value="HEAD")}, cancellable=true)
    private void onItemEntityRender(ItemEntityRenderState mc90, MatrixStack mc13, OrderedRenderCommandQueue mc11, CameraRenderState mc46, CallbackInfo callbackInfo) {
        if (((Boolean)groovclient$wrapping.get()).booleanValue()) {
            return;
        }
        OrderedRenderCommandQueue mc89 = EntityShaderBridge.tryWrapItemCollector(mc11);
        if (mc89 != mc11) {
            groovclient$wrapping.set(true);
            try {
                ((ItemEntityRenderer)this).render(mc90, mc13, mc89, mc46);
            }
            finally {
                groovclient$wrapping.set(false);
                EntityShaderBridge.onRenderComplete();
            }
            callbackInfo.cancel();
        }
    }

    private static Boolean lambda$static$0() {
        return false;
    }
}

