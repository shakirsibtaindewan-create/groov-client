/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import itz.vrgn1337.groovclient.api.util.BindManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationManager;
import itz.vrgn1337.groovclient.api.util.rotation.RotationUtils;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={PlayerEntity.class})
public class PlayerMixin {
    @Inject(method={"attack"}, at={@At(value="HEAD")}, cancellable=true)
    private void onAttackPre(Entity mc2, CallbackInfo callbackInfo) {
        if (this != Main.mc.player) {
            return;
        }
        if (!BindManager.c()) {
            callbackInfo.cancel();
        }
    }

    @ModifyExpressionValue(method={"method_75122", "method_7263"}, at={@At(value="INVOKE", target="Lnet/minecraft/PlayerEntity;method_36454()F")})
    private float causeExtraKnockback(float f2) {
        if (this != Main.mc.player) {
            return f2;
        }
        if (!RotationUtils.a()) {
            return f2;
        }
        return RotationManager.getInstance().k();
    }

    @ModifyExpressionValue(method={"method_6007"}, at={@At(value="INVOKE", target="Lnet/minecraft/PlayerEntity;method_36454()F")}, require=0)
    private float groovclient$playerTickYaw(float f2) {
        return this.resolveSilentYaw();
    }

    @ModifyExpressionValue(method={"method_7324"}, at={@At(value="INVOKE", target="Lnet/minecraft/PlayerEntity;method_36454()F")}, require=0)
    private float groovclient$attackYaw(float f2) {
        return this.resolveSilentYaw();
    }

    @Unique
    private float resolveSilentYaw() {
        if (Main.mc.player != this || !RotationManager.getInstance().d()) {
            return Main.mc.player.getYaw();
        }
        return RotationManager.getInstance().k();
    }
}

