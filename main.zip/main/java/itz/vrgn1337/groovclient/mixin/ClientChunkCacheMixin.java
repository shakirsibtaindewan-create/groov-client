/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.entrypoint.Main;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.client.world.ClientChunkManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import itz.vrgn1337.groovclient.api.event.hooks.ChunkEvent;
import itz.vrgn1337.groovclient.api.event.hooks.ChunkEvent;

@Mixin(value={ClientChunkManager.class})
public class ClientChunkCacheMixin {
    @Inject(method={"loadChunkFromPacket"}, at={@At(value="RETURN")})
    private void onChunkLoad(int n2, int n3, PacketByteBuf mc86, Map map, Consumer consumer, CallbackInfoReturnable callbackInfoReturnable) {
        Main.eventBus().post(ChunkEvent.Post.get(new ChunkPos(n2, n3)));
    }

    @Inject(method={"method_2859"}, at={@At(value="HEAD")})
    private void onChunkUnload(ChunkPos mc4, CallbackInfo callbackInfo) {
        Main.eventBus().post(ChunkEvent.Pre.get(mc4));
    }
}

