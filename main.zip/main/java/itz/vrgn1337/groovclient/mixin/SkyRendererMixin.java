/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.mixin;

import itz.vrgn1337.groovclient.api.event.hooks.RenderSkyEvent;
import itz.vrgn1337.groovclient.entrypoint.Main;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={SkyRendering.class})
public class SkyRendererMixin {
    @Inject(method={"renderTopSky"}, at={@At(value="RETURN")})
    private void groovclient$onRenderSkyDiscPost(int n2, CallbackInfo callbackInfo) {
        Main.eventBus().post(RenderSkyEvent.getInstance());
    }
}

