/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.social;

import java.util.UUID;

public final class Friend {
    private String a;
    private UUID b;

    public Friend(String string, UUID uUID) {
        this.a = string == null ? "" : string;
        this.b = uUID;
    }

    public String a() {
        return this.a;
    }

    public UUID b() {
        return this.b;
    }

    public void a(String string) {
        this.a = string == null ? "" : string;
    }

    public void a(UUID uUID) {
        this.b = uUID;
    }
}

