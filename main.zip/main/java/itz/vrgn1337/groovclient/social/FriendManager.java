/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.social;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import itz.vrgn1337.groovclient.config.ClientSettings;
import itz.vrgn1337.groovclient.social.Friend;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.entity.player.PlayerEntity;

public final class FriendManager {
    private static final FriendManager a = new FriendManager();
    private final CopyOnWriteArrayList<Friend> b = new CopyOnWriteArrayList();

    public static FriendManager getInstance() {
        return a;
    }

    private FriendManager() {
    }

    public List b() {
        return Collections.unmodifiableList(this.b);
    }

    public boolean a(String string, UUID uUID) {
        Friend friend;
        String string2 = FriendManager.c(string);
        if (string2.isEmpty() && uUID == null) {
            return false;
        }
        Friend friend2 = uUID == null ? null : this.b(uUID);
        Friend friend3 = string2.isEmpty() ? null : this.b(string2);
        Friend friend4 = friend = friend2 != null ? friend2 : friend3;
        if (friend == null) {
            this.b.add(new Friend(string2, uUID));
            ClientSettings.getInstance().n();
            return true;
        }
        boolean bl = false;
        if (uUID != null && !uUID.equals(friend.b())) {
            friend.a(uUID);
            bl = true;
        }
        if (!string2.isEmpty() && !string2.equals(friend.a())) {
            friend.a(string2);
            bl = true;
        }
        if (bl) {
            ClientSettings.getInstance().n();
        }
        return bl;
    }

    public boolean a(UUID uUID) {
        if (uUID == null) {
            return false;
        }
        boolean bl = this.b.removeIf(arg_0 -> b.lambda$removeByUuid$0((UUID)uUID, arg_0));
        if (bl) {
            ClientSettings.getInstance().n();
        }
        return bl;
    }

    public boolean a(String string) {
        String string2 = FriendManager.c(string);
        if (string2.isEmpty()) {
            return false;
        }
        boolean bl = this.b.removeIf(arg_0 -> b.lambda$removeByName$1((String)string2, arg_0));
        if (bl) {
            ClientSettings.getInstance().n();
        }
        return bl;
    }

    public void a(boolean bl) {
        this.b.clear();
        if (bl) {
            ClientSettings.getInstance().n();
        }
    }

    public boolean a(PlayerEntity mc6) {
        if (mc6 == null) {
            return false;
        }
        UUID uUID = mc6.getUuid();
        if (uUID != null && this.b(uUID) != null) {
            return true;
        }
        String string = mc6.getName().getString();
        return !string.isBlank() && this.b(string) != null;
    }

    public boolean a(UUID uUID, String string) {
        if (uUID != null && this.b(uUID) != null) {
            return true;
        }
        return this.b(string) != null;
    }

    public Friend b(UUID uUID) {
        if (uUID == null) {
            return null;
        }
        for (Friend friend : this.b) {
            if (!uUID.equals(friend.b())) continue;
            return friend;
        }
        return null;
    }

    public Friend b(String string) {
        String string2 = FriendManager.c(string);
        if (string2.isEmpty()) {
            return null;
        }
        for (Friend friend : this.b) {
            if (!string2.equalsIgnoreCase(friend.a())) continue;
            return friend;
        }
        return null;
    }

    public JsonArray c() {
        JsonArray jsonArray = new JsonArray();
        for (Friend friend : this.b) {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("name", friend.a());
            if (friend.b() != null) {
                jsonObject.addProperty("uuid", friend.b().toString());
            }
            jsonArray.add((JsonElement)jsonObject);
        }
        return jsonArray;
    }

    public void a(JsonArray jsonArray) {
        this.b.clear();
        if (jsonArray == null) {
            return;
        }
        for (JsonElement jsonElement : jsonArray) {
            if (!jsonElement.isJsonObject()) continue;
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            String string = jsonObject.has("name") ? FriendManager.c(jsonObject.get("name").getAsString()) : "";
            UUID uUID = null;
            if (jsonObject.has("uuid")) {
                try {
                    uUID = UUID.fromString(jsonObject.get("uuid").getAsString());
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            if (string.isEmpty() && uUID == null || uUID != null && this.b(uUID) != null || !string.isEmpty() && this.b(string) != null) continue;
            this.b.add(new Friend(string, uUID));
        }
    }

    private static String c(String string) {
        if (string == null) {
            return "";
        }
        return string.trim();
    }

    private static boolean lambda$removeByName$1(String string, Friend friend) {
        return string.equalsIgnoreCase(friend.a());
    }

    private static boolean lambda$removeByUuid$0(UUID uUID, Friend friend) {
        return uUID.equals(friend.b());
    }
}

