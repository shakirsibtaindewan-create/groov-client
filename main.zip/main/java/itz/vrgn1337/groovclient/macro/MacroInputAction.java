/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.macro;

public enum MacroInputAction {
    Attack, Use, Jump, Sneak, Drop, Sprint;

    private MacroInputAction() {

    }

}

