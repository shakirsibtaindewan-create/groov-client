/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.macro;

public enum MacroStepType {
    Swap, Wait, Press, Hold;

    private MacroStepType() {

    }

}

