/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.macro;

import itz.vrgn1337.groovclient.macro.MacroStep;
import java.util.ArrayList;
import java.util.List;

public class MacroProfile {
    private String a;
    private int b = -1;
    private final List<MacroStep> c = new ArrayList<>();

    public MacroProfile(String string) {
        this.a = string;
    }

    public String a() {
        return this.a;
    }

    public void a(String string) {
        this.a = string == null ? "" : string;
    }

    public int b() {
        return this.b;
    }

    public void a(int n) {
        this.b = n;
    }

    public List<MacroStep> c() {
        return this.c;
    }

    public void a(MacroStep macroStep) {
        if (macroStep != null) {
            this.c.add(macroStep);
        }
    }

    public void b(int n) {
        if (n >= 0 && n < this.c.size()) {
            this.c.remove(n);
        }
    }

    public void a(int n, int n2) {
        if (n < 0 || n >= this.c.size()) {
            return;
        }
        if (n2 < 0 || n2 >= this.c.size()) {
            return;
        }
        if (n == n2) {
            return;
        }
        MacroStep macroStep = (MacroStep)this.c.remove(n);
        this.c.add(n2, macroStep);
    }
}

