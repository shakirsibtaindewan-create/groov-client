/*
 * Decompiled with CFR 0.152.
 */
package itz.vrgn1337.groovclient.macro;

import itz.vrgn1337.groovclient.macro.MacroInputAction;
import itz.vrgn1337.groovclient.macro.MacroStepType;

public class MacroStep {
    private MacroStepType a;
    private int b;
    private int c;
    private MacroInputAction d;

    public MacroStep(MacroStepType macroStepType) {
        this.a = macroStepType;
        this.b = 0;
        this.c = 100;
        this.d = MacroInputAction.Use;
    }

    public MacroStepType a() {
        return this.a;
    }

    public int b() {
        return this.b;
    }

    public int c() {
        return this.c;
    }

    public MacroInputAction d() {
        return this.d;
    }

    public void a(MacroStepType macroStepType) {
        this.a = macroStepType;
    }

    public void a(int n) {
        this.b = Math.max(0, Math.min(8, n));
    }

    public void b(int n) {
        this.c = Math.max(0, Math.min(60000, n));
    }

    public void a(MacroInputAction macroInputAction) {
        this.d = macroInputAction;
    }

    public MacroStep e() {
        MacroStep macroStep = new MacroStep(this.a);
        macroStep.b = this.b;
        macroStep.c = this.c;
        macroStep.d = this.d;
        return macroStep;
    }
}

